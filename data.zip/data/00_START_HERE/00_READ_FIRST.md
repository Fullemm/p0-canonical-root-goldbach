---
name: 00_READ_FIRST
kind: orientation
layer: 0
audience: language-model
read_cost_tokens: ~1800
status: CURRENT
generated: false
---

# READ FIRST

You are looking at an AI-first knowledge base for one research programme:
an attempt at **binary Goldbach** through the *factorization graph* of an even
number `N`. This file tells you where to look. It does not contain mathematics.

## The one-paragraph summary of the mathematics

For even `N`, put an edge `p -> q` whenever `q | N-p`. A prime `p` is GOOD if
`N-p` is prime (a Goldbach representation) and BAD when the complement is composite; a complement of 1 is a separate unit boundary. Goldbach failure at `N` implies the existence of a nonempty closed BAD set.
The converse is false: such sets also occur when Goldbach holds. Such minimal closed sets are called **cores**. Exactly
six `N <= 10^4` are known to carry a core (`128, 1718, 1862, 1928, 2200, 6142`),
and all six of them *still satisfy Goldbach* — cores are a necessary, not
sufficient, obstruction. The programme's goal is to prove no core can exist for
the sub-class that a genuine Goldbach counterexample would require. See
`01_CURRENT_STATE.md`.

## The three layers (this is the architecture)

| Layer | Folder | What it is | Mutable? |
|---|---|---|---|
| **Raw** | `07_HISTORICAL_CORPUS/raw/` | All 84 original files, **byte-identical**, SHA-256 manifested | NO — immutable |
| **Working knowledge** | `01_`–`05_` | Selected results, explicit historical versions, concepts, proofs, artifacts and maintained frontier | maintained inputs plus generated views |
| **Indexes** | `06_INDEXES/` | Generated registries/cache alongside maintained `_curated` inputs and audit evidence | do not discard curated inputs |
| **Legacy output** | `08_HUMAN_OUTPUTS/` | Historical human snapshot, excluded from the current rebuild | not current authority |

The split exists to satisfy two demands at once. **Nothing is ever deleted** —
a refuted theorem stays recoverable in raw and in `06_INDEXES/supersession.jsonl`.
Confirmed errors are retired or scoped explicitly. Status and verification are
separate: the canonical layer includes killed and review-gated claims, and this
audit does not certify every historical proof.

See [AI_NAVIGATION_MAP.md](AI_NAVIGATION_MAP.md) for the maintained decision tree and ID resolver.

## Reading order, by what you are trying to do

| Your task | Read this, in this order | Budget |
|---|---|---|
| Understand the state and continue research | `01_CURRENT_STATE` → `02_NOTATION` → `03_CURRENT_FRONTIER` → `05_DO_NOT_RETRY` | ~9k tok |
| "Was this idea already tried?" | `06_INDEXES/killed_routes.jsonl`, then `06_INDEXES/aliases.jsonl`, then grep `07_HISTORICAL_CORPUS/extracted/biblia_semantic_index.md` | ~4k tok |
| "Is this actually new?" | `07_HISTORICAL_CORPUS/extracted/REDISCOVERY_FINDINGS.md` — verified collisions between the current runs and the Biblia | ~2k tok |
| "Find theorems about concept X" | `02_CANONICAL_CONCEPTS/<x>.md` → matched records; consult history for uncurated results | query-specific |
| "What is this theorem's current status?" | resolver → scoped statement, `status` AND `verification`, then source proof | query-specific |
| "Show me the counterexample" | `06_INDEXES/counterexamples.jsonl` → exact source; snippets may require scope and witness reconstruction from the supplied source | query-specific |
| "Recover the full proof" | structured metadata `proof_location` → canonical statement and source; proof extracts are aids | ~2k tok |
| "Check the computation" | structured metadata `computation` → `06_INDEXES/experiments.jsonl` → code/certificate | ~3k tok |
| "What depends on what" | `06_INDEXES/logical_dependencies.jsonl` (curated proof edges); `dependencies.jsonl` contains only citations | query-specific |

Use targeted reading. Exact source sizes and line counts are generated in
`06_INDEXES/inventory.json`; binary artifacts are excluded from text-line counts.
Layer 0 plus a handful of records is the intended working set. Reading budgets
above are estimates; the saved retrieval benchmark reports executed byte costs.

## Hard rules that govern this repository

1. **Losslessness.** `07_HISTORICAL_CORPUS/raw/` is append-only and byte-exact.
   Verify with `09_TOOLS/verify_manifest.py`. Never edit a file there.
2. **No reconstruction.** If a script is *mentioned* in a checkpoint but its file
   is not in the corpus, it is recorded in `06_INDEXES/missing_artifacts.md` as
   `MISSING ORIGINAL ARTIFACT`. Do **not** rewrite it from prose, pseudocode or
   reported output. A `VERIFIED COMPUTATION` claim does not imply a recoverable
   script.
3. **Status is not decoration.** `04_STATUS_DISCIPLINE.md` defines the vocabulary.
   `PROVED` records a proof claim with an explicit verification field; source labels
   alone do not certify that this audit checked the proof. Review gates are binding.
4. **Quantifier hostility.** Several past errors in this programme were silent
   quantifier changes (max-vs-min, "some cover" vs "every cover", missing
   `max S < N/3`). See `05_DO_NOT_RETRY.md` §C. Re-derive quantifiers; do not
   inherit them from a summary.
5. **Check for rediscovery before claiming novelty — and check against the
   corpus, not against the master.** Several novelty checks in runs J..R were made
   against `master_ai.tex`, which is a 29k-line summary; three results turned out
   to be present in the 50k-line Biblia anyway (`REDISCOVERY_FINDINGS.md`). The 50k-line *Biblia* and
   the 396k-line CRD layer already contain many mechanisms under older names.
   `06_INDEXES/aliases.jsonl` and `07_HISTORICAL_CORPUS/extracted/biblia_semantic_index.md`
   exist specifically for this. Run `01_CURRENT_STATE.md` → "Rediscovery
   protocol" before writing "new".

## What is *not* here

- No accepted proof of Goldbach. The programme is open. Contrary historical
  claims require source and scope review; not every archived claim is canonicalized.
- No reconstructed code. See rule 2.
- No editorial rewriting of the originals. The canonical layer *summarises and
  links*; the originals say what they say.

## Provenance convention

Every generated canonical record carries `sources:` with file and line pointers
into the raw layer; the resolver and structured metadata provide current provenance. `07_HISTORICAL_CORPUS/raw/MANIFEST.sha256` pins the bytes those line
numbers refer to. If a line number ever fails to resolve, the manifest is the
arbiter, not the record.
