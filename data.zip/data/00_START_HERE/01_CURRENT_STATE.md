---
name: 01_CURRENT_STATE
kind: state-of-the-programme
layer: 0
audience: language-model
read_cost_tokens: ~4200
status: CURRENT
as_of: 2026-09-09
binding_through: run S
generated: false
---

# CURRENT STATE OF THE PROGRAMME

## 0. Current source orientation

`ai_master_1_6.tex` is the newer reference snapshot integrating Q through R3
(chapter `ch:postQR`, lines 8134–8498). Its raw R3 appendix contains the cumulative
run R checkpoint. **Run S (2026-09-09) is newer than master 1.6 and is not merged
into either master snapshot.** Its current authority is the structured S records
and `07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt`.
The older `07_HISTORICAL_CORPUS/raw/root/master_ai.tex` is v1.5, binding only
through run P-R2. Consult the structured current records and their verification/
scope fields; no snapshot silently overrides a more precise source. Hashes and
roles are in `06_INDEXES/sources.jsonl`.

## 1. The object

Fix an even `N >= 6`. A prime `p` is **active** iff `p < N` and `p` does not
divide `N`. The **row** of `p` is the integer `N-p` with its factorization.
There is a directed edge `p -> q` iff `q | N-p`. `p` is **GOOD** iff `N-p` is
prime (i.e. `p + (N-p)` is a Goldbach representation), **BAD** iff the complement is composite; complement 1 is a separate unit boundary.
Traversal is **stopped**: a GOOD node is popped but never expanded, so a GOOD
child is an *escape edge*, not an enqueued vertex. If `N/2` is prime the
diagonal gives SUCCESS at depth 0.

Full notation, including every alias the corpus uses for these objects, is in
`02_NOTATION.md`.

## 2. The central reduction (this is what makes the programme finite)

Define the fixed-point filtration below `N/3`:

```
B_0     = { p < N/3 : p active, N-p composite }
B_{i+1} = { p in B_i : every prime factor of N-p lies in B_i }
B_N     = the fixed point;      R_N = product of q over q in B_N
```

**Failure criterion (composite complement domain).** `p_k` fails iff `PF(N-p_k) is a subset of B_N`, iff
`rad(m) | R_N` where `m = N - p_k`. This is the identity the programme runs on:
a purely local divisibility test against a single integer `R_N`.

**Cores.** The inclusion-minimal closed BAD sets are exactly the terminal
strongly connected components of the FULL factor graph consisting entirely of BAD vertices. Every core is strongly
connected, source-free, has `|S| >= 2`, and all its labels lie below `N/3`.

**Self-smooth representation (SSR).** `B_N` is nonempty iff there is a nonempty finite
set `S` of primes coprime to `N` with `max S < N/3` and `N - S` contained in
the multiplicative closure of `S`. Since `B_N` empty implies Goldbach(`N`),
**SSR-exclusion is strictly stronger than Goldbach.** Proving no core exists
for all `N` would prove Goldbach; the converse does not hold.

> **The load-bearing caveat, stated once and applying everywhere below.**
> Cores exist. All six known hosts *also satisfy Goldbach*. A core is a
> necessary condition extracted from the graph, not a Goldbach counterexample.
> A Goldbach conclusion needs a separate implication excluding every possible
> counterexample; excluding all cores is a sufficient but already false target.

## 3. The six known hosts (complete for the searched range)

Every core found in the corpus, with run R's independently recomputed audit.
`s = |S|`, `P = max S`, `parent` = the unique `r` with `P | N-r`, `d = E_P`,
`N-r = k*P^d`, `E_q = sum over p in S of v_q(N-p)`.

| N | basin | s=\|core\| | P | parent r | d | k | min Omega | sum E | sum(E-d) | max E |
|---|---|---|---|---|---|---|---|---|---|---|
| 128  | 10 | 8  | 41  | 5 | 1 | 3 | 2 | 20 | 12 | 7 |
| 1718 | 55 | 28 | 571 | 5 | 1 | 3 | 2 | 74 | 46 | 20 |
| 1862 | 55 | 21 | 619 | 5 | 1 | 3 | 2 | 61 | 40 | 25 |
| 1928 | 41 | 14 | 641 | 5 | 1 | 3 | 2 | 45 | 31 | 12 |
| 2200 | 2  | 2  | 13  | 3 | 3 | 1 | 3 | 10 | 4  | 7 |
| 6142 | 66 | 10 | 877 | 3 | 1 | 7 | 2 | 40 | 30 | 13 |

`N = 2200` is the **standing witness** that survives nearly every attack: its
core is `S = {3, 13}` with `N-3 = 13^3` and `N-13 = 3^7`. Among these six hosts it is the unique
pure-top-row host (`k = 1`), the unique `d >= 2` host, and the unique host with
no branching row at all. **If a proposed argument does not survive N = 2200,
it is dead.** Check it there first; it is two lines of arithmetic.

301 upper roots fail across the recorded census.

## 4. What is proved — by layer

### 4.1 Classification of small cores (runs J and P-R2)

- **2-core structural normal form is proved; global classification is OPEN.**
  For primes `p<q`, a two-core is exactly `N=p+q^b=q+p^c`, `2<=b<c`.
  `N=2200`, `{3,13}`, is the only known solution, not the only proved possible one.
  Run J reports a finite exhaustive box `p^m<=10^24` (which covers `N<=10^24`
  but may also contain hosts above that boundary; these domains are not equal).
  Biblia Iteration 27 already contains the normal form and reciprocity.
  Its elementary exclusions `c!=3`, `b=2 => c>=5`, and hence `p<N^(1/4)`
  have now been checked directly (see `ASTRA_MATH_AUDIT.md`, I27).
  The historical `10^27` / `10^36` censuses remain **HISTORICAL CLAIM / REQUIRES
  HUMAN REVIEW**: the original implementations and primality coverage have not
  been recovered or independently verified. Fixed-exponent finiteness does not
  imply a uniform classification over unbounded exponents.
- `P1` — 2-core bound `q2^2 <= N - q1`. **PROVED.**
- `P3` — three-core dichotomy. **PROVED**, domain: cores of size 3.
- `P8-R` — four-core dichotomy by partner. **PROVED** (branch (I) repaired to
  include pure rows with base `q3` or `q4`).
- `P4-R` — coprimality of exponents, with the full `gcd(b,c)` argument
  including the parity sub-case. **PROVED.** Parts (2a) and (2b) are the
  mechanism of Biblia Iteration 95 (line 25624), reached independently; the earlier RF-2 novelty claim for part
  (2c) is withdrawn: I95's size argument also applies to that pair under the
  small-parent hypothesis. P4-R supplies an explicit all-N proof. See `REDISCOVERY_FINDINGS.md`
  RF-2.

### 4.2 Normal forms and scope (run P-R2)

- `P2-R` — small/large normal form. **PROVED under the hypothesis `max S < N/3`.**
  The hypothesis is load-bearing: at `N = 128`, `S = core ∪ {53}` breaks it,
  because `128 - 53 = 75 = 3 * 5^2`.
- `P5-R` — cycle-cover scope plus the **product criterion**: if
  `prod(S) >= N^floor(s/2)` then *every* cover has a cycle of product `>= N`.
  This separates the four non-involutive cores from the two involutive ones by
  a proved criterion instead of enumeration.
- `P7-R` — **complementary** to K-SPARSE-ROW, not a strengthening. Reclassified.
- `E1-R` — re-scoped after the `N = 2200`, `S = {3, 13, 1471}` check (1471 is a
  source above `N/3`).
- `E5-R` — "no **NEW** host in the class"; the four hosts it reports are the
  known ones. The original phrasing contradicted its own output.

### 4.3 The reciprocal-forest layer (run Q — integrated in master 1.6)

- `Q-RECIPROCAL-FOREST-01`, `Q-RECIPROCAL-DEFECT-01` — defect
  `delta(F) = |V| - 2*nu(F)` of the reciprocal forest.
- `Q-UNIQUE-INVOLUTION-01`, `Q-TWO-CYCLE-TRANSFER-01`.
- `Q-PARITY-CYCLE-LOCK-01` — the cycle product `K_C` satisfies
  `K_C = 1 (mod 2N)` for even length and `K_C = N-1 (mod 2N)` for odd length.
- `Q-MINIMUM-CYCLE-DESCENT-01` — for a saturated odd cycle (`K_C=N-1`),
  the full cofactor `a_p=(N-p)/f(p)` divides `p-1`. Closure and an existing cover
  place its smaller prime factors in other cover components.
- `Q-CYCLE-COVER-ARITHMETIC-01`, `Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01`.
- `Q-SATURATED-ODD-CYCLE-WITNESS-01` — the explicit witness at `N = 100224`:
  the 3-cycle `1613 -> 3181 -> 1831 -> 1613` with `31 * 53 * 61 = 100223 = N-1`,
  which nonetheless has the GOOD escape `1613 -> 31`, `N - 31 = 100193` prime.
- `Q-SIX-HOST-AUDIT-01` — the six-host table with `edges(F)`, `nu(F)`, `delta`,
  cover counts.
- `Q-STRATEGIC-AUDIT-01` — **the rediscovery finding**, see §6.

### 4.4 The column-pressure layer (run R3 — integrated in master 1.6)

All results below assume `S` is source-free, active, closed and BAD; `P = max S`
has a unique internal parent `r`; `d = E_P`; `N - r = k*P^d`.

- `R-MAXIMUM-COLUMN-PRESSURE-01` — **PROVED, all N, all sizes.** `A > R^d`,
  equivalently `sum over q in S of (E_q - d)*log q > 0`. Some `q < P` has
  `E_q > d`. Uses the uniqueness of `P`'s parent and the gap `P^d - Q^d`.
- `R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01` — **PROVED.** No such set has all
  column totals equal; `E_P` cannot even be the largest column total. This is
  about *total valuations across rows*, not equal row lengths or degrees.
- `R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01` — **PROVED.** `Omega(N-p) >= d+1`
  for every `p != r` (and for `p = r` too when `k >= 3`); when `k = 1` the
  parent row is the *unique* minimum-`Omega` row. Hence
  `E_P <= min_p Omega(N-p)`, with equality exactly at a pure top row.
- `R-LINEAR-VALUATION-SURPLUS-01` — **PROVED.** `sum(E_q - d) >= s-1` if `k=1`,
  `>= s` if `k >= 3`; so `max_{q<P} E_q >= d+1` resp. `>= d+2`.
- `R-COLUMN-SPREAD-ONE-NORMAL-FORM-01` — **PROVED, NECESSARY ONLY.** Column
  range 0 is impossible; range 1 forces exactly: `d >= 2`, pure top row
  `N-r = P^d`, `E_q = d+1` for every `q < P`, `Omega(N-p) = d+1` for every
  `p != r`, `Omega(N-r) = d`. This is a normal form, **not an existence claim**;
  no known core has spread `<= 1`.
- `R-HOSTILE-COUNTEREXAMPLES-01` — **VERIFIED EXACT CERTIFICATES.** Three
  scope kills, two checked on real cores; the no-closure witness is a nonclosed set. See `05_DO_NOT_RETRY.md` §B.

### 4.5 Residue/matching closure (run S — newer than master 1.6)

Run S adds four scoped statements; none proves Goldbach or universal `p0` success.

- `S-CANONICAL-CRT-INJECTIVITY-01` — **PROVED-EXTERNAL.** For a failed
  canonical root and `N>=50`, reduction modulo `m=N-p0` is injective on the
  non-root reachable labels. Thus the canonical CRT state count has **no global
  collision-multiplicity loss**: `|A_m|=|R'|`. The primitive subgroup-product
  corollary still needs an upper bound strong enough to beat the required
  population. The only external input is Nagura's prime-interval theorem.
- `S-RESIDUE-QUOTIENT-ARITY-01` — **PROVED.** A load-one first-front prime
  defines an index `t_q` dividing `Omega(N-u)-1` for every non-root row, including
  the special `u=q` row. A semiprime non-root row forces all such indices to one.
- `S-RANGE-ONE-MATCHING-01` — **PROVED.** Any source-free closed BAD set with
  column spread at most one has a perfect matching/cycle cover; in fact every
  support edge extends to a cover. This closes Hall only in the spread-one branch.
- `S-ARITY-GCD-PURE-TOP-PRESSURE-01` — **PROVED.** The common arity gcd
  strengthens pure-top surplus pressure; spread one forces that gcd to one and
  therefore trivializes all load-one residue quotient indices in that branch.

Fresh finite checks supplied with S rerun successfully: 69 load-one RAL instances
on the six listed hosts, 120 synthetic regular matrices and 8 canonical injection
windows. These checks corroborate the scoped proofs; they are not an all-`N` census.

### 4.6 The p0 question (runs J and S)

Run J did not establish a special `p0` mechanism. Run S does establish one precise
canonical geometric advantage — injectivity modulo `m=N-p0` — but **does not turn
it into universal success**. In particular all relevant residue subgroups may still
be full and all quotient indices may equal one. Do not infer `p0` success from
canonical injectivity alone.

## 5. What is NOT proved

Binary Goldbach, universal root success, and host finiteness are all **OPEN**.
No result above eliminates cores; several explicitly coexist with them. The
current bottleneck is stated in `03_CURRENT_FRONTIER.md`: run R supplies a
*lower* bound on exponent surplus with **no uniform upper bound**, and `N = 2200`
shows the surplus can sit entirely in pure prime powers with no collisions at
all — so any argument that charges each surplus unit to a collision fails.

## 5.1 Historical visibility recovery (Biblia audit in progress)

The raw 50,085-line Biblia is byte-preserved but was not fully semantic-canonicalized. Staged anti-rediscovery recovery is active. **Lines 1–10000 are now agent-visibility-complete at the recovery standard:** 255 formal theorem-like objects plus 63 warnings/status/open/rejected/protocol objects are exposed (318 records total).

These records are **not automatic truth promotions**: theorem-like cards default to `HISTORICAL CLAIM / REQUIRES HUMAN REVIEW`, while warnings/open/rejected/experiment/protocol cards are `HISTORICAL CONTROL OBJECT`. Use them to prevent rediscovery and to compare scope; maintained canonical records still control current truth. See `00_START_HERE/06_HISTORICAL_COMPLETENESS_RECOVERY.md`.

## 6. Rediscovery protocol — run this before writing "new"

**Read `07_HISTORICAL_CORPUS/extracted/REDISCOVERY_FINDINGS.md` first** — it
records the audited I27/I28/I95/I151 relationships and the remaining unreviewed candidates.

Two systemic causes, both still live:

- **several novelty checks used `master_ai.tex` without the relevant full archival comparison.** The master is a 29k-line *summary*; the Biblia is 50k lines and the
  CRD layer 396k. Absence from the master is not absence from the corpus.
- **the Biblia is written in Polish** and numbers its results by iteration, not
  by stable ID, so there is no English identifier to grep for. Use
  `06_INDEXES/aliases.jsonl` and `07_HISTORICAL_CORPUS/extracted/glossary_pl_en.md`.

Run Q's strategic audit found that two mechanisms presented as new were already
in the *Biblia*:

- the **small/large decomposition** is substantially the "pierwiastkowy atraktor
  SCC" mechanism, *Biblia* Iteration 10, from line 6207: the least-factor map
  sends a terminal BAD SCC below `sqrt(N)`;
- **ordered parents** are *Biblia* Iteration 18, lines 10177–10268.

Other anchors the alias layer records: the two-cycle identity
`N = p + q + t*p*q` at `thm:gfg-two-cycle` (~line 1601); the Global Cycle
Product Lock, lines 1484–1530; `thm:atak5-g3` (~lines 5437–5460); closed-subcore
descent, killed ~line 49363.

Before claiming a mechanism is new:

1. grep `06_INDEXES/aliases.jsonl` for every synonym of your concept — the corpus
   calls the same object *SCC / core / terminal SCC / BAD basin / EAC*, and
   *matching / permutation / cycle cover / involution*, and
   *collision / parent / support / factor flow*;
2. read `07_HISTORICAL_CORPUS/extracted/biblia_semantic_index.md`;
3. check `06_INDEXES/killed_routes.jsonl` — it may not be new *and* not work.

The exact-column-product identity `A = prod q^{E_q}` is old (Biblia's global SCC
lock; Flow Factor Theory conservation). Run R correctly declines to claim it.

## 7. Source-metadata caution

`crd_theory_core(1).tex` **opens with a "Failure Log" title** that does not match
its contents. Use actual contents and stable result IDs, never the filename.
Similarly, `Flow Factor Theory(1).txt` is a Polish working transcript, not a
theory document; treat it as a session log.
