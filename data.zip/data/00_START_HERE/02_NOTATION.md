---
name: 02_NOTATION
kind: notation-and-aliases
layer: 0
audience: language-model
read_cost_tokens: ~2600
status: CURRENT
generated: false
---

# CANONICAL NOTATION, WITH THE CORPUS'S ALIASES

The corpus spans several eras (Biblia → CRD → Flow Factor → checkpoint runs
J..R) and **renames the same objects between eras**. The right-hand column is
the reason this file exists: it is how you avoid re-deriving an old theorem
because it was written in an older dialect.

## 1. Base objects

| Canonical | Meaning | Also written as |
|---|---|---|
| `N` | the even target, `N >= 6` | `2n`, `2x` |
| `x` | `N/2` | the midpoint, the diagonal |
| `A` (context: prime set) | active primes: `p` prime, `p < N`, `p` does not divide `N` | active labels, admissible primes |
| row of `p` | the integer `N-p` with its factorization | complement, partner value, `m` |
| `p -> q` | directed edge, `q \| N-p` | factor flow, support edge, parent relation |
| GOOD | `N-p` is prime | escape, success, hit |
| BAD | `N-p` composite | miss, blocked |
| escape edge | GOOD child of a popped node | exit, escape route |
| `PF(n)` | set of prime factors of `n` | support, `supp`, `omega`-set |
| `rad(n)` | product of distinct prime factors | radical, squarefree kernel |
| `Omega(n)` | prime factors **with multiplicity** | total degree, row degree |
| `omega(n)` | number of **distinct** prime factors | support size, branching |

> `Omega` vs `omega` is a recurring source of error. Run R's row-degree bound
> is about `Omega`. It does **not** give `omega >= 2`; `3^7` supplies degree 7
> with support 1. See `05_DO_NOT_RETRY.md` §B3.

## 2. The BAD filtration

| Canonical | Definition | Also written as |
|---|---|---|
| `B_0` | `{ p < N/3 : p active, N-p composite }` | initial BAD layer |
| `B_{i+1}` | `{ p in B_i : PF(N-p) is a subset of B_i }` | closure step, `Gamma`-step |
| `B_N` (= `B_low`) | the fixed point of that filtration | largest closed BAD set below `N/3`, BAD basin, EAC |
| `R_N` | `prod of q over q in B_N` | the basin radical, the blocking modulus |
| `Gamma_S` | multiplicative closure of the prime set `S` | `S`-smooth numbers, the `S`-monoid |
| core | inclusion-minimal closed BAD set | **terminal SCC**, minimal core, SCC, attractor, sink component |
| host | an `N` admitting a core | carrier, witness `N` |
| basin | all primes whose traversal is trapped in a core | catchment, closed BAD set |

**Alias warning.** "SCC" in the Biblia usually means what the checkpoints call a
**core** (a *terminal* SCC), not any strongly connected component. Biblia's
"pierwiastkowy atraktor SCC" = the root/least-factor attractor mechanism.

**Failure criterion (the identity everything runs on).**
For composite complements `m=N-p_k`, `p_k` fails ⟺ `PF(N-p_k) ⊆ B_N` ⟺ `rad(m) | R_N`, where `m = N - p_k`.

**Rank formula.** `k = pi(N-m) - pi((N/2)^-) - 1` indexes the upper root `p_k`
by its position above the midpoint. The special target of the programme is the
combination of this rank formula with `rad(m) | R_N`.

## 3. Self-smooth representation (SSR)

`B_N != empty` ⟺ there is a nonempty finite set `S` of primes coprime to `N` with
`max S < N/3` and `N - S ⊆ Gamma_S`.

`B_N = empty` ⟹ Goldbach(`N`). Hence **SSR-exclusion is strictly stronger than
Goldbach**: a proof of SSR-exclusion proves Goldbach, but Goldbach does not
give SSR-exclusion, and indeed six hosts satisfy Goldbach while carrying cores.

## 4. Column / valuation notation (run R)

For a source-free active closed BAD set `S`:

```
s   = |S|
P   = max S                        Q = max (S \ {P})
r   = the unique p in S with P | N-p        (uniqueness is a theorem)
d   = E_P
N-r = k * P^d,   k odd, P does not divide k     ("pure top row" iff k = 1)
E_q = sum over p in S of v_q(N-p)          (column total, WITH multiplicity)
R   = prod over q in S of q
A   = prod over p in S of (N-p)
```

Closure gives the exact identity `A = prod over q in S of q^{E_q}`. This
identity is **old** (Biblia global SCC lock; Flow Factor conservation) — do not
present it as new.

`h_q = max over p of v_q(N-p)` splits the surplus:
`sum(E_q - d) = sum(E_q - h_q) + sum(h_q - d)` — repeat use across rows, plus
pure prime powers. `E_q` is **not** support indegree; multiplicities count.

## 5. Matching / cycle notation (run Q and P-R2)

| Canonical | Meaning | Also written as |
|---|---|---|
| reciprocal forest `F` | the subgraph of mutual (2-cycle) relations | reciprocal graph, involution graph |
| `nu(F)` | maximum matching size | matching number |
| `delta(F)` | `\|V\| - 2*nu(F)` | defect, deficiency |
| cycle cover | a permutation of `S` along edges | matching, permutation, involutive cover (when all cycles have length 2) |
| `K_C` | product of full row cofactors `(N-p)/next(p)` along `C` | cycle product, cycle lock |
| parity cycle lock | `K_C = 1 (mod 2N)` for even length; `= N-1 (mod 2N)` for odd | global cycle product lock |
| `a_p` | full cofactor `(N-p)/f(p)`; `a_p \| p-1` only on saturated odd cycles | order, descent index |
| product criterion | `prod(S) >= N^{floor(s/2)}` ⟹ every cover has a cycle of product `>= N` | — |

Two-cycle identity: `N = p + q + t*p*q` (Biblia `thm:gfg-two-cycle`, ~line 1601).

## 6. Pillai equation (2-cores)

A 2-core `{q1, q2}` forces `q1^a - q1 = q2^b - q2`. The only solution in the
enumeration box is `3^7 - 3 = 13^3 - 13 = 2184`, giving `N = 2200`.

**Domain discipline:** the search is exhaustive over the box `p^m <= X` with
`X = 10^24`. This box covers every relevant `N<=X` because `p^m=N-q<X`, but can include
hosts above X. Quote the actual box and separately justify its coverage.

## 7. External machinery cited

Baker / **Matveev** linear forms in logarithms — Evertse's Leiden notes,
Theorem 5.4, citing Matveev, *Izv. Math.* **64** (2000), 1217–1269, with
`A(S) = 1.4 * 30^{s+3} * s^{9/2} * prod log q`. Used only where a result is
labelled `PROVED USING EXTERNAL THEOREM`; such results inherit that theorem's
hypotheses and must say so.

## 8. Notational traps recorded from actual errors

1. `max S < N/3` is a **hypothesis**, not a convention. Omitting it broke P2
   (`N = 128`, `S = core ∪ {53}`, `128-53 = 75 = 3*5^2`).
2. "every cover" vs "some cover": P5 was first computed by **maximising** over
   covers where the statement needed a **minimum**. `N = 6142` has a
   five-2-cycle involution with all products below `N`.
3. A pure row is any prime-power row. R's minimum-row conclusion requires
   purity at the **largest base of the whole closed set**, not an arbitrary pure row or largest parent (`N = 128`: `N-3 = 5^3` is pure but
   5 is not the largest label).
4. `p^m <= X` is not `N <= X` (§6).
5. A selected BAD path is not the complete BFS. Density-one is not every-`N`.

Full unsafe basin U(N) can include upstream labels above N/3; B_N is its lower part.
Core terminality is in the FULL graph, not merely its induced BAD subgraph.
Source-free means every label has an internal parent. These objects are related, not identical.
