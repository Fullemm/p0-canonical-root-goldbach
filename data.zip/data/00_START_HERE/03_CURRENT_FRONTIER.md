---
name: 03_CURRENT_FRONTIER
kind: open-problems
layer: 0
audience: language-model
read_cost_tokens: ~1900
status: CURRENT
as_of: 2026-09-09
binding_through: run S
generated: false
---

# THE CURRENT FRONTIER

Current through run S. Master 1.6 `sec:postQR-frontier` is a comparison snapshot
through Q–R3; S is newer and lives in the structured records plus its raw checkpoint.
Q absorption, R valuation capacity and S residue/matching constraints are related
open approaches, with no proved equivalence between their budgets.

## F1 — The missing uniform upper bound (the main bottleneck)

Run R proves a **lower** bound on exponent surplus:

```
sum over q in S of (E_q - d)  >=  s-1   (pure top row, k = 1)
                              >=  s     (k >= 3)
```

and on the logarithmic scale `sum (E_q - d) log q > s log 2` in the non-pure
case. There is **no uniform upper bound** on the same quantity. Decompose:

```
sum(E_q - d) = sum(E_q - h_q)  +  sum(h_q - d)
                 repeat use          pure powers
```

Either resource may be large. **`N = 2200` puts the entire surplus in pure
powers with no collisions at all** (`N-3 = 13^3`, `N-13 = 3^7`). Therefore:

> An argument that charges every surplus unit to a collision **fails**. This is
> not a gap to be patched; it is refuted by a real core.

**The open question, precisely:** bound both actual repeat valuations and high
pure powers *while preserving row identities*, or import information about
**all** prime roots that a genuine Goldbach failure supplies (as opposed to the
information a mere core supplies — the six hosts show these differ).

## F2 — The absorption problem (carried from run Q)

Transferring rooted absorption to an arbitrary core is **not** available; the
post-CRD failure log records why. `N = 2200` has no branching row at all, so any
mechanism requiring branching is empty exactly where the hard case lives.
Open: an absorption statement that survives support size 1.

## F3 — Host finiteness

Are there finitely many `N` with `B_N != empty`? Six are known below the
searched range. **OPEN.** Do not attempt to settle this by enlarging a scan;
see `05_DO_NOT_RETRY.md` §A1.

## F4 — Universal root success

Does every even `N` have some root `p_k` with `rad(N - p_k)` not dividing `R_N`?
This is equivalent to Goldbach in the relevant range. **OPEN.** The recorded
census has 301 failing upper roots — failing roots are common; what is needed
is that they never exhaust the range.

## F5 — The special target (from the original programme brief)

Combine the rank formula `k = pi(N-m) - pi((N/2)^-) - 1` with the failure
criterion `rad(m) | R_N`. The intent is a statement about the *position* of a
failing root, not merely its existence. **Not yet attempted in a way that
survives audit.** Any first-row law that depends only on `k`, or only on
`N - p_k`, is already known to be false — see `05_DO_NOT_RETRY.md` §A4.

## F6 — Column-spread-one existence

`R-COLUMN-SPREAD-ONE-NORMAL-FORM-01` gives an exact **necessary** form for cores
with column range `<= 1`: `d >= 2`, pure top row, `E_q = d+1` for all `q < P`,
`Omega(N-p) = d+1` for all `p != r`. Run S now proves that every such support has
a perfect matching/cycle cover and that every support edge extends to a cover; it
also forces the arity gcd to one. No known core has spread `<= 1`. **OPEN:** does
such an arithmetic core exist? Eliminating this class would be genuine progress,
but it remains only a sub-class of possible cores.

## Additional current branches (master 1.6 comparison)

- **F7 — complete-row cover structure:** common N and actual prime rows must
  supply information absent from Q's abstract support family. That family is
  not an arithmetic core.
- **F8 — arbitrary-size Hall defect outside spread one:** Q descent assumes a
  cycle cover. Matching is now proved at arbitrary size in S's column-spread-one
  branch, in addition to the earlier small-core cases. The unrestricted all-size
  no-cover branch remains open; R does not require a matching.
- **F9 — canonical residue capacity after injectivity:** S proves that global
  CRT states modulo `m=N-p0` are injective in a failed canonical world. The live
  target is therefore not collision multiplicity but a **strict joint restriction**
  on the actual groups `G_q` and the necessary residual population `|R'|`. All
  `G_q` may still be full and all quotient indices `t_q` may still equal one.

## What would count as real progress

A uniform arithmetic capacity theorem controlling both repeated valuations and
high single-row powers; a strict canonical residue-subgroup/population inequality
after S's injectivity theorem; or a theorem using the all-root information available
under genuine Goldbach failure. A claim must survive the existing six cores.
Universal elimination of all cores or all `d>=2` cores is false at N=2200 and
is not an attainable research target. Small-size extensions require a uniform
purpose beyond continuing a case-by-case ladder.

## What would not count

An enlarged census; a restatement of `A = prod q^{E_q}`; a bound that holds
only for `d = 1`; any statement whose quantifiers have not been re-derived.
