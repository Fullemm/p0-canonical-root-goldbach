# Status and verification discipline

Status classifies a claim; verification records who checked which evidence.
Neither a generated label nor a historical PROVED stamp certifies a proof.
`SOURCE-REPORTED-NOT-RECHECKED` requires proof inspection before use as a new premise.
`ASTRA-PROOF-CHECKED` is limited to the current scoped statement and this audit's report.
Finite code runs corroborate finite claims; they do not prove universal mathematics.

| Status | Meaning |
|---|---|
| PROVED | A stated proof with its exact hypotheses; check verification |
| PROVED WITH REPAIR | Current statement/proof carries an explicit correction |
| PROVED-EXTERNAL | Relies on a named external theorem and its hypotheses |
| VERIFIED COMPUTATION | Exact finite procedure, with domain and evidence links |
| VERIFIED EXACT CERTIFICATE | Specified hand-checkable arithmetic/finite witness |
| FINITE CENSUS | Exhaustive only over the stated finite domain and filters |
| CONJECTURE / OPEN | Unresolved proposition / research question |
| CONDITIONAL | Depends on an explicitly unproved hypothesis, not merely an ordinary domain assumption |
| EMPIRICAL | Observation or heuristic, not a general theorem |
| KILLED | A specific proposed inference or strengthening is refuted |
| SUPERSEDED | Historical version or retired ID; resolve its successor |
| HISTORICAL CLAIM | Source-reported assertion not promoted to current verified truth |
| REQUIRES HUMAN REVIEW | Evidence, parser interpretation or proof dependency unresolved |
| MIXED | Separate proved, computational or open components; read component scope |
| AUDITED ASSESSMENT | Evidence/strategy/scope assessment, not a mathematical theorem |

Unknown text does not become OPEN, and the word SCOPE does not become a computation.
Exact certificates are not unresolved conjectures. An all-N proof using a proved finite
parameter box remains an all-N computer-assisted theorem, with its computation linked.
Pending-audit flags remain visible. A true theorem with an explicit partner<N/3
hypothesis is not conditional on an unproved conjecture.

The maintained normalizer is `09_TOOLS/kb_status.py`; record-specific interpretations
live in `06_INDEXES/_curated/result_overlays.jsonl`. `status_raw` preserves historical
wording. `review_queue.jsonl` exposes verification and metadata debt. A null assumption
list means unknown, not no assumptions. No script may infer logical dependencies from
mere name occurrences: citations and proof edges are separate indexes.

Historical versions and killed routes remain recoverable. A later date alone is not
proof of strengthening. Version selection needs an explicit reason; repairs retain
the exact defect, source and witness. Test normalization and source consistency with
`python 09_TOOLS/validate_kb.py` after every rebuild.
