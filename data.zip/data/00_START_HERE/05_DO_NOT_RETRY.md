---
name: 05_DO_NOT_RETRY
kind: negative-knowledge
layer: 0
audience: language-model
read_cost_tokens: ~2800
status: CURRENT
as_of: 2026-09-08
generated: false
---

# DO NOT RETRY

Negative knowledge, with witnesses. Everything here was actually attempted and
actually failed; each entry says *why*, and where possible gives the exact
counterexample so you can refute a variant of your own idea in two lines.

**How to use this file:** before starting any line of attack, grep it for the
mechanism *and its aliases* (`02_NOTATION.md`). A route can be dead in a form
you would not recognise under the current dialect.

## A. Structurally exhausted search patterns

These are not "unlikely to work"; they are patterns that have been run to
exhaustion in this programme and produce no new information.

**A1. Enlarging a scan to enlarge a range.** Bigger `N`-scans of a bounded set
do not convert a bounded census into a theorem. Host finiteness (`F3`) will not
fall to a larger search. A search box is admissible only when a **theorem
produces it** — as the Pillai analysis produces `p^m <= X` for 2-cores.

**A2. Scans of exhausted `(k, m)` fibres.** Already complete. No new fibre data.

**A3. Fixed finite prime-label signatures.** Fixing a finite alphabet of prime
labels and classifying signatures over it. The alphabet does not move with `N`;
see A5.

**A4. First-row laws depending only on `k`, or only on `N - p_k`.** Refuted.
The failure of a root is a **joint** condition on `rad(m)` and `R_N`; neither
argument alone determines it. Any proposed "law of the first row" in one
variable is already known false.

**A5. Treating a fixed alphabet `S` as if it were a moving `B_N`.** `B_N`
depends on `N`. A theorem proved for a fixed `S` transfers to `B_N` only with a
uniformity argument, which has never been supplied. This is the single most
common way a false general claim has entered this corpus.

**A6. Arbitrary CRT programming of selected edges.** Choosing congruences to
manufacture desired edges. Produces configurations that are not closed, not
BAD, or not active. See B3 for what closure actually buys.

**A7. Confusing a selected BAD path with the complete BFS.** A path chosen to
look bad is not the traversal. The traversal is *stopped* (`02_NOTATION.md` §1),
and a single escape edge anywhere ends it.

**A8. Presenting density-one as every-`N`.** Density-one statements are already
available in the literature and do not touch the binary problem. Do not
re-derive one and present it as progress.

## B. Killed extensions, with exact witnesses

**B1. Iterating the column-pressure theorem at the newly found higher-exponent
prime. KILLED by a real core.**
`N = 2200`, core `S = {3, 13}`, `N-3 = 13^3`, `N-13 = 3^7`. Both primes have a
unique parent; `E_13 = 3`, `E_3 = 7`. `R-MAXIMUM-COLUMN-PRESSURE-01` holds with
`P = 13`, `d = 3`. Re-applying it with base 3 and `d = 7` would demand
`3^7 * 13^3 > (3*13)^7`, which is **false**; likewise that row has `Omega = 3`,
not `>= 8`. **The order geometry (largest prime) is essential and the theorem
does not bootstrap.**

**B2. Assuming an arbitrary pure row is the minimum-`Omega` row. KILLED.**
`N = 128`: the core contains `N-3 = 5^3` (`Omega = 3`) and `N-5 = 3*41`
(`Omega = 2`). The pure base 5 is **not** the largest core label. The theorem is
about a pure row at the **largest base of the whole closed set** — not at any
pure row, and not at the largest *parent*.

**B3. Dropping full closure from the row-degree theorem. KILLED.**
`N = 128`, `S = {5, 7, 11}`: active labels, composite rows, `P = 11` with unique
parent 7 and `N-7 = 11^2`. But `N-5 = 3*41` has only two prime factors, against
the would-be `>= 3`. The factor 41 **leaves** `S`. This is exactly why the
`Q^d` comparison needs closure, and it is not a core.

**B4. Replacing multiplicity by branching. KILLED.**
`Omega(N-p) >= d+1` does **not** imply `omega >= d+1` or even `omega >= 2`. A
pure power of a smaller prime supplies the whole degree, as `3^7` does at
`N = 2200`. Any strengthening to distinct factors erases precisely the
surviving case.

**B5. Charging every exponent-surplus unit to a collision. KILLED.**
`N = 2200` places the entire surplus in pure powers, with no collisions at all.
See `03_CURRENT_FRONTIER.md` F1.

**B6. Transferring rooted absorption to an arbitrary core. KILLED** by the
post-CRD failure log. `N = 2200` has no branching row, so branching-dependent
absorption is vacuous exactly on the hard case.

**B7. "Every core is involutive." REFUTED** by the product criterion
`P5-R(c)` at `N = 128, 1718, 1862, 1928`. Conversely `N = 6142` **is**
involutive: `{3,877},{5,17},{7,409},{13,227},{19,157}`, products
`2631, 85, 2863, 2951, 2983`, every one below `N = 6142`.

**B8. Closed-subcore descent. KILLED** in the Biblia, around line 49363.

**B9. Merely increasing a lower bound for an unbounded cofactor product.**
The post-CRD failure log explains why this is insufficient: the resource being
bounded from below is not the one that needs bounding from above.

## C. Recorded quantifier and scope errors (our own)

These were caught by hostile audit **after** being written down as results.
They are listed so the same shapes are recognised, not to relitigate them.

**C1. `P-FAIL-MAXMIN-OVER-COVERS-20260908P`** — P5(c) was computed by
**maximising** over cycle covers where the statement required a **minimum**.
Witness: `N = 6142`'s five-2-cycle involution, all products `< N` (B7).
*Shape to watch: "there is a cover with…" silently replacing "every cover has…".*

**C2. Missing hypothesis `max S < N/3` in P2.** Witness: `N = 128`,
`S = core ∪ {53} = {3,5,7,11,13,23,29,41,53}` is a closed BAD set with
`128 - 53 = 75 = 3*5^2`; `53 > N/3 = 42.67` so the small/large partition fails,
and `N - 53 = 75 < 2N/3 = 85.3` so clause (iii) fails as well.

**C3. Over-scoped E1.** Witness: `N = 2200`, `S = {3, 13, 1471}` with rows
`13^3`, `3^7`, `3^6`; 1471 is a **source above `N/3`**.

**C4. P1b's square window needs the partner below `N/3`.** Witness: `N = 128`,
`q = 103`, `128 - 103 = 25 = 5^2`, `S = {3,5,7,11,13,23,29,41,103}` closed BAD.
The base 5 satisfies P1b (`5 < sqrt(128) = 11.314`) but **fails the window**
(`5 < sqrt(2N/3) = 9.238`), because `103 > N/3 = 42.67` makes
`N - 103 = 25 < 2N/3 = 85.33`.

**C5. E5's conclusion contradicted its own output** — it reported hosts
128/1718/1862/2200 while claiming none exist. Corrected to "no **NEW** host in
the class". *Shape to watch: a summary line that does not match the table above it.*

**C6. P8 branch (I) omitted pure rows with base `q3` or `q4`.** Repaired in P8-R.

**C7. Root-list bug (run J).** `primerange(N//2, N)` filtered by `N % p`
excluded `p0 = 859` for `N = 1718` (the diagonal case, `N/2` prime), giving 4
"nontrivial" hosts instead of 3. Detected by comparing against the master's
EXP3. *Shape to watch: an activity filter silently deleting the diagonal.*

**C8. `purecore.c` `MAXW = 4096`** was an unproved completeness assumption:
closure overflow was silently treated as rejection. Repaired in `purecore2.c`
with `MAXW = 200000` plus explicit `closure-overflows` and `large-child-events`
counters; both zero at `X = 1e10`, output byte-identical. *Shape to watch: a
fixed workspace bound that turns "too big to check" into "rejected".*

## D. Things that are old, not new

Claiming any of these as new will be caught by the alias layer:

- the exact column-product identity `A = prod q^{E_q}` — Biblia global SCC lock;
  Flow Factor Theory conservation identities;
- the **small/large decomposition** — Biblia Iteration 10, "pierwiastkowy
  atraktor SCC", from line 6207;
- **ordered parents** — Biblia Iteration 18, lines 10177–10268;
- the two-cycle identity `N = p + q + t*p*q` — `thm:gfg-two-cycle`, ~line 1601;
- the Global Cycle Product Lock — lines 1484–1530.

## E. Non-mathematical rules for this repository

- Do not reconstruct a missing script from prose, pseudocode or reported output.
  Record it in `06_INDEXES/missing_artifacts.md` and move on.
- Do not rewrite the master or any raw file. The canonical layer is where
  current knowledge lives.
- Do not claim priority or novelty against the outside literature without an
  actual check; the corpus's own `SOURCE CLAIM: NEW-PROVED` labels are claims,
  not verdicts (`04_STATUS_DISCIPLINE.md` §5).
