# Literature and source ledger

Before launching a new literature search or claiming that an external theorem is a new bridge for this project, query the recovered literature layer.

- Bibliography: `06_INDEXES/BIBLIOGRAPHY_INDEX.jsonl` (92 entries).
- Literature/use/no-go intelligence: `06_INDEXES/LITERATURE_INTELLIGENCE.jsonl` (101 records).
- Citation locations: `06_INDEXES/BIBLIOGRAPHY_USAGE_INDEX.jsonl`.
- Exact source cards: `07_HISTORICAL_CORPUS/extracted/literature_intelligence/`.

The crucial distinction is **source result vs what the project takes vs what the source does not provide**. A bibliographic citation alone is never a truth promotion.

Use:
```bash
python 09_TOOLS/kb_query.py literature "<tool / theorem / author / obstacle>"
```
