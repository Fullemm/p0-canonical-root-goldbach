# AI navigation map

This repository studies Goldbach through prime factor graphs. Goldbach and universal p0 success remain unproved. Use this page without conversation context. Paths below are relative to `struktura/`.

## Minimum startup

Read this page, `00_START_HERE/01_CURRENT_STATE.md`, and `02_NOTATION.md` in that directory. Before research, also read `03_CURRENT_FRONTIER.md` and `05_DO_NOT_RETRY.md`. Read `04_STATUS_DISCIPLINE.md` before using any result as a premise. Exact inventory and context costs are measured in the ASTRA reports, not guessed from old counts.

Current truth is a canonical record WITH its structured overlay and verification field. `ai_master_1_6.tex` is a preserved Q–R3 snapshot; run S is newer and is represented by its structured records and raw checkpoint. Archived `master_ai.tex` is v1.5 through P-R2. No master automatically overrides a proof, a repair or a counterexample.

## Decision tree

| Need | First operation | Then open |
|---|---|---|
| Current strongest state | Read `01_CURRENT_STATE.md` | Relevant current records and `03_CURRENT_FRONTIER.md` |
| New idea / effect without an ID | `python 09_TOOLS/kb_query.py search "your terms"` | Top results; check scope, non-implications and proof verification |
| Different terminology | Search `06_INDEXES/aliases.jsonl` or a concept page | Read warnings: search terms are not assertions of equivalence |
| Old theorem ID or shortened name | `python 09_TOOLS/kb_query.py resolve OLD-ID` | Resolved current object; explicit old version remains linked |
| Stronger or repaired version | Resolver, then `supersession.jsonl` | Successor proof and reason/witness; chronology alone is not evidence |
| Verify a proof | `structured_results.jsonl`: scope, assumptions, proof_location | Exact raw passage and `logical_dependencies.jsonl`; generated proof extracts are reading aids |
| Find a counterexample | Search `counterexamples.jsonl`, `killed_routes.jsonl`, `05_DO_NOT_RETRY.md` | Exact witness and precisely which strengthening it kills |
| Computational evidence | `experiments.jsonl` and record `computation` | Exact domain, code, certificate, original checkpoint; finite means finite |
| Missing original code | `missing_original_artifacts.jsonl`, then `embedded_sources.jsonl` | Source reference, surviving output, reproducibility impact; do not reconstruct |
| Old mechanism / anti-rediscovery | `06_HISTORICAL_COMPLETENESS_RECOVERY.md`, `REDISCOVERY_FINDINGS.md`, then `kb_query.py history "terms"` | Recovery theorem/control card or exact source range; historical presence is not current proof status |
| Unmapped old ID | `06_INDEXES/_extract/id_references.jsonl` and `archive_objects.jsonl` | Historical source only; a raw PROVED label is not canonical approval |
| Continue from an open branch | `03_CURRENT_FRONTIER.md`, `05_FRONTIER/` | Q cover/no-cover distinction, R capacity wall, S residue/matching branch, existing killed extensions |

The search command returns candidates, not answers or proofs. If the top results miss a needed hypothesis, broaden terms or use historical search. Failed discovery does not establish novelty.

## Important distinctions before using search results

- A BAD core may coexist with Goldbach; all six known hosts do. Full closure includes EVERY factor. An induced BAD SCC can conceal GOOD escape edges.
- A closed set, its full unsafe basin and a minimal core are different objects. Source-free means every label has an internal parent; it is not a synonym for closed.
- A bipartite perfect matching gives a directed cycle cover; an involution is the special all-2-cycle cover. General cover existence is not proved at arbitrary core size.
- Omega counts factors with multiplicity; omega counts distinct factors. R constrains Omega. A pure row can have large Omega and support one.
- R uses the largest LABEL, not the largest exponent or the largest factor chosen anew in each row. Iteration 28 contains its unique-parent precursor; Iteration 151 studies selected trajectories.
- Q saturated-cycle descent assumes a cover and full closure. Its many-to-one absorption capacity is open. R gives a lower surplus, with no contradictory uniform upper bound.
- Two-core Pillai normal form and I27's fourth-root bound are proved; global uniqueness of N=2200 is not. Historical larger scans require review.
- The failure criterion is for composite root complements. Unit rows and the prime diagonal have separate behavior. Evidence for p0 is limited; an unexplained pattern is not a theorem or a refutation.

## Source and identity contracts

`results.jsonl` has one selected object per maintained logical ID, including explicit retired-ID redirects. `result_versions.jsonl` holds historical versions. Old physical paths stay readable, with version-qualified IDs and historical warnings. `logical_id_resolver.jsonl` is the lookup authority for stable IDs, abbreviations and explicit versions.

Use `result_summaries.jsonl` for cheap discovery; open `structured_results.jsonl` only for matching records. Null metadata means not yet curated, not “no assumptions”. `dependencies.jsonl` contains textual citations ONLY; `logical_dependencies.jsonl` contains explicitly curated proof edges.

`07_HISTORICAL_CORPUS/raw/MANIFEST.sha256`, `06_INDEXES/_curated/astra_baseline.json` and `sources.jsonl` anchor provenance. Current verification coverage and unresolved historical claims are in `review_queue.jsonl`, `ASTRA_MATH_AUDIT.md` and `ASTRA_COMPLETENESS_AUDIT.md`.

## Incremental maintenance

Add original evidence without altering existing raw files and append its checksum to the manifest after verifying bytes. Add the theorem/counterexample/experiment metadata to maintained inputs under `06_INDEXES/_curated/`. An existing ID with competing versions requires an explicit `version_selection.json` choice and reason. Run `python 09_TOOLS/rebuild_kb.py --full` for new sources; use `rebuild_kb.py` for overlay-only changes. Run `benchmark_kb.py` for retrieval changes. The build never creates TeX/PDF.

Do not edit generated records directly: their inputs are preserved overlays plus exact source slices. New input formats must be explicitly imported or supported by the extractor; verify that every intended result was discovered. Unrelated concept pages, resolver, counts and search cache are generated automatically.


## Literature / external-theorem novelty checks

Before repeating a literature search, read `00_START_HERE/07_LITERATURE_AND_SOURCE_LEDGER.md` or run `python 09_TOOLS/kb_query.py literature "..."`. The layer preserves what a source proved, what the project used, and what the source explicitly did **not** provide.
