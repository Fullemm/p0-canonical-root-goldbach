---
id: ALL-UPPER-ROOT
logical_id: ALL-UPPER-ROOT
version_id: ALL-UPPER-ROOT@E
kind: canonical-result
run: E
title: "NEW EXACT RESULT:"
status: PROVED
status_raw: "PROVED (elementary generalization of existing canonical fixed-point theorem)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/source_rank_spectrum_checkpoint_2026-09-07E.txt", line: 4, line_end: 119}
metadata: {"stable_id": "ALL-UPPER-ROOT", "version_id": "ALL-UPPER-ROOT@E", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/source_rank_spectrum_checkpoint_2026-09-07E.txt", "line": 4, "line_end": 119}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/source_rank_spectrum_checkpoint_2026-09-07E.txt", "line": 4, "line_end": 119}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# NEW EXACT RESULT:

*Run E - status `PROVED` (raw: `PROVED (elementary generalization of existing canonical fixed-point theorem).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
1. NEW EXACT RESULT: ALL-UPPER-ROOT FIXED POINT
For even N and any upper prime root r>=N/2 with composite complement m=N-r>1,
    r fails  <=>  PF(N-r) subset B_N,
where B_N is the largest active closed BAD set below N/3 from the existing CRD fixed-point filtration.
Reason: every factor of an odd composite row N-p has cofactor >=3, hence every child is <N/3; failure therefore yields a closed BAD low set. Converse is closure.
STATUS: PROVED (elementary generalization of existing canonical fixed-point theorem).

2. EXACT RANK FAILURE FORMULA
Put x=N/2 and pi(x^-) = number of primes strictly below x. If m=N-p_k, then
    k = pi(N-m)-pi(x^-)-1.
On the composite-complement domain,
    p_k fails <=> rad(m) | R_N,
where R_N = product_{q in B_N} q.
Thus the composite failure-rank spectrum is exactly the prime-counting image of B_N-smooth prime-backed mirrors.

3. NEW EXACT RESULT: RAMANUJAN UNIT-ROW OBSTRUCTION
Let R_n be the nth Ramanujan prime. Standard Ramanujan-prime fact: R_n is prime and
    pi(R_n)-pi(R_n/2)=n.
For every fixed k>=1 set P=R_{k+1} and N=P+1. Then N is even and exactly k+1 primes lie in (P/2,P], equivalently in [N/2,N). Therefore
    p_k(N)=P=N-1,
so N-p_k=1: a degenerate unit-row failure.
Hence NO fixed noncanonical rank k>=1 can be universally successful for the raw algorithm.
By Bertrand, p0 can never be N-1: for P=N-1>=5 prime, Bertrand applied to (P-1)/2 gives an earlier prime in [N/2,P); N=4 is direct. Thus p0 is the unique fixed rank not forced to have a unit-row failure.
STATUS: PROVED using standard Ramanujan-prime theorem / Bertrand. Application novelty not audited.

Guaranteed Ramanujan witnesses for the composite-safe candidates:
 k=10: R_11=101, N=102
 k=14: R_15=151, N=152
 k=26: R_27=307, N=308
 k=28: R_29=347, N=348
 k=30: R_31=367, N=368
 k=62: R_63=823, N=824
 k=63: R_64=827, N=828
 k=71: R_72=983, N=984
 k=74: R_75=1021, N=1022
The exact scan also found additional unit rows for some ranks.

4. FULL FIFO STRESS SCAN -- ALL EVEN N<=10^7
Implementation: exact linear SPF sieve, full distinct-factor FIFO BFS, duplicate suppression, inclusive W, no depth/work cutoff, no probable-prime tests. Unit rows excluded from the composite-failure count and counted separately. Regression: k=0 reproduces published p0 statistics exactly: mean W=7.052697211, max W=151 at N=3542948, max depth=10 at N=11822.

rank  eligible   composite  unit  composite_fail  meanW       maxW@N       maxDepth@N
0     4999999    4016277    0     0               7.052697211 151@3542948  10@11822
10    4999949    4305357    1     0               7.667464808 138@8708888  8@4298
14    4999925    4303563    2     0               7.668315425 157@8765846  9@2214218
20    4999884    4303761    2     1               7.670092946 175@8817218  9@1928
26    4999855    4303279    2     0               7.669350611 155@6435428  9@7202
28    4999835    4303232    5     0               7.668785470 163@9751754  9@11420
30    4999819    4302484    3     0               7.665228081 152@7644278  10@44246
62    4999588    4302844    1     0               7.669281949 160@7713518  9@1928
63    4999586    4302932    1     0               7.661838000 149@4531018  9@11822
71    4999511    4301412    3     0               7.662366579 159@9534652  8@14198
74    4999489    4302377    1     0               7.665502814 146@9751304  9@11822

Interpretation: all nine noncanonical candidate ranks retain ZERO nondegenerate/composite failures through 10^7, but they are not easier than p0. Their mean work is higher (~7.66-7.67 vs 7.05), and several have max work exceeding the canonical record 151 in this same range. Rank 30 attains depth 10.
Control k=20 has the known genuine composite failure at N=1862.

5. FULL-WORLD / ESCAPE-MARGIN STRESS -- ALL EVEN N<=10^6
Root-generic analogue of the project's escape margin G_esc: expand the entire reachable BAD world and count all GOOD child edges. Failure iff G_esc=0; G_esc=1 is graph-theoretically one escape edge away from closure.
Every one of k=10,14,26,28,30,62,63,71,74 has MANY G_esc=1 cases despite zero composite failures.
Largest observed one-escape worlds among these ranks:
 k10:  world 34 at N=2078, r=1103
 k14:  world 34 at N=2078, r=1129
 k26:  world 66 at N=14198, r=7349
 k28:  world 65 at N=44246, r=22409
 k30:  world 65 at N=44246, r=22441
 k62:  world 65 at N=44246, r=22741
 k63:  world 64 at N=14198, r=7673
 k71:  world 71 at N=14198, r=7727
 k74:  world 65 at N=44246, r=22871

Exact sole escape edges:
 N=2078: for k=10,14,26,28,30,62,63 the sole escape is 179 -> 211, because 2078-211=1867 prime.
 N=14198: for k=26,63,71 (and several others, including p0 in its own world) the sole escape is 71 -> 277, because 14198-277=13921 prime.
 N=44246: for k=28,30,62,74 (also k26 and control k20) the sole escape is 9941 -> 2287, because 44246-2287=41959 prime.
At N=44246, k=30 succeeds only at depth 10 with W=64 despite having exactly one escape edge in a 65-vertex BAD world.

MULTI-RANK NEAR-FAILURE SEARCH, N<=10^6:
Maximum number of the nine candidate ranks simultaneously having G_esc=1 is 7.
 N=2078: k=10,14,26,28,30,62,63 all have the SAME sole escape 179->211.
 N=1718: seven candidate ranks have G_esc=1 (with several different sole edges).
Thus zero-failure ranks are not separated from failure by a large margin; several can sit on the same one-edge bottleneck.

6. HARD-P0 INPUT CROSS-STRESS
Selected examples:
 N=11822 (canonical depth record 10): k26 depth9 W62; k63 depth9 W58; k74 depth9 W57.
 N=976904 (old canonical work record 133): k62 depth7 W104; k63 depth7 W96; k28 depth7 W74.
 N=3542948 (canonical W=151 record): k14 depth7 W127; k26 depth7 W130; k10 depth6 W94.
No candidate failure is produced; several remain comparably hard.

7. SAFE-RANK SPECTRUM ON THE SIX KNOWN EAC HOSTS
Using the six historical hosts 128,1718,1862,1928,2200,6142 and exact basin membership, for ranks 0<=k<=118 the composite-failure-free indices (on every host where the rank exists) are exactly
    {0,10,14,26,28,30,62,63,71,74}.
There is no exact periodicity of this finite safe/fail indicator with period m<=60.
The neighbors of the safe indices frequently fail, e.g. k9 and k11 around k10; k13 and k15 around k14; k25/k27 around k26. This looks like irregular holes in shifted-smooth mirror spectra, not a congruence class in k.

Important finite-range caveat: for large k some small EAC hosts do not even possess p_k below N, so finite-X 'zero failure' becomes increasingly vacuous. The common full six-host rank range is only k=0,...,12; in that range the only composite-safe indices are 0 and 10. Among the five larger hosts the common range extends to k=118.

8. EXACT GENERAL FORM OF THE RANK SPECTRUM
For N=2x, define
 M_fail(N) = {m: 1<m<x, N-m prime, rad(m)|R_N},
where R_N=product_{q in B_N}q.
Then
 F_comp(N) = { pi(N-m)-pi(x^-)-1 : m in M_fail(N) }.
The raw failure set adds the unit term m=1 when N-1 is prime.
Thus a fixed rank k is nondegenerately safe for every N iff k never occurs in the prime-counting image of a B_N-smooth prime-backed mirror over all N.
No simpler rank-only formula is presently known.

9. CURRENT INTERPRETATION / FRONTIER
- Strict raw universality: every k>=1 is KILLED by the Ramanujan unit-row theorem. Only k=0 can even be a universal-success candidate.
- Composite-only universality H_k*: still open for k=0 and for the finite-survivor noncanonical ranks; k=20 is refuted at N=1862.
- Stress data strongly argues that k=10 etc are not protected by a large escape margin or easy traversal; they can be one edge from failure and as hard as p0.
- Best structural object remains the shifted-smooth mirror / basin rank spectrum, not k modulo a fixed integer.
- Next serious proof target: simultaneous B_N-smooth mirrors at small prime-root gaps (S-unit spacing / support-overlap constraints), or a construction showing some currently composite-safe fixed k eventually hits a genuine EAC basin.

END CHECKPOINT
```
