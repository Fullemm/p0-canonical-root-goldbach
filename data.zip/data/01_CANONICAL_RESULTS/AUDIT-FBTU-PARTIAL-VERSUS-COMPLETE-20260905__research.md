---
id: AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905
logical_id: AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905
version_id: AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905@research
kind: canonical-result
run: research
title: "FAIL-"
status: REQUIRES HUMAN REVIEW
status_raw: "SCOPE-CORRECTED; the blanket bounded-depth BFS no-go is NOT ESTABLISHED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 66, line_end: 104}
metadata: {"stable_id": "AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905", "version_id": "AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905@research", "status": "REQUIRES HUMAN REVIEW", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 66, "line_end": 104}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 66, "line_end": 104}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `REQUIRES HUMAN REVIEW` (raw: `SCOPE-CORRECTED; the blanket bounded-depth BFS no-go is NOT ESTABLISHED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905
STATUS: SCOPE-CORRECTED; the blanket bounded-depth BFS no-go is NOT ESTABLISHED
by the supplied CRT argument. This is not a proof of a bounded-depth closer.
CLAIM / ROUTE:
Master theorem FBTU and its following finite-local wall (around lines
4320–4333), citing the post-CRD dossier, use programming of finite BAD
subtrees to rule out bounded-depth failure-dynamics arguments.
The dossier explicitly calls the object a BAD-subtree. It supplies no proof
that every unspecified prime factor of every expanded row is also BAD.
The p0 dossier marks the imported claims PENDING INDEPENDENT AUDIT.
EXACT FAILURE:
Prescribed divisibilities force selected edges, not an entire factor row.
A factor not named in a CRT transcript may be a GOOD child. A selected BAD
path or BAD cycle is an existential statement. Failure of the full BFS
through depth d is a universal statement about ALL reachable vertices at
depths <=d. CRT compatibility alone does not justify that quantifier change.
COUNTEREXAMPLE / OBSTRUCTION:
N=92, canonical P=47, h=1 (46 composite, 47 prime).
92-47=45=3^2*5; 92-3=89 is prime.
92-5=87=3*29; 92-29=63=3^2*7; 92-7=85=5*17.
Thus 47->5->29->7 is a selected all-BAD path and 5->29->7->5
is an all-BAD cycle, while the complete canonical traversal succeeds at
depth 1 via 3. Arbitrarily long BAD walks can be unrolled in this one world;
they do not give arbitrarily large shortest GOOD depth.
This example refutes the implication from a selected BAD transcript to a
full BAD traversal, not the existence of prescribed partial trees.
WHAT SURVIVES:
The finite congruence/valuation programming theorem with its actual
compatibility hypothesis. The historical FAIL-P0-FINITE-VALUATION-SIGNATURE
and reflection obstruction survive on those restricted domains.
DO NOT REPEAT:
Do not use FAIL-P0-FINITE-BAD-TRAVERSAL or the master finite-local wall to
claim that ALL complete finite BFS neighbourhoods can be reproduced by CRT.
Do not reverse this correction into a claimed p0 proof or into a claim that
arbitrarily deep complete BAD neighbourhoods do not exist.
POSSIBLE REPLACEMENT:
An exact theorem about complete neighbourhoods, controlling the residual
cofactors, or a correctly restricted theorem about selected edges only.
```
