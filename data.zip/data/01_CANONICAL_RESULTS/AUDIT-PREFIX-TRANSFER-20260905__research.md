---
id: AUDIT-PREFIX-TRANSFER-20260905
logical_id: AUDIT-PREFIX-TRANSFER-20260905
version_id: AUDIT-PREFIX-TRANSFER-20260905@research
kind: canonical-result
run: research
title: "Audit prefix transfer"
status: PROVED
status_raw: "PROVED (independent proof audit of the supplied checkpoint, not a new claim)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 13, line_end: 65}
metadata: {"stable_id": "AUDIT-PREFIX-TRANSFER-20260905", "version_id": "AUDIT-PREFIX-TRANSFER-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 13, "line_end": 65}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 13, "line_end": 65}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Audit prefix transfer

*Run research - status `PROVED` (raw: `PROVED (independent proof audit of the supplied checkpoint, not a new claim).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: AUDIT-PREFIX-TRANSFER-20260905
STATUS: PROVED (independent proof audit of the supplied checkpoint, not a new claim).
EXACT STATEMENT:
Let 3=P_0<P_1<... be the odd primes, X>=4 an integer, I the first index
with P_I>=X, K>=0 an integer, b_j=(P_j-1)/2, L=b_(I+K).
For x>=4 let i satisfy P_(i-1)<x<=P_i, p_k(2x)=P_(i+k),
m_k(2x)=2x-p_k(2x). For any E of positive odd integers <=X, B=|E|,
T=sum_(x=4..X) sum_(k=0..K) 1_E(m_k(2x)) satisfies
T<=6(K+1) B (1+log^+(L/B)) when B>0, and T=0 when B=0.
HYPOTHESES: No failure hypothesis; E may depend on X and K. Nonpositive
complements do not belong to E. The claim counts incidences, not just inputs.
PROOF:
Fix selected endpoint j. The disjoint source cells for ranks 0..K unite,
after restricting to x>=4, into the portion of
P_max(0,j-K-1)<x<=P_j that actually occurs. Dropping x<=X enlarges it.
In output coordinate t=(m-1)/2 the containing interval is
J_j=(2a_j-b_j,b_j] intersect Z, a_j=b_max(0,j-K-1).
Its core C_j=(a_j,b_j] has |J_j|=2|C_j|. Zero-length cores are absent.
Each integer belongs to at most K+1 cores, since the cores are unions of
at most K+1 consecutive disjoint elementary gaps (b_(i-1),b_i]. All are
inside {1,...,L}. With A={(m-1)/2:m in E}, use the uncentred integer-interval
maximal function M_A(t)=sup_(J containing t) |A intersect J|/|J|.
A longest-first disjoint selection of witnessing intervals for M_A>u,
0<u<=1, covers their union after tripling the retained intervals. Integer
intervals of cardinality n can be tripled to cardinality 3n-2; hence
|{M_A>u}|<=3B/u. Only finitely many witnessing intervals exist: their
length is <B/u and each intersects the finite A.
Layer cake gives, on any set U of cardinality at most L,
sum_U M_A <= integral_0^1 min(L,3B/u)du
<=3B(1+log^+(L/B)).
For every t in C_j, |A intersect J_j|<=2|C_j|M_A(t).
Average over C_j, sum j, and use core multiplicity K+1. This proves T.
HOSTILE CHECK:
The source cell is closed at its upper endpoint, so x prime is included.
Endpoint j=0 never occurs for x>=4. Initial cells are truncated using P_0=3.
Truncating the last cell and excluding nonpositive complements only decrease T.
Grouping by endpoint is essential: summing separate k bounds would lose
another K+1. No prime-gap distribution enters the finite inequality.
DEPENDENCIES: Elementary maximal-interval covering only.
IMPLICATION:
The supplied density-zero transfer, fixed-rank normal-order deduction, and
growing direct-prefix no-go follow, subject to their stated standard
number-theoretic inputs. The squarefree-density proof also needs finite
residue equidistribution; density-zero transfer alone is insufficient.
RELATION TO GOLDBACH: No positive representation count. No inference about
factorization-graph traversal from the direct-prefix failure estimate.
RELATION TO p0 EXCEPTIONALITY: Shared by all fixed nearby roots.
WHAT REMAINS OPEN: Nonlocal rooted reachability and every-point positivity.

AUDIT NOTE: The supplied Scott–Bozek branch is not used as a classification.
No conclusion about its completeness is promoted without rechecking primary
sources. The global/rooted failure distinction is maintained throughout.
```
