---
id: AUDIT-RADIUS-TWO-INPUT-20260906B
logical_id: AUDIT-RADIUS-TWO-INPUT-20260906B
version_id: AUDIT-RADIUS-TWO-INPUT-20260906B@research
kind: canonical-result
run: research
title: "Audit radius two input"
status: PROVED
status_raw: "AUDITED; previous theorem retained as PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3376, line_end: 3395}
metadata: {"stable_id": "AUDIT-RADIUS-TWO-INPUT-20260906B", "version_id": "AUDIT-RADIUS-TWO-INPUT-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3376, "line_end": 3395}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3376, "line_end": 3395}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Audit radius two input

*Run research - status `PROVED` (raw: `AUDITED; previous theorem retained as PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: AUDIT-RADIUS-TWO-INPUT-20260906B
STATUS: AUDITED; previous theorem retained as PROVED.
The four parametrizations in COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS were
rechecked directly. The first and second cofactors are odd and >=3;
q!=r follows from activity; after removing the first-factor band each
fixed-parameter product is <=8X^(1-eta). Prime values exceed their
corresponding positive leading coefficients for sufficiently large X,
including eta=((loglog X)^3/log X)^(1/5). Therefore discarded
imprimitive forms truly have no actual prime solutions. The six CC
determinants agree with the written formulas. No fixed-depth/global-
failure scope change is needed.
The exact FKL Lemma 5.1 was reopened in the primary author paper,
https://arxiv.org/pdf/0904.0473, printed pp.12--13. Its rank/size
hypotheses and explicit B term also permit FIVE fixed linear forms;
no new external theorem is required for that extension.
The potential new obstacle at later roots is real: the equations now
contain 2h rather than 2, so gcd(b,2a-1) can be a nontrivial divisor
of h. The following lemma controls its total contribution instead of
assuming it away.
```
