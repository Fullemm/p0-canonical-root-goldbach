---
id: AUTO-ACTIVITY-20260907J
logical_id: AUTO-ACTIVITY-20260907J
version_id: AUTO-ACTIVITY-20260907J@J
kind: canonical-result
run: J
title: "Auto activity"
status: PROVED
status_raw: "PROVED  (also SCOPE-CORRECTION)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 129, line_end: 152}
metadata: {"stable_id": "AUTO-ACTIVITY-20260907J", "version_id": "AUTO-ACTIVITY-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 129, "line_end": 152}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 129, "line_end": 152}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1083, style: ID-TABLE}
---

# Auto activity

*Run J - status `PROVED` (raw: `PROVED  (also SCOPE-CORRECTION)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T1.  AUTO-ACTIVITY-20260907J          STATUS: PROVED  (also SCOPE-CORRECTION)
--------------------------------------------------------------------------------
STATEMENT.  Let p be active (p prime, p < N, p !| N) and let q be any prime
factor of N-p.  Then q is active, and q != p.  Consequently
        Gamma_N(p) = PF(N-p)   exactly,
and p is never its own child (no loops).

PROOF.  q | N-p and q < N-p < N.  If q | N then q | (N)-(N-p) = p, so q = p as
both are prime, hence p | N, contradicting activity.  So q !| N, i.e. q is
active.  If q = p then p | N-p, so p | N, the same contradiction.  QED

SCOPE-CORRECTION to def:graph.  The master states that "the condition q !| N is
not cosmetic: without it the graph acquires absorbing cycles through the
divisors of N".  That is correct as a statement about the graph defined on ALL
primes.  On the active subgraph -- which is the only place the corpus ever uses
it, since stopped_traversal() requires an active root and by T1 every enqueued
vertex is then active -- the filter never fires.  Verified: over all even
N < 4000, all 1 089 925 pairs (active p, prime factor q of N-p) satisfy q !| N;
zero exceptions.  Practical consequence: the "if N % q != 0" line in children()
is a no-op on the reachable set, and any argument that draws structural
conclusions from the presence of that filter (rather than from activity of the
root) is drawing them from nothing.

--------------------------------------------------------------------------------
```
