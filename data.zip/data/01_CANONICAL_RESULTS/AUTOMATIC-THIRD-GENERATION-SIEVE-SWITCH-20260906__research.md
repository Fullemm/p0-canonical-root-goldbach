---
id: AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906
logical_id: AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906
version_id: AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906@research
kind: canonical-result
run: research
title: "FAIL-"
status: KILLED
status_raw: "KILLED AS AN INFERENCE; no third-generation theorem is refuted."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2686, line_end: 2730}
metadata: {"stable_id": "AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906", "version_id": "AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906@research", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2686, "line_end": 2730}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2686, "line_end": 2730}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `KILLED` (raw: `KILLED AS AN INFERENCE; no third-generation theorem is refuted.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906
STATUS: KILLED AS AN INFERENCE; no third-generation theorem is refuted.
CLAIM / ROUTE: Repeat the four-switch proof of the radius-two theorem
without a new argument to obtain every fixed complete BAD radius.
WHY IT LOOKED PROMISING: Each edge offers a choice between fixing its
prime label and fixing its cofactor, and at depth two the smaller
choices give a long enough progression outside one negligible band.
EXACT FAILURE:
At depth three, all three labels may have size about X^0.4, with their
row cofactors about X^0.6. The product of even the smaller choices then
has size about X^1.2. The progression parameter need not have a growing
interval to sieve. A whole interval of exponent choices has this
problem; it is not confined to a shrinking band around sqrt X that
can be discarded as in the radius-two proof.
COUNTEREXAMPLE / OBSTRUCTION:
This is a parameter-range obstruction to the proposed proof, not an
assertion that prime paths in that range have been constructed in
positive density. Those paths must be bounded arithmetically; size
constraints alone do not eliminate them. Common factors in some moduli
could help particular patterns but have not been controlled uniformly.
WHAT SURVIVES: The complete radius-two theorem and the growing-depth
path-product barrier. Neither requires a fixed factor alphabet.
DO NOT REPEAT: Do not promote the heuristic loglog(N) branching factor
and a 1/log N endpoint-prime probability to an independence theorem;
do not apply a prime-tuple asymptotic with a bounded sieve variable.
POSSIBLE REPLACEMENT: A simultaneous estimate for the three-generation
bilinear congruences, or a different parametrization that resolves the
large-product region with all degeneracies and remainder terms controlled.

AUDIT / PROVENANCE NOTES 2026-09-06
The result named SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT and the later
COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX are the same theorem,
with the latter splitting off SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE as a
separate lemma. They must not be counted as two independent advances.
Both versions are retained as incremental proof records.
The older failure-log statement about a prime-tuple/codegree wall is not
contradicted: the present proofs only need prime-tuple UPPER bounds to
show rare shallow success. They provide no pointwise lower prime count.
The old automatic envelope-iteration failure likewise remains valid;
the new radius-two proof uses four explicit arithmetic parametrizations,
not iteration with an enlarged smoothness envelope.
A selective search in the master, Biblia and post-CRD failure log found
no earlier complete-radius density theorem supplying this consumer.
That search is not a literature novelty audit.
```
