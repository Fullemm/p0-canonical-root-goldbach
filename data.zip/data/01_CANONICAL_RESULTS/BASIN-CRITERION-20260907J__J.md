---
id: BASIN-CRITERION-20260907J
logical_id: BASIN-CRITERION-20260907J
version_id: BASIN-CRITERION-20260907J@J
kind: canonical-result
run: J
title: "Basin criterion"
status: PROVED
status_raw: "PROVED (independent re-proof)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 190, line_end: 222}
metadata: {"stable_id": "BASIN-CRITERION-20260907J", "version_id": "BASIN-CRITERION-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 190, "line_end": 222}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 190, "line_end": 222}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1085, style: ID-TABLE}
---

# Basin criterion

*Run J - status `PROVED` (raw: `PROVED (independent re-proof)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T3.  BASIN-CRITERION-20260907J          STATUS: PROVED (independent re-proof)
--------------------------------------------------------------------------------
STATEMENT.
(a) If S is closed and BAD and p in S with p > N/3, then every child of p is
    < N/3.  Hence S ^ (0, N/3) is closed, nonempty whenever S is nonempty, and
    B_N != empty <=> some nonempty closed BAD set exists.
(b) For every upper root r >= N/2 with m = N-r composite and > 1:
        r fails  <=>  PF(m) subseteq B_N   <=>   rad(m) | R_N.
(c) p in B_N  <=>  p prime, p < N/3, p !| N, and N-p is B_N-smooth.
    (Compositeness of N-p is then automatic.)

PROOF.
(a) N-p < 2N/3 is odd and composite (BAD, and N-p > 1 since p < N-1 for
p > N/3, N >= 6), so its least prime factor is >= 3 and every prime factor is
<= (N-p)/3 < 2N/9 < N/3.  If S is nonempty pick p in S; if p > N/3 then
PF(N-p) is nonempty and contained in S ^ (0,N/3).
(b) (=>) If the stopped traversal from r fails, then by lem:closure the world
R_N(r) is closed and BAD; its non-root vertices lie below N/3 by (a); the set
Reach(PF(m)) is therefore a closed BAD subset of {p < N/3}, hence contained in
B_N, and PF(m) subseteq B_N.  (<=) If PF(m) subseteq B_N then the traversal
after step one never leaves B_N (closedness) and B_N contains no GOOD vertex,
so no escape edge exists and r is BAD; failure.
(c) (<=) is closedness plus maximality: if N-p is B_N-smooth then
B_N u {p} is closed and BAD, so equals B_N by maximality.  (=>) is closedness.
For the parenthesis: N-p > 2N/3 > N/3 > max B_N, so N-p is not itself a member
of B_N and is not 1, hence has at least two prime factors with multiplicity.
QED

VERIFICATION.  (b) was checked mechanically on every upper root of every host:
891 (N, r) pairs, 0 mismatches between the stopped traversal (reference
implementation semantics, including the diagonal rule 2r = N) and the criterion.

--------------------------------------------------------------------------------
```
