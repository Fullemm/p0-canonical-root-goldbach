---
id: BIBLIA-I151-DYNAMICS-AUDIT
logical_id: BIBLIA-I151-DYNAMICS-AUDIT
version_id: BIBLIA-I151-DYNAMICS-AUDIT@I151-audit
kind: canonical-result
run: I151-audit
title: "Iteration 151: largest-factor dynamics, audited scope"
status: PROVED WITH REPAIR
status_raw: "AUDITED HISTORICAL IMPORT"
audit: ASTRA-PROOF-CHECKED
source_audit: ASTRA-CHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "root/goldbach_biblia(1).tex", line: 30394, line_end: 30654}
metadata: {"stable_id": "BIBLIA-I151-DYNAMICS-AUDIT", "version_id": "BIBLIA-I151-DYNAMICS-AUDIT@I151-audit", "status": "PROVED WITH REPAIR", "scope": "Largest-factor selected trajectories and simple BAD cycles", "assumptions": ["N even", "Active odd BAD starting prime", "f_N(p)=largest prime factor of N-p; stop at GOOD"], "statement": "Every finite trajectory terminates at GOOD or enters a BAD cycle. Prescribed directed cycle fixes N mod product(labels) by CRT. Product divisibility is only a consequence, NOT an equivalent encoding of the ordered cycle.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 30394, "line_end": 30654}, "depends_on": [], "consequences": [], "does_not_imply": ["A selected cycle is not full closure", "Does not contain R valuation pressure", "No uniform success theorem"], "killed_stronger_forms": [], "counterexamples": ["N=136 labels {13,41,19}: reversing the true cycle preserves product divisibility but loses required edges"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 30394, "line_end": 30654}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 30394, "relation": "COMPLEMENTARY DYNAMICS; CRT-converse wording repaired"}], "computation": [], "concepts": ["factorization-graph", "stopped-traversal", "unique-top-parent", "cycle-product-lock"], "historical_aliases": ["ch:iter151", "thm:151-zamek"], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Iteration 151: largest-factor dynamics, audited scope

*Run I151-audit - status `PROVED WITH REPAIR` (raw: `AUDITED HISTORICAL IMPORT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Every finite trajectory terminates at GOOD or enters a BAD cycle. Prescribed directed cycle fixes N mod product(labels) by CRT. Product divisibility is only a consequence, NOT an equivalent encoding of the ordered cycle.

**Assumptions:** N even; Active odd BAD starting prime; f_N(p)=largest prime factor of N-p; stop at GOOD.

**Does not imply:** A selected cycle is not full closure; Does not contain R valuation pressure; No uniform success theorem.

## Source transcript (historical wording; apply current metadata)

```
 \chapter{Iteracja 151: układ dynamiczny największego czynnika pierwszego}
\label{ch:iter151}

\section{Motywacja: od zamknięcia do trajektorii}

Dotychczasowy atak operował \emph{zamknięciem} wierzchołka $p_0$: świat
$W(p_0)$ powstaje przez przeszukiwanie wszerz i jego rozmiar rośnie
(pomiar iteracji~150: do $|W|=359$ dla $N\le 3\cdot 10^6$). Zamknięcie jest
obiektem o~nieograniczonym rozmiarze, więc każdy dowód oparty na~nim musi
kontrolować nieograniczoną liczbę wierszy naraz.

W~tej iteracji zastępujemy zamknięcie \emph{pojedynczą trajektorią}.
Kluczowa obserwacja: aby udowodnić hipotezę Goldbacha dla~$N$ wystarczy
\emph{jeden} wierzchołek dobry, a~nie cały świat. Wystarczy zatem
\emph{jedna ścieżka} prowadząca do wierzchołka dobrego. Ścieżkę taką
wyznacza deterministyczne odwzorowanie, a~certyfikat ma rozmiar liniowy
w~długości ścieżki, nie wykładniczy w~rozmiarze świata.

\begin{definition}[Odwzorowanie największego czynnika]
\label{def:151-fN}
Niech $N$ będzie parzyste, a~$p$ aktywną liczbą pierwszą
($p\nmid N$, $3\le p\le N-3$). Odwzorowanie
\[
   f_N(p) \;=\; P(N-p),
\]
gdzie $P(\cdot)$ oznacza największy czynnik pierwszy, jest określone
dokładnie wtedy, gdy $p$ jest \emph{zły}, tzn. $N-p$ jest złożone.
Dla $p$ dobrego $f_N(p)$ pozostaje nieokreślone.
\end{definition}

Odwzorowanie $f_N$ jest \emph{funkcją}: kolapsuje stopień wyjściowy grafu
GFG do jedynki, wybierając w~każdym wierszu jedno wyróżnione dziecko.
Graf funkcyjny $f_N$ jest sumą „rho-kształtów”: każda trajektoria jest
ciągiem wstępnym zakończonym cyklem albo urywa się w~wierzchołku dobrym.

\begin{lemma}[Poprawność dziedziny]
\label{lem:151-domena}
Jeśli $p$ jest aktywne, to każdy czynnik pierwszy liczby $N-p$ jest
aktywny. W~szczególności $f_N(p)$ jest aktywne, a~filtr aktywności
w~definicji GFG jest automatyczny.
\end{lemma}
\begin{proof}
Niech $q\mid N-p$ i~$q\mid N$. Wtedy $q\mid p$, więc $q=p$, a~zatem
$p\mid N$ --- sprzeczność z~aktywnością $p$. Ponadto $N$ jest parzyste
i~$p$ nieparzyste, więc $N-p$ jest nieparzyste i~$q\ne 2$.
\end{proof}

\section{Dychotomia trajektorii}

\begin{theorem}[Dychotomia]
\label{thm:151-dychotomia}
Dla każdego $N$ parzystego i~każdej aktywnej złej liczby pierwszej $p$
orbita $p,\;f_N(p),\;f_N^2(p),\dots$ spełnia dokładnie jedną
z~możliwości:
\begin{enumerate}[label=\emph{(\alph*)}]
\item po skończonej liczbie kroków trafia w~wierzchołek dobry $q$;
      wtedy $q+(N-q)=N$ jest reprezentacją Goldbacha dla~$N$;
\item wpada w~cykl $p_1\to p_2\to\dots\to p_k\to p_1$ złożony wyłącznie
      ze~złych liczb pierwszych.
\end{enumerate}
\end{theorem}
\begin{proof}
Zbiór aktywnych liczb pierwszych mniejszych od~$N$ jest skończony.
Trajektoria albo się urywa (dziedzina $f_N$ nie zawiera wierzchołków
dobrych --- przypadek~(a)), albo jest nieskończona, a~wtedy musi
powtórzyć wartość, co daje cykl. Wszystkie elementy cyklu leżą
w~dziedzinie $f_N$, są więc złe.
\end{proof}

\begin{corollary}[Kryterium cyklowe]
\label{cor:151-kryterium}
Jeżeli trajektoria $p_0,\;f_N(p_0),\dots$ nie wpada w~cykl, to hipoteza
Goldbacha zachodzi dla~$N$, a~certyfikat ma długość równą liczbie kroków.
\end{corollary}

\begin{theorem}[Brak punktów stałych]
\label{thm:151-fixed}
Dla każdego $N$ parzystego i~każdej aktywnej $p$ zachodzi $f_N(p)\ne p$.
Nie istnieją zatem cykle długości~$1$.
\end{theorem}
\begin{proof}
$f_N(p)=p$ oznacza $p\mid N-p$, czyli $p\mid N$ --- sprzeczność.
\end{proof}

\section{Zamek iloczynowy cyklu}

Cykle są obiektami sztywnymi. Poniższe twierdzenie pokazuje, że cykl
\emph{wyznacza $N$} modulo iloczyn swoich liczb pierwszych --- niezależnie
od~tego, czy powstał z~$f_N$, czy z~dowolnego innego wyboru dzieci.

\begin{theorem}[Zamek iloczynowy]
\label{thm:151-zamek}
Niech $p_1\to p_2\to\dots\to p_k\to p_1$ będzie dowolnym cyklem
w~grafie $\mathrm{GFG}(N)$, tzn. $p_{i+1}\mid N-p_i$ dla $i$ cyklicznie.
Wtedy
\[
   N \equiv p_{i-1} \pmod{p_i}\qquad (i=1,\dots,k),
\]
a~w~konsekwencji, przez chińskie twierdzenie o~resztach,
\[
   N \bmod \prod_{i=1}^{k} p_i
\]
jest \emph{jednoznacznie wyznaczone przez sam cykl}. Równoważnie
\[
   \prod_{i=1}^{k} p_i \;\Big|\; \prod_{i=1}^{k} (N-p_i).
\]
\end{theorem}
\begin{proof}
$p_{i+1}\mid N-p_i$ daje $N\equiv p_i \pmod{p_{i+1}}$. Liczby $p_i$ są
parami różne, więc moduły są parami względnie pierwsze i~CRT stosuje się
bezpośrednio. Druga postać wynika z~$p_{i+1}\mid N-p_i$ i~różnowartościowości.
\end{proof}

\begin{corollary}[Cykl długości~2]
\label{cor:151-k2}
Jeśli $p\to q\to p$ jest cyklem, to
\[
   pq \;\big|\; N-p-q,
\]
a~ponieważ $p$ i~$q$ są złe (więc $N\ne p+q$), zachodzi ostra nierówność
\[
   pq \;\le\; N-p-q.
\]
Równoważnie: istnieje $m\ge 1$ takie, że
\[
   \boxed{\,m N + 1 \;=\; (mp+1)(mq+1)\,}
\]
oraz $N = p+q+mpq$.
\end{corollary}
\begin{proof}
$q\mid N-p$ i~$p\mid N-q$ dają $pq\mid (N-p)(N-q)=N^2-N(p+q)+pq$, czyli
$pq\mid N(N-p-q)$. Ponieważ $\gcd(N,pq)=1$, mamy $pq\mid N-p-q$.
Gdyby $N=p+q$, to $p$ byłoby dobre. Kładąc $N-p-q=mpq$ dostajemy
$N=p+q+mpq$ i~$mN+1=mp+mq+m^2pq+1=(mp+1)(mq+1)$.
\end{proof}

\begin{corollary}[Cykl długości~3]
\label{cor:151-k3}
Dla cyklu $p_1\to p_2\to p_3\to p_1$ zachodzi
\[
   p_1p_2p_3 \;\big|\; N^2 - e_1 N + e_2,
\]
gdzie $e_1=p_1+p_2+p_3$, $e_2=p_1p_2+p_1p_3+p_2p_3$.
\end{corollary}

\begin{remark}[Unifikacja z~iteracjami 138--140]
\label{rem:151-unifikacja}
Importowany przypadek równości iteracji 138--140 brzmiał:
\[
   m_0=qr,\qquad p_0=qr+q+r,\qquad N=2qr+q+r,\qquad (2q+1)(2r+1)=2N+1 .
\]
Jest to \emph{dokładnie} przypadek $m=2$ wniosku~\ref{cor:151-k2}: wtedy
$N-q-r=2qr$, a~tożsamość $(2q+1)(2r+1)=2N+1$ jest szczególnym przypadkiem
$mN+1=(mp+1)(mq+1)$. Rodzina 2-cyklowa jest zatem naturalnym uogólnieniem
tamtego przypadku na~wszystkie $m\ge 1$ i~pokazuje, że tamten wynik nie
był izolowaną koincydencją, lecz jednym poziomem jednoparametrowej
rodziny.
\end{remark}

\section{Pomiar}

Program \texttt{atak\_iter151\_dynamika.c} przebiega wszystkie parzyste
$N\le X$ o~złym $p_0$ i~mierzy dwie strategie:

\begin{itemize}
\item \textbf{A} --- czysta trajektoria $p\leftarrow P(N-p)$;
\item \textbf{B} --- strategia zachłanna: w~każdym wierszu sprawdzamy
      \emph{wszystkie} dzieci; jeśli któreś jest dobre, kończymy,
      w~przeciwnym razie przechodzimy do~$P(N-p)$.
\end{itemize}

Dla $X=3\cdot 10^5$ (111\,520 złych światów):

\begin{center}
\begin{tabular}{lrr}
\toprule
& \textbf{A (czysta)} & \textbf{B (zachłanna)}\\
\midrule
średnia liczba kroków        & 6,159 & 2,046\\
maksymalna liczba kroków     & 78 ($N=202\,232$) & 58 ($N=282\,374$)\\
odsetek trajektorii w~cyklu  & 4,112\,\% & 0,764\,\%\\
rozwiązane w~0 krokach       & --- & 47\,381 (42,5\,\%)\\
\bottomrule
\end{tabular}
\end{center}

Rekordy długości certyfikatu rosną wolno:

\begin{center}
\begin{tabular}{lrrrrr}
\toprule
rząd $N$ & $10^1$ & $10^2$ & $10^3$ & $10^4$ & $10^5$\\
\midrule
A & 2 & 15 & 29 & 49 & 78\\
B & 1 & 14 & 28 & 39 & 58\\
\bottomrule
\end{tabular}
\end{center}

Wzrost jest zgodny z~modelem geometrycznym: przy średniej $\mu\approx\log N$
maksimum po $n$ próbach zachowuje się jak $\mu\log n$, czyli
$O\!\left((\log N)^2\right)$.

\subsection{Cykle}

Program \texttt{atak\_iter151\_cykle.c} wypisuje każdy napotkany cykl
i~weryfikuje zamek~\ref{thm:151-zamek}. Dla $X=3\cdot 10^5$:

\begin{itemize}
\item 4\,586 trajektorii wpada w~cykl;
\item \textbf{liczba naruszeń zamka CRT: 0} (weryfikacja pełna,
      wszystkie $k$ kongruencji dla każdego cyklu);
\item rozkład długości cyklu: $k=2$: 228, $k=3$: 620, $k=4$: 536,
      $k=5$: 459, $k=6$: 393, $k=7$: 352, $k=8$: 274, \dots,
      maksimum $k=48$ przy $N=282\,374$;
\item $\log\!\left(\prod p_i\right)/\log N$ osiąga 30,75 --- iloczyn
      liczb cyklu jest zwykle \emph{ogromnie} większy od~$N$, więc
      $N$ jest przez cykl wyznaczone jednoznacznie.
\end{itemize}

Przykłady najmniejszych cykli:
\begin{center}
\begin{tabular}{rrl}
\toprule
$N$ & $k$ & cykl\\
\midrule
92  & 4 & $5\to29\to7\to17\to5$\\
124 & 5 & $19\to7\to13\to37\to29\to19$\\
136 & 3 & $13\to41\to19\to13$\\
148 & 2 & $5\to13\to5$\quad ($pq=65$, $N-p-q=130=2\cdot 65$, $m=2$)\\
406 & 3 & $11\to79\to109\to11$\\
\bottomrule
\end{tabular}
\end{center}

Dla $N=136$ i~cyklu $(13,41,19)$: $e_1=73$, $e_2=1559$,
$N^2-e_1N+e_2=10\,127=13\cdot 41\cdot 19$ --- iloraz w~wniosku
\ref{cor:151-k3} wynosi dokładnie~1.

\section{Wnioski strategiczne}

\begin{enumerate}
\item \textbf{Certyfikat liniowy.} Strategia B rozwiązuje 99,24\,\%
      złych światów, średnio w~2 krokach. Certyfikat Goldbacha ma wtedy
      postać krótkiego łańcucha $p_0\to q_1\to\dots\to q_s$ z~jawnymi
      rozkładami wierszy --- obiekt rozmiaru $O(s\log N)$ zamiast całego
      świata $W(p_0)$.
\item \textbf{Trajektoria nie wystarcza.} Cykle występują (4,1\,\%
      i~0,76\,\%), więc kryterium~\ref{cor:151-kryterium} nie stosuje się
      do~wszystkich $N$. Czysta dynamika nie jest drogą do~dowodu.
\item \textbf{Ale cykle są sztywne.} Zamek~\ref{thm:151-zamek} pokazuje,
      że cykl wyznacza $N$ modulo iloczyn swoich elementów, a~dla $k=2$
      redukuje się do~jednoparametrowej rodziny
      $mN+1=(mp+1)(mq+1)$. To jest właściwy kierunek: przenieść ciężar
      z~\emph{wielkości} świata na~\emph{sztywność} jego rdzenia.
      Iteracja 152 doprowadza tę myśl do~końca.
\item \textbf{Uczciwe ograniczenie.} Twierdzenia tej iteracji nie
      wykluczają żadnego $N$. Ich wartość polega na~zamianie obiektu
      docelowego (świat $W$, rozmiar nieograniczony) na~obiekt sztywny
      (cykl, wyznaczający $N$ przez CRT).
\end{enumerate}
```
