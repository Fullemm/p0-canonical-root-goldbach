---
id: BIBLIA-I27-ELEMENTARY-RESTRICTIONS
logical_id: BIBLIA-I27-ELEMENTARY-RESTRICTIONS
version_id: BIBLIA-I27-ELEMENTARY-RESTRICTIONS@I27-audit
kind: canonical-result
run: I27-audit
title: "Iteration 27: elementary two-core restrictions"
status: PROVED
status_raw: "AUDITED HISTORICAL IMPORT"
audit: ASTRA-PROOF-CHECKED
source_audit: ASTRA-CHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "root/goldbach_biblia(1).tex", line: 12895, line_end: 12969}
metadata: {"stable_id": "BIBLIA-I27-ELEMENTARY-RESTRICTIONS", "version_id": "BIBLIA-I27-ELEMENTARY-RESTRICTIONS@I27-audit", "status": "PROVED", "scope": "Every two-core, all N", "assumptions": ["N=p+q^b=q+p^c", "p<q odd primes", "b,c>=2"], "statement": "c!=3; b=2 implies c>=5; always c>=4 and p<N^(1/4).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 12895, "line_end": 12969}, "depends_on": ["TWO-CORE-PILLAI-20260907J"], "consequences": [], "does_not_imply": ["Does not validate historical scans to 10^36", "No uniform exponent bound or uniqueness"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 12895, "line_end": 12969}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 12895, "relation": "CONFIRMED STRONGER HISTORICAL RESULT"}], "computation": [], "concepts": ["pillai-equation", "pure-row"], "historical_aliases": ["cor:iteration27-c4", "prop:iteration27-small-c"], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Iteration 27: elementary two-core restrictions

*Run I27-audit - status `PROVED` (raw: `AUDITED HISTORICAL IMPORT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

c!=3; b=2 implies c>=5; always c>=4 and p<N^(1/4).

**Assumptions:** N=p+q^b=q+p^c; p<q odd primes; b,c>=2.

**Does not imply:** Does not validate historical scans to 10^36; No uniform exponent bound or uniqueness.

## Source transcript (historical wording; apply current metadata)

```
\section{Wykluczenia elementarne}

\begin{lemma}[Postać Hensela dla \(b=2\)]
\label{lem:iteration27-hensel-form}
Jeżeli \(b=2\), to \(q=1+pu\), gdzie
\begin{equation}
 pu^{2}+u+1=p^{\,c-1} .
 \label{eq:iteration27-quadratic}
\end{equation}
Wtedy \(p\mid u+1\); pisząc \(u=pw-1\) z \(w\ge1\) otrzymujemy
\begin{equation}
 p^{\,c-2}=w+(pw-1)^{2}.
 \label{eq:iteration27-w-form}
\end{equation}
Ponadto \(u\) jest \emph{jednoznacznie} wyznaczone przez parę \((p,c)\): jest
jedynym pierwiastkiem dodatnim \eqref{eq:iteration27-quadratic}, a
równocześnie jedynym podniesieniem Hensela rozwiązania \(u\equiv-1\pmod p\)
kongruencji \(pu^{2}+u+1\equiv0\pmod{p^{\,c-1}}\) (pochodna \(2pu+1\) jest
jednostką modulo \(p\)).
\end{lemma}

\begin{proof}
Dla \(b=2\) \eqref{eq:iteration27-reciprocity} daje \(q=1+pu\) i
\(p^{c-1}=1+qu=1+u+pu^{2}\), czyli \eqref{eq:iteration27-quadratic}.
Redukując modulo \(p\) i korzystając z \(c\ge3\): \(0\equiv u+1\).
Podstawienie \(u=pw-1\) daje
\(p^{c-1}=pw+p(pw-1)^{2}\), skąd \eqref{eq:iteration27-w-form}.
Jednoznaczność: \eqref{eq:iteration27-quadratic} jest równaniem kwadratowym o
dodatnim współczynniku wiodącym i wartości \(1-p^{c-1}<0\) w zerze, więc ma
dokładnie jeden pierwiastek dodatni. Wersja Hensela: rozwiązanie kongruencji
modulo \(p^{c-1}\) jest jedyne, a \(u\asymp p^{(c-2)/2}<p^{c-1}\).
\end{proof}

\begin{proposition}[\(b=2\) wymusza \(c\ge5\)]
\label{prop:iteration27-small-c}
Nie istnieje rdzeń rozmiaru \(2\) z \(b=2\) i \(c\in\{3,4\}\).
\end{proposition}

\begin{proof}
\emph{Przypadek \(c=3\).} \eqref{eq:iteration27-w-form} daje
\(p=w+(pw-1)^{2}\), czyli po uporządkowaniu względem \(p\)
\[
 w^{2}p^{2}-(2w+1)p+(w+1)=0 .
\]
Wyróżnik wynosi \((2w+1)^{2}-4w^{2}(w+1)=-4w^{3}+4w+1\). Dla \(w=1\) jest on
równy \(1\) i daje \(p\in\{1,2\}\), a więc żadnej nieparzystej liczby
pierwszej. Dla \(w\ge2\) mamy \(-4w^{3}+4w+1\le-23<0\), więc równanie nie ma
pierwiastków rzeczywistych.

\emph{Przypadek \(c=4\).} \eqref{eq:iteration27-w-form} daje
\(p^{2}=w+(pw-1)^{2}\), czyli
\[
 (w^{2}-1)p^{2}-2wp+(w+1)=0 .
\]
Dla \(w=1\) redukuje się to do \(-2p+2=0\), czyli \(p=1\). Dla \(w\ge2\)
wyróżnik wynosi \(4w^{2}-4(w^{2}-1)(w+1)=4(-w^{3}+w+1)\le-20<0\).
\end{proof}

\begin{corollary}[Każdy rdzeń rozmiaru dwa ma \(c\ge4\)]
\label{cor:iteration27-c4}
Ponieważ \(2\le b<c\), warunek \(c=3\) wymusza \(b=2\), co
\cref{prop:iteration27-small-c} wyklucza. Zatem \(c\ge4\), a stąd
\begin{equation}
 p\le N^{1/4}.
 \label{eq:iteration27-p-bound}
\end{equation}
\end{corollary}

\begin{remark}
\Cref{cor:iteration27-c4} jest tym, co czyni przeszukanie tanim: mniejsza
liczba pierwsza rdzenia jest ograniczona przez \emph{czwarty} pierwiastek z
\(N\), nie przez \(N/2\). Przy \(p\le10^{9}\) obejmuje to wszystkie
\(N\le10^{36}\).
\end{remark}

```
