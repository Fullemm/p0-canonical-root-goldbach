---
id: CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907
logical_id: CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907
version_id: CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907@research
kind: canonical-result
run: research
title: "Canonical first support cycle realization"
status: PROVED
status_raw: "PROVED; an explicit consumer of the surviving partial-CRT method."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5474, line_end: 5589}
metadata: {"stable_id": "CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907", "version_id": "CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5474, "line_end": 5589}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5474, "line_end": 5589}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Canonical first support cycle realization

*Run research - status `PROVED` (raw: `PROVED; an explicit consumer of the surviving partial-CRT method.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: CANONICAL-FIRST-SUPPORT-CYCLE-REALIZATION-20260907
STATUS: PROVED; an explicit consumer of the surviving partial-CRT method.
EXACT STATEMENT:
For every ordered list q_1,...,q_l of distinct odd primes, l>=2, there
exists a FIXED positive integer h and infinitely many even integers N
such that, with P=p0(N)=N/2+h and m=N-P:
 (a) each q_i divides m, so every listed label lies at depth 1;
 (b) every q_i is active and BAD;
 (c) q_1 -> q_2 -> ... -> q_l -> q_1 is a directed cycle of the actual
     factorization graph induced on the complete first support PF(m).
There may be additional edges, factors and GOOD children. No assertion
is made that PF(m) equals the prescribed list, that the induced cycle
is a terminal component, or that the COMPLETE BFS fails.
Consequently canonical roots have first-factor induced subgraphs with
arbitrarily long directed BAD cycles and arbitrarily large strongly
connected subgraphs. The strong component may have additional vertices
and edges, and need not be closed in the full factorization graph.

HYPOTHESES / QUANTIFIERS:
The list is fixed before constructing h or the arithmetic progression.
The infinitude is in N for each such fixed list and fixed h. It is not
uniform in growing l, not a density assertion, and not a statement about
the h=1 subfamily. The construction does NOT prescribe all cofactors.

PROOF:
Set M=product q_i and write indices cyclically, q_0=q_l. Choose h by
 2h = q_{i-1} (mod q_i), for i=1,...,l.
The Chinese remainder theorem applies because the odd primes q_i are
distinct and 2 is invertible modulo each q_i. It determines one residue
class h modulo M. None of its residues is zero: q_{i-1} is a distinct
prime, hence is not divisible by q_i. In particular gcd(2h,M)=1.
Choose any fixed positive representative h of that class.

We will choose a large odd prime P with P=2h (mod M), and set
 N=2(P-h), m=P-2h. To enforce canonicity, for EVERY even integer j
with 2<=j<=h choose a new prime ell_j>h, outside {q_1,...,q_l}, with
all these new primes distinct, and impose P=j (mod ell_j). Add P=1
(mod 2). These congruences have pairwise coprime moduli. Their common
class A modulo L=2M*product ell_j is reduced: its residues are nonzero
modulo every q_i, every ell_j (because 0<j<ell_j), and 2.
Dirichlet's theorem therefore supplies infinitely many primes P=A
(mod L). Discard finitely many small P so that P>2h+M, P-h>2,
P-j>ell_j for every chosen j, and all inequalities below are strict.
For odd 1<=j<=h, P-j is even and >2. For even j, ell_j is a proper
factor of P-j. Thus EVERY integer in [P-h,P) is composite. It follows
that P is exactly the least prime at or above N/2=P-h: P=p0(N).

By P=2h (mod M), all q_i divide m=P-2h. The root complement is positive
and divisible by M with l>=2, hence composite; each q_i is reached in
the complete first factor set. Modulo q_i, N=2P-2h=2h=q_{i-1}, which
is nonzero; therefore all q_i are active. For each i,
 N-q_i = 2h-q_i =0 (mod q_{i+1}).
For sufficiently large P, N-q_i>q_{i+1}; so this row is composite and
its COMPLETE factorization includes q_{i+1}. This gives every claimed
BAD cycle edge, including the closing edge. Increasing P changes N,
so infinitely many distinct N are obtained. Every label of the cycle
is in PF(m); therefore the cycle is genuinely in that induced subgraph,
not merely somewhere deeper in the reachable graph. This proves the
statement without a prime-tuple conjecture or a bounded-BFS assertion.

EXTERNAL INPUT AUDIT:
Only Dirichlet's theorem for one FIXED reduced arithmetic progression
is used: if gcd(A,L)=1, there are infinitely many primes P=A (mod L).
Verified in Andrew V. Sutherland, MIT 18.785, Fall 2021, Lecture 18,
Theorem 18.1, page 1:
https://math.mit.edu/classes/18.785/2021fa/LectureNotes18.pdf
No simultaneous primality of different linear forms is requested.

HOSTILE CHECK / NECESSARY SMALL-GAP BARRIER:
For ANY upper root R=N/2+h with m=N-R and S=PF(m), an internal edge
u->v with u,v in S obeys v|(2h-u), the old shadow identity. Since R
is prime and m<R, no v in S divides 2h; in particular internal self-
loops are impossible. If a is the least label on a directed cycle and
b is its next label, then b>a. A nonzero multiple of b equal to 2h-a
cannot be negative: if 2h<a its absolute value is <a<b. Consequently
2h-a>=b and h> a. Thus a first-support cycle necessarily has a label
below h. In particular the existing h=1 DAG theorem is untouched.
The CRT construction is compatible with this necessary bound: its h
cannot lie below every prescribed cycle label, because its congruences
would then give a strictly decreasing edge at every step of the cycle.
The fragile step in canonical CRT programming is primitivity of the
P progression; it was checked for EACH old and new prime modulus above.
Using the q_i themselves as arbitrary prime-gap blockers without that
check would be unjustified. Proper-factor thresholds were also imposed,
so a small shifted prime equal to its assigned divisor is excluded.

TWO-CYCLE SPECIALIZATION:
For distinct odd primes a,b in S, the two edges a->b and b->a occur
if and only if 2h=a+b (mod ab), equivalently
 h=(a+b)/2 (mod ab).
Indeed each edge supplies one of the two congruences, and their CRT
combination is 2h=a+b (mod ab); division by 2 is legitimate modulo odd
ab. The smallest positive representative is (a+b)/2<ab. All positive
solutions are h=(a+b)/2+t*ab with integers t>=0. For a=3,b=11 one can
therefore choose the small fixed value h=7. The general construction
then gives infinitely many canonical first-support 3<->11 cycles.

HISTORICAL RELATION:
This does not revive the killed reading of FBTU as complete-BFS
universality. Cite the existing FAIL-P0-FINITE-BAD-TRAVERSAL together
with its binding correction AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905
and the Biblia iteration-108 cofactor-leakage warning. The construction
is a concrete, fully audited partial-factor consumer of what survived.
It adds an explicit FIRST-SUPPORT cyclic obstruction to a proposed
acyclicity explanation; it is not a new general finite-local no-go.
RELATION TO GOLDBACH:
No Goldbach failure follows. Extra branches can and do reach GOOD.
RELATION TO p0:
An all-p0 acyclicity or uniform cycle-size bound is false. The h=1
acyclicity property and its full-BFS conjugacy with root 2 remain valid,
but neither property extends automatically to the whole canonical family.
WHAT REMAINS OPEN:
Any obstruction to complete BAD closure, with all moving factors retained.
NOVELTY: NOT YET AUDITED; no novelty claim for CRT programming itself.
```
