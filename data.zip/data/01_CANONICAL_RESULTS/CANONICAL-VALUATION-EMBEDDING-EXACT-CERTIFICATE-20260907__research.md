---
id: CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907
logical_id: CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907
version_id: CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907@research
kind: canonical-result
run: research
title: "Canonical valuation embedding exact certificate"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5793, line_end: 5872}
metadata: {"stable_id": "CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907", "version_id": "CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5793, "line_end": 5872}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5793, "line_end": 5872}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Canonical valuation embedding exact certificate

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: CANONICAL-VALUATION-EMBEDDING-EXACT-CERTIFICATE-20260907
STATUS: VERIFIED COMPUTATION.
DOMAIN:
One constructed example, using the noncanonical source (N0,R0)=(344,179)
with h0=7 and S={3,5,11}. No exhaustive-range claim is made.
CONSTRUCTION / VALUES:
The proof gives t_3=3,t_5=2,t_11=2, hence L=81675.
Use the progression P=179 (mod L), P=1 (mod 2),
 P=2 (mod 13), P=4 (mod 17), P=6 (mod 19).
Its common class is P=499197779 (mod 685906650).
A prime member is P=9415984229, yielding N=18831968444 and h=7.
The interval [P-7,P) is composite: odd shifts are even >2; shifts
2,4,6 have the proper divisors 13,17,19 respectively. Trial division
also checked primality of P. Thus P=p0(N) exactly, with no reliance on
a probable-prime certificate or an assumed preceding prime gap.
COMPLETE ROWS NEEDED FOR THE VALUATION CERTIFICATE:
 m=P-14=3*5*11*229*249199;
 N-3 = 11*13*131692087;
 N-5 = 3*89*6709*10513;
 N-11 = 3^2*17*101*239*5099.
All displayed factors are prime. On S these reproduce the original
root exponents (1,1,1), and exactly the internal weighted edges
 3->11 (weight 1), 5->3 (weight 1), 11->3 (weight 2).
The extra root multiplier is 57066571=229*249199, coprime to 3*5*11.
The full first support is therefore strictly larger than S, as the
proof requires. Both extra first children are BAD:
 N-229=5*53*653*108827;
 N-249199=5*37*199*511523.
The COMPLETE first frontier is BAD in this particular example, but
that extra fact was verified here and does not follow from the embedding.
The full FIFO search nevertheless succeeds at depth 2 after W=11 tests:
 P ->5 ->10513, and N-10513=18831957931 is prime.
Primality, all displayed factors and this BFS were checked using exact
trial division. The finite example illustrates preservation of the
internal cycle and valuations while an unprescribed factor supplies a
GOOD escape. It is not a failed canonical world.
REPRODUCTION:
CRT was solved with integer modular inverses, starting with class 179
modulo 81675 and then combining moduli 2,13,17,19. The first retained
prime in the resulting nonnegative progression is the displayed P;
that order is diagnostic only, not a minimality theorem about all N.
The complete certificate is retained in this TXT; the auxiliary scratch
record is canonical_valuation_embedding_20260907.json.
NOVELTY: NOT YET AUDITED.


AUDIT ADDENDUM: NECESSARY BOUNDARIES OF THE EMBEDDING NO-GO
STATUS: VERIFIED COMPUTATION / SCOPE-CORRECTED.
1. GOOD flags really are not preserved. A small exact example is
 (N0,R0)=(20,11), h0=1, m0=9=3^2, S={3}.
The original child 3 is GOOD because 20-3=17 prime. Take P=173,
N=344 and h=1. Then P=11 (mod 27), m=171=3^2*19 has the same
3-adic root exponent, and 344-3=341=11*31 has the same 3-adic row
valuation zero as 17. The entire induced graph on the labelled subset
{3} (one vertex of root weight 2, no internal edge) is unchanged,
but that vertex is now BAD. Thus adding GOOD/BAD flags to the theorem
without new hypotheses is false. This is a concrete boundary of the
retained theorem, not a counterexample to it.
2. Arbitrary incompatible edge data are still impossible. On labels
{3,5,7}, simultaneous edges 5->3 and 7->3 would require N=2 and N=1
modulo 3. No N realizes them. The fixed-gap theorem starts from an
actual upper-root graph, so its compatibility is guaranteed and its
primitivity is then proved. The cycle-realization theorem prescribes
one incoming predecessor per target and permits extra edges; it does
not assert universality of every directed graph on arbitrary labels.
3. The low-gap support LOWER bound proved earlier is not hereditary
under deleting vertices. It therefore escapes the hereditary no-go,
as do the complete-support height restrictions. This logical escape
alone does not turn them into a contradiction for large moving support.
4. None of these arguments assumes global Goldbach failure. The
failure counterexample (1862,1597) is a rooted failure in an ordinary
Goldbach-successful N. Its use kills only the unconditional prime-lift
success claim, not a theorem restricted to a global failed world.
5. No recent asymptotic estimate was needed in this continuation.
The checkpoint's earlier growing-root/growing-depth sieve claims have
not been strengthened or reclassified by the elementary results here.

=========================
STRONGST NEW RESULTS
=========================
```
