---
id: CLOSED-ALPHABET-COUNT-20260905
logical_id: CLOSED-ALPHABET-COUNT-20260905
version_id: CLOSED-ALPHABET-COUNT-20260905@research
kind: canonical-result
run: research
title: "Closed alphabet count"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 226, line_end: 274}
metadata: {"stable_id": "CLOSED-ALPHABET-COUNT-20260905", "version_id": "CLOSED-ALPHABET-COUNT-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 226, "line_end": 274}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["CLOSED-ALPHABET-COUNT"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 226, "line_end": 274}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Closed alphabet count

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: CLOSED-ALPHABET-COUNT-20260905
STATUS: PROVED.
EXACT STATEMENT:
Fix a finite set S of odd primes, s=|S|. Let C_S be the set of even N for
which there is a nonempty set C subset S of active primes (p does not divide
N), all N-p composite, with PF(N-p) subset C for every p in C.
Then |C_S| <= binomial(s,2) * 2^(9s+16), over ALL positive N.
PROOF:
A singleton C={a} is impossible: closure would give N-a=a^e and hence a|N,
contrary to activity. Let a<b be the two smallest elements of C.
The two complete rows U=N-a and V=N-b are coprime. Indeed, a common prime
l belongs to C and divides U-V=b-a. It cannot be a because a does not
divide U by activity. Every other prime of C is at least b>b-a, also
impossible. Thus gcd(U,V)=1. Both rows are S-smooth and satisfy
U-V=b-a. For each of binomial(s,2) choices of a,b, apply
COPRIME-SUPPORTED-AFFINE-COUNT with A=1, B=-1, C=b-a.
Each U determines N=U+a. The union bound proves the claim.
HOSTILE CHECK:
No SCC minimality is needed; full factor closure and activity are needed.
The set C and all its valuations may vary with N. They all lie inside ONE
fixed S. Dropping composite-row or prime-root conditions in the counting
lemma is harmless because the count becomes larger. Singleton inactivity
is why trivial p|N components are excluded.
DEPENDENCIES: BS-1996; two-smallest-row coprimality, already in the corpus
and reproved here. No Scott/Bozek two-vertex classification is used.
IMPLICATION / NEW CONSUMER:
With S={odd primes <=y}, s=pi(y)-1, the total number of N admitting ANY
closed active BAD set supported below y is at most
binomial(s,2)*2^(9s+16), with no upper bound on N required.
Consequently, for y(X)=c log X log log X and fixed 0<c<1/(9 log 2),
#{N<=X: such a closed set exists with max C<=y(X)}
<= X^(9c log 2+o(1))=o(X).
For each X, all moving supports in this event are contained in the SAME
alphabet S_y(X), so taking their union is justified. The prime number theorem
gives pi(y(X))=(c+o(1))log X. No union over arbitrary unbounded labels is made.
RELATION TO HISTORICAL FIXED-S WALL:
This does not repeat the invalid within-one-world capacity argument.
It counts DISTINCT N across a family sharing an explicitly bounded envelope.
It still gives no every-N exclusion and no height bound for exceptional N.
RELATION TO GOLDBACH:
Applies also to ordinary successful N containing bad components. Under global
Goldbach failure a closed BAD set exists, but nothing proved here forces
its labels below y(X). Hence this is not a Goldbach proof or a new estimate
for the full Goldbach exceptional set.
RELATION TO p0 EXCEPTIONALITY: Global graph restriction; no selector dependence.
WHAT REMAINS OPEN: Large or moving support, and canonical access to it.
NOVELTY: NOT YET AUDITED; new application within this checkpoint, not a claim
that bounded-prime smooth-pair counting is new to number theory.
```
