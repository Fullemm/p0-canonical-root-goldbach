---
id: CLOSED-ALPHABET-COUNT@research
logical_id: CLOSED-ALPHABET-COUNT
version_id: CLOSED-ALPHABET-COUNT@research
kind: historical-version
run: research
title: "Closed alphabet count"
status: SUPERSEDED
status_raw: "at most binomial(s,2)*2^(9s+16) distinct even N"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1909, line_end: 1911}
metadata: {"stable_id": "CLOSED-ALPHABET-COUNT", "version_id": "CLOSED-ALPHABET-COUNT@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1909, "line_end": 1911}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "CLOSED-ALPHABET-COUNT-20260905", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1909, "line_end": 1911}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: CLOSED-ALPHABET-COUNT-20260905
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Closed alphabet count

*Run research - status `SUPERSEDED` (raw: `at most binomial(s,2)*2^(9s+16) distinct even N`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `CLOSED-ALPHABET-COUNT-20260905` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
3. CLOSED-ALPHABET-COUNT: at most binomial(s,2)*2^(9s+16) distinct even N
   support a closed active BAD set inside any one fixed alphabet of s primes.
   A common slowly growing prime envelope gives a rigorous density corollary.
```
