---
id: COFACTOR-CHAIN-EXACT-MODULUS-20260906B
logical_id: COFACTOR-CHAIN-EXACT-MODULUS-20260906B
version_id: COFACTOR-CHAIN-EXACT-MODULUS-20260906B@research
kind: canonical-result
run: research
title: "Cofactor chain exact modulus"
status: PROVED
status_raw: "PROVED; affine identity archival in substance, exact modulus"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4260, line_end: 4313}
metadata: {"stable_id": "COFACTOR-CHAIN-EXACT-MODULUS-20260906B", "version_id": "COFACTOR-CHAIN-EXACT-MODULUS-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4260, "line_end": 4313}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4260, "line_end": 4313}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Cofactor chain exact modulus

*Run research - status `PROVED` (raw: `PROVED; affine identity archival in substance, exact modulus`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COFACTOR-CHAIN-EXACT-MODULUS-20260906B
STATUS: PROVED; affine identity archival in substance, exact modulus
and averaging consumer recorded explicitly for the new sieve use.
EXACT STATEMENT:
Let x,h be positive integers, q_0=x+h, and let a_1,...,a_d be odd
integers >=3. Put A_0=C_0=1 and, for 1<=j<=d,
 A_j=a_1*...*a_j,       C_j=2*A_(j-1)-C_(j-1).
The recurrence a_j*q_j=2x-q_(j-1) is equivalent to
 A_j*q_j=C_j*x+(-1)^j*h.                                  (CF)
All q_j are integers if and only if
 C_d*x=(-1)^(d+1)*h modulo A_d.                            (CM)
Writing e=gcd(C_d,A_d), this condition is soluble precisely when e|h;
if soluble, it specifies exactly one residue class of x modulo A_d/e.
Every q_j is an integer affine form in the resulting progression
variable, with positive leading coefficient C_j*A_d/(A_j*e).
In particular for h=1 the compatible modulus is exactly A_d, since
e=1 is necessary. This is not assumed for later same-N roots.

PROOF:
Induction in the recurrence gives (CF), with the initial identity
q_0=x+h. Since every a_j>=3, C_1=1, and induction gives
 0<C_j<=2*A_(j-1) for all j>=1.
Indeed the subtraction term C_(j-1) is positive and, for j>=2,
C_(j-1)<=2*A_(j-2)<2*A_(j-1). Thus all coefficients are positive.
For i<j, reduction modulo A_i in the recurrence for C shows
 C_j=(-1)^(j-i)*C_i modulo A_i,
because A_(j-1) is divisible by A_i whenever j>i. Consequently (CM)
implies C_i*x+(-1)^i*h=0 modulo A_i for EVERY i<=d. This proves
that final integrality implies all earlier integrality; the converse
is immediate. The solvability and modulus assertions are the elementary
linear-congruence theorem after dividing by e.
For x=x_0+(A_d/e)*t, divisibility of each earlier numerator for all
integer t implies A_i divides C_i*A_d/e. Alternatively C_i agrees
up to sign with C_d modulo A_i and C_d*A_d/e is divisible by A_i.
Hence every stated leading coefficient is a positive integer. The
constants are integers by the choice of x_0. This proves everything.

HOSTILE CHECK:
One cannot simply divide every earlier modulus A_j by the final gcd e:
e may not divide A_j. What is integral is C_j*A_d/(A_j*e), by the
congruence just proved. The reduced modulus need not equal the product
of separately reduced edge moduli. At h=1 the coprimality conclusion
comes from the numerator +/-1, not from hypothetical independence of
cofactors. No prime or BAD hypothesis is needed for the algebra.
HISTORICAL RELATION: The master identifies
G-CRD-PATH-AFFINE-COFACTOR-NORMAL-FORM as a surviving exact transport
lemma. FAIL-V48-DIRECT-REFLECTED-TAG-INHERITANCE-001 warns against
preserving an old divisibility tag along a path; (CF) transports the
changing term instead. FAIL-V51-ALTERNATE-PATH-CONGRUENCE-AMPLIFIES-
DEEP-POWER-001 does not apply: no extra valuation is inferred from an
invertible common factor. The consumer below counts prime solutions.
DEPENDENCIES: Elementary induction and linear congruences.
NOVELTY: NOT YET AUDITED; do not claim novelty of affine transport.
```
