---
id: COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G
logical_id: COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G
version_id: COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G@research
kind: canonical-result
run: research
title: "Complete bounded mirror safety census"
status: PROVED
status_raw: "VERIFIED EXACT COMPUTATION WITH PROVED GLOBAL SEARCH BOUND."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6732, line_end: 6777}
metadata: {"stable_id": "COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G", "version_id": "COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6732, "line_end": 6777}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6732, "line_end": 6777}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Complete bounded mirror safety census

*Run research - status `PROVED` (raw: `VERIFIED EXACT COMPUTATION WITH PROVED GLOBAL SEARCH BOUND.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COMPLETE-BOUNDED-MIRROR-SAFETY-CENSUS-20260907G
STATUS: VERIFIED EXACT COMPUTATION WITH PROVED GLOBAL SEARCH BOUND.
The previous finite-fibre theorem permits a wider census than the old
dangerous-mirror list. Enumerate EVERY odd composite integer m<=3053,
and EVERY realization at each rank in {0,10,14,26,28,30,62,63,71,74},
over ALL even N. It suffices to test odd primes m<P<30204, with N=P+m.
Implementation/result: rank_fibre_closure_20260907G.py / corresponding JSON.
There are 1090 such distinct composite integers m, and each occurs at
each listed rank, consistent with surjectivity.
Rank: total composite cases / failures / largest realized N / max depth / max W:
  0: 1882 / 0 / 6114 / 7 / 34
 10: 2219 / 0 / 6282 / 8 / 30
 14: 2244 / 0 / 6354 / 8 / 39
 26: 2205 / 0 / 6552 / 7 / 39
 28: 2242 / 0 / 6570 / 8 / 35
 30: 2236 / 0 / 6582 / 7 / 27
 62: 2274 / 0 / 7144 / 9 / 32
 63: 2275 / 0 / 7146 / 8 / 33
 71: 2271 / 0 / 7296 / 7 / 40
 74: 2282 / 0 / 7324 / 7 / 36
The largest N for each rank has m=3053; root values and depth/work
witnesses are recorded exactly in the JSON. This is an exhaustive
bounded-mirror statement for all N, NOT a new large-N BFS record.

The same enumeration gives the COMPLETE global unit-row input sets:
  k=0: empty
  k=10: {102}
  k=14: {140,152}
  k=26: {284,308}
  k=28: {314,318,332,338,348}
  k=30: {354,360,368}
  k=62: {824}
  k=63: {828}
  k=71: {972,978,984}
  k=74: {1022}
The stated analytic bound proves there can be no further unit rows
at arbitrarily large N for these ranks. This is stronger than simply
counting unit rows up to a chosen experimental cutoff.
HARNESS CHECK:
An initial unit-only diagnostic accidentally included P=2,N=3. This
violates the odd-prime/even-N domain and was removed before accepting
these results. The final code explicitly starts at P>=3 and asserts
P odd, N even, N>=4, and an empty canonical unit set. Composite-case
counts were unaffected. All 214-mirror transplant counts were asserted
equal to the independent preceding audit.
```
