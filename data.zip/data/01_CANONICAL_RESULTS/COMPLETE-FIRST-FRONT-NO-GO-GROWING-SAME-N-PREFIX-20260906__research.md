---
id: COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906
logical_id: COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906
version_id: COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906@research
kind: canonical-result
run: research
title: "Complete first front no go growing same n prefix"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2365, line_end: 2446}
metadata: {"stable_id": "COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906", "version_id": "COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2365, "line_end": 2446}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2365, "line_end": 2446}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Complete first front no go growing same n prefix

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COMPLETE-FIRST-FRONT-NO-GO-GROWING-SAME-N-PREFIX-20260906
STATUS: PROVED.
EXACT STATEMENT:
Let K=K(X)>=1 be integers with
 K=o(log X/(loglog X)^3).
For all but o(X/log X) primes P in [X,2X], set N=2(P-1). Let Q_0=P,
Q_1,Q_2,... be the successive primes starting at P. Simultaneously for
EVERY 0<=k<=K, Q_k is BAD and EVERY prime factor of N-Q_k is BAD.
Equivalently none of these complete stopped traversals succeeds at
radius 0 or 1. Each Q_k is exactly p_k(N); these roots refer to the SAME N.
This is a relative-density-one theorem in the prime-parametrized h=1
family, not a density-one theorem among all even N.
One admissible concrete prefix is floor(log X/(loglog X)^5).
A quantitative upper bound for the exceptional proportion, up to an
absolute constant for sufficiently large X, is
 (loglog X)^2/log X + sqrt(K*(loglog X)^3/log X).

PROOF:
For K in the stated range, PNT ensures that there are more than K primes
between 2X and 3X for large X. Thus Q_K<=3X for every P in [X,2X].
Summing Q_K-P over these starting primes counts each consecutive prime
gap inside [X,3X] at most K times. The sum of all such gaps is at most
2X. Consequently
 #{P in [X,2X] prime: Q_K-P>H-1} <=2KX/(H-1).                 (G)
This uses only the sum of gaps, not a bound on individual gaps or a
second moment. If Q_K-P<=H-1, every k>=1 has h_k=Q_k-P+1<=H and the
pair (P,Q_k) lies in SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE. Hence the
number of starting P admitting ANY successful radius-one traversal
among k=1,...,K with Q_K-P<=H-1 is at most
 O(H*X*(loglog X)^3/(log X)^3).
There is no extra K factor: that lemma already counts all eligible
pairs P,Q and all offsets h<=H, and a union is bounded by that count.
The k=0 exception is O(X*(loglog X)^2/(log X)^2), by the preceding
canonical theorem. Divide the sum of these three bounds by
#{P in [X,2X]}~X/log X. The exceptional proportion is
 O((loglog X)^2/log X + K*log X/H
                         + H*(loglog X)^3/(log X)^2).
Choose H equal to an integer within 1 of
 sqrt(K*(log X)^3/(loglog X)^3).
It tends to infinity and lies below sqrt X/10 for large X; the rounding
and H-1 in (G) change only the constant. The last two terms are both
of the asserted square-root order, and tend to zero by the assumption
on K. This proves the quantitative and qualitative assertions.
For good starting P the complements are positive: Q_k=P+O(H), so
N-Q_k=P-2-O(H)>1. No root divides N, since each root is prime in
(N/2,N), strictly above the diagonal. If a child q divided N then
q would divide its root Q_k, impossible because q<Q_k. Thus the BAD
conclusions have the active, positive-composite meaning, as required.

HOSTILE CHECK:
This gives COMPLETE first-front BADness, not merely a selected CRT
subtree or many small BAD children. It therefore repairs one limited
part of the old full-BFS no-go with a different, analytic proof.
It proves neither arbitrary depth nor failure of the complete traversal.
The relative family restriction is indispensable in this proof: the
additional prime P=N/2+1 supplies a sieve dimension for nearby roots.
Markov's estimate in (G) is over prime starts P, not over all integer
midpoints weighted by their containing prime gap. Confusing those two
sampling measures would be an invalid extension to all even N.
The theorem does not assert that the factor supports or deeper dynamics
of Q_0 and Q_1 agree; it asserts a shared entire radius-one failure event.

DEPENDENCIES:
FKL Lemma 5.1 via the fully checked consumers above; PNT; exact gap sum.
No Goldbach-failure hypothesis, no lower-bound prime-tuples conjecture,
no Scott--Bozek classification, no iteration of an envelope theorem.
RELATION TO GOLDBACH:
An unconditional obstruction to using a growing nearby-root prefix with
one factorization generation as a typical solver in this infinite family.
It does not obstruct multigeneration traversal or general Goldbach pairs.
RELATION TO p0:
A substantive same-N negative comparison: even an entire complete first
front is asymptotically BAD for p0 and a growing family of its neighbours.
The empirical exceptional behavior must, if real, be attributed to
something stronger than ubiquitous shallow success. No universal
p0-specific reachability advantage is proved here.
WHAT REMAINS OPEN:
In particular, no corresponding complete radius-two theorem is proved.
The original question about every fixed complete BAD BFS depth remains
open beyond radius one.
NOVELTY: NOT YET AUDITED.
```
