---
id: COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906
logical_id: COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906
version_id: COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906@research
kind: canonical-result
run: research
title: "EXPERIMENT-"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION; exact exhaustive finite scans."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2731, line_end: 3246}
metadata: {"stable_id": "COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906", "version_id": "COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2731, "line_end": 3246}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2731, "line_end": 3246}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# EXPERIMENT-

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION; exact exhaustive finite scans.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
EXPERIMENT-ID: COMPLETE-FRONT-AND-RADIUS-TWO-AUDIT-20260906
STATUS: VERIFIED COMPUTATION; exact exhaustive finite scans.
METHOD:
A full smallest-prime-factor sieve through 4,000,100; integer-only
factor extraction; exact prime table lookups. No probable-prime tests.
Scan A: all prime starts in each of [100,1000), [1000,10000),
[10000,100000), [100000,1000000), [1000000,2000000). For SAME N=2(P-1),
compare roots of ranks 0,1,2,5. Classify success at depth 0, at depth 1,
or absence of success through depth 1. The last category does NOT
assert success at depth 2.
Scan B: all prime starts in [1000,10000), [10000,100000),
[100000,200000), [1000000,2000000). Classify actual shortest success
at depth 0,1,2, or no success through depth 2. Enumerate all successful
length-two paths after excluding earlier success, and check (T), the
three necessary gcd conditions, and all six CC determinants exactly.
There are 43,150 such paths in these domains; every check passed.
No claim of a global-depth BFS census is made. All four switching regimes
occur in the finite scan, so omitting any of them would omit real paths.
The finite prime interval [1000000,2000000) has 70,435 starts. Of these,
14,498 have the complete radius-two BAD property. This is about 20.6%,
not close to the limiting density one; the proven bounds are asymptotic
and are not being calibrated to this numerical range.
The first complete radius-two BAD certificate in the scanned domain
starting at P=1000 is P=1091, N=2180:
 N-P=1089=3^2*11^2;
 N-3=2177=7*311;
 N-11=2169=3^2*241;
 N-7=2173=41*53;
 N-241=1939=7*277;
 N-311=1869=3*7*89.
Every row at distances 0,1,2 is composite. The repeated label 3 is
already at distance 1; it is not counted as a new distance-2 vertex.
The certificate concerns finite depth only, not a closed BAD set.
For the six historical N=128,1718,1862,1928,2200,6142, the maximal low
closed BAD sets were also reconstructed exactly, and their two least
labels satisfy b^2<N and coprime rows. This is a targeted audit of the
height refinement, not a new census of autonomous components.
Full reproducible diagnostic code and exact output follow. These are
finite verification records, not the proof of any asymptotic theorem.
import numpy as np
from math import isqrt, gcd
from collections import Counter
import json
L=4000100
spf=np.zeros(L+1,dtype=np.int32)
for p in range(2,isqrt(L)+1):
    if spf[p]==0:
        z=spf[p*p::p]
        z[z==0]=p
primes=np.flatnonzero(spf[2:]==0)+2
isprime=np.zeros(L+1,dtype=np.bool_);isprime[primes]=True

def pf(n):
    out=[]
    while n>1:
        p=int(spf[n]) or n
        out.append(p)
        while n%p==0:n//=p
    return out

def first(N,Q):
    m=N-Q
    if isprime[m]:return 0,[]
    qs=pf(m)
    good=[q for q in qs if isprime[N-q]]
    return (1 if good else 2),good
out={}
for lo,hi in [(100,1000),(1000,10000),(10000,100000),(100000,1000000),(1000000,2000000)]:
    inds=np.flatnonzero((primes>=lo)&(primes<hi))
    hist=Counter(); examples={}
    for idx in inds:
        P=int(primes[idx]); N=2*(P-1)
        v=tuple(first(N,int(primes[idx+k]))[0] for k in [0,1,2,5])
        hist[v]+=1
        examples.setdefault(v,N)
    out[f'{lo}<=P<{hi}']={'prime_count':len(inds),'root_depth_capped_2_counts':[[sum(c for v,c in hist.items() if v[j]==d) for d in [0,1,2]] for j in range(4)],'all_four_no_success_depth_0_or_1':sum(c for v,c in hist.items() if min(v)==2),'first_witness_all_four':examples.get((2,2,2,2))}
checks={}
for N in [128,1718,1862,1928,2200,6142]:
    C=set(int(p) for p in primes if p<N/3 and N%p and not isprime[N-p])
    while True:
        D={p for p in C if set(pf(N-p))<=C}
        if D==C:break
        C=D
    a,b=sorted(C)[:2]
    assert b*b<N and gcd(N-a,N-b)==1
    checks[N]={'closed_size':len(C),'a':a,'b':b,'b_squared':b*b,'row_supports':[pf(N-a),pf(N-b)]}
out['closed_pair_checks']=checks
out['conventions']='Exact exhaustive sieve and trial extraction via SPF. Depth 2 means no success at depth 0 or 1, and is not an actual success-depth assertion. Roots k=0,1,2,5 refer to SAME N=2(P-1).'
print(json.dumps(out,indent=2))
{
  "100<=P<1000": {
    "prime_count": 143,
    "root_depth_capped_2_counts": [
      [
        27,
        79,
        37
      ],
      [
        59,
        50,
        34
      ],
      [
        44,
        65,
        34
      ],
      [
        42,
        57,
        44
      ]
    ],
    "all_four_no_success_depth_0_or_1": 4,
    "first_witness_all_four": 692
  },
  "1000<=P<10000": {
    "prime_count": 1061,
    "root_depth_capped_2_counts": [
      [
        170,
        517,
        374
      ],
      [
        306,
        394,
        361
      ],
      [
        293,
        398,
        370
      ],
      [
        288,
        409,
        364
      ]
    ],
    "all_four_no_success_depth_0_or_1": 52,
    "first_witness_all_four": 2024
  },
  "10000<=P<100000": {
    "prime_count": 8363,
    "root_depth_capped_2_counts": [
      [
        1019,
        3662,
        3682
      ],
      [
        1777,
        2937,
        3649
      ],
      [
        1754,
        2915,
        3694
      ],
      [
        1774,
        2930,
        3659
      ]
    ],
    "all_four_no_success_depth_0_or_1": 704,
    "first_witness_all_four": 20276
  },
  "100000<=P<1000000": {
    "prime_count": 68906,
    "root_depth_capped_2_counts": [
      [
        6945,
        27567,
        34394
      ],
      [
        12469,
        22233,
        34204
      ],
      [
        11973,
        22621,
        34312
      ],
      [
        12174,
        22872,
        33860
      ]
    ],
    "all_four_no_success_depth_0_or_1": 8124,
    "first_witness_all_four": 200096
  },
  "1000000<=P<2000000": {
    "prime_count": 70435,
    "root_depth_capped_2_counts": [
      [
        6702,
        26908,
        36825
      ],
      [
        11667,
        21869,
        36899
      ],
      [
        11365,
        22330,
        36740
      ],
      [
        11264,
        22327,
        36844
      ]
    ],
    "all_four_no_success_depth_0_or_1": 9390,
    "first_witness_all_four": 2000064
  },
  "closed_pair_checks": {
    "128": {
      "closed_size": 10,
      "a": 3,
      "b": 5,
      "b_squared": 25,
      "row_supports": [
        [
          5
        ],
        [
          3,
          41
        ]
      ]
    },
    "1718": {
      "closed_size": 55,
      "a": 3,
      "b": 5,
      "b_squared": 25,
      "row_supports": [
        [
          5,
          7
        ],
        [
          3,
          571
        ]
      ]
    },
    "1862": {
      "closed_size": 55,
      "a": 3,
      "b": 5,
      "b_squared": 25,
      "row_supports": [
        [
          11,
          13
        ],
        [
          3,
          619
        ]
      ]
    },
    "1928": {
      "closed_size": 41,
      "a": 3,
      "b": 5,
      "b_squared": 25,
      "row_supports": [
        [
          5,
          7,
          11
        ],
        [
          3,
          641
        ]
      ]
    },
    "2200": {
      "closed_size": 2,
      "a": 3,
      "b": 13,
      "b_squared": 169,
      "row_supports": [
        [
          13
        ],
        [
          3
        ]
      ]
    },
    "6142": {
      "closed_size": 66,
      "a": 3,
      "b": 5,
      "b_squared": 25,
      "row_supports": [
        [
          7,
          877
        ],
        [
          17,
          19
        ]
      ]
    }
  },
  "conventions": "Exact exhaustive sieve and trial extraction via SPF. Depth 2 means no success at depth 0 or 1, and is not an actual success-depth assertion. Roots k=0,1,2,5 refer to SAME N=2(P-1)."
}
exec(open('diagnostic_20260906.py').read().split('out={}')[0])
from fractions import Fraction

def radius2(N,P):
    if isprime[N-P]:return 0,0,[]
    qs=pf(N-P)
    if any(isprime[N-q] for q in qs):return 1,0,[]
    successes=[]
    cases=Counter()
    for q in qs:
        a=(P-2)//q
        for r in pf(N-q):
            if not isprime[N-r]:continue
            b=(N-q)//r
            assert q!=r and a>=3 and b>=3 and a%2==b%2==1
            assert b*r==(2*a-1)*q+2 and P==a*q+2
            g=N-r
            successes.append((q,r,a,b,g))
            assert gcd(q,b)==1
            assert gcd(r,2*a-1)==1
            assert gcd(b,2*a-1)==1
            A=(-2*pow(2*a-1,-1,b))%b
            if A==0:A=b
            R=((2*a-1)*A+2)//b
            forms=[(b,A),(2*a-1,R),(a*b,a*A+2),(2*a*b-2*a+1,2*a*A+2-R)]
            pairs=[(0,2),(0,1),(0,3),(2,1),(2,3),(1,3)]
            expected=[2*b,2,2*(b-1),2*(1-a),-2*(a*(b-1)+1),-2]
            actual=[forms[i][0]*forms[j][1]-forms[j][0]*forms[i][1] for i,j in pairs]
            assert actual==expected and all(actual)
    return (2 if successes else 3),len(successes),successes

out={}; cert=None; totalpaths=0
for lo,hi in [(1000,10000),(10000,100000),(100000,200000),(1000000,2000000)]:
    ps=primes[(primes>=lo)&(primes<hi)]
    c=Counter(); pathcount=0; regimes=Counter(); smallest={}
    for pp in ps:
        P=int(pp);N=2*(P-1)
        d,n,rows=radius2(N,P);c[d]+=1;pathcount+=n
        smallest.setdefault(d,N)
        for q,r,a,b,g in rows:
            regime=('L' if q*q<=lo else 'C')+('L' if r*r<=lo else 'C')
            regimes[regime]+=1
        if d==3 and cert is None:
            frontier1=pf(P-2)
            frontier2=sorted(set(r for q in frontier1 for r in pf(N-q)))
            cert={'P':P,'N':N,'root_row':pf(P-2),'first_rows':{q:pf(N-q) for q in frontier1},'second_rows':{r:pf(N-r) for r in frontier2}}
            assert all(not isprime[N-v] and N-v>1 for v in [P]+frontier1+frontier2)
    out[f'{lo}<=P<{hi}']={'prime_count':len(ps),'exact_success_depth_0_1_2_or_no_success_through_2':[c[j] for j in range(4)],'number_of_depth2_successful_paths_after_excluding_depth0_1':pathcount,'parameter_regimes_at_sqrt_lo':dict(regimes),'first_N_in_each_depth_category':smallest}
    totalpaths+=pathcount
out['certificate_complete_BAD_radius_two']=cert
out['all_radius2_identity_and_six_CC_determinant_checks']=f'passed for {totalpaths} actual successful length-two paths'
print(json.dumps(out,indent=2))
{
  "1000<=P<10000": {
    "prime_count": 1061,
    "exact_success_depth_0_1_2_or_no_success_through_2": [
      170,
      517,
      251,
      123
    ],
    "number_of_depth2_successful_paths_after_excluding_depth0_1": 397,
    "parameter_regimes_at_sqrt_lo": {
      "CL": 85,
      "CC": 70,
      "LL": 109,
      "LC": 133
    },
    "first_N_in_each_depth_category": {
      "1": 2016,
      "2": 2024,
      "0": 2040,
      "3": 2180
    }
  },
  "10000<=P<100000": {
    "prime_count": 8363,
    "exact_success_depth_0_1_2_or_no_success_through_2": [
      1019,
      3662,
      2363,
      1319
    ],
    "number_of_depth2_successful_paths_after_excluding_depth0_1": 3770,
    "parameter_regimes_at_sqrt_lo": {
      "LL": 1321,
      "LC": 1123,
      "CL": 746,
      "CC": 580
    },
    "first_N_in_each_depth_category": {
      "2": 20012,
      "0": 20016,
      "1": 20120,
      "3": 20324
    }
  },
  "100000<=P<200000": {
    "prime_count": 8392,
    "exact_success_depth_0_1_2_or_no_success_through_2": [
      936,
      3481,
      2543,
      1432
    ],
    "number_of_depth2_successful_paths_after_excluding_depth0_1": 4103,
    "parameter_regimes_at_sqrt_lo": {
      "LL": 1835,
      "CC": 426,
      "LC": 1056,
      "CL": 786
    },
    "first_N_in_each_depth_category": {
      "1": 200004,
      "3": 200084,
      "2": 200096,
      "0": 200304
    }
  },
  "1000000<=P<2000000": {
    "prime_count": 70435,
    "exact_success_depth_0_1_2_or_no_success_through_2": [
      6702,
      26908,
      22327,
      14498
    ],
    "number_of_depth2_successful_paths_after_excluding_depth0_1": 34880,
    "parameter_regimes_at_sqrt_lo": {
      "LL": 16192,
      "CL": 6598,
      "LC": 8591,
      "CC": 3499
    },
    "first_N_in_each_depth_category": {
      "1": 2000004,
      "3": 2000064,
      "0": 2000076,
      "2": 2000160
    }
  },
  "certificate_complete_BAD_radius_two": {
    "P": 1091,
    "N": 2180,
    "root_row": [
      3,
      11
    ],
    "first_rows": {
      "3": [
        7,
        311
      ],
      "11": [
        3,
        241
      ]
    },
    "second_rows": {
      "3": [
        7,
        311
      ],
      "7": [
        41,
        53
      ],
      "241": [
        7,
        277
      ],
      "311": [
        3,
        7,
        89
      ]
    }
  },
  "all_radius2_identity_and_six_CC_determinant_checks": "passed for 43150 actual successful length-two paths"
}

EXTERNAL-INPUT: PINTZ-GOLDBACH-EXCEPTIONAL-SET
STATUS: Exact theorem statement and hypotheses checked in primary paper.
Janos Pintz, A new explicit formula in the additive theory of primes with
applications II. The exceptional set in Goldbach's problem, Theorem 1,
arXiv:1804.09084v2 (30 April 2018), printed p.2.
https://arxiv.org/pdf/1804.09084
Writing E(Y) for the number of even n<=Y not expressible as two primes,
the theorem states E(Y)<Y^0.72 for Y above an ineffective constant.
Only the consequence E(4X)=o(X/log X) is used below. This run checked
the statement, not the entire 45-page proof and its prerequisite papers.
The exponent is an inherited external theorem, not improved in this run.
```
