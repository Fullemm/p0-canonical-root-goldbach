---
id: COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906
logical_id: COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906
version_id: COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906@research
kind: canonical-result
run: research
title: "Complete h1 first front rare success"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2105, line_end: 2172}
metadata: {"stable_id": "COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906", "version_id": "COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2105, "line_end": 2172}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2105, "line_end": 2172}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Complete h1 first front rare success

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS-20260906
STATUS: PROVED.
EXACT STATEMENT:
For X sufficiently large, the number of primes P in [X,2X] for which
N=2(P-1), root P, has a GOOD vertex at directed distance 0 or 1 is
 O(X*(loglog X)^2/(log X)^2).
Thus, with relative density one among primes P, P and EVERY prime
factor q of P-2 are BAD for this same N. This is a statement about the
COMPLETE radius-one frontier, including all large prime factors.
It does not say the traversal fails at later generations.

PROOF:
P is canonical because N/2=P-1 and P-1 is an even integer >2.
A GOOD root requires P-2 prime. The two-form sieve for n,n-2 counts
these primes by O(X/(log X)^2).
Otherwise m=P-2 is an odd composite. If a first-generation vertex q is
GOOD, write m=a*q, where q is an odd prime and a>=3 is odd. Then
 P=a*q+2,             N-q=(2a-1)*q+2
are both prime. Count such pairs (a,q); overcounting several GOOD
children of the same P is harmless.
For q<=sqrt X, fix q and sieve in a<=2X/q the two forms
 q*a+2,              2q*a+2-q.
They are primitive: gcd(q,2)=1 and gcd(2q,2-q)=1. Their determinant is
-q*(q+2), nonzero, and Delta=2q^3*(q+2)<=O(X^2). Except at ell=q
there is at least one root of their product modulo every prime ell
(the first form suffices unless ell=q). The uniform two-form consumer
therefore gives
 O(X*loglog X/(q*(log X)^2)).
Summing over prime q<=sqrt X costs O(loglog X), by the Euler-product
bound proved above, giving O(X*(loglog X)^2/(log X)^2).
For q>sqrt X, fix odd a>=3. Now a<=2sqrt X and q<=2X/a. Sieve in q
using the THREE forms
 q,                  a*q+2,                 (2a-1)*q+2.
All are primitive. Their pair determinants are 2, 2, 2(1-a), nonzero.
The product Delta is polynomially bounded in X. There is at least one
root modulo every prime, because the first form is q itself. Hence
the count for each a is
 O(X*(loglog X)^2/(a*(log X)^3)).
Sum over a<=2sqrt X; the harmonic sum is O(log X). The resulting bound
is again O(X*(loglog X)^2/(log X)^2). All prime values in the actual
count exceed the sieve's r, since q>sqrt X and P,N-q have size at least
X up to an absolute constant. The sieve variable in both cases has
upper limit >=sqrt X, verifying the uniformity premise. This proves
the asserted count.
PNT gives #{P in [X,2X]}~X/log X; dividing proves relative density one.
When the root is BAD, each q|m is active: a prime dividing q and N
would divide P, impossible since q<P. Also q<=m/3, so N-q>1. Removing
the prime case makes N-q positive composite, not a unit or inactive row.

HOSTILE CHECK:
The identity in the sieve is N-q=2a*q+2-q, not 2a*q+4-q.
The large-q range is NOT discarded as negligible and is NOT treated
with a short progression estimate. Switching to the small cofactor a
creates three distinct prime forms and controls that entire range.
This is the step absent from a small-child-only argument. The result
is relative to the thin family N/2+1 prime, not density one among all
even N. The union bound counts all first-front GOOD children; no
independence of primality and factorization is assumed.
DEPENDENCIES: The uniform two-/three-form sieve consumer; PNT only for
the relative-density interpretation. No conjectural prime tuples.
RELATION TO GOLDBACH: A rigorous limitation on shallow traversal in an
infinite canonical family. It neither supplies nor denies a Goldbach
representation using deeper reached vertices or other primes.
RELATION TO p0: Actual complete-frontier statement for canonical h=1.
Nearby roots for the SAME N are tested in the next result.
WHAT REMAINS OPEN: Complete radius-two control, and every fixed depth.
NOVELTY: NOT YET AUDITED.
```
