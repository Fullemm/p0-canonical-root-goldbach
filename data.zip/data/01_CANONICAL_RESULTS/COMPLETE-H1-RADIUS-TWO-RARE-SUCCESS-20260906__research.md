---
id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906
logical_id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906
version_id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906@research
kind: canonical-result
run: research
title: "Complete h1 radius two rare success"
status: PROVED
status_raw: "PROVED (new full-generation extension; proof audited case by case)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2447, line_end: 2609}
metadata: {"stable_id": "COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906", "version_id": "COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2447, "line_end": 2609}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2447, "line_end": 2609}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Complete h1 radius two rare success

*Run research - status `PROVED` (raw: `PROVED (new full-generation extension; proof audited case by case).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906
STATUS: PROVED (new full-generation extension; proof audited case by case).
EXACT STATEMENT:
Let P range over primes in [X,2X], N=2(P-1), canonical root P. The
proportion of these P for which ANY vertex at directed distance <=2
from P is GOOD tends to zero as X tends to infinity. In particular
there are infinitely many canonical h=1 roots whose COMPLETE radius-two
neighbourhood consists of BAD vertices.
More quantitatively, with L=log X and l=loglog X, the number of exceptional
P is O((X/L)*(l^3/L)^(1/5)). This bound is asymptotic with an absolute
constant; it is not an asserted numerical proportion at small X.
No conclusion is made about distance three or eventual traversal failure.

PROOF:
Success at distance <=1 is already counted by O(X*l^2/L^2). Consider a
shortest successful path P -> q -> r with q BAD and r GOOD. Put
 a=(P-2)/q,       b=(N-q)/r,       g=N-r.
Then q,r,P,g are odd primes, a,b are odd integers >=3, q!=r, and
 P=a*q+2,
 b*r=(2a-1)*q+2,
 g=2a*q+2-r.                                               (T)
We have q<(2/3)X, r<(4/3)X, P>=X, and g>2N/3>=cX.
Fix 0<eta<1/8, initially independent of X. Remove all P for which
P-2 has a prime divisor q in
 [X^(1/2-eta), X^(1/2+eta)].                                (BAND)
For a fixed prime q here, the one-form FKL bound applied to q*a+2,
a<=2X/q, gives O(X/(q*L)), uniformly for eta<1/8. Indeed its singular
series is (1-1/q)^(-1)<=3/2, its B is log(q)/q, and log(2X/q)>=3L/8.
Partial summation using pi(t)=O(t/log t) gives
 sum_(q in BAND prime)1/q=O(eta+1/L).
Consequently at most O((eta+1/L)*X/L) starting primes are removed.
This is a count of a factor occurrence, not an independence assertion.

Every remaining path has either q<X^(1/2-eta) or q>X^(1/2+eta).
Split also at r=sqrt X. In each of the following four cases we obtain
an arithmetic progression with at least a power of X available for
sieving. The product of the fixed parameters is <=8X^(1-eta).
All stated sieve-variable upper limits are therefore >=cX^eta.

CASE LL: q<X^(1/2-eta), r<=sqrt X. Fix the two distinct primes q,r.
The conditions are P=2 modulo q and 2P=2+q modulo r. They specify one
class A modulo q*r. Choose 1<=A<=q*r and write P=A+q*r*t. Since
q*r<X and P>=X, t>=1 and t<=2X/(q*r).
Sieve the TWO forms P and g=2P-2-r. Their determinant is
 -(q*r)*(r+2), nonzero. If either is imprimitive, its fixed divisor is
at most 2q*r=o(X), smaller than its actual prime value, so that class
has no solutions and can be discarded. Their common leading primes
are only q,r; away from those primes there is a root of the first
form (with the harmless factor 2 handled by its odd leading coefficient).
Thus their singular series is O(l), since at most two odd primes can
have nu=0, each contributing a bounded local factor. FKL bounds this
case for each q,r by
 O(X*l/(q*r*(eta*L)^2)).
Summing reciprocals of q,r over primes <=2X gives O(l^2). The total is
 O(X*l^3/(eta^2*L^2)).

CASE LC: q<X^(1/2-eta), r>sqrt X. Fix the prime q and the odd integer
b=(N-q)/r<=4sqrt X. The congruences are P=2 modulo q and
2P=2+q modulo b. They are compatible only if gcd(q,b)=1: otherwise
q|b would imply q|2. Because b is odd, the compatible case gives one
class A modulo q*b. Write P=A+q*b*t, 1<=A<=q*b, so t>=1 and
t<=2X/(q*b). The THREE prime forms are
 P=A+q*b*t,
 r=(2A-2-q)/b+2q*t,
 g=2P-2-r.
All coefficients are positive. Their leading coefficients are q*b,
2q, 2q*(b-1). For large X each is smaller than its actual prime value:
q*b<=4X^(1-eta), P,g>=cX, and 2q<sqrt X<r. Therefore an imprimitive
form has no actual prime solutions and is discarded.
To check the determinants, regard P=(b*r+q+2)/2 and
g=(b-1)*r+q as affine forms in r. The three relevant nonzero constants
are q+2, q, and q-2(b-1). The last cannot vanish: q is odd and
2(b-1) even. Changing to the t parameter preserves nonvanishing.
The leading coefficient 2q of r gives a root at every odd prime except
q; at 2, the leading coefficient q*b of P is odd. Hence S=O(l^2).
The contribution for fixed q,b is
 O(X*l^2/(q*b*(eta*L)^3)).
The reciprocal prime sum costs O(l), and the reciprocal b sum O(L).
This case contributes O(X*l^3/(eta^3*L^2)).

CASE CL: q>X^(1/2+eta), r<=sqrt X. Fix odd a=(P-2)/q<=2X^(1/2-eta)
and the prime r. The condition r|((2a-1)q+2) forces gcd(r,2a-1)=1;
otherwise the odd prime r would divide 2. Thus q=A+r*t is a unique
progression with 1<=A<=r, t>=1, t<=2X/(a*r).
Sieve the THREE forms q, P=a*q+2, g=2a*q+2-r. Before substituting
q=A+r*t, their pair determinants are 2, 2-r, -a*(r+2), all nonzero.
Their t-coefficients are r,a*r,2a*r. They are smaller than their actual
prime values because q>sqrt X>=r and a*r<=2X^(1-eta). Discard any
imprimitive forms, which therefore have no solutions. The first form
has a root at every prime except possibly r, so S=O(l^2).
The count for each a,r is O(X*l^2/(a*r*(eta*L)^3)). Sum over a and
prime r to get O(X*l^3/(eta^3*L^2)).

CASE CC: q>X^(1/2+eta), r>sqrt X. Fix odd a<=2X^(1/2-eta) and
b<=4sqrt X. The relation b*r=(2a-1)q+2 forces gcd(b,2a-1)=1, since
this odd gcd divides 2. Thus q=A+b*t for a unique 1<=A<=b. For large
X, q>X^(1/2+eta)>b, so t>=1, and t<=2X/(a*b). Let
 R=((2a-1)*A+2)/b, an integer. The FOUR prime forms in t are
 q=A+b*t,
 r=R+(2a-1)*t,
 P=a*A+2+a*b*t,
 g=2a*A+2-R+[2a*b-2a+1]*t.
All coefficients are positive. The coefficients of q,r are <their
actual prime values since b<q and 2a-1<r for large X. The coefficients
of P,g are <=16X^(1-eta)=o(X), also smaller than their actual values.
Therefore nonprimitive forms again give no solutions. Their six
pairwise determinants, in the order (q,P),(q,r),(q,g),(P,r),(P,g),(r,g),
are
 2b, 2, 2(b-1), 2(1-a), -2[a(b-1)+1], -2.
They are all nonzero for a,b>=3. Moreover gcd(b,2a-1)=1, so at least
one of the first two forms has invertible leading coefficient modulo
every prime. Hence nu(ell)>=1 for all ell and S=O(l^3).
The count is O(X*l^3/(a*b*(eta*L)^4)). Two harmonic sums over a,b
cost O(L^2), giving O(X*l^3/(eta^4*L^2)).

In all four cases, the representatives, coefficients and determinants
are bounded by fixed powers of X; B_FKL=O(l) uniformly. For fixed eta
the sieve exponential is bounded, and adding the four cases gives
 O(X*l^3/(eta^4*L^2)). Adding BAND and radius-one exceptions, and
dividing by X/L, gives
 O(eta+1/L+l^2/L+l^3/(eta^4*L)).                             (R2)
For each fixed eta the last three terms tend to zero. Letting eta
decrease to zero proves the qualitative relative-density-one claim.
For the quantitative claim choose eta=(l^3/L)^(1/5). Then eta<1/8
for large X, eta*L tends to infinity much faster than l, and all the
coefficient-vs-prime comparisons above remain valid. The FKL hypotheses
and its bounded exponential factor hold uniformly, since every sieve
variable limit is >=cX^eta and B_FKL=O(l)=o(eta*L). Factors eta^(-r)
from the denominator were already retained explicitly. Thus (R2)
is O((l^3/L)^(1/5)), as claimed.
After excluding success at distances 0,1,2, every vertex in this complete
radius-two neighbourhood is active with positive composite complement:
activity propagates along edges, and children of BAD rows are <N/3.
This is exactly the asserted stopped-graph conclusion.

HOSTILE CHECK:
The proof counts a shortest successful path, but bounds the UNION of
all such paths. That is sufficient to exclude every GOOD vertex in the
complete radius-two frontier. It is not a selected-path construction.
The exceptional BAND covers every possible first child in that size
range, even if it is not on a shortest path. Removing it is an upper
bound, hence safe. Its estimate uses a one-form prime progression bound,
not an assumption that shifted-prime factors behave independently.
The four switches cover all remaining q,r, and none silently applies
an asymptotic in a progression with only O(1) terms. The positive t>=1
checks avoid adding one unsieved term for every parameter pair.
The equations are for h=1. Replacing 2 by 2h in (T) can introduce
nontrivial common divisors in the progression moduli; this proof is
NOT automatically a theorem for neighbouring roots or general h.
A third generation is not obtained by repeating this four-case argument:
three selected smaller parameters can already have product >X on a
region of nonvanishing size. That requires a new counting input.
DEPENDENCIES: FKL Lemma 5.1, including its k=1 case; Chebyshev upper
prime count; PNT for relative prime density. No lower prime-tuple bound.
RELATION TO GOLDBACH: Rules out a universal depth-two canonical solver
on the h=1 family, and shows depth-two success is rare there. It leaves
eventual success and all ordinary Goldbach representations untouched.
RELATION TO p0: A negative theorem about complete depth two at p0. The
same-N nearby-prefix theorem currently remains proved only at depth one.
WHAT REMAINS OPEN: Complete radius three, arbitrary fixed radius, and
any positive restriction forbidding a closed BAD reachable set.
NOVELTY: NOT YET AUDITED.
```
