---
id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS@research
logical_id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS
version_id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS@research
kind: historical-version
run: research
title: "Complete h1 radius two rare success"
status: SUPERSEDED
status_raw: "almost every prime start P in"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3320, line_end: 3323}
metadata: {"stable_id": "COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS", "version_id": "COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3320, "line_end": 3323}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3320, "line_end": 3323}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Complete h1 radius two rare success

*Run research - status `SUPERSEDED` (raw: `almost every prime start P in`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS-20260906` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
1. COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS: almost every prime start P in
   the h=1 family has its entire radius-two neighbourhood BAD, with
   exceptional proportion O(((loglog X)^3/log X)^(1/5)). Four explicit
   sieve switches control both generations, including large factors.
```
