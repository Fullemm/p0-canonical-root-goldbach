---
id: COMPLETE-H1-TWO-ROW-FINITENESS-20260905
logical_id: COMPLETE-H1-TWO-ROW-FINITENESS-20260905
version_id: COMPLETE-H1-TWO-ROW-FINITENESS-20260905@research
kind: canonical-result
run: research
title: "Complete h1 two row finiteness"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 187, line_end: 225}
metadata: {"stable_id": "COMPLETE-H1-TWO-ROW-FINITENESS-20260905", "version_id": "COMPLETE-H1-TWO-ROW-FINITENESS-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 187, "line_end": 225}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 187, "line_end": 225}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Complete h1 two row finiteness

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: COMPLETE-H1-TWO-ROW-FINITENESS-20260905
STATUS: PROVED.
EXACT STATEMENT:
Fix a finite set S of odd primes, s=|S|. There are at most
s * 2^(9s+16) even integers N with P=N/2+1 prime, m=N-P=P-2>1,
PF(m) subset S, and PF(N-q) subset S for q=min PF(m).
No assertion of complete traversal failure is assumed; N-q need not be BAD.
PROOF:
For each such N the selected q belongs to S. Write v=N-q=2m+2-q.
Any common prime divisor of m and v divides q-2 and is at least q by
minimality of q. Since 0<q-2<q, this is impossible. Hence gcd(m,v)=1.
Apply COPRIME-SUPPORTED-AFFINE-COUNT with (u,v)=(m,N-q) and
A=2, B=-1, C=q-2. The equation 2m-v=q-2 has nonzero right side.
For each of the s choices of q there are at most 2^(9s+16) possible pairs.
Each m determines N=2m+2 uniquely. Summing proves the bound.
HOSTILE CHECK:
Uses the COMPLETE supports of m AND N-q. Specifying only selected divisors
of these rows does not satisfy the hypotheses. The theorem allows m prime,
so restricting it to BAD roots only reduces the set. N-q is positive for
all admitted N, because q<=m<N. q is odd and q-2 is never zero.
DEPENDENCIES: Elementary h=1 minimum-factor orthogonality (reproved above)
and COPRIME-SUPPORTED-AFFINE-COUNT.
IMPLICATION:
A fixed finite alphabet cannot carry complete root and next-generation rows
for infinitely many canonical h=1 inputs, even when all exponents vary.
This gives a quantitative obstruction to the strong/full-support reading of
FBTU, beyond the elementary observation that fixing all factors AND all
exponents fixes N. Partial CRT programming survives.
RELATION TO HISTORICAL FAILURES:
The corpus already warns that fixed-S finiteness is not a moving-S proof.
We do NOT use this as a Goldbach closer. Its consumer here is a correction
to an infinite full-transcript assertion with genuinely FIXED labels.
RELATION TO GOLDBACH: Does not rule out a single failed world.
RELATION TO p0 EXCEPTIONALITY: A real arithmetic restriction in the h=1
subfamily, but not a distinction between all p0 and all nearby roots.
WHAT REMAINS OPEN: Complete BAD neighbourhoods with moving prime labels;
existence of arbitrarily large shortest GOOD depth for canonical roots.
NOVELTY: NOT YET AUDITED.
```
