---
id: CORE-REDUCTION-20260907J
logical_id: CORE-REDUCTION-20260907J
version_id: CORE-REDUCTION-20260907J@J
kind: canonical-result
run: J
title: "Core reduction"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 153, line_end: 189}
metadata: {"stable_id": "CORE-REDUCTION-20260907J", "version_id": "CORE-REDUCTION-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 153, "line_end": 189}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 153, "line_end": 189}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1084, style: ID-TABLE}
---

# Core reduction

*Run J - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T2.  CORE-REDUCTION-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let K be the family of nonempty Gamma_N-closed BAD subsets of A.
If K is nonempty then:
  (i)   K is closed under unions and under nonempty intersections; B_N is its
        maximum (restricted to {p < N/3}, which costs nothing by T3(a));
  (ii)  the minimal members of K are exactly the terminal strongly connected
        components of the digraph induced on B_N;
  (iii) every minimal member T is strongly connected, source-free
        (Src(T) = empty), and satisfies |T| >= 2;
  (iv)  every member of K contains a minimal member.
We call a minimal member a CORE.

PROOF.
(i) If S, S' are closed then Gamma_N(S u S') = Gamma_N(S) u Gamma_N(S')
subseteq S u S', and Gamma_N(S ^ S') subseteq S ^ S'; badness is inherited.
(iv) Let S in K and p in S.  Reach(p) (forward closure) is nonempty, closed,
BAD and contained in S.  Iterating p -> some q in Reach(p) with
Reach(q) strictly smaller gives a strictly decreasing chain of finite sets;
it terminates at a T with Reach(q) = T for every q in T.
(ii) If T is minimal then for each q in T, Reach(q) in K and Reach(q) subseteq T,
so Reach(q) = T; hence T is strongly connected and closed, i.e. a terminal SCC.
Conversely let C be a terminal SCC and D subseteq C nonempty closed; pick q in D;
then C = Reach(q) subseteq D, so D = C.
(iii) Suppose |T| = 1, T = {p}.  Closedness gives PF(N-p) subseteq {p}, and
N-p > 1 (unit rows are excluded, and p < N/3 forces N-p > 2N/3 > 1), so
N-p = p^e with e >= 1, hence p | N, contradicting activity (T1).  So |T| >= 2,
and strong connectivity of a set with at least two vertices gives every vertex
an in-edge inside T, i.e. Src(T) = empty.  QED

REMARK.  (iii) upgrades the corpus's raw-appendix observation ("a terminal SCC
exists; it has at least two vertices by activity") to the full lattice picture,
and (ii) makes cores canonical objects rather than an existence statement.
Empirically the cores are much smaller than B_N: sizes 8, 28, 21, 14, 2, 10
against |B_N| = 10, 55, 55, 41, 2, 66.

--------------------------------------------------------------------------------
```
