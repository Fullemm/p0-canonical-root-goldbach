---
id: CORE-SIZES-20260907J
logical_id: CORE-SIZES-20260907J
version_id: CORE-SIZES-20260907J@J
kind: canonical-result
run: J
title: "Core sizes"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 487, line_end: 501}
metadata: {"stable_id": "CORE-SIZES-20260907J", "version_id": "CORE-SIZES-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 487, "line_end": 501}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 487, "line_end": 501}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1096, style: ID-TABLE}
---

# Core sizes

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X4.  CORE-SIZES-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
Terminal SCCs of Gamma_N restricted to B_N, six hosts.  Each host has exactly
ONE core:
   N=128   core size  8, max  41 : {3,5,7,11,13,23,29,41}
   N=1718  core size 28, max 571
   N=1862  core size 21, max 619
   N=1928  core size 14, max 641
   N=2200  core size  2, max  13 : {3,13}
   N=6142  core size 10, max 877 : {3,5,7,13,17,19,157,227,409,877}
Lemmas T4, T5 verified on all six: the divisor sets are single residue classes,
the count bound holds, max(core) divides exactly one row (N-5, N-5, N-5, N-5,
N-3, N-3 respectively), and no core has a source.

--------------------------------------------------------------------------------
```
