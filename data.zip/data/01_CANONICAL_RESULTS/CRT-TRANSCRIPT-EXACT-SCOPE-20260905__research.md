---
id: CRT-TRANSCRIPT-EXACT-SCOPE-20260905
logical_id: CRT-TRANSCRIPT-EXACT-SCOPE-20260905
version_id: CRT-TRANSCRIPT-EXACT-SCOPE-20260905@research
kind: canonical-result
run: research
title: "Crt transcript exact scope"
status: PROVED
status_raw: "PROVED (precise repair of FACP, not a novelty claim)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 105, line_end: 135}
metadata: {"stable_id": "CRT-TRANSCRIPT-EXACT-SCOPE-20260905", "version_id": "CRT-TRANSCRIPT-EXACT-SCOPE-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 105, "line_end": 135}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 105, "line_end": 135}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Crt transcript exact scope

*Run research - status `PROVED` (raw: `PROVED (precise repair of FACP, not a novelty claim).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: CRT-TRANSCRIPT-EXACT-SCOPE-20260905
STATUS: PROVED (precise repair of FACP, not a novelty claim).
EXACT STATEMENT / HYPOTHESES:
Fix finitely many integer affine forms L_j(P)=a_j P+b_j and finitely many
requirements v_l(L_j(P))=e or v_l(L_j(P))>=e. Assume all conditions admit
one residue class P=A mod M with gcd(A,M)=1; for an exact valuation include
l^(e+1) in M. Assume every form required to be composite has a specified
prime divisor and is positive and tends to infinity along the progression.
Then infinitely many primes P realize these conditions; every required
composite form is composite for all sufficiently large such P. These P
are canonical roots of N=2(P-1), h=1.
PROOF:
The constraints are unions of residue classes for finite prime-power
moduli. Choose the assumed common reduced class A mod M. Dirichlet's
theorem supplies infinitely many primes in it. Exact valuations are decided
mod l^(e+1), lower valuations mod l^e. A growing positive form divisible
by a fixed prime eventually exceeds that prime. Finally P-1 is an even
composite integer for P>=5, proving canonicity. No assertion about the
unprescribed cofactors occurs in the proof.
HOSTILE CHECK:
Conditions involving the same prime are NOT independently programmable.
For a fixed-label edge a->b in an h=1 world one needs
2P=a+2 mod b; if b also divides P-2, compatibility forces a=2 mod b.
If b divides a+2, the edge may instead force P=0 mod b, violating the
reduced-class hypothesis. Compatibility must be checked, not waved away.
DEPENDENCIES: CRT and Dirichlet's theorem on reduced progressions.
RELATION TO GOLDBACH: No global failure hypothesis or conclusion.
RELATION TO p0 EXCEPTIONALITY: Shows a precise class of partial local
constraints is compatible with p0; does not cover complete BFS closure.
WHAT REMAINS OPEN: Uniform control of all unprescribed child factors.
```
