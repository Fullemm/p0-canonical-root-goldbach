---
id: DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G
logical_id: DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G
version_id: DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G@research
kind: canonical-result
run: research
title: "COROLLARY-"
status: VERIFIED COMPUTATION
status_raw: "PROVED EFFECTIVE EXHAUSTION plus the independent exact computation."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6692, line_end: 6719}
metadata: {"stable_id": "DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G", "version_id": "DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6692, "line_end": 6719}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6692, "line_end": 6719}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# COROLLARY-

*Run research - status `VERIFIED COMPUTATION` (raw: `PROVED EFFECTIVE EXHAUSTION plus the independent exact computation.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY-ID: DANGEROUS-MIRROR-TRANSPLANTS-GLOBALLY-EXHAUSTED-20260907G
STATUS: PROVED EFFECTIVE EXHAUSTION plus the independent exact computation.
For every odd m<=3053 and every k<=74, n<=74+763+2=839. Thus
 P<R_839<3356*log(3356)<30204,
 N<33257.
The deliberately loose final numerical inequality needs no floating
rounding: e>5/2 and (5/2)^9>3356 give log(3356)<9.
The audited scan to N<=200000 therefore covers EVERY realization over
ALL N of the 214 dangerous mirrors at the nine candidate ranks
 K={10,14,26,28,30,62,63,71,74}.
Consequently, the total is globally EXACTLY 4035 realizations, with
ZERO failed traversals and exactly 147 one-GOOD-edge worlds.
This upgrades the domain of the 07F transplant statement: it is a
complete finite set, not merely a test that might acquire further
realizations above 200000. The control-rank totals displayed above are
also globally exhaustive, since every control rank is at most 74.
SCOPE:
This is not universal safety of these ranks. It excludes failure only
for this FIXED list of 214 exact integers m. New mirrors, changed
exponents, and new closed BAD structures are not covered. It does not
prove the global six-host conjecture. This global finite-fibre conclusion
does not rely on the external EAC census through 10^8.
RESEARCH CONSEQUENCE:
Increasing the N cutoff while keeping this mirror list and these ranks
cannot add any case at all. Further transplant research must vary the
exact mirrors or the ranks; continued scanning of these same fibres is
mathematically exhausted.
```
