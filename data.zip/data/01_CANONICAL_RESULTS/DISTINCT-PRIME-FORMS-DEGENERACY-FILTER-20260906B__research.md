---
id: DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B
logical_id: DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B
version_id: DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B@research
kind: canonical-result
run: research
title: "Distinct prime forms degeneracy filter"
status: PROVED
status_raw: "PROVED; elementary lemma used to audit five-form switches."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3449, line_end: 3483}
metadata: {"stable_id": "DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B", "version_id": "DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3449, "line_end": 3483}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3449, "line_end": 3483}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Distinct prime forms degeneracy filter

*Run research - status `PROVED` (raw: `PROVED; elementary lemma used to audit five-form switches.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: DISTINCT-PRIME-FORMS-DEGENERACY-FILTER-20260906B
STATUS: PROVED; elementary lemma used to audit five-form switches.
EXACT STATEMENT:
Suppose a parametrized arithmetic configuration requires k integer
linear forms L_i(t)=u_i*t+v_i, with u_i>0, to take pairwise DISTINCT
prime values, each greater than u_i. If one form is imprimitive, or
if a pair of primitive forms has zero determinant u_i*v_j-u_j*v_i,
then the configuration has no solutions.
PROOF:
If d=gcd(u_i,v_i)>1, it divides every value and satisfies d<=u_i<L_i(t);
no such value is prime. If two primitive coefficient vectors are
proportional with positive ratio lambda, Bezout for each vector shows
both lambda and 1/lambda are positive integers. Hence lambda=1 and
the forms are identical. Their values cannot be distinct. This proves
both exclusions. A zero constant term causes no exception to Bezout.
HOSTILE CHECK: The coefficient-versus-value comparison and DISTINCT
prime-value requirement must be proved from the actual configuration.
Neither is automatic for arbitrary linear forms. The filter excludes
parameter choices with no actual solutions; it does not count their
solutions by an incorrectly high-dimensional sieve.
DEPENDENCIES: Bezout and primality. NOVELTY: NOT YET AUDITED.

SIEVE EXTENSION 2026-09-06B:
UNIFORM-FEW-FORMS-SIEVE-CONSUMER applies unchanged to k=5 (as well as
k=2,3,4): the primary FKL lemma permits every fixed k. Write
L=log X, l=loglog X. If coefficients and nonzero determinants are
bounded by fixed powers of X, log z>=c*eta*L, z<=X^C, and
L^(-1/4)<=eta<=1/8, then B_FKL=O(l)=o(eta*L). Thus the sieve count
is O(z*S/(eta*L)^k), with an absolute constant when k<=5 and c,C
are fixed. The earlier Euler-product proof gives S=O(l^(k-1)) when
nu(ell)>=1 at every prime. The same bound survives at most TWO
exceptional odd primes where nu may vanish, since each extra local
factor is bounded by a fixed power of 3/2. No fixed-coefficient-only
asymptotic is substituted for the uniform FKL statement.
```
