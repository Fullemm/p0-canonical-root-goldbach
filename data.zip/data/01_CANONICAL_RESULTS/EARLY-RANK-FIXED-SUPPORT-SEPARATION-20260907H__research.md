---
id: EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H
logical_id: EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H
version_id: EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H@research
kind: canonical-result
run: research
title: "Early rank fixed support separation"
status: PROVED
status_raw: "PROVED. Quantitative restriction on COMPLETE factorizations,"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 7463, line_end: 7534}
metadata: {"stable_id": "EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H", "version_id": "EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7463, "line_end": 7534}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7463, "line_end": 7534}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Early rank fixed support separation

*Run research - status `PROVED` (raw: `PROVED. Quantitative restriction on COMPLETE factorizations,`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: EARLY-RANK-FIXED-SUPPORT-SEPARATION-20260907H
STATUS: PROVED. Quantitative restriction on COMPLETE factorizations,
without any assumption about BAD closure or the BFS verdict.

Let S be a fixed nonempty finite set of odd primes, s=|S|, and put
  A(S)=1.4*30^(s+3)*s^(9/2)*product_(q in S) log q,
  c(S)=(log(3)/exp(1))^A(S)/6.
All logarithms are natural. Let N be sufficiently large and even. If
  N/2<=p_i<p_j<=2N/3
and both m_i=N-p_i and m_j=N-p_j have ALL prime factors in S, then
  j-i > c(S)*N^(19/40)/(log N)^A(S).                 (H2-rank)
The indices are the usual ZERO-based ranks among primes >=N/2.
The constant is not intended to be numerically useful.

In particular, for every fixed epsilon with 0<epsilon<19/40,
for all sufficiently large even N there is AT MOST ONE S-smooth
complement among
  N-p_0, ..., N-p_floor(N^(19/40-epsilon)).          (H2-prefix)
This includes every fixed prefix p_0,...,p_K. It is a pointwise eventual
statement, not just a density estimate. The excluded S=empty case is
trivial: its only smooth positive integer is 1, while these complements
are eventually >=N/3.

Proof of complete-support separation.
The verified rational real-field Matveev estimate recorded earlier in
MATVEEV-IN-BMS-9.4 applies to
  Lambda=m_i/m_j-1=(p_j-p_i)/m_j >0.
For q in S write b_q=v_q(m_i)-v_q(m_j). Since m_i,m_j<N and q>=3,
  |b_q|<=log N/log 3.
At least one b_q is nonzero. Omit zero coefficients and then enlarge
back to S; log q>1 for every odd prime makes this enlargement harmless.
The already verified estimate gives
  log Lambda > -A(S)*(1+log(log N/log 3)),
and, since m_j>=N/3,
  p_j-p_i > (N/3)*(log(3)/exp(1))^A(S)/(log N)^A(S). (H2-distance)
No coprimality between the two complements is needed.

External prime-gap input, checked in the original paper:
R. C. Baker, G. Harman, J. Pintz, The difference between consecutive
primes, II, Proc. London Math. Soc. 83 (2001), 532-562, Theorem 1.
https://www.cs.umd.edu/~gasarch/BLOGPAPERS/BakerHarmanPintz.pdf
For all sufficiently large real x, [x-x^0.525,x] contains a prime.
We need only this established exponent, not an optimal current exponent.

If u<v are adjacent primes in [N/2,2N/3], apply that theorem at
x=v-1/2. Its prime is at most u, so
  v-u <= 1/2+(v-1/2)^0.525 <= 2*N^0.525.
Summing the j-i adjacent gaps yields
  p_j-p_i<=2*(j-i)*N^0.525.
Combine with H2-distance and use 1-0.525=19/40 to prove H2-rank.

For completeness, the growing prefix in H2-prefix lies in the required
interval for sufficiently large N. For N/2<=x<=2N/3, the same external
theorem applied at x+2*N^0.525 supplies a prime in (x,x+2*N^0.525],
provided this right endpoint is <=N and N is sufficiently large.
Iteration, starting at N/2, therefore gives
  p_j<=N/2+2*(j+1)*N^0.525
until the bound reaches 2N/3. For j<=N^(19/40-epsilon) it stays below
2N/3 for sufficiently large N, because the additional term is o(N).
If two complements in this prefix were S-smooth, H2-rank would imply
  N^(19/40-epsilon)>c(S)*N^(19/40)/(log N)^A(S),
which is false for all sufficiently large N. This proves the result.
The harmless possibility p_0=N/2 when N/2 is prime is covered too.

Effectivity and attribution. The analytic threshold exists; no usable
numerical value of it was computed in this run. Matveev's input is the
same classical smooth-number separation mechanism already used for
closed BAD labels in this checkpoint. The new consumer is a quantitative
separation of RANKS of two smooth first complements, even without any
closed graph, and the resulting growing prime prefix. It must not be
presented as a new theorem on general gaps between smooth numbers.
```
