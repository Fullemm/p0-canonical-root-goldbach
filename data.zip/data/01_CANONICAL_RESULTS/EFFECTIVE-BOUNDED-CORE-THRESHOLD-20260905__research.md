---
id: EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905
logical_id: EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905
version_id: EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905@research
kind: canonical-result
run: research
title: "Effective bounded core threshold"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 464, line_end: 500}
metadata: {"stable_id": "EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905", "version_id": "EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 464, "line_end": 500}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 464, "line_end": 500}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Effective bounded core threshold

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: EFFECTIVE-BOUNDED-CORE-THRESHOLD-20260905
STATUS: PROVED.
EXACT STATEMENT:
For real y>=5, put s_y=#{odd primes <=y},
  A_y=1.4*30^(s_y+3)*s_y^(9/2)*product_(3<=q<=y, prime) log q,
  D_y=A_y+log(2y),
  F(y)=exp(2 D_y log(2 D_y)).
If an even N admits ANY nonempty closed active BAD set C with max C<=y,
then N<F(y). Thus N>=F(y) excludes all such sets, regardless of their
branching and cardinality. F is explicit and effectively computable.

PROOF:
When N<=2y the bound is immediate because D_y>log(2y) and F(y)>2y.
When N>2y, use (H), A(C)<=A_y, M<=y, and t=log N>1 to get
  t-log(2y) < A_y*(1+log t).
Indeed log((N-M)/M)>=log((N-y)/y)>t-log(2y), while log3>1
implies log(t/log3)<log t. Consequently t<D_y*(1+log t).
For any D>=1, the inequality t<D(1+log t), t>1, implies
  t<2D log(2D).
To verify it, put t_0=2D log(2D), u=log(2D)>0. Then
 t_0/D-(1+log t_0)=u-1-log u>=0.
The function t/D-1-log t is strictly increasing for t>D, and t_0>D.
Thus t>=t_0 is impossible. Apply this with D=D_y and exponentiate.

HOSTILE CHECK:
A_y is a uniform envelope for ALL choices of C inside primes <=y.
The bound is enormous and is not a practical census endpoint even for small y.
It bounds N for a specified maximum label y; it is NOT a Goldbach N_0.
It supplies the height control that BS counting alone does not provide.

RELATION TO HISTORICAL FAILURES:
The old Matveev support lemma required |R|>=b+2 to obtain two rows with
labels <=sqrt N. This proof removes that condition: it uses arbitrary
distinct rows and max C as their gap bound. If max C is already large,
the desired small-support exclusion is automatic. The old warning about
huge constants and moving/unbounded support still applies.
```
