---
id: EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G
logical_id: EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G
version_id: EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G@research
kind: canonical-result
run: research
title: "Effective finite rank mirror fibres"
status: PROVED
status_raw: "PROVED using an explicitly identified prime-counting theorem."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6660, line_end: 6691}
metadata: {"stable_id": "EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G", "version_id": "EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6660, "line_end": 6691}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6660, "line_end": 6691}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Effective finite rank mirror fibres

*Run research - status `PROVED` (raw: `PROVED using an explicitly identified prime-counting theorem.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: EFFECTIVE-FINITE-RANK-MIRROR-FIBRES-20260907G
STATUS: PROVED using an explicitly identified prime-counting theorem.
Let m>=1 be odd, P>m an odd prime, N=P+m and P=p_k(N), k>=0.
Set c(m)=ceil((m-1)/4), n=k+c(m)+2. Then
 P < R_n < 4*n*log(4*n),
 N < m+4*n*log(4*n).
Here R_n is the nth Ramanujan prime. Thus for EVERY fixed pair (k,m)
there are only finitely many realizations, with an effective upper bound.
For m>=3 that finite set is nonempty by the audited surjectivity theorem.
The apparent tension disappears: surjectivity over ranks does not imply
infinitely many realizations at a fixed rank.
PROOF:
Put H(P)=pi(P)-pi(P/2). The interval (P/2,P] contains H(P) primes.
To obtain [(P+m)/2,P), remove P and the primes in
 (P/2,(P+m)/2).
The latter interval contains exactly (m-1)/2 integers. For P>=5 all
these primes are odd, so there are at most c(m) of them. The only
remaining case P=3,m=1 removes no integers and satisfies the same bound.
Therefore k>=H(P)-1-c(m). If P>=R_n, the defining property of R_n
gives H(P)>=n=k+c(m)+2, hence k>=k+1, a contradiction.
EXTERNAL INPUT:
J. Sondow, Ramanujan Primes and Bertrand's Postulate, Theorem 2:
 R_n < 4*n*log(4*n) for every n>=1.
Primary source https://arxiv.org/pdf/0907.5232, pages 2-3 of the PDF.
Only this established bound and the definition of R_n are imported;
the rank/mirror argument above is the present elementary application.
Logarithms are natural. No EAC census or twin-core classification enters.
BOUNDARY CHECK:
The deletion is an OPEN interval at both ends; if (P+m)/2 is prime it
must remain in the rank count. Removing exactly (m-1)/2 integers respects
this. The prime P itself contributes the separate subtraction of one.
```
