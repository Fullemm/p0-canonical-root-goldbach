---
id: ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905
logical_id: ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905
version_id: ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905@research
kind: canonical-result
run: research
title: "FAIL-"
status: KILLED
status_raw: "KILLED AS AN INFERENCE; the two-generation theorem remains PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1869, line_end: 1899}
metadata: {"stable_id": "ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905", "version_id": "ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905@research", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1869, "line_end": 1899}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1869, "line_end": 1899}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `KILLED` (raw: `KILLED AS AN INFERENCE; the two-generation theorem remains PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: ENVELOPE-ESCAPE-AUTOMATIC-ITERATION-20260905
STATUS: KILLED AS AN INFERENCE; the two-generation theorem remains PROVED.
CLAIM / ROUTE: Iterate H1-ALL-BRANCH-INJECTIVE-ESCAPE until a finite graph
cannot contain more vertices, thereby obtaining a Goldbach pair.
WHY IT LOOKED PROMISING: The theorem gives an injective set of actual new
large primes using an independent height bound, rather than a scalar identity.
EXACT FAILURE: At the next generation the relation N=2m+2 is no longer a
relation with the NEW row anchor. Also the larger alphabet envelope may be
of order N, while the premise N>=F_2(y_new) then fails spectacularly.
The new labels may enter a closed large core. Neither injectivity nor the
height premise persists automatically.
COUNTEREXAMPLE / OBSTRUCTION: The explicit changing-envelope dependence of
F_2 and loss of the h=1 row identity are sufficient obstructions; this is
not a constructed canonical failure.
WHAT SURVIVES: One fully justified two-generation expansion, and the global
support-height constraint on any subsequently closed core.
DO NOT REPEAT: Do not replace a fixed y in the proved premise by the newly
produced, larger y without verifying the premise again.
POSSIBLE REPLACEMENT: A different invariant or a height-sensitive argument
that survives changing alphabets and is forced by actual closed failure.

REFERENCE BOOK
Yann Bugeaud, Linear Forms in Logarithms and Applications, EMS, 2018.
Publisher: https://ems.press/content/book-files/22003
For ordinary prime-counting and probabilistic number theory, the input
checkpoint's G. Tenenbaum, Introduction to Analytic and Probabilistic
Number Theory, 3rd ed., AMS, 2015, remains an appropriate background book.

=========================
STRONGEST NEW RESULTS
=========================
```
