---
id: EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G
logical_id: EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G
version_id: EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G@research
kind: canonical-result
run: research
title: "COROLLARY-"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6720, line_end: 6731}
metadata: {"stable_id": "EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G", "version_id": "EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6720, "line_end": 6731}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6720, "line_end": 6731}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# COROLLARY-

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY-ID: EVERY-FIXED-RANK-HAS-ONLY-FINITELY-MANY-UNIT-ROWS-20260907G
STATUS: PROVED.
For m=1, any unit row at rank k satisfies
 N<1+R_(k+2)<1+4*(k+2)*log(4*(k+2)).
Combined with surjectivity: every k>=1 has a NONEMPTY FINITE set of
unit-row inputs, while p0 has none. This is an exact distinction in
raw all-input admissibility. It provides no distinction in eventual
success after discarding finitely many inputs or restricting to
composite complements. Do not turn this finite degeneracy into a
proof that only p0 can be asymptotically or nondegenerately universal.
```
