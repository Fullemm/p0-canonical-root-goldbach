---
id: EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907
logical_id: EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907
version_id: EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907@research
kind: canonical-result
run: research
title: "Exact scan work convention audit"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION / SOURCE-CORRECTION."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5150, line_end: 5178}
metadata: {"stable_id": "EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907", "version_id": "EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5150, "line_end": 5178}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5150, "line_end": 5178}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Exact scan work convention audit

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION / SOURCE-CORRECTION.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: EXACT-SCAN-WORK-CONVENTION-AUDIT-20260907
STATUS: VERIFIED COMPUTATION / SOURCE-CORRECTION.
DOMAIN:
Exact full FIFO BFS, ascending distinct prime factors, duplicate suppression
on discovery; every even 4<=N<=10^7. No work/depth cutoff, random sampling,
probable-prime test or incomplete factorization.
RESULT:
4,999,999 canonical inputs; zero failures. Inclusive work W counts the
successful vertex. Mean W=7.052697210539442, maximum W=151 first at
N=3542948; maximum success depth 10 first at N=11822.
Through N<=10^6: mean W=5.804359608719217, max W=133 at N=976904.
The old article's displayed step statistics use W, but its pseudocode
counted expanded composite rows E. On success W=E+1; on failure W=E.
This is a counting-convention repair, not a change to success verdicts.
Root-rank ablation k=0,...,6 through N<=200000 reproduces failures
[0,2,4,5,3,2,1], with eligible composite-complement denominators
[73394,81448,81043,80909,80788,80980,80829].
The complete upper-half composite-root census through N<=20000 has
4,041,839 eligible roots, 301 failures at the six known hosts, and
2261 excluded unit-complement rows. Host multiplicities are
128:8, 1718:68, 1862:63, 1928:57, 2200:4, 6142:101.
Independent trial division verifies all 999 canonical inputs through
2000, all three named record inputs, and ten exact example roots with
explicit prime ranks. This is NOT a second independent full-range scan.
SOURCE:
Reproduction source and raw compressed records are in the completed
p0_zenodo_release archive. These regenerated records do not replace
proof and do not extend the original canonical numerical bound.
```
