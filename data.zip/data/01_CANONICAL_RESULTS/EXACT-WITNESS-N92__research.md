---
id: EXACT-WITNESS-N92
logical_id: EXACT-WITNESS-N92
version_id: EXACT-WITNESS-N92@research
kind: canonical-result
run: research
title: "EXPERIMENT-"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION, with displayed arithmetic independently sufficient."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 136, line_end: 154}
metadata: {"stable_id": "EXACT-WITNESS-N92", "version_id": "EXACT-WITNESS-N92@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 136, "line_end": 154}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 136, "line_end": 154}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# EXPERIMENT-

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION, with displayed arithmetic independently sufficient.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
EXPERIMENT-ID: EXACT-WITNESS-N92
STATUS: VERIFIED COMPUTATION, with displayed arithmetic independently sufficient.
DOMAIN: one even N=92, active vertices 47,3,5,29,7,17; unit rows excluded.
METRIC: selected BAD path/cycle versus shortest path to a GOOD vertex.
METHOD: trial division through the integer square root, exact arithmetic.
RESULT: displayed rows above; additionally 92-17=75=3*5^2.
No exhaustive-range or asymptotic claim is attached to this witness.

EXTERNAL-INPUT: BS-1996
STATUS: PRIMARY STATEMENT VERIFIED.
F. Beukers and H. P. Schlickewei, The equation x+y=1 in finitely generated
groups, Acta Arithmetica 78 (1996), 189–199, Theorem 1.1.
Author-hosted full text: https://webspace.science.uu.nl/~beuke106/s-units.pdf
(The available author PDF has a January 8, 2007 typesetting date.)
Exact input: in the Q-closure of a finitely generated subgroup of
(C^*)^2 of rank r, x+y=1 has at most 2^(8r+8) solutions. In particular the
same bound holds in the subgroup itself. No height bound is asserted.
Only this input theorem is external; applications and rank bookkeeping follow.
```
