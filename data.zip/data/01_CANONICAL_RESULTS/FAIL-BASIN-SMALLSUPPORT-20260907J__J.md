---
id: FAIL-BASIN-SMALLSUPPORT-20260907J
logical_id: FAIL-BASIN-SMALLSUPPORT-20260907J
version_id: FAIL-BASIN-SMALLSUPPORT-20260907J@J
kind: canonical-result
run: J
title: "Fail basin smallsupport"
status: KILLED
status_raw: "KILLED (FR1)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 827, line_end: 834}
metadata: {"stable_id": "FAIL-BASIN-SMALLSUPPORT-20260907J", "version_id": "FAIL-BASIN-SMALLSUPPORT-20260907J@J", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 827, "line_end": 834}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 827, "line_end": 834}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1104, style: ID-TABLE}
---

# Fail basin smallsupport

*Run J - status `KILLED` (raw: `KILLED (FR1)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FR1.  FAIL-BASIN-SMALLSUPPORT-20260907J
Hypothesis tried: real basins have small support, so S-unit / smooth-number /
short-interval machinery applies.  KILLED by X1: |B_N| = 10,55,55,41,2,66 and
max B_N is EXACTLY the largest prime below N/3 in four of six cases
(41, 571, 619, 641 against N/3 = 42.7, 572.7, 620.7, 642.7).  On such a support "N-p is B_N-smooth" is close to no constraint at all.
Only the cores are small, and even they reach 877 = N/7 (N = 6142) and 28
elements (N = 1718).
```
