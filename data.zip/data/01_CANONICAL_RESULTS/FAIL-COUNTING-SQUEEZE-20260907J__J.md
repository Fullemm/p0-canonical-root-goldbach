---
id: FAIL-COUNTING-SQUEEZE-20260907J
logical_id: FAIL-COUNTING-SQUEEZE-20260907J
version_id: FAIL-COUNTING-SQUEEZE-20260907J@J
kind: canonical-result
run: J
title: "Fail counting squeeze"
status: KILLED
status_raw: "KILLED (FR2)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 835, line_end: 843}
metadata: {"stable_id": "FAIL-COUNTING-SQUEEZE-20260907J", "version_id": "FAIL-COUNTING-SQUEEZE-20260907J@J", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 835, "line_end": 843}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 835, "line_end": 843}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1105, style: ID-TABLE}
---

# Fail counting squeeze

*Run J - status `KILLED` (raw: `KILLED (FR2)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FR2.  FAIL-COUNTING-SQUEEZE-20260907J
Hypothesis tried: count S-smooth integers in (2N/3, N) against the |S| rows
required, to force a contradiction.  Every version attempted fails, and MUST
fail: the six hosts are exact witnesses that the system has solutions, so no
unconditional contradiction exists.  Recorded so that it is not retried.  The
same applies to the weighted-exponent-matrix sum rules
(sum_i log(N-q_i) = sum_j E_j log q_j) -- every bound obtained runs in the
harmless direction.
```
