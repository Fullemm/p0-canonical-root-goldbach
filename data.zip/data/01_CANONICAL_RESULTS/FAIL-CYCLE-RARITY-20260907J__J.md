---
id: FAIL-CYCLE-RARITY-20260907J
logical_id: FAIL-CYCLE-RARITY-20260907J
version_id: FAIL-CYCLE-RARITY-20260907J@J
kind: canonical-result
run: J
title: "Fail cycle rarity"
status: KILLED
status_raw: "KILLED (FR4)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 852, line_end: 861}
metadata: {"stable_id": "FAIL-CYCLE-RARITY-20260907J", "version_id": "FAIL-CYCLE-RARITY-20260907J@J", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 852, "line_end": 861}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 852, "line_end": 861}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1107, style: ID-TABLE}
---

# Fail cycle rarity

*Run J - status `KILLED` (raw: `KILLED (FR4)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FR4.  FAIL-CYCLE-RARITY-20260907J
Hypothesis tried: B_N != empty forces a cycle in the composite-complement
subgraph, and cycles are rare.  T8 gives the cycle and the bound pq < N for
2-cycles, but cycles are NOT rare.  MEASURED: among the 300 even N in
[100000, 100600), 80.3% admit at least one 2-cycle {p,q} with p,q < N/3,
pq | N-p-q and both rows composite; the mean number of such 2-cycles per N is
1.61 (maximum 7).  Cycle existence therefore carries no rarity at all.  The rarity is
entirely in the requirement that the whole closure avoid GOOD, which is
Goldbach-hard by T10.
```
