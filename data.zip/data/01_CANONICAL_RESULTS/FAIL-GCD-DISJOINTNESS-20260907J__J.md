---
id: FAIL-GCD-DISJOINTNESS-20260907J
logical_id: FAIL-GCD-DISJOINTNESS-20260907J
version_id: FAIL-GCD-DISJOINTNESS-20260907J@J
kind: canonical-result
run: J
title: "Fail gcd disjointness"
status: KILLED
status_raw: "KILLED (FR3)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 844, line_end: 851}
metadata: {"stable_id": "FAIL-GCD-DISJOINTNESS-20260907J", "version_id": "FAIL-GCD-DISJOINTNESS-20260907J@J", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 844, "line_end": 851}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 844, "line_end": 851}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1106, style: ID-TABLE}
---

# Fail gcd disjointness

*Run J - status `KILLED` (raw: `KILLED (FR3)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FR3.  FAIL-GCD-DISJOINTNESS-20260907J
Hypothesis tried: gcd(N-q_i, N-q_k) | q_k - q_i forces the exponent vectors to
be almost disjoint, hence a matching, hence a size contradiction.  The
implication is true (it is the engine of T4/T5) but the bound
|q_k - q_i| < max S is too weak whenever max S is comparable to N/3, which it
is on every real basin.  The derived "each row dominated by one prime power of
size >= 2N/(3 P^s)" is vacuous for s >= 3.
```
