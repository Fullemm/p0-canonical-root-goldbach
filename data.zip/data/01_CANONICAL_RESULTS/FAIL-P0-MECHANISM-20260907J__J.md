---
id: FAIL-P0-MECHANISM-20260907J
logical_id: FAIL-P0-MECHANISM-20260907J
version_id: FAIL-P0-MECHANISM-20260907J@J
kind: canonical-result
run: J
title: "the important one"
status: AUDITED ASSESSMENT
status_raw: "KILLED (FR5)"
audit: K-SCOPE-CORRECTION-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 862, line_end: 905}
metadata: {"stable_id": "FAIL-P0-MECHANISM-20260907J", "version_id": "FAIL-P0-MECHANISM-20260907J@J", "status": "AUDITED ASSESSMENT", "scope": "Empirical explanatory claim, corrected by K audit", "assumptions": ["Only three genuine composite-mirror host trials"], "statement": "The supplied evidence does not establish p0 exceptionalism. A universal arithmetic mechanism is not mathematically refuted by this small sample.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 862, "line_end": 905}, "depends_on": [], "consequences": [], "does_not_imply": ["Not a theorem that p0 cannot be special"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 862, "line_end": 905}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 6, "relation": "later scope correction"}], "computation": [], "concepts": ["p0-exceptionality"], "historical_aliases": [], "search_aliases": [], "verification": "K-SCOPE-CORRECTION-CHECKED", "metadata_completeness": "CURATED"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1108, style: ID-TABLE}
---

# the important one

*Run J - status `AUDITED ASSESSMENT` (raw: `KILLED (FR5)`) - audit `K-SCOPE-CORRECTION-CHECKED`*

> Verification: **K-SCOPE-CORRECTION-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

The supplied evidence does not establish p0 exceptionalism. A universal arithmetic mechanism is not mathematically refuted by this small sample.

**Assumptions:** Only three genuine composite-mirror host trials.

**Does not imply:** Not a theorem that p0 cannot be special.

## Source transcript (historical wording; apply current metadata)

```
FR5.  FAIL-P0-MECHANISM-20260907J   (the important one)
Hypothesis abandoned: that there exists a structural/dynamical mechanism making
p_0 safer than nearby ranks.  See section 8.  The observation to be explained
has three data points, is matched exactly by rank 10 and beaten by ranks 26 and
71, and would have to distinguish rank 0 from rank 1 at the same N -- which the
master's own cor:postDH-fixedprojection forbids for any fixed finite prime-label
projection and its EXP8 shows to be invisible to every aggregate observable.
The programme is explaining noise.

================================================================================
7.  RELATION TO GOLDBACH
================================================================================

7.1  Direction of implication (T10).  B_N = empty => Goldbach(N);
p_0 succeeds => Goldbach(N).  Both project targets are therefore at least as
hard as Goldbach for each N, and the first is strictly harder
(N = 1862, 1928, 6142 satisfy Goldbach and have B_N != empty; N = 2200 has a
two-element basin and satisfies Goldbach comfortably).

7.2  The clean reformulation.  T3(c) says
        B_N != empty  <=>  there is a finite nonempty set S of primes with
                           gcd(prod S, N) = 1, max S < N/3, and N - S contained
                           in Gamma_S.
That is: N minus each prime of S is S-smooth.  Call this a SELF-SMOOTH
REPRESENTATION of N.  Binary Goldbach for N > 6142 follows from
        (SSR)  no even N > 6142 has a self-smooth representation.
(SSR) is a purely multiplicative statement -- no primality of N-p is mentioned
anywhere in it -- and is exactly the object the corpus calls the moving basin.
This is the "reduction to a sharper and more recognisable problem" that the run
can honestly offer: not easier than Goldbach (it is strictly stronger), but
stated entirely inside the theory of S-unit / Pillai equations with moving
support, where T6, T7, T9 and X3 are the first four results.

7.3  What is NOT claimed.  Nothing here proves Goldbach, proves H is finite,
proves X1, or improves any Goldbach exceptional-set estimate.  The known
external verification of Goldbach to 4*10^18 (Oliveira e Silva-Herzog-Pardi)
remains untouched and unusable here.

================================================================================
8.  RELATION TO p_0 EXCEPTIONALITY
================================================================================

This is the principal result of the run.
```
