---
id: FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905
logical_id: FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905
version_id: FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905@research
kind: canonical-result
run: research
title: "EXPERIMENT-"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 618, line_end: 1774}
metadata: {"stable_id": "FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905", "version_id": "FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 618, "line_end": 1774}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 618, "line_end": 1774}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# EXPERIMENT-

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
EXPERIMENT-ID: FINITE-CELL-AND-CLOSED-WORLD-STRESS-20260905
STATUS: VERIFIED COMPUTATION.
DOMAIN:
All integer 4<=x<=200000 for the residue and moment checks; ranks
k=0,1,2,5,20; small-prime cutoffs z=7,31,101 (15 configurations).
These z are diagnostics of the finite identities; they are not an assertion
that the asymptotic scale z=(log X)^alpha is numerically informative here.
The residue/moment identities include negative complements. The graph
consumer excludes nonpositive complements, x below sqrt(X), and inputs
with a GOOD prime <=z. Unit rows contribute zero to small factor counts.
For graph closure, exactly the six previously supplied N were reconstructed:
128,1718,1862,1928,2200,6142; this is NOT a scan for all N<=6142 or beyond.
METRICS:
Exact residue discrepancy for every q and pair-product q*r; second moment;
actual BAD-child count; maximal low closed set by deletion to a fixed point;
terminal SCCs; smallest-row gcd; pure-row count; and complete stopped BFS
from ranks 0,1,2. Pure row means exactly one distinct prime factor.
CHECKS:
For all residue counts, the integer certificate |d*A_d-H|<=d*J passed.
The explicit second-moment upper bound
H*mu+J*(s^2+2*mu*s) passed in all 15 cases. On every eligible input
the actual number of small BAD children equalled the small-divisor count.
Every reconstructed terminal component was closed, active, entirely BAD,
and its two smallest rows were coprime. All assertions passed.
EXTREMAL / RELEVANT WITNESSES:
N=128: terminal size=8, pure rows=2, max label=41; C=[3, 5, 7, 11, 13, 23, 29, 41].
N=1718: terminal size=28, pure rows=1, max label=571; C=[3, 5, 7, 11, 13, 17, 29, 31, 37, 41, 43, 53, 59, 67, 79, 89, 127, 137, 149, 181, 211, 239, 241, 383, 523, 563, 569, 571].
N=1862: terminal size=21, pure rows=1, max label=619; C=[3, 5, 11, 13, 17, 41, 43, 47, 53, 67, 83, 107, 113, 167, 179, 251, 359, 593, 607, 617, 619].
N=1928: terminal size=14, pure rows=0, max label=641; C=[3, 5, 7, 11, 13, 17, 53, 71, 73, 103, 113, 383, 619, 641].
N=2200: terminal size=2, pure rows=2, max label=13; C=[3, 13].
N=6142: terminal size=10, pure rows=0, max label=877; C=[3, 5, 7, 13, 17, 19, 157, 227, 409, 877].
The components at N=1928 and 6142 have ZERO pure rows. They show the
branching hypothesis removed from the old Matveev lemma is a real domain
extension. They satisfy the new necessary height inequality, with enormous
slack; they do not refute any global-Goldbach-failure theorem.
Maximum finite residue discrepancy among the recorded configurations: 5335.66666667; source-cell upper bound J=17983.
Maximum recorded small BAD-child count: 5.
All asymptotic and all-N assertions rely on the written proofs.
Floating-point logarithmic comparisons in the code illustrate the size
of the Matveev margin and do not constitute a rigorous numerical theorem.

REPRODUCIBLE CODE (single-file Python, requires NumPy)
Save the following code separately only when reproducing the diagnostics.
BEGIN DIAGNOSTIC CODE
from math import isqrt, gcd, log
from collections import deque
import json
from pathlib import Path
import numpy as np

X=200000
limit=2*X+2000
isp=np.ones(limit+1,dtype=bool);isp[:2]=False
for p in range(2,isqrt(limit)+1):
    if isp[p]:isp[p*p::p]=False
ps=np.flatnonzero(isp)
spf=np.arange(limit+1,dtype=np.int64)
for p in ps[ps<=isqrt(limit)]:
    sl=spf[int(p)*int(p)::int(p)]
    mask=sl==np.arange(int(p)*int(p),limit+1,int(p))
    sl[mask]=p

def fac(n):
    out={}
    while n>1:
        p=int(spf[n]);out[p]=out.get(p,0)+1;n//=p
    return out

def world(N,r):
    if 2*r==N:return {'depth':0,'R':[],'good':[r]}
    todo=deque([(r,0)]);seen={r};R=[];good=[];first=None
    while todo:
        p,d=todo.popleft()
        if isp[N-p]:
            good.append(p)
            if first is None:first=d
            continue
        assert N-p>1
        R.append(p)
        for q in fac(N-p):
            assert N%q!=0
            if q not in seen:seen.add(q);todo.append((q,d+1))
    return {'depth':first,'R':sorted(R),'good':sorted(good)}

def tarjan(adj):
    index={};low={};stack=[];active=set();comps=[]
    def go(v):
        index[v]=low[v]=len(index);stack.append(v);active.add(v)
        for w in adj[v]:
            if w not in index:go(w);low[v]=min(low[v],low[w])
            elif w in active:low[v]=min(low[v],index[w])
        if low[v]==index[v]:
            comp=[]
            while True:
                w=stack.pop();active.remove(w);comp.append(w)
                if w==v:break
            comps.append(sorted(comp))
    for v in adj:
        if v not in index:go(v)
    return comps

xs=np.arange(4,X+1,dtype=np.int64);ii=np.searchsorted(ps,xs)
H=len(xs);J=len(np.unique(ii));res=[]
for k in [0,1,2,5,20]:
    ms=2*xs-ps[ii+k]
    for z in [7,31,101]:
        small=[int(q) for q in ps if 3<=q<=z]
        s=len(small);mu=sum(1/q for q in small)
        f=np.zeros(H,dtype=np.int64)
        maxdisc=0
        for j,q in enumerate(small):
            f+=(ms%q==0)
            ds=[q]+[q*r for r in small[:j]]
            for d in ds:
                count=int((ms%d==0).sum())
                # Exact integer discrepancy certificate, no floating point.
                assert abs(d*count-H)<=d*J
                maxdisc=max(maxdisc,abs(count-H/d))
        variance=float(((f-mu)**2).sum())
        variance_bound=H*mu+J*(s*s+2*mu*s)
        assert variance<=variance_bound+1e-7
        pos=ms>0
        smallgood=np.zeros(H,dtype=bool)
        smallbad_count=np.zeros(H,dtype=np.int64)
        for q in small:
            good=isp[2*xs-q] if 2*xs[0]-q>=0 else np.array([2*int(x)-q>=2 and bool(isp[2*int(x)-q]) for x in xs])
            smallgood|=good
            smallbad_count+=(pos & (ms%q==0) & (2*xs>2*q) & ~good)
        eligible=pos & (xs>=isqrt(X)+1) & ~smallgood
        assert np.all(smallbad_count[eligible]==f[eligible])
        res.append({'k':k,'z':z,'nonpositive':int((~pos).sum()),
                    'mu':mu,'actual_mean':float(f.mean()),'actual_variance':variance/H,
                    'max_residue_discrepancy':maxdisc,'source_cell_bound':J,
                    'any_small_good_inputs':int(smallgood.sum()),
                    'eligible_graph_bridge_inputs':int(eligible.sum()),
                    'max_small_bad_children':int(smallbad_count.max())})

cores=[]
for N in [128,1718,1862,1928,2200,6142]:
    B={int(p) for p in ps if 3<=p<N/3 and N%int(p)!=0 and not isp[N-int(p)]}
    while True:
        nxt={p for p in B if set(fac(N-p))<=B}
        if nxt==B:break
        B=nxt
    adj={p:set(fac(N-p)) for p in B}
    comps=tarjan(adj)
    terminal=[c for c in comps if all(adj[p]<=set(c) for p in c)]
    out=[]
    for C in terminal:
        a,b=C[:2]
        assert gcd(N-a,N-b)==1
        rows={p:fac(N-p) for p in C}
        assert all(set(row)<=set(C) and sum(row.values())>=2 for row in rows.values())
        pure=sum(len(row)==1 for row in rows.values())
        M=max(C);s=len(C)
        logA=log(1.4)+(s+3)*log(30)+4.5*log(s)+sum(log(log(q)) for q in C)
        lhs=log((N-M)/M)
        # Logarithmic comparison avoids overflows and is diagnostic only.
        assert log(lhs)<logA+log(1+log(log(N)/log(3)))
        out.append({'C':C,'size':s,'pure_rows':pure,'M':M,'two_min_rows_gcd':gcd(N-a,N-b),
                    'height_lhs':lhs,'log10_A':logA/log(10),'rows':rows})
    root_index=int(np.searchsorted(ps,N//2))
    roots=[]
    for k in range(3):
        p=int(ps[root_index+k]);w=world(N,p)
        roots.append({'k':k,'p':p,'m_factors':fac(N-p),'depth':w['depth'],'R_size':len(w['R'])})
    cores.append({'N':N,'B_size':len(B),'terminal':out,'roots':roots})

n92=world(92,47)
assert n92['depth']==1
for a,b in [(47,5),(5,29),(29,7),(7,5)]:
    assert (92-a)%b==0 and not isp[92-a] and not isp[92-b]
output={'domain':{'x_min':4,'x_max':X,'ranks':[0,1,2,5,20],
                  'z_values':[7,31,101],'scope':'exhaustive residue/moment checks at these finite parameters; not an asymptotic census'},
        'moment_checks':res,'known_closed_worlds':cores,
        'N92':{'root':47,'shortest_good_depth':n92['depth'],'R':n92['R'],'good':n92['good']},
        'checks':'all assertions passed'}
Path('/workspace/scratch/db0c19a2d4d9/checkpoint_diagnostics.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'checks':output['checks'],'moment_cases':len(res),
                 'known_worlds':[{'N':c['N'],'B_size':c['B_size'],'terminal':[{key:t[key] for key in ['size','pure_rows','M','log10_A']} for t in c['terminal']],'roots':c['roots']} for c in cores],
                 'N92':output['N92']},indent=2))

END DIAGNOSTIC CODE

COMPLETE DIAGNOSTIC OUTPUT
{
  "domain": {
    "x_min": 4,
    "x_max": 200000,
    "ranks": [
      0,
      1,
      2,
      5,
      20
    ],
    "z_values": [
      7,
      31,
      101
    ],
    "scope": "exhaustive residue/moment checks at these finite parameters; not an asymptotic census"
  },
  "moment_checks": [
    {
      "k": 0,
      "z": 7,
      "nonpositive": 0,
      "mu": 0.6761904761904762,
      "actual_mean": 0.6255343830157453,
      "actual_variance": 0.5041111680167265,
      "max_residue_discrepancy": 5335.6666666666715,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 90156,
      "eligible_graph_bridge_inputs": 109748,
      "max_small_bad_children": 3
    },
    {
      "k": 0,
      "z": 31,
      "nonpositive": 0,
      "mu": 1.065696836388161,
      "actual_mean": 0.9840997614964224,
      "actual_variance": 0.900648678697622,
      "max_residue_discrepancy": 5335.6666666666715,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 171998,
      "eligible_graph_bridge_inputs": 27998,
      "max_small_bad_children": 5
    },
    {
      "k": 0,
      "z": 101,
      "nonpositive": 0,
      "mu": 1.312718191147881,
      "actual_mean": 1.2083131246968704,
      "actual_variance": 1.1748641703513216,
      "max_residue_discrepancy": 5335.6666666666715,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 197552,
      "eligible_graph_bridge_inputs": 2445,
      "max_small_bad_children": 5
    },
    {
      "k": 1,
      "z": 7,
      "nonpositive": 0,
      "mu": 0.6761904761904762,
      "actual_mean": 0.6853552803292049,
      "actual_variance": 0.5027517190535636,
      "max_residue_discrepancy": 752.3333333333285,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 90156,
      "eligible_graph_bridge_inputs": 109748,
      "max_small_bad_children": 3
    },
    {
      "k": 1,
      "z": 31,
      "nonpositive": 0,
      "mu": 1.065696836388161,
      "actual_mean": 1.0837412561188418,
      "actual_variance": 0.8788562862563026,
      "max_residue_discrepancy": 752.3333333333285,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 171998,
      "eligible_graph_bridge_inputs": 27998,
      "max_small_bad_children": 5
    },
    {
      "k": 1,
      "z": 101,
      "nonpositive": 0,
      "mu": 1.312718191147881,
      "actual_mean": 1.330524957874368,
      "actual_variance": 1.1190787532897006,
      "max_residue_discrepancy": 752.3333333333285,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 197552,
      "eligible_graph_bridge_inputs": 2445,
      "max_small_bad_children": 5
    },
    {
      "k": 2,
      "z": 7,
      "nonpositive": 4,
      "mu": 0.6761904761904762,
      "actual_mean": 0.6757051355770337,
      "actual_variance": 0.4963820996997494,
      "max_residue_discrepancy": 505.66666666666606,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 90156,
      "eligible_graph_bridge_inputs": 109748,
      "max_small_bad_children": 3
    },
    {
      "k": 2,
      "z": 31,
      "nonpositive": 4,
      "mu": 1.065696836388161,
      "actual_mean": 1.0690610359155388,
      "actual_variance": 0.865234941052481,
      "max_residue_discrepancy": 505.66666666666606,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 171998,
      "eligible_graph_bridge_inputs": 27998,
      "max_small_bad_children": 5
    },
    {
      "k": 2,
      "z": 101,
      "nonpositive": 4,
      "mu": 1.312718191147881,
      "actual_mean": 1.318204773071596,
      "actual_variance": 1.1091539806479949,
      "max_residue_discrepancy": 505.66666666666606,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 197552,
      "eligible_graph_bridge_inputs": 2445,
      "max_small_bad_children": 5
    },
    {
      "k": 5,
      "z": 7,
      "nonpositive": 18,
      "mu": 0.6761904761904762,
      "actual_mean": 0.6767401511022665,
      "actual_variance": 0.5068375422456733,
      "max_residue_discrepancy": 130.80000000000018,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 90156,
      "eligible_graph_bridge_inputs": 109748,
      "max_small_bad_children": 3
    },
    {
      "k": 5,
      "z": 31,
      "nonpositive": 18,
      "mu": 1.065696836388161,
      "actual_mean": 1.0651409771146567,
      "actual_variance": 0.8621199575250112,
      "max_residue_discrepancy": 161.30909090909108,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 171998,
      "eligible_graph_bridge_inputs": 27998,
      "max_small_bad_children": 5
    },
    {
      "k": 5,
      "z": 101,
      "nonpositive": 18,
      "mu": 1.312718191147881,
      "actual_mean": 1.3149047235708535,
      "actual_variance": 1.1085079110185263,
      "max_residue_discrepancy": 161.30909090909108,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 197552,
      "eligible_graph_bridge_inputs": 2445,
      "max_small_bad_children": 5
    },
    {
      "k": 20,
      "z": 7,
      "nonpositive": 111,
      "mu": 0.6761904761904762,
      "actual_mean": 0.6762601439021585,
      "actual_variance": 0.5039366415893064,
      "max_residue_discrepancy": 100.66666666666606,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 90156,
      "eligible_graph_bridge_inputs": 109748,
      "max_small_bad_children": 3
    },
    {
      "k": 20,
      "z": 31,
      "nonpositive": 111,
      "mu": 1.065696836388161,
      "actual_mean": 1.064990974864623,
      "actual_variance": 0.8678897531228617,
      "max_residue_discrepancy": 157.5294117647063,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 171998,
      "eligible_graph_bridge_inputs": 27998,
      "max_small_bad_children": 5
    },
    {
      "k": 20,
      "z": 101,
      "nonpositive": 111,
      "mu": 1.312718191147881,
      "actual_mean": 1.3126396895953438,
      "actual_variance": 1.1086295262486547,
      "max_residue_discrepancy": 157.5294117647063,
      "source_cell_bound": 17983,
      "any_small_good_inputs": 197552,
      "eligible_graph_bridge_inputs": 2445,
      "max_small_bad_children": 5
    }
  ],
  "known_closed_worlds": [
    {
      "N": 128,
      "B_size": 10,
      "terminal": [
        {
          "C": [
            3,
            5,
            7,
            11,
            13,
            23,
            29,
            41
          ],
          "size": 8,
          "pure_rows": 2,
          "M": 41,
          "two_min_rows_gcd": 1,
          "height_lhs": 0.752336051950276,
          "log10_A": 23.377296381473453,
          "rows": {
            "3": {
              "5": 3
            },
            "5": {
              "3": 1,
              "41": 1
            },
            "7": {
              "11": 2
            },
            "11": {
              "3": 2,
              "13": 1
            },
            "13": {
              "5": 1,
              "23": 1
            },
            "23": {
              "3": 1,
              "5": 1,
              "7": 1
            },
            "29": {
              "3": 2,
              "11": 1
            },
            "41": {
              "3": 1,
              "29": 1
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 67,
          "m_factors": {
            "61": 1
          },
          "depth": 0,
          "R_size": 0
        },
        {
          "k": 1,
          "p": 71,
          "m_factors": {
            "3": 1,
            "19": 1
          },
          "depth": 1,
          "R_size": 9
        },
        {
          "k": 2,
          "p": 73,
          "m_factors": {
            "5": 1,
            "11": 1
          },
          "depth": null,
          "R_size": 9
        }
      ]
    },
    {
      "N": 1718,
      "B_size": 55,
      "terminal": [
        {
          "C": [
            3,
            5,
            7,
            11,
            13,
            17,
            29,
            31,
            37,
            41,
            43,
            53,
            59,
            67,
            79,
            89,
            127,
            137,
            149,
            181,
            211,
            239,
            241,
            383,
            523,
            563,
            569,
            571
          ],
          "size": 28,
          "pure_rows": 1,
          "M": 571,
          "two_min_rows_gcd": 1,
          "height_lhs": 0.6975159074733605,
          "log10_A": 69.09427702086347,
          "rows": {
            "3": {
              "5": 1,
              "7": 3
            },
            "5": {
              "3": 1,
              "571": 1
            },
            "7": {
              "29": 1,
              "59": 1
            },
            "11": {
              "3": 1,
              "569": 1
            },
            "13": {
              "5": 1,
              "11": 1,
              "31": 1
            },
            "17": {
              "3": 5,
              "7": 1
            },
            "29": {
              "3": 1,
              "563": 1
            },
            "31": {
              "7": 1,
              "241": 1
            },
            "37": {
              "41": 2
            },
            "41": {
              "3": 1,
              "13": 1,
              "43": 1
            },
            "43": {
              "5": 2,
              "67": 1
            },
            "53": {
              "3": 2,
              "5": 1,
              "37": 1
            },
            "59": {
              "3": 1,
              "7": 1,
              "79": 1
            },
            "67": {
              "13": 1,
              "127": 1
            },
            "79": {
              "11": 1,
              "149": 1
            },
            "89": {
              "3": 2,
              "181": 1
            },
            "127": {
              "37": 1,
              "43": 1
            },
            "137": {
              "3": 1,
              "17": 1,
              "31": 1
            },
            "149": {
              "3": 1,
              "523": 1
            },
            "181": {
              "29": 1,
              "53": 1
            },
            "211": {
              "11": 1,
              "137": 1
            },
            "239": {
              "3": 1,
              "17": 1,
              "29": 1
            },
            "241": {
              "7": 1,
              "211": 1
            },
            "383": {
              "3": 1,
              "5": 1,
              "89": 1
            },
            "523": {
              "5": 1,
              "239": 1
            },
            "563": {
              "3": 1,
              "5": 1,
              "7": 1,
              "11": 1
            },
            "569": {
              "3": 1,
              "383": 1
            },
            "571": {
              "31": 1,
              "37": 1
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 859,
          "m_factors": {
            "859": 1
          },
          "depth": 0,
          "R_size": 0
        },
        {
          "k": 1,
          "p": 863,
          "m_factors": {
            "3": 2,
            "5": 1,
            "19": 1
          },
          "depth": 1,
          "R_size": 29
        },
        {
          "k": 2,
          "p": 877,
          "m_factors": {
            "29": 2
          },
          "depth": null,
          "R_size": 29
        }
      ]
    },
    {
      "N": 1862,
      "B_size": 55,
      "terminal": [
        {
          "C": [
            3,
            5,
            11,
            13,
            17,
            41,
            43,
            47,
            53,
            67,
            83,
            107,
            113,
            167,
            179,
            251,
            359,
            593,
            607,
            617,
            619
          ],
          "size": 21,
          "pure_rows": 1,
          "M": 619,
          "two_min_rows_gcd": 1,
          "height_lhs": 0.697177818826115,
          "log10_A": 54.142312309949745,
          "rows": {
            "3": {
              "11": 1,
              "13": 2
            },
            "5": {
              "3": 1,
              "619": 1
            },
            "11": {
              "3": 1,
              "617": 1
            },
            "13": {
              "43": 2
            },
            "17": {
              "3": 2,
              "5": 1,
              "41": 1
            },
            "41": {
              "3": 1,
              "607": 1
            },
            "43": {
              "17": 1,
              "107": 1
            },
            "47": {
              "3": 1,
              "5": 1,
              "11": 2
            },
            "53": {
              "3": 3,
              "67": 1
            },
            "67": {
              "5": 1,
              "359": 1
            },
            "83": {
              "3": 1,
              "593": 1
            },
            "107": {
              "3": 3,
              "5": 1,
              "13": 1
            },
            "113": {
              "3": 1,
              "11": 1,
              "53": 1
            },
            "167": {
              "3": 1,
              "5": 1,
              "113": 1
            },
            "179": {
              "3": 2,
              "11": 1,
              "17": 1
            },
            "251": {
              "3": 2,
              "179": 1
            },
            "359": {
              "3": 2,
              "167": 1
            },
            "593": {
              "3": 3,
              "47": 1
            },
            "607": {
              "5": 1,
              "251": 1
            },
            "617": {
              "3": 1,
              "5": 1,
              "83": 1
            },
            "619": {
              "11": 1,
              "113": 1
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 937,
          "m_factors": {
            "5": 2,
            "37": 1
          },
          "depth": 2,
          "R_size": 23
        },
        {
          "k": 1,
          "p": 941,
          "m_factors": {
            "3": 1,
            "307": 1
          },
          "depth": null,
          "R_size": 24
        },
        {
          "k": 2,
          "p": 947,
          "m_factors": {
            "3": 1,
            "5": 1,
            "61": 1
          },
          "depth": 1,
          "R_size": 22
        }
      ]
    },
    {
      "N": 1928,
      "B_size": 41,
      "terminal": [
        {
          "C": [
            3,
            5,
            7,
            11,
            13,
            17,
            53,
            71,
            73,
            103,
            113,
            383,
            619,
            641
          ],
          "size": 14,
          "pure_rows": 0,
          "M": 641,
          "two_min_rows_gcd": 1,
          "height_lhs": 0.6970397506754565,
          "log10_A": 37.78714243994619,
          "rows": {
            "3": {
              "5": 2,
              "7": 1,
              "11": 1
            },
            "5": {
              "3": 1,
              "641": 1
            },
            "7": {
              "17": 1,
              "113": 1
            },
            "11": {
              "3": 3,
              "71": 1
            },
            "13": {
              "5": 1,
              "383": 1
            },
            "17": {
              "3": 1,
              "7": 2,
              "13": 1
            },
            "53": {
              "3": 1,
              "5": 4
            },
            "71": {
              "3": 1,
              "619": 1
            },
            "73": {
              "5": 1,
              "7": 1,
              "53": 1
            },
            "103": {
              "5": 2,
              "73": 1
            },
            "113": {
              "3": 1,
              "5": 1,
              "11": 2
            },
            "383": {
              "3": 1,
              "5": 1,
              "103": 1
            },
            "619": {
              "7": 1,
              "11": 1,
              "17": 1
            },
            "641": {
              "3": 2,
              "11": 1,
              "13": 1
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 967,
          "m_factors": {
            "31": 2
          },
          "depth": 2,
          "R_size": 16
        },
        {
          "k": 1,
          "p": 971,
          "m_factors": {
            "3": 1,
            "11": 1,
            "29": 1
          },
          "depth": null,
          "R_size": 18
        },
        {
          "k": 2,
          "p": 977,
          "m_factors": {
            "3": 1,
            "317": 1
          },
          "depth": null,
          "R_size": 17
        }
      ]
    },
    {
      "N": 2200,
      "B_size": 2,
      "terminal": [
        {
          "C": [
            3,
            13
          ],
          "size": 2,
          "pure_rows": 2,
          "M": 13,
          "two_min_rows_gcd": 1,
          "height_lhs": 5.125336663215231,
          "log10_A": 9.33629253712542,
          "rows": {
            "3": {
              "13": 3
            },
            "13": {
              "3": 7
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 1103,
          "m_factors": {
            "1097": 1
          },
          "depth": 0,
          "R_size": 0
        },
        {
          "k": 1,
          "p": 1109,
          "m_factors": {
            "1091": 1
          },
          "depth": 0,
          "R_size": 0
        },
        {
          "k": 2,
          "p": 1117,
          "m_factors": {
            "3": 1,
            "19": 2
          },
          "depth": 3,
          "R_size": 5
        }
      ]
    },
    {
      "N": 6142,
      "B_size": 66,
      "terminal": [
        {
          "C": [
            3,
            5,
            7,
            13,
            17,
            19,
            157,
            227,
            409,
            877
          ],
          "size": 10,
          "pure_rows": 0,
          "M": 877,
          "two_min_rows_gcd": 1,
          "height_lhs": 1.792329432195893,
          "log10_A": 28.764079106274437,
          "rows": {
            "3": {
              "7": 1,
              "877": 1
            },
            "5": {
              "17": 1,
              "19": 2
            },
            "7": {
              "3": 1,
              "5": 1,
              "409": 1
            },
            "13": {
              "3": 3,
              "227": 1
            },
            "17": {
              "5": 3,
              "7": 2
            },
            "19": {
              "3": 1,
              "13": 1,
              "157": 1
            },
            "157": {
              "3": 2,
              "5": 1,
              "7": 1,
              "19": 1
            },
            "227": {
              "5": 1,
              "7": 1,
              "13": 2
            },
            "409": {
              "3": 2,
              "7": 2,
              "13": 1
            },
            "877": {
              "3": 4,
              "5": 1,
              "13": 1
            }
          }
        }
      ],
      "roots": [
        {
          "k": 0,
          "p": 3079,
          "m_factors": {
            "3": 1,
            "1021": 1
          },
          "depth": 2,
          "R_size": 12
        },
        {
          "k": 1,
          "p": 3083,
          "m_factors": {
            "7": 1,
            "19": 1,
            "23": 1
          },
          "depth": 2,
          "R_size": 13
        },
        {
          "k": 2,
          "p": 3089,
          "m_factors": {
            "43": 1,
            "71": 1
          },
          "depth": null,
          "R_size": 15
        }
      ]
    }
  ],
  "N92": {
    "root": 47,
    "shortest_good_depth": 1,
    "R": [
      5,
      7,
      17,
      29,
      47
    ],
    "good": [
      3
    ]
  },
  "checks": "all assertions passed"
}
```
