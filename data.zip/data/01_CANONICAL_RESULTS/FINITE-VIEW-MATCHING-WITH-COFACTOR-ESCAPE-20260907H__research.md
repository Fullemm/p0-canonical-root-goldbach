---
id: FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H
logical_id: FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H
version_id: FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H@research
kind: canonical-result
run: research
title: "Finite view matching with cofactor escape"
status: PROVED
status_raw: "PROVED by combining H1 and H2."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 7535, line_end: 7688}
metadata: {"stable_id": "FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H", "version_id": "FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7535, "line_end": 7688}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7535, "line_end": 7688}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Finite view matching with cofactor escape

*Run research - status `PROVED` (raw: `PROVED by combining H1 and H2.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: FINITE-VIEW-MATCHING-WITH-COFACTOR-ESCAPE-20260907H
STATUS: PROVED by combining H1 and H2.
Fix a finite valuation prescription T,e_l and any K>=1. H1 realizes it
at all first K+1 roots simultaneously for infinitely many common N.
For ANY additional fixed finite alphabet S of odd primes, H2 says that,
after finitely many exceptions, at least K of those K+1 complements
contain a prime outside S. The exponents of the additional primes in
S need not be bounded. Thus agreeing on every inspected valuation is
compatible with inevitable escape from every fixed full-factor alphabet.
For S=T the escape would follow trivially from fixed exponents and
growing complements; allowing an arbitrary larger S with unrestricted
exponents is the substantive extra statement.

Consequence for the research programme, with quantifiers kept explicit.
The mechanism applies to p_0 and other early ranks alike. It neither
identifies the exceptional possible S-smooth member nor forces p_0 to
be outside S. A failing basin B_N can change and grow with N, so taking
S=B_N separately at each N is NOT a valid use of this fixed-S eventual
theorem. Earlier fixed-alphabet closed-BAD finiteness already rules out
any permanent bounded alphabet for such basins; H2 does not bypass that
obstruction or prove success for a class of ranks.

SAVE POINT H2: separation proof and scope recorded before experiments.

COROLLARY: A FIXED PRIME-LABEL PROJECTION ALSO FAILS TO IDENTIFY p_0.
Fix a finite list T of prime labels and K. For the common N constructed
in H1, project each rooted graph onto its root plus the active labels
in T: keep precisely the edges whose child label is in T, and retain
their exact prime exponents. Keep GOOD/BAD flags for the labels in T
as well, if desired. For sufficiently large N all roots are outside T
and all their complements are composite. Under relabelling of the root,
these K+1 projected graphs are identical. The root-to-T multiplicities
are identical by H1; every other retained row and flag depends only on
the same N and the same label q in T, not on the chosen root.
This is a statement about a FIXED-LABEL projection, not a fixed-depth
ball of the full graph: even the first full BFS layer can contain new
prime labels tending to infinity with N. Thus it does not transfer a
full BFS success or failure from one root to another.

ELEMENTARY CONSUMER: LOW-GAP ROOTS HAVE DISJOINT EARLIER FIRST SUPPORTS.
Status: proved elementary consequence of the already archived identity
that two odd parents of a common factor q differ by a multiple of 2q.
No novelty is claimed for that identity.
Suppose N/2<r<s<N are prime upper roots with positive odd complements.
If q divides both N-r and N-s, then
  2q divides s-r, and hence h_s>=h_r+2q>=2q+1.
Consequently, if s-N/2<=2*min PF(N-s), its full initial support is
disjoint from that of EVERY earlier upper root r>N/2. A possible
boundary root r=N/2 prime causes no exception: its complement r is
larger than N-s, so their prime supports cannot meet.
The numerical factor 2 is sharp even for adjacent roots:
  N=1152, p_0=577, p_1=587,
  N-p_0=575=5^2*23, N-p_1=565=5*113,
  h_0=1, h_1=11=2*5+1, p_1-p_0=10=2*5.
Another equality example is N=80, p_0=41, p_2=47 with common factor 3.

This explains a constraint in the H1 construction: sharing a prescribed
small factor forces later roots away from the centre by at least twice
that factor. More precisely, its fixed offsets are multiples of M, so
h_j>=1+j*M. The construction does not put all these roots in the earlier
h<minPF(m) regime. Conversely, disjointness of initial supports does not
force success. The already certified failed roots (N,r)=(1718,877) and
(6142,3089) have h=18<minPF(m), and therefore have the disjointness just
proved. Disjoint first supports can still feed closed BAD components.

EXACT FINITE WITNESSES AND AUDIT, RUN H
Source code is itself saved as a plain TXT:
  nowe/rank_prefix_probe_20260907H_code.txt
Full output with factorization and FIFO certificates:
  nowe/rank_prefix_probe_20260907H_results.txt
Method: complete integer smallest-prime-factor sieve through 2,000,000;
full sorted-factor FIFO BFS, and an independent greatest-closed-BAD
fixed point for N=1862. No probable-prime tests or delegated work.

Consecutive-prime strings were enumerated with P_0<=1,000,001, equivalently
N=2(P_0-1)<=2,000,000, requiring every selected complement composite.
1. Residue 5 modulo 18, length 3: exactly 51 strings in this domain.
   First witness: N=40364; p_0=20183,p_1=20201,p_2=20219.
   m_0=20181=3*7*31^2,
   m_1=20163=3*11*13*47,
   m_2=20145=3*5*17*79.
   All have v_3=1, h values 1,19,37, and all succeed at depth 1 via
   3+40361=40364. The three complete supports are different.
2. Residue 7 modulo 50, length 2: exactly 8 strings in this domain.
   First witness: N=63812; p_0=31907,p_1=31957.
   m_0=31905=3^2*5*709, m_1=31855=5*23*277.
   Both have v_5=1. The p_0 run reaches GOOD at depth 1, W=2;
   the p_1 run reaches GOOD at depth 2, W=5. Their FIFO lists are
   [31907,3] and [31957,5,23,277,3], respectively.
   Both end at the verified prime pair 3+63809=63812.

Opposite verdicts despite an identical prescribed valuation at the SAME N:
  N=1862,
  p_0=937, m_0=925=5^2*37: SUCCESS, depth 2, W=6;
  p_118=1787, m_118=75=3*5^2: FAIL, W=22.
Both complements have v_5=2. The successful path is 937 -> 37 -> 73,
using 1862-37=1825=5^2*73 and 1862-73=1789 prime. The failing support
{3,5} lies in the independently recomputed closed basin B_1862, whose
complete factor rows are already in run G. The new TXT output also
contains EVERY row visited in this failing 22-vertex run. Thus the
different verdict does not rest on discarding an untested cofactor.

The elementary overlap inequality was additionally checked on the six
known host values 128,1718,1862,1928,2200,6142: 98,367 upper-root pairs,
36,058 common-prime incidences, and 7 composite roots satisfying the
stated low-gap disjointness condition. All exact assertions passed.
The pair domain is N/2<r<s<N-1, excluding unit complements and a possible
boundary root. Boundary-root disjointness was covered in the proof.
This is an illustration on six hosts, not a new all-N host census.

ARCHIVE CROSS-CHECK AND SCOPE
A text search found no earlier Shiu/Freiberg application in this workspace.
The old 19/40 exponent also occurs in an unrelated conditional abc
calculation in the Biblia; that is not the H2 rank-separation theorem.
The old flow notes already contain the 2q shared-child spacing identity;
the low-gap statement above is explicitly only its present consumer.
Neither external-source attribution nor a mathematical novelty claim
has been inferred from the absence of a text-search hit.

The current Goldbug OEIS page was checked during source reconnaissance:
https://oeis.org/A306746
Its definition includes an additional condition max(label)>N/4 and its
displayed sequence omits N=2200, unlike the six EAC hosts in this file.
Consequently its reported next-term bound above 5*10^8 has NOT been
used to upgrade the all-EAC census or to certify any additional ranks.

LATEST STATE -- 2026-09-07H
Ocena po tej rundzie:
1. p_0 nie jest odizolowane przez dowolnie zadane, lecz skonczone dane
   o malych czynnikach pierwszych. Te same dane mozna zrealizowac przy
   jednym N dla p_0,...,p_K, dla kazdego ustalonego K, nieskonczenie
   wiele razy. Dotyczy to nawet dokladnych wykladnikow i projekcji
   grafu na ustalony skonczony zbior etykiet.
2. Istnieje wspolna, udowodniona geometria wielu poczatkowych rang:
   ich pelne dopelnienia nie moga dwukrotnie korzystac wylacznie z tego
   samego ustalonego alfabetu pierwszego, gdy N jest dostatecznie duze.
   Mozna objac nawet prefiks do N^(0.475-epsilon). Jest to wspolna
   wlasnosc arytmetyczna, NIE dowod wspolnej klasy rang zawsze udanych.
3. Dla rzeczywistego wyjasnienia sukcesu potrzebne pozostaje powiazanie
   wyboru pierwszego korzenia z PELNYM, zmieniajacym sie wraz z N
   zbiorem BAD. Wlasnie tej zaleznosci nie kontroluja powyzsze twierdzenia.
   Nie wybraly one p_0 jako jedynego mozliwego wyjatku ani nie wykluczyly
   porazek dla kandydackich rang 10,14,26,28,30,62,63,71,74.
4. Najbardziej uzasadniony dalszy cel to ograniczenie jednoczesnych
   pelnych faktoryzacji w zmiennym B_N, wraz z rzeczywistym polozeniem
   pierwszego korzenia. Dalsze samo dopasowywanie skonczonych reszt,
   wykladnikow lub sztywnych alfabetow nie usuwa wykazanej przeszkody.

Run H used ZERO subagents. All new artifacts are TXT. Important proofs
were saved at H1 and H2 before the finite experiments; complete current
conclusions and reproducible examples are now saved here as well.
No universal p_0 theorem or Goldbach proof has been obtained.
END CURRENT CHECKPOINT -- 2026-09-07H
```
