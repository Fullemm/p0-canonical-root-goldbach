---
id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907
logical_id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907
version_id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907@research
kind: canonical-result
run: research
title: "Fixed gap canonical valuation embedding"
status: PROVED
status_raw: "PROVED; precise extension/consumer of CRT-TRANSCRIPT-EXACT-SCOPE."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5634, line_end: 5735}
metadata: {"stable_id": "FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907", "version_id": "FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5634, "line_end": 5735}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["FIXED-GAP-CANONICAL-VALUATION-EMBEDDING"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5634, "line_end": 5735}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Fixed gap canonical valuation embedding

*Run research - status `PROVED` (raw: `PROVED; precise extension/consumer of CRT-TRANSCRIPT-EXACT-SCOPE.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907
STATUS: PROVED; precise extension/consumer of CRT-TRANSCRIPT-EXACT-SCOPE.
EXACT STATEMENT:
Let N0>=4 be even and let R0>=N0/2 be an admissible prime upper root
with COMPOSITE m0=N0-R0. Set h0=R0-N0/2 and S=PF(m0).
There exist infinitely many even N with canonical prime root
 P=p0(N)=N/2+h0, m=N-P composite, such that for every q in S,
  v_q(m)=v_q(m0),
and for every p,q in S,
  v_q(N-p)=v_q(N0-p).
All primes of S occur at depth 1 in the COMPLETE search from P.
Every such N sufficiently large has additional first factors outside S.

GRAPH FORM OF THE CONCLUSION:
Construct the first-support graph on PF(N-R), labelling each vertex q
by its prime value and by v_q(N-R), and labelling every internal edge
p->q by v_q(N-p)>0. This agrees with the internal edges of the stopped
factorization graph: an internal first-support edge cannot come from
a prime complement. On the original subset S, the new canonical graph
has EXACTLY the original labelled vertices, edge valuations and NONEDGES.
The numerical gap h0 is also preserved. Additional vertices outside S
and edges incident to them remain unrestricted. GOOD/BAD flags at a
vertex with no internal edges are not asserted to be preserved.

PROOF:
Because m0 is composite, R0>N0/2, h0 is a positive integer, R0 is odd,
and m0 is odd. Moreover R0>m0, so R0 is distinct from every prime in S.
For each q in S set
 t_q = 1 + max( v_q(m0), max_{p in S} v_q(N0-p) ),
and put L=product_{q in S} q^(t_q). These numbers are finite, L is odd,
and gcd(R0,L)=1. Require a new prime P to satisfy P=R0 (mod L).
Keep h0 FIXED and define N=2(P-h0), m=P-2h0. Then
 m=m0 (mod L),   N=N0 (mod L),
since m0=R0-2h0 and N0=2(R0-h0). If a positive integer n is congruent
to a modulo q^(v_q(a)+1), then v_q(n)=v_q(a): division by q^v leaves
the same nonzero residue modulo q. By the definition of t_q this gives
all the asserted root and row valuations, including their zero values.

To make P canonical with the very SAME h0, add P=1 (mod 2). For every
even j in [2,h0], choose a distinct new prime ell_j>h0 not dividing L,
and add P=j (mod ell_j). The moduli are pairwise coprime. The common
class is reduced: R0 is coprime to L, P is odd, and 0<j<ell_j at every
new modulus. By Dirichlet's theorem there are infinitely many primes P
in this class. Take P>R0 and large enough that P-h0>2 and P-j>ell_j
for every even j used. Each odd j in [1,h0] makes P-j even and >2;
each even j gives a proper factor ell_j. The entire interval
[P-h0,P) is therefore composite. Hence P=p0(2(P-h0)), with gap h0.
This verifies canonicity by actual compositeness certificates rather
than silently treating an arbitrary upper root as canonical.

The exact positive valuations of m at every q in S place all S in
PF(m). Since m>m0>=4 and m is divisible by the original m0, the new
root is BAD and every label in S is indeed reached at depth 1 in the
complete search. For any original p,q in S, p<=m0<R0 and q<=m0, so
 N0-p>=N0-m0=R0>q.
Thus if q divides N0-p it is a proper divisor, and the corresponding
row is BAD. For the larger N the same properness holds. Positive row
valuations therefore give actual stopped-graph edges on S in both
worlds, with identical weights; zero valuations give identical nonedges.
This proves the asserted induced-graph equality, including the case of
an originally GOOD vertex whose complement prime is outside S.
Finally, all exponents at primes of S in m equal those in m0. If there
were no extra factor outside S, unique factorization would give m=m0,
contrary to P>R0. So additional support is NECESSARY in every retained
new world. Distinct primes P give distinct even N, proving infinitude.

HOSTILE CHECK:
Primitivity uses R0>m0. The diagonal/direct case m0=R0 is NOT allowed:
then the needed congruence P=R0 (mod R0) would not be reduced. The
hypothesis m0 composite removes this problem and fixes the relevant
BAD-root domain. A single-pair Goldbach success among first children
is not required to survive: preserving finite valuations is not the
same as preserving complement primality. No factor is declared absent
outside S, and no complete BFS transcript is copied. The proof itself
shows that new first factors MUST appear. Consequently it cannot
conflict with complete fixed-alphabet finiteness or supply an iteration
with an unchanged alphabet.

DEPENDENCIES / HISTORICAL AUDIT:
CRT, elementary exact valuations, and Dirichlet's fixed reduced-
progression theorem verified above in MIT Lecture 18, Theorem 18.1.
This extends the checkpoint's CRT-TRANSCRIPT-EXACT-SCOPE-20260905 from
already compatible h=1 partial constraints to a concrete compatible
table obtained from ANY actual upper BAD root, with its own h0 held
fixed. The additional step enforces the prime-free canonical interval.
It is a precise consumer of what survived FAIL-P0-FINITE-VALUATION-
SIGNATURE and FAIL-P0-FINITE-BAD-TRAVERSAL, subject to the later
AUDIT-FBTU-PARTIAL-VERSUS-COMPLETE-20260905 correction. No duplicate
claim of complete-BFS universality is introduced.
RELATION TO GOLDBACH:
No root failure is copied, and no prime-pair existence theorem follows.
RELATION TO p0:
A rigorous limit on what the root's finite internal factor arithmetic
can distinguish. The useful consumer is the hereditary-property no-go
below; the statement is not itself an eventual-success mechanism.
WHAT REMAINS OPEN:
Properties using the COMPLETE alphabet, external row factors, GOOD
status, absolute N or root location, or later reachability can escape
this embedding theorem. No conclusion about them is inferred here.
NOVELTY: NOT YET AUDITED; no novelty claim for the underlying CRT method.
```
