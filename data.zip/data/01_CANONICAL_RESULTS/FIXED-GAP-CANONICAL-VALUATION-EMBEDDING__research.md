---
id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING@research
logical_id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING
version_id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING@research
kind: historical-version
run: research
title: "Fixed gap canonical valuation embedding"
status: SUPERSEDED
status_raw: "and its HEREDITARY-FIRST-"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5873, line_end: 5878}
metadata: {"stable_id": "FIXED-GAP-CANONICAL-VALUATION-EMBEDDING", "version_id": "FIXED-GAP-CANONICAL-VALUATION-EMBEDDING@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5873, "line_end": 5878}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5873, "line_end": 5878}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Fixed gap canonical valuation embedding

*Run research - status `SUPERSEDED` (raw: `and its HEREDITARY-FIRST-`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `FIXED-GAP-CANONICAL-VALUATION-EMBEDDING-20260907` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
1. FIXED-GAP-CANONICAL-VALUATION-EMBEDDING and its HEREDITARY-FIRST-
   SUPPORT-P0-NO-GO: exact preservation of the original induced first-
   support graph, root exponents and internal row valuations at the
   SAME numerical h, inside infinitely many canonical worlds. This
   rules out a precisely specified class of universal p0 separators.
   Complete support and eventual reachability are explicitly outside it.
```
