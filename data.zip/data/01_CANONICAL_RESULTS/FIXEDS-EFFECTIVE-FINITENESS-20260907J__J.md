---
id: FIXEDS-EFFECTIVE-FINITENESS-20260907J
logical_id: FIXEDS-EFFECTIVE-FINITENESS-20260907J
version_id: FIXEDS-EFFECTIVE-FINITENESS-20260907J@J
kind: canonical-result
run: J
title: "Fixeds effective finiteness"
status: PROVED-EXTERNAL
status_raw: "PROVED USING EXTERNAL THEOREM"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 345, line_end: 428}
metadata: {"stable_id": "FIXEDS-EFFECTIVE-FINITENESS-20260907J", "version_id": "FIXEDS-EFFECTIVE-FINITENESS-20260907J@J", "status": "PROVED-EXTERNAL", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 345, "line_end": 428}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 345, "line_end": 428}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1091, style: ID-TABLE}
---

# Fixeds effective finiteness

*Run J - status `PROVED-EXTERNAL` (raw: `PROVED USING EXTERNAL THEOREM`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T9.  FIXEDS-EFFECTIVE-FINITENESS-20260907J   STATUS: PROVED USING EXTERNAL THEOREM
--------------------------------------------------------------------------------
EXTERNAL INPUT (verified against a primary-source statement).  Matveev's
theorem in the rational form: let a_1,...,a_m be nonzero rationals and
b_1,...,b_m integers with a_1^{b_1} ... a_m^{b_m} != 1.  Then
        | a_1^{b_1} ... a_m^{b_m} - 1 |  >  (eB)^{-C_0},
        B = max |b_j|,  C_0 = (e/2) * 30^{m+3} * m^{4.5} * prod_j max{1, log H(a_j)},
where H(x) is the naive height.  [G. Matveev, Izv. Math. 64 (2000) 1217-1269;
statement as reproduced in J.-H. Evertse, Diophantine Approximation lecture
notes, Leiden, Chapter 5, Theorem 5.4.  Fetched and checked in this run.  The
constant agrees with the master's A(S) = 1.4 * 30^{s+3} s^{9/2} prod log q.]

STATEMENT.  Let S be a finite set of odd primes with s = |S| >= 2, and let
d = min { |q - q'| : q != q' in S }.  If S is a closed BAD set for the even
number N, then with B = log N / log 3 and
        C_0(S) = (e/2) * 30^{s+3} * s^{4.5} * prod_{q in S} log q ,
        log( (2N/3) / d )  <  C_0(S) * log(eB) .
In particular, for each fixed S there are only finitely many N for which S is
closed and BAD, and N is bounded effectively in terms of S alone.

PROOF.  Choose q_1 < q_2 in S with q_2 - q_1 = d.  Put u = N-q_1, v = N-q_2.
Both are S-smooth (T3(c)) and u - v = d != 0, so u/v = prod_{q in S} q^{c_q} != 1
with |c_q| <= log N / log q <= B.  Matveev gives |u/v - 1| > (eB)^{-C_0}.  But
|u/v - 1| = d/v and v = N - q_2 > 2N/3 (as q_2 < N/3), so
d/(2N/3) >= d/v > (eB)^{-C_0}, which is the displayed inequality.  Since the
right side grows only like log log N in N, the inequality bounds N effectively.
QED

REMARK.  This is the pair-difference refinement of the corpus's closed-support
height inequality: using the MINIMAL gap in S rather than max S puts the whole
of log N on the left.  It is a genuine constraint on the moving support (it is
uniform in N and does not fix S in advance).  Section 5, HC2 shows that it is
also, on every real basin, between 10^9 and 10^159 times weaker than the truth.

--------------------------------------------------------------------------------
T10.  SANDWICH-20260907J          STATUS: PROVED  (the scope theorem)
--------------------------------------------------------------------------------
STATEMENT.  For every even N >= 14:
  (a) if B_N = empty then N is a sum of two primes;
  (b) if the canonical traversal from p_0 succeeds then N is a sum of two primes;
  (c) hence, writing H = {N : B_N != empty} and Phi(N) = {m < N/2 : rad(m) | R_N
      and N-m prime},
        {N : B_N = empty}  (strictly contained in)  {N : p_0 succeeds}
                           (contained in)           {N : Goldbach holds},
      and the middle set differs from the first exactly on
        { N in H : m_0(N) not in Phi(N) }.
  (d) The inclusion in (c) is strict: N = 1862, 1928, 6142 have B_N != empty and
      p_0 succeeding.

PROOF.  (a) Suppose N has no Goldbach representation.  For N >= 6 the prime 2 is
inactive and N-2 is even, so no representation uses 2; hence every active p has
N-p composite or equal to 1, and N-p = 1 only for p = N-1 > N/3.  Let
C = {p in A : p < N/3}.  C is nonempty for every even N >= 14: if every odd
prime below N/3 divided N then N >= prod_{3<=p<N/3} p = e^{theta(N/3)}/2, which
already exceeds N once N/3 >= 11 (e^{theta(11)}/2 = 1155 > 33) and grows
exponentially thereafter; the range 14 <= N < 33 is checked directly.  (The only
even N at all for which C is empty are 6, 8 and 12, verified exhaustively for
all even N <= 6*10^4; all three satisfy Goldbach directly.)  Every p in C is BAD, and by T3(a) every child
of p is < N/3 and active, hence in C.  So C is a nonempty closed BAD set and
B_N != empty.  (b) success produces a GOOD vertex, i.e. a Goldbach pair.
(c), (d): (c) is T3(b) with k = 0 plus (a),(b); (d) is VERIFCOMP (section 4).
QED

CONSEQUENCE (this is the point).  Every target of the CRD/p_0 architecture --
X1, "B_N = empty for large N", "p_0 always succeeds" -- IMPLIES binary Goldbach
for the same N.  The corpus records this for X1 (sec:X1).  T10 makes it exact
and, with (c), localises the ENTIRE extra content of X1 beyond basin-emptiness
to the host set H.  Since H has six known elements and (section 4) no others
below the extended census bound, X1 is -- conditionally on H being finite --
a statement about three integers.

================================================================================
4.  COMPUTATIONAL EXPERIMENTS
================================================================================

General provenance.  All experiments run in a single session, Python 3 +
sympy 1.14 (exact integer arithmetic throughout; no floating point in any
arithmetic decision), plus two C programs compiled with gcc 13.3 -O2 using
64-bit signed integers.  All primality is deterministic: sympy isprime, or a
byte sieve in the C programs.  Factorisation is sympy factorint (exact) or a
smallest-prime-factor sieve.  No randomised primality decision is load-bearing.
Scripts are reproduced in section 4.7.

--------------------------------------------------------------------------------
```
