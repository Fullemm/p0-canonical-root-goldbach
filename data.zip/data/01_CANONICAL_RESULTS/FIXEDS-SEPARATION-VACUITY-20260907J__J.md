---
id: FIXEDS-SEPARATION-VACUITY-20260907J
logical_id: FIXEDS-SEPARATION-VACUITY-20260907J
version_id: FIXEDS-SEPARATION-VACUITY-20260907J@J
kind: canonical-result
run: J
title: "Is thm:postDH-supportsep usable"
status: REQUIRES HUMAN REVIEW
status_raw: "SCOPE-CORRECTION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 760, line_end: 826}
metadata: {"stable_id": "FIXEDS-SEPARATION-VACUITY-20260907J", "version_id": "FIXEDS-SEPARATION-VACUITY-20260907J@J", "status": "REQUIRES HUMAN REVIEW", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 760, "line_end": 826}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 760, "line_end": 826}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1100, style: ID-TABLE}
---

# Is thm:postDH-supportsep usable

*Run J - status `REQUIRES HUMAN REVIEW` (raw: `SCOPE-CORRECTION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
HC3.  Is thm:postDH-supportsep usable?   FIXEDS-SEPARATION-VACUITY-20260907J
                                          STATUS: SCOPE-CORRECTION
The theorem states j - i > c(S) N^{19/40} (log N)^{-A(S)} with
A(S) = 1.4 * 30^{s+3} s^{9/2} prod log q and c(S) = (log(3/e))^{A(S)}/6.
The bound exceeds 1 -- i.e. says anything at all -- only when
(19/40) log N > A(S)(log log N + 2.317) + 1.79.  (The master's c(S) is printed
as (log 3/e)^{A(S)}/6; the constant 2.317 above reads that as log(3/e).  Reading
it instead as (log 3)/e replaces 2.317 by 0.906 and changes none of the orders
of magnitude below.)  Solving:
   S = {3}                 (s=1)  A = 1.25e6   needs N > exp(5.3e7)
   S = {3,13} (N=2200 core, s=2)  A = 2.17e9   needs N > exp(1.3e11)
   S = {3,5,7}             (s=3)  A = 4.93e11  needs N > exp(3.5e13)
   core of N = 6142       (s=10)  A = 5.81e28  needs N > exp(9e30)
The theorem is TRUE and is not withdrawn; but it is numerically vacuous for
every N below exp(5*10^7) even for a ONE-element alphabet, and for every N below
exp(9*10^30) for an alphabet the size of a real core.  It should be recorded as
an asymptotic statement with no finite content, not as a tool at the frontier.
Note the corpus's own frontier box asks to "uniformise the fixed-S geometry";
HC3 shows the fixed-S geometry has nothing to uniformise.

HC4.  Is the statistical reading of section 8 an over-claim?
The COUNTS in X5 are exact computations.  The p-values are HEURISTIC: they
assume rank 0 is exchangeable with other ranks under the null, which is exactly
what is at issue.  The claim made is the negative one -- the data do not reject
the null -- and that is the correct direction for a null-hypothesis argument.
Three separate null models were used (pooled rate 0.402 -> P = 0.214;
per-host rates -> P = 0.088; size-matched top-10 rates -> P = 0.140), plus a
Fisher exact test of rank 0 against rank 1 (0/3 vs 2/5, P = 0.357).  None
rejects at any conventional level.  If a fourth, fifth, ... host is ever found
with p_0 succeeding, the p-value falls; it would take of order 8 to 15 further
hosts with p_0 tested and surviving before the observation becomes significant.

HC5.  Could the six hosts be non-representative because they are small?
Yes, and that is stated: the whole discussion is conditional on H being what the
census says it is.  X1 and X2 extend the census, they do not close it.  But the
direction of the bias is against the p_0 hypothesis, not for it: T10 says any N
with B_N = empty is uninformative, so a larger census that finds no new host
REDUCES the evidence for p_0 exceptionality to the same three trials, while a
census that finds new hosts supplies new trials that could refute it.

HC6.  Did I confuse a selected path with the complete BFS?
No.  Every verdict in this run comes from either the complete stopped traversal
(reference implementation) or the exact fixed-point criterion, and the two were
checked against each other on all 891 pairs.  No selected transcript, no
prescribed CRT edge, no fixed alphabet is used anywhere.

HC7.  Quantifier discipline.
T6, T7, T8, T9, T10 are for-all-N statements.  T9 is uniform in N and does NOT
fix S in advance (that is the whole point of using the pair difference).  X1-X5
are finite-domain statements with their domains stated.  X6 is labelled
EMPIRICAL PATTERN.  The p-values are labelled HEURISTIC.  Nothing here is
density-one or average-case dressed as every-N.

HC8.  Novelty.
No novelty is claimed for T3 (it is the corpus's own thm:postDH-allroot,
reproved), for T10(a) (implicit in the corpus's class-D discussion and stated
in the raw appendix), or for the general idea of a terminal SCC (present in the
raw appendix).  T1, T2 (as a lattice statement), T4, T5, T6 (both directions and
the converse construction), T7, T8, and T9 (pair-difference form) were not
found in the master; they have NOT been checked against the external literature
and no priority claim is made.  T6 is an instance of a Pillai-type equation and
is certainly not new as an equation.

================================================================================
6.  FAILED ROUTES DISCOVERED IN THIS RUN
================================================================================
```
