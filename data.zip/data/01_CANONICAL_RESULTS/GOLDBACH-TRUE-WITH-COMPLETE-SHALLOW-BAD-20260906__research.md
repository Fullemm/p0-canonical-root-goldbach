---
id: GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906
logical_id: GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906
version_id: GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906@research
kind: canonical-result
run: research
title: "Goldbach true with complete shallow bad"
status: PROVED
status_raw: "PROVED, using the preceding external exceptional-set theorem."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3247, line_end: 3319}
metadata: {"stable_id": "GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906", "version_id": "GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3247, "line_end": 3319}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3247, "line_end": 3319}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Goldbach true with complete shallow bad

*Run research - status `PROVED` (raw: `PROVED, using the preceding external exceptional-set theorem.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: GOLDBACH-TRUE-WITH-COMPLETE-SHALLOW-BAD-20260906
STATUS: PROVED, using the preceding external exceptional-set theorem.
EXACT STATEMENT:
For relative density one of primes P in [X,2X], N=2(P-1) simultaneously:
 (a) has an ordinary binary Goldbach representation;
 (b) has no GOOD vertex through depth two from its canonical root P;
 (c) has no GOOD vertex through depth one from any of the first K+1
     roots, whenever K=o(log X/(loglog X)^3).
For fixed epsilon,delta in (0,1), the growing-depth path-product barrier
may also be imposed simultaneously. In particular there are infinitely
many genuine Goldbach numbers with all these shallow BAD properties.
PROOF:
The map P -> 2(P-1) is injective and its values lie below 4X. Hence the
number of starting primes violating (a) is at most E(4X)=O(X^0.72),
which is o(X/log X). The exceptions to (b), (c), and the optional
path-product assertion are each o(X/log X) by the proved results above.
The union of these finitely many exceptional sets remains o(X/log X),
whereas PNT gives ~X/log X prime starts. This proves the statement.
HOSTILE CHECK:
This does not claim that their complete canonical traversals eventually
succeed: the Goldbach pair in (a) might be outside the reachable set.
It does prove that a complete shallow BAD neighbourhood is compatible
with ordinary Goldbach truth on an asymptotically full part of this
prime-parametrized family. No theorem requiring global failure is being
applied to such ordinary successful N.
DEPENDENCIES: The new shallow-front theorems plus the stated external
exceptional-set bound. No pointwise Goldbach assertion is smuggled in.
RELATION TO p0: Reinforces the distinction between generic shallow BADness
and whatever deeper canonical-root phenomenon the computations suggest.
WHAT REMAINS OPEN: Eventual canonical reachability, and binary Goldbach
for every even N. NOVELTY: NOT YET AUDITED.

FINAL HOSTILE AUDIT 2026-09-06
1. The radius-two proof's weakest step was availability of a long sieve
   variable. All four parametrizations explicitly have fixed-parameter
   product <=8X^(1-eta). The only removed first-factor range has mass
   O(eta+1/log X) in the prime-start sample. eta*log X grows for the
   quantitative choice, so all variable-length and coefficient-size
   comparisons used by the sieve remain valid.
2. Primitive forms and nonzero determinants were checked separately in
   every use, including the nearby-root degeneracy h+1=2a. An upper
   prime-tuples bound was never silently used for coincident forms.
3. Source uniformity comes from FKL's explicit B condition. A generic
   theorem with constants depending arbitrarily on coefficients would
   not justify the switching proofs or their growing prefixes.
4. The sample throughout the analytic continuation is P prime, with
   N=2(P-1). It is not the uniform-even-N sample of the earlier transfer
   theorem. No unproved change of sampling measure has been made.
5. Shallow BADness is a union-over-all-successful-paths conclusion,
   hence controls the complete BFS radius in question. It does not
   control its remaining radii or the final closed reachable set.
6. The h=1 radius-two switching result is not automatically shared by
   p1 for the same N; no p0 advantage may be inferred from the absence
   of that extension. The full first-front theorem IS explicitly shared
   by a growing same-N nearby prefix.
7. Numerical scans verify exact identities and finite classifications;
   they do not verify the limiting densities. At the scanned scales,
   many depth-two successes still occur. The upper bounds were not
   fitted to the data and no finite threshold was claimed.
8. The height refinement is a necessary condition shared by any closed
   active BAD set. It neither excludes arbitrary moving support nor
   repairs the killed automatic envelope iteration.
9. Literature novelty has not been audited. The mathematical proofs
   have been locally stress-tested in this run, but have not received
   a separate external adversarial review.
Reproduction note: in the diagnostic section, save the first new Python
block as diagnostic_20260906.py and the second as audit_radius2_20260906.py;
the intervening JSON blocks are their exact outputs. Both use numpy.
No additional diagnostic files are required as permanent deliverables.

=========================
STRONGEST NEW RESULTS
=========================
```
