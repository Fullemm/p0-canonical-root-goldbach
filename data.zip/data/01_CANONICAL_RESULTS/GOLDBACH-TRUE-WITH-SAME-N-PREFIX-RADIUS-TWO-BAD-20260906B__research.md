---
id: GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B
logical_id: GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B
version_id: GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B@research
kind: canonical-result
run: research
title: "COROLLARY-"
status: PROVED
status_raw: "PROVED, using the previously source-checked global exceptional"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3764, line_end: 3779}
metadata: {"stable_id": "GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B", "version_id": "GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3764, "line_end": 3779}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3764, "line_end": 3779}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# COROLLARY-

*Run research - status `PROVED` (raw: `PROVED, using the previously source-checked global exceptional`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY-ID: GOLDBACH-TRUE-WITH-SAME-N-PREFIX-RADIUS-TWO-BAD-20260906B
STATUS: PROVED, using the previously source-checked global exceptional
set theorem, not an assumption of rooted success.
For all but o(X/log X) primes P in [X,2X], N=2(P-1) has a Goldbach
representation while every root of the prefix in the preceding theorem
has a complete radius-two BAD neighborhood.
PROOF: Pintz's checked bound E(Y)<Y^0.72 for sufficiently large Y gives
at most E(4X)=o(X/log X) possible Goldbach counterexamples in this
injectively parametrized family. Unite that exceptional set with the
one from (PREFIX2). No root reachability conclusion follows merely
from existence of a Goldbach pair elsewhere in the graph.
SOURCE: J. Pintz, A new explicit formula in the additive theory of
primes with applications II, primary https://arxiv.org/pdf/1804.09084,
Theorem 1 (statement previously checked; its long proof is not
reproved in this checkpoint). Ineffective threshold is harmless here.
```
