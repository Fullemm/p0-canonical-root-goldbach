---
id: GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B
logical_id: GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B
version_id: GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B@research
kind: canonical-result
run: research
title: "Growing forms uniform sieve consumer"
status: PROVED
status_raw: "PROVED from the same primary FKL Lemma 5.1."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4337, line_end: 4386}
metadata: {"stable_id": "GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B", "version_id": "GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4337, "line_end": 4386}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4337, "line_end": 4386}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Growing forms uniform sieve consumer

*Run research - status `PROVED` (raw: `PROVED from the same primary FKL Lemma 5.1.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: GROWING-FORMS-UNIFORM-SIEVE-CONSUMER-20260906B
STATUS: PROVED from the same primary FKL Lemma 5.1.
EXACT STATEMENT USED:
Fix epsilon>0. Let L=log X, l=loglog X, and
 2<=k<=2*l/log l,       X^epsilon<=z<=3X.
Consider k primitive positive-leading-coefficient integer linear forms
with coefficients and constants of absolute value <=10X^2, and all
pairwise determinants nonzero. If their root count nu(ell)>=1 at every
prime ell, then the number of positive t<=z with every form prime and
>k is at most
 2^(k+1)*k!*z*(C*l)^(k-1)/(epsilon*L)^k                  (GF)
for an absolute C and sufficiently large X depending on epsilon.
For any fixed k the same assertion holds with (C*l)^k without the
nu>=1 assumption. The constants are uniform in the varying forms.

PROOF:
Let Delta be the absolute product of all leading coefficients and all
pairwise determinants. It is a nonzero integer, with
 log(3*Delta)=O(k^2*L).
Outside primes dividing Delta, the roots of the k forms are distinct,
so nu(ell)=k. As in the earlier Euler-product proof,
 sum_(ell|Delta) log ell/ell = O(loglog(3*Delta))=O(l),
 prod_(ell|Delta)(1-1/ell)^(-1) <= C*loglog(3*Delta)<=C'*l.
The first estimate follows by splitting at log(3*Delta), using the
Chebyshev bound below that cutoff, and summing log ell over divisors
above it. The second is the already proved elementary Euler bound.
Thus B_FKL<=k*sum_(ell|Delta)log ell/ell=O(k*l).
If the singular series S is zero there are no such prime values >k.
Otherwise its factors outside Delta are at most 1 by
1-k/ell<=(1-1/ell)^k, and at primes dividing Delta the condition nu>=1
gives factors <=(1-1/ell)^(-(k-1)). Therefore S<=(C*l)^(k-1).
For fixed k without nu>=1 the exponent k gives a valid upper bound.
Both FKL hypotheses hold uniformly: k=O(l/log l)=o(L/l) and
B=O(k*l)=o(L), while log z>=epsilon*L. Its explicit exponential
error is exp(O(k^2*l/(epsilon*L)))=1+o(1), hence <=2 for large X.
Substitution gives (GF). No unspecified fixed-k constant has been
allowed to grow with the number of generations.

SOURCE-AUDIT:
The exact growing-k statement and its error term were reopened in
Ford--Konyagin--Luca, Prime chains and Pratt trees, Lemma 5.1, primary
https://arxiv.org/pdf/0904.0473, printed pp.12--13. Their following
Lemma 5.2 confirms the same Euler-product method, but the argument
above checks it directly for the present forms. This does not invoke
their more specialized averaging theorem for Pratt-chain forms.
HOSTILE CHECK: The k! remains explicit and will only be cancelled by
the ordered-simplex bound; ignoring it without that bound would reduce
the provable depth. All determinants are required nonzero before B
is estimated; repeating a form could make B infinite.
```
