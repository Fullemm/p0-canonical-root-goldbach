---
id: H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905
logical_id: H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905
version_id: H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905@research
kind: canonical-result
run: research
title: "H1 all branch injective escape"
status: PROVED
status_raw: "PROVED (strict strengthening of the preceding two-generation theorem)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1775, line_end: 1834}
metadata: {"stable_id": "H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905", "version_id": "H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1775, "line_end": 1834}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["H1-ALL-BRANCH-INJECTIVE-ESCAPE"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1775, "line_end": 1834}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# H1 all branch injective escape

*Run research - status `PROVED` (raw: `PROVED (strict strengthening of the preceding two-generation theorem).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905
STATUS: PROVED (strict strengthening of the preceding two-generation theorem).
EXACT STATEMENT:
Keep the hypotheses and explicit F_2(y) of H1-TWO-GENERATION-ENVELOPE-ESCAPE:
N=2(P-1), P prime, m=P-2 composite, Q=PF(m) subset {odd primes <=y},
and N>=F_2(y). Then EVERY q in Q satisfies P^+(N-q)>y.
Moreover the sets
  L_q={r>y: r prime and r divides N-q}, q in Q,
are all nonempty and pairwise disjoint.
Consequently either the canonical traversal succeeds at depth <=1, or its
actual depth-2 frontier contains at least |Q| DISTINCT prime labels >y.
If any of those new labels is GOOD, the traversal succeeds at depth <=2.

PROOF:
Inspect the previous full proof. Its use of q=min PF(m) was unnecessary:
all it needed was q in Q, 3<=q<=y, and v=N-q=2m+2-q.
The same nonzero form Lambda=2m/v-1=(q-2)/v has the same uniform bound
for every q in Q. Thus every L_q is nonempty.
If a prime r belonged to L_q and L_q' for q!=q', it would divide
(N-q)-(N-q')=q'-q. But 0<|q'-q|<y<r, impossible.
If every q in Q is BAD, the stopped traversal expands each such child in
world mode, and each selected r_q in L_q is reached. Their disjointness
makes them |Q| distinct new prime vertices, none in Q. Also each N-q
is odd and composite, so each factor r_q< N/3<P; none is the original
root. Their shortest root distance is therefore exactly 2. They are active
by the activity proof in the preceding result. If some q in Q is GOOD, success
has already occurred at depth 1. This proves every alternative.

HOSTILE CHECK:
This is NOT a claim that every residual gcd quotient is free of Q. Old
prime-power excess may coexist with the forced large factor in each row.
The injection uses r>y and the ACTUAL row difference; it is not Hall
expansion inferred from a generic collision average. In an implementation
that stops as soon as any GOOD is found, the entire frontier need not be
materialized; the alternative is success or the complete stopped graph's
stated expansion. No expansion is asserted at later generations.

DEPENDENCIES:
Exact h=1 relation; verified Matveev bound; elementary row-gap divisibility.
No PR-MQ, Scott classification, global failure, or conjectural prime tuples.
RELATION TO HISTORICAL FAILURES:
The positive consumer escaping the previous collision-budget obstruction is
an INDEPENDENT height bound on complete y-smooth rows. It is precisely the
piece absent from attempts to infer new support merely from singleton mass.
This does not erase those counterexamples: for each fixed y the result
applies only beyond the enormous explicit F_2(y).
RELATION TO GOLDBACH:
Success OR an injective collection of actual new reachable primes. Still no
control of the complete rows at those new primes, so no proof of termination.
RELATION TO p0 EXCEPTIONALITY:
A nontrivial dynamical theorem for canonical h=1 roots with bounded initial
prime envelope relative to N. It is not yet a theorem distinguishing p0 from
p1: no same-N failure of this property for p1 has been established.
WHAT REMAINS OPEN:
Control after this forced exit. The new labels may be as large as N/3, at
which point F_2 of the enlarged envelope greatly exceeds N; automatic
iteration is invalid.
NOVELTY: NOT YET AUDITED.

FINAL HOSTILE AUDIT / LIMITATIONS
```
