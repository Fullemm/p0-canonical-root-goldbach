---
id: H1-ALL-BRANCH-INJECTIVE-ESCAPE@research
logical_id: H1-ALL-BRANCH-INJECTIVE-ESCAPE
version_id: H1-ALL-BRANCH-INJECTIVE-ESCAPE@research
kind: historical-version
run: research
title: "H1 all branch injective escape"
status: SUPERSEDED
status_raw: "is a conditional arithmetic theorem with a"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1835, line_end: 1868}
metadata: {"stable_id": "H1-ALL-BRANCH-INJECTIVE-ESCAPE", "version_id": "H1-ALL-BRANCH-INJECTIVE-ESCAPE@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1835, "line_end": 1868}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1835, "line_end": 1868}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
also_at:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1905, style: NUMBERED-ID-LINE}
---

# H1 all branch injective escape

*Run research - status `SUPERSEDED` (raw: `is a conditional arithmetic theorem with a`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `H1-ALL-BRANCH-INJECTIVE-ESCAPE-20260905` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
1. H1-ALL-BRANCH-INJECTIVE-ESCAPE is a conditional arithmetic theorem with a
   very severe N-versus-y hypothesis. No explicit example with N>=F_2(y),
   and no infinite prime family satisfying that small-envelope hypothesis,
   is supplied in this run. Its logical consumer is correct; its practical
   nonvacuity at that scale and usefulness for a Goldbach architecture are
   not established. Do not silently report it as a typical-input statement.
2. The support-height theorem applies to a terminal core without assuming
   two pure rows. The finite cores with no pure rows verify this is an actual
   extension of the historical domain, but the numeric bound is very weak.
3. BS-1996 counts solutions; it does not bound their heights. The height
   bound uses a separate, explicitly verified Matveev input. These dependencies
   must not be interchanged.
4. The new bounded-alphabet counts do not bound the union over arbitrary
   moving alphabets. Their density corollary explicitly confines all supports
   to the primes <=y(X) before applying the bound.
5. The small-child theorem produces MANY actual BAD children, not an ALL-BAD
   first frontier. Large GOOD children are its exact remaining obstruction.
   Runtime consequences specify the sorting and early-stopping conventions.
6. The strongest growing-direct-prefix estimate from the INPUT checkpoint
   remains valid after the audit. It controls direct Goldbach pairs only;
   no theorem here promotes its failure to graph-traversal failure.
7. FBTU is not declared false as a theorem about admissible partial trees.
   The inferred blanket theorem about complete BFS neighbourhoods is not
   established by the supplied proof. Older Biblia iteration 108 already
   documents the residual-factor obstruction. No opposite complete-depth
   theorem has been proved in this continuation.
8. The Scott–Bozek even-exponent branch was neither eliminated nor used as
   a dependency. No published theorem is declared false in this report.
9. No source correction, necessary condition, finite computation, or
   density-one statement is called a proof of binary Goldbach.
10. Proofs and targeted arithmetic checks were performed in this continuation.
    They have not received a separate external adversarial review. No claim
    of literature novelty is made for any new application.
```
