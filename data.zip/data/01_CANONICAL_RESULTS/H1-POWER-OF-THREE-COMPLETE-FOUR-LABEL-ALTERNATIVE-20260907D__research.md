---
id: H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D
logical_id: H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D
version_id: H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D@research
kind: canonical-result
run: research
title: "COROLLARY-"
status: PROVED
status_raw: "PROVED; pointwise strengthening of the prior three-label result."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6483, line_end: 6518}
metadata: {"stable_id": "H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D", "version_id": "H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6483, "line_end": 6518}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6483, "line_end": 6518}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# COROLLARY-

*Run research - status `PROVED` (raw: `PROVED; pointwise strengthening of the prior three-label result.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY-ID: H1-POWER-OF-THREE-COMPLETE-FOUR-LABEL-ALTERNATIVE-20260907D
STATUS: PROVED; pointwise strengthening of the prior three-label result.
EXACT STATEMENT:
For u>=2 with P=3^u+2 prime and N=2(P-1), the canonical search from
p0=P either succeeds by depth 2 or discovers at least FOUR distinct
nonroot labels by depth 3.
PROOF:
P-1 is even and composite, so P is exactly p0 and h=1. The first
complement is 3^u. If N-3 is prime, success occurs at depth 1.
Otherwise the preceding non-perfect-power lemma implies that its
complete factorization has at least two distinct primes. None is 3,
because N-3=2*3^u-1=2 (mod 3); all its factors therefore exceed 3.
The upward four-label theorem applies with q=3,h=1.
RELATION TO p0:
This is a real restriction in a specific canonical family, not a
universal four-label theorem or an explanation for all p0. The more
general lemma is shared by other roots satisfying its explicit
complete-factor hypotheses. Branches returning through small primes
outside those hypotheses remain unexcluded.
RELATION TO GOLDBACH:
Success or branching. FOUR does not rule out a larger closed BAD world.
The three-label obstruction from the previous run is now excluded
for this q=3,h=1 family, but the global h=1 problem remains open.

EXACT NONVACUITY CERTIFICATE FOR THE BAD-THROUGH-TWO CASE:
 u=14, P=4782971 prime, N=9565940, N-P=3^14.
 N-3=9565937=1063*8999.
 N-1063=9564877=7*43*739.
 N-8999=9556941=3*17*73*151.
Every listed factor is prime, and all rows at depths 0,1,2 are
composite. Thus nine distinct nonroot labels appear through depth 3:
 {3,1063,8999,7,43,739,17,73,151}.
The prime root and factors were checked by exact integer trial division.
The lower bound FOUR is not claimed sharp in this restricted family.
```
