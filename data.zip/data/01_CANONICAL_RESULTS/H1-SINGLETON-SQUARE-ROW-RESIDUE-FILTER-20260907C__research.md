---
id: H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C
logical_id: H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C
version_id: H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C@research
kind: canonical-result
run: research
title: "H1 singleton square row residue filter"
status: PROVED
status_raw: "PROVED; necessary conditions only."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6137, line_end: 6154}
metadata: {"stable_id": "H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C", "version_id": "H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6137, "line_end": 6154}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6137, "line_end": 6154}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# H1 singleton square row residue filter

*Run research - status `PROVED` (raw: `PROVED; necessary conditions only.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: H1-SINGLETON-SQUARE-ROW-RESIDUE-FILTER-20260907C
STATUS: PROVED; necessary conditions only.
EXACT STATEMENT:
If r=q^u+2 is prime, u>=2, N=2q^u+2, and N-q=b^2 with b prime,
then u is odd and at least three, and q=23 (mod 24).
PROOF:
If q=3, then N-q=2*3^u-1=2 (mod 3), which cannot be a square.
For q!=3, even u gives r=q^u+2=0 (mod 3), with r>3, contradicting
primality. Thus u is odd and u>=3. The primality of r now excludes
q=1 (mod 3), so q=2 (mod 3). Since an odd integer to an odd power
is congruent to itself modulo 8, b^2=2q^u+2-q=q+2 (mod 8).
Odd squares are 1 modulo 8; hence q=7 (mod 8), giving q=23 (mod 24).
SCOPE:
This uses h=1 and complete pure-power rows. It is not asserted for all
p0 or all h, and supplies neither existence nor impossibility of this
sparse configuration. It merely reduces the unresolved square bottleneck.
```
