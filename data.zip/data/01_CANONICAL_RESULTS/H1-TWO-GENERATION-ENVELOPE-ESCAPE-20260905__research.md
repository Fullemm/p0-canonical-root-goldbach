---
id: H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905
logical_id: H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905
version_id: H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905@research
kind: canonical-result
run: research
title: "H1 two generation envelope escape"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 544, line_end: 617}
metadata: {"stable_id": "H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905", "version_id": "H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 544, "line_end": 617}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 544, "line_end": 617}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# H1 two generation envelope escape

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: H1-TWO-GENERATION-ENVELOPE-ESCAPE-20260905
STATUS: PROVED.
EXACT STATEMENT:
For y>=5 let s_y=#{odd primes <=y} and define
 A_y^+=1.4*30^(s_y+4)*(s_y+1)^(9/2)*log 2*
       product_(3<=l<=y, prime) log l,
 D_y^+=2*A_y^++log(2y),
 F_2(y)=exp(2*D_y^+*log(2*D_y^+)).
Let N=2(P-1), P>=5 prime, with m=P-2 composite and PF(m) contained in
{odd primes <=y}. Put q=min PF(m). If N>=F_2(y), then
  P^+(N-q)>y.                                      (E2)
Thus either q itself is GOOD, giving success at depth 1, or the stopped
traversal from canonical P reaches a prime r>y at depth 2.
No global failure or full rooted failure is assumed.

PROOF:
Suppose instead that both complete rows m and v=N-q are supported on odd
primes <=y. q<=y and v=2m+2-q, so
 Lambda=2m/v-1=(q-2)/v>0.
For N>2y, Lambda<2y/N. (N>=F_2(y) implies N>2y.)
The expression 2m/v has a nonzero exponent 1 on base 2, and its other bases
are odd primes <=y. Their exponent differences have absolute value at most
log N/log 3; all exponents are bounded by 2 log N.
Apply the verified rational real Matveev form to these bases. Base 2 has
height log2>0.16 and is always present. Omitted odd bases may be padded since
their logarithms exceed 1. Hence, with t=log N,
 log Lambda > -A_y^+*(2+log t),
where 1+log(2 log N)<2+log t has been used.
Combining bounds gives
 t<log(2y)+A_y^+*(2+log t) <= D_y^+*(1+log t).
The inversion proved above implies N<F_2(y), a contradiction. This proves E2.
If q is BAD, every prime r|N-q is an actual child and is active: r|N would
force r|q, hence r=q and q|N, already impossible because q|m and
N=2m+2. Consequently a factor r>y is reached at depth 2. If q is GOOD, the
stopped traversal stops that branch at q and has already succeeded.

HOSTILE CHECK:
The large r is a factor of the COMPLETE row N-q, not a residual quotient
obtained by gcd removal. It is genuinely outside the WHOLE prescribed
prime envelope, not just a surplus valuation of an old prime. A GOOD q is
handled before claiming that its children are traversed. A large reached
prime r need not be GOOD; no Goldbach conclusion follows in the BAD-q branch.
The finite h=1 transcript can still be prescribed by CRT: this theorem
forces some of its previously uncontrolled cofactors to carry larger primes.

DEPENDENCIES: Matveev-in-BMS-9.4, exact h=1 arithmetic, elementary inversion.
RELATION TO HISTORICAL FAILURES:
This is an actual escape consumer, so the fixed-alphabet finiteness warning
does not invalidate it. It still cannot iterate with a fixed useful bound,
since the new alphabet may grow and its threshold changes. It does not
revive the failed collision-to-new-support argument PR-MQ.
RELATION TO GOLDBACH: Success OR a provable enlarged reachable alphabet.
RELATION TO p0 EXCEPTIONALITY:
A concrete reachability theorem in the canonical h=1 subfamily. We have not
shown a corresponding property fails at p1 for the same N, nor covered all
canonical gaps. It therefore is not an explanation of universal p0 success.
WHAT REMAINS OPEN: A mechanism that turns repeated necessary envelope escape
into GOOD reachability, with control that survives the changing envelope.
NOVELTY: NOT YET AUDITED.

EXTERNAL CLASSICAL INPUT CHECKS
PNT: pi(t)~t/log t, Hadamard and de la Vallee Poussin (1896).
Statement and a complete proof checked in D. Zagier, Newman's Short Proof
of the Prime Number Theorem, American Mathematical Monthly 104 (1997),
705–708: https://sites.math.rutgers.edu/~zeilberg/EM18/zagier.pdf
The upper bound pi(t)=O(t/log t) and the interval consequence
pi(2t)-pi(t)~t/log t follow directly. No error term or AP uniformity is used.
Dirichlet (1837): if gcd(a,m)=1, m>=1, infinitely many primes are
a mod m. The exact statement is independently given in Paul Pollack,
Hypothesis H and an impossibility theorem, Rendiconti del Seminario
Matematico Universita Politecnico Torino 68 (2010), starting at p.183:
https://seminariomatematico.polito.it/rendiconti/68-2/183.pdf
No theorem about several simultaneously prime affine forms is used.
```
