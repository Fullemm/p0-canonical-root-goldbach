---
id: HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907
logical_id: HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907
version_id: HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907@research
kind: canonical-result
run: research
title: "Hereditary first support p0 no go"
status: PROVED
status_raw: "PROVED, as an exact consumer of the preceding embedding."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5736, line_end: 5792}
metadata: {"stable_id": "HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907", "version_id": "HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5736, "line_end": 5792}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5736, "line_end": 5792}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Hereditary first support p0 no go

*Run research - status `PROVED` (raw: `PROVED, as an exact consumer of the preceding embedding.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: HEREDITARY-FIRST-SUPPORT-P0-NO-GO-20260907
STATUS: PROVED, as an exact consumer of the preceding embedding.
EXACT STATEMENT:
Consider a property Q(h,G) of finite directed graphs G whose vertices
carry prime labels q and root exponents, and whose edges carry row
valuations, as in FIXED-GAP-CANONICAL-VALUATION-EMBEDDING. Suppose Q
is hereditary under induced subgraphs at fixed h: whenever Q(h,G)
holds, it holds on every induced subgraph, retaining vertex/edge labels
and exponents. Q may use the numerical labels and h, but has no extra
unrecorded dependence on the absolute N, root R, or outside factors.
Then the following two statements are equivalent:
 (A) Q holds for the first-support graph of EVERY canonical BAD root p0.
 (B) Q holds for the first-support graph of EVERY admissible upper BAD
     prime root R>=N/2, including all nearby roots that are BAD.
Moreover, if (B) fails, (A) fails for infinitely many N with one fixed h.

PROOF:
(B) implies (A) because canonical roots are upper roots. Conversely,
assume (A) and take an arbitrary upper BAD root (N0,R0). The preceding
embedding supplies a canonical BAD-root graph G' at the same h0 that
contains its full original graph G0 as an induced subgraph with all
stated labels and weights unchanged. By (A), Q(h0,G') holds. Heredity
then implies Q(h0,G0). The original upper BAD root was arbitrary,
so (B) follows. If Q(h0,G0) fails for one such root, every canonical
embedding G' fails Q by the contrapositive of heredity. There are
infinitely many distinct N carrying those embeddings. This proves
the strengthened failure conclusion as well.

HOSTILE CHECK / EXACT CLASS OF THE NO-GO:
Heredity is essential and is not silently assumed for an arbitrary
invariant. Examples inside the class include acyclicity, forbidding a
fixed labelled finite cycle/pattern, a uniform upper bound on directed
cycle length or strong-component size, and hereditary restrictions on
internal row valuations. These properties cannot universally hold for
p0 while failing for a nearby BAD root. The theorem does not say their
frequencies are equal, or compare p0 and p1 at every same N.
OUTSIDE its scope are complete BADness (GOOD flags can change), equality
of the WHOLE prime alphabet with a fixed set, completeness of all row
factorizations inside that alphabet, a lower support bound, full BFS
closure, or full multigeneration success. Such properties need not be
hereditary under the stated restriction, and external factors are the
precise information deliberately not preserved by the construction.
This is therefore a mathematically specified subclass of a finite-local
no-go, NOT the old overbroad claim that any finite BFS invariant fails.

RELATION TO p0 / GOLDBACH:
A broad, rigorous negative answer for these graph-and-valuation
properties; it does not answer whether the complete canonical traversal
always reaches GOOD. Same-N witnesses above illustrate both directions
for acyclicity; this theorem supplies the universal logical limitation.
WHAT REMAINS OPEN:
A non-hereditary complete-support or multigeneration invariant that
actually forbids a closed BAD canonical reachable world.
NOVELTY: NOT YET AUDITED; theorem consumer and scope are explicitly new
entries here, not a claim of priority over the literature.
```
