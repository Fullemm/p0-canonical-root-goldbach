---
id: HOST-CENSUS-EXACT-20260907J
logical_id: HOST-CENSUS-EXACT-20260907J
version_id: HOST-CENSUS-EXACT-20260907J@J
kind: canonical-result
run: J
title: "Host census exact"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 429, line_end: 444}
metadata: {"stable_id": "HOST-CENSUS-EXACT-20260907J", "version_id": "HOST-CENSUS-EXACT-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 429, "line_end": 444}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 429, "line_end": 444}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1093, style: ID-TABLE}
---

# Host census exact

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X1.  HOST-CENSUS-EXACT-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
DOMAIN: every even N with 6 <= N <= 2 600 000 (two C processes, ranges
[6, 1.4e6] and [1.4e6, 2.6e6], both run to completion).
ALGORITHM: for each N, mark alive every odd prime p <= (N-1)/3 with p !| N and
N-p composite; then propagate death by reverse edges: when q dies, kill every
p <= (N-1)/3 with p = N (mod q).  This computes exactly the set of p that
cannot reach a GOOD vertex, i.e. B_N (T3(c)).  Sequential-memory worklist,
O(N * sum_{q} 1/q) per N.
RESULT: B_N != empty for exactly the six values
        128, 1718, 1862, 1928, 2200, 6142
and for no other even N in the range.  This reproduces EXP7 (which stopped at
6*10^4) exactly, and extends the exhaustive census by a factor of 43.
BASINS: |B_N| = 10, 55, 55, 41, 2, 66;  max B_N = 41, 571, 619, 641, 13, 2011.

--------------------------------------------------------------------------------
```
