---
id: HOST-LOWGOLDBACH-DEPRESSION-20260907J
logical_id: HOST-LOWGOLDBACH-DEPRESSION-20260907J
version_id: HOST-LOWGOLDBACH-DEPRESSION-20260907J@J
kind: canonical-result
run: J
title: "Host lowgoldbach depression"
status: EMPIRICAL
status_raw: "EMPIRICAL PATTERN"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 564, line_end: 582}
metadata: {"stable_id": "HOST-LOWGOLDBACH-DEPRESSION-20260907J", "version_id": "HOST-LOWGOLDBACH-DEPRESSION-20260907J@J", "status": "EMPIRICAL", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 564, "line_end": 582}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 564, "line_end": 582}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1098, style: ID-TABLE}
---

# Host lowgoldbach depression

*Run J - status `EMPIRICAL` (raw: `EMPIRICAL PATTERN`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X6.  HOST-LOWGOLDBACH-DEPRESSION-20260907J          STATUS: EMPIRICAL PATTERN
--------------------------------------------------------------------------------
For each host, G_low = #{p < N/3 : p !| N, N-p prime} and the ratio
G_low / pi(N/3), against the same ratio for the 40 nearest even numbers:
    N=128 : 0.167  (neighbourhood mean 0.401, MINIMUM of the neighbourhood)
    N=1718: 0.135  (mean 0.277, MINIMUM)
    N=1862: 0.204  (mean 0.268)
    N=1928: 0.183  (mean 0.267)
    N=2200: 0.240  (mean 0.263)
    N=6142: 0.159  (mean 0.234)
All six hosts are below their local mean, two are the local minimum.  Four of
the six (128 = 2^7, 1718 = 2*859, 1928 = 2^3*241, 6142 = 2*37*83) have a
singular series within 4% of the minimum possible value, i.e. no small odd prime
factor.  READING: the basin survives when the low half of N is Goldbach-poor,
because the peeling that destroys basins is driven exactly by the primes
q < N/3 with N-q prime.  This is a mechanism, not a theorem, and the sample is
six.

--------------------------------------------------------------------------------
```
