---
id: HOST-SEEDED-DEEP-20260907J
logical_id: HOST-SEEDED-DEEP-20260907J
version_id: HOST-SEEDED-DEEP-20260907J@J
kind: canonical-result
run: J
title: "Host seeded deep"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 445, line_end: 468}
metadata: {"stable_id": "HOST-SEEDED-DEEP-20260907J", "version_id": "HOST-SEEDED-DEEP-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 445, "line_end": 468}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 445, "line_end": 468}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1094, style: ID-TABLE}
---

# Host seeded deep

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X2.  HOST-SEEDED-DEEP-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
DOMAIN: every even N with 6 <= N <= 60 000 000; seeds = all odd primes <= 200.
(Run to completion.  A partial run to 3*10^8 was terminated for time; it had
reported no host beyond the six at the point it was stopped.)
ALGORITHM: for each N and each seed s <= 200 with s < N/3 and s !| N and N-s
composite, breadth-first the forward closure of s in Gamma_N with early abort on
the first GOOD vertex.  If the closure exhausts without a GOOD vertex it IS a
nonempty closed BAD set (T2/T3), so N is a host.
SCOPE (exact): this finds every host whose basin contains a prime <= 200.  It
does not exclude hosts whose basin has minimum element > 200.
RESULT: exactly the same six hosts; NO SEVENTH HOST in the range.  In every one
of the six the forward closure of the seed 3 is exactly the core, with sizes
8, 28, 21, 14, 2, 10 -- independently matching the terminal-SCC computation X4.

CONSEQUENCE FOR SECTION 8.  The master's canonical scan runs to N <= 10^7, which
is entirely inside this range.  So within the whole canonical-scan range there
is no host beyond the six except possibly one whose basin has minimum element
> 200 -- which would additionally have to avoid the class N mod l for all 46
primes l <= 200 (T3(c) plus the roughness of its minimal row).  The three-trial
conclusion of section 8 is therefore robust across the entire range in which
"no canonical failure" has ever been checked.

--------------------------------------------------------------------------------
```
