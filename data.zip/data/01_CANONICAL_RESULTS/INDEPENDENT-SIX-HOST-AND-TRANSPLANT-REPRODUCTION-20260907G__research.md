---
id: INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G
logical_id: INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G
version_id: INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G@research
kind: canonical-result
run: research
title: "AUDIT-"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION, independently reimplemented in this run."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6591, line_end: 6659}
metadata: {"stable_id": "INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G", "version_id": "INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6591, "line_end": 6659}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6591, "line_end": 6659}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# AUDIT-

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION, independently reimplemented in this run.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
AUDIT-ID: INDEPENDENT-SIX-HOST-AND-TRANSPLANT-REPRODUCTION-20260907G
STATUS: VERIFIED COMPUTATION, independently reimplemented in this run.
Implementation: rank_audit_20260907G.py, result rank_audit_20260907G.json.
Exact integer sieve to 200000, complete distinct-factor FIFO, duplicate
suppression, no depth/work cutoff, no probable-prime tests. On each host
the maximal active low BAD fixed point was computed independently and
its membership verdict checked against a separate complete BFS for EVERY
upper root having composite complement.
Host N: upper roots below N; size of maximal low BAD set; failed roots:
 128:   13; 10; 8
 1718: 119; 55; 68
 1862: 126; 55; 63
 1928: 131; 41; 57
 2200: 143;  2; 4
 6142: 361; 66; 101
Total 301 failed roots, 214 distinct composite mirrors, 188 distinct
failed ranks. Exactly 173 indices in 0..360 avoid these six spectra.
The exact 173-index list agrees with the uploaded 07F, entry for entry.
Within 0..118 the survivors are exactly
 {0,10,14,26,28,30,62,63,71,74}.

The ENTIRE specified transplant suite was also independently rerun:
all 214 dangerous m, every P>m with even N=P+m<=200000, retain the
indicated exact rank, test full BFS and explore the entire stopped BAD
world for GOOD child edges. Every count in 07F was reproduced.
Rank: cases / failures / worlds with exactly one GOOD child edge:
  0: 358 / 0 / 10
  7: 430 / 1 / 18
  8: 434 / 5 / 17
  9: 445 / 1 / 21
 11: 454 / 3 / 18
 20: 439 / 1 / 20
 48: 446 / 3 / 13
 10: 458 / 0 / 20
 14: 441 / 0 / 23
 26: 442 / 0 / 16
 28: 453 / 0 / 15
 30: 424 / 0 / 19
 62: 462 / 0 / 16
 63: 452 / 0 / 15
 71: 451 / 0 / 15
 74: 452 / 0 / 8
Nine candidate ranks together: 4035 cases, zero failures, 147 one-edge
worlds. This is an audit of the supplied experiment, not a new range record.

All same-(rank,mirror) opposite-verdict certificates in 07F were checked:
 (7,27): N116 success versus N128 failure;
 (20,799): N1862 failure versus N1886 success;
 (48,729): N2200 failure versus N2180 and N2210 success.
Their exact complete transcripts are in the result JSON. These establish
that (k,m) does not determine verdict, even with all first-row exponents.
The root clone at N1144 was checked too: roots 577=p0, 997=p62,
1123=p82 all have initial support {3,7}, success depth 7 and W=16.
The post-root tested labels are
 3,7,163,379,109,5,17,23,67,19,59,359,31,157,53;
the final complement is 1091 prime. BOTH root complements must be
composite in the full-transcript clone theorem; equal supports alone
do not equate a direct GOOD root with a BAD root having that support.

EXTERNAL-CENSUS PROVENANCE:
Bozek's paper reports an EAC census through 10^8 with precisely the six
hosts above, in its section 4. Source https://arxiv.org/pdf/1909.09900.
Combining that reported census with the elementary active-BAD/EAC
equivalence transfers the six-host failure spectrum to N<=10^8.
This uses the author's computation; the present run did not scan all
N<=10^8 (or repeat the uploaded 10^7 work/depth statistics).
The global assertion that these are the only hosts is still unproved.
```
