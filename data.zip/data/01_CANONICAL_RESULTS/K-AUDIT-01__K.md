---
id: K-AUDIT-01
logical_id: K-AUDIT-01
version_id: K-AUDIT-01@K
kind: canonical-result
run: K
title: "K audit"
status: PROVED
status_raw: "SCOPE-CORRECTED / PROVED AS INDICATED BELOW"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 9, line_end: 48}
metadata: {"stable_id": "K-AUDIT-01", "version_id": "K-AUDIT-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 9, "line_end": 48}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 9, "line_end": 48}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K audit

*Run K - status `PROVED` (raw: `SCOPE-CORRECTED / PROVED AS INDICATED BELOW`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-AUDIT-01 -- SCOPE-CORRECTED / PROVED AS INDICATED BELOW
The attached suggestion is treated as a proposed research agenda, not as
instructions overriding the user's freedom to choose the attack. The master
is read as mathematical source material. Its audited post-J chapter was
checked against its raw J appendix and the existing H checkpoint.

The useful pivot is from special-root statistics to complete closed BAD
cores. On the six known hosts, p_0 has a composite complement at only
1862,1928,6142. This weakens the empirical case for a special dynamic
mechanism, but does not mathematically refute such a mechanism. The raw J
language declaring the p_0 mechanism killed is not adopted.

Definitions used here. N is even. A prime q is active if q<N and q does
not divide N. BAD means N-q is composite. PF(n) is the full set of distinct
prime factors. A closed BAD set S satisfies PF(N-q) subset S for all q in S.
A core is a minimal nonempty such set. B_N is the largest active closed
BAD set below N/3. For composite upper-root complements, failure is exactly
PF(N-r) subset B_N. The six known hosts have one core each, of sizes
8,28,21,14,2,10 in the order 128,1718,1862,1928,2200,6142.

The elementary core reduction, automatic activity, no self-edges, and
prime-factor bound q<N/3 were rechecked from their proofs. A core is
strongly connected and source-free. In particular every vertex of a core
really is a child of some row, so all its labels are below N/3.

Scope detail: an arbitrary closed BAD set can include extra high source
vertices; it need not itself be entirely below N/3. Results below that use
the interval (2N/3,N) for ALL rows are stated for cores, or explicitly for
closed sets entirely below N/3. The indegree and ordered-forest results do
not need that interval hypothesis.

The large J computations (all-N census to 2.6 million, seeded search to
60 million, two-core classification within N<=10^24) are source-reported
verified computations, NOT independently rerun at those ranges here.
Their domain restrictions and the audited square-partner completeness
argument are retained. The six concrete cores are independently recomputed
and fully factored in the auxiliary K result TXT.

2. CHOSEN ATTACK
```
