---
id: K-CHOICE-01
logical_id: K-CHOICE-01
version_id: K-CHOICE-01@K
kind: canonical-result
run: K
title: "K choice"
status: REQUIRES HUMAN REVIEW
status_raw: "Investigate ordered incidence rigidity and the four-core"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 49, line_end: 56}
metadata: {"stable_id": "K-CHOICE-01", "version_id": "K-CHOICE-01@K", "status": "REQUIRES HUMAN REVIEW", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 49, "line_end": 56}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 49, "line_end": 56}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K choice

*Run K - status `REQUIRES HUMAN REVIEW` (raw: `Investigate ordered incidence rigidity and the four-core`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-CHOICE-01 -- Investigate ordered incidence rigidity and the four-core
class. This seems more productive than trying to infer protection of p_0
from three selector-informative host examples. Excluding all large hosts
would itself be a stronger target than Goldbach, so no claim is made that
the pivot makes the original problem easy.

3. NEW THEOREMS / LEMMAS AND THEIR PROOFS
```
