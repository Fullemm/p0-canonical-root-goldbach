---
id: K-COMBINATORIAL-AUDIT-01
logical_id: K-COMBINATORIAL-AUDIT-01
version_id: K-COMBINATORIAL-AUDIT-01@K
kind: canonical-result
run: K
title: "K combinatorial audit"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 407, line_end: 424}
metadata: {"stable_id": "K-COMBINATORIAL-AUDIT-01", "version_id": "K-COMBINATORIAL-AUDIT-01@K", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 407, "line_end": 424}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 407, "line_end": 424}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K combinatorial audit

*Run K - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-COMBINATORIAL-AUDIT-01 -- VERIFIED COMPUTATION
Complete enumeration on s=2,3,4 of all 2^(s*(s-1)) loop-free directed
graphs was filtered by strong connectivity, uniqueness of a smaller
parent, and distinct bases for pure rows. Remaining counts were:
  s=2:   1 graph,  0 matching failures,  0 Hamilton-cycle failures;
  s=3:   8 graphs, 0 matching failures,  0 Hamilton-cycle failures;
  s=4: 266 graphs,22 matching failures, 50 Hamilton-cycle failures.
Every four-vertex matching failure has exactly the K14 support form.
All eight pure-free four-vertex patterns have the K6 form and a Hamilton
cycle. The universal ordered-degree inequalities were checked on every
retained graph as well as on all six independently recomputed cores.
The sharp triangular graph constructions were checked for every d=1,...,20,
with sizes s up to 211. All assertions passed.

These graph enumerations are COMPLETE within their finite graph domain.
They do not enumerate prime solutions to the associated Diophantine
systems, and no arithmetic existence is inferred from a passing graph.
```
