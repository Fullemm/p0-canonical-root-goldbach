---
id: K-FAIL-FREE-DELETION-01
logical_id: K-FAIL-FREE-DELETION-01
version_id: K-FAIL-FREE-DELETION-01@K
kind: canonical-result
run: K
title: "K fail free deletion"
status: KILLED
status_raw: "KILLED IN THE CLOSURE-PRESERVING FORM"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 487, line_end: 496}
metadata: {"stable_id": "K-FAIL-FREE-DELETION-01", "version_id": "K-FAIL-FREE-DELETION-01@K", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 487, "line_end": 496}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 487, "line_end": 496}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K fail free deletion

*Run K - status `KILLED` (raw: `KILLED IN THE CLOSURE-PRESERVING FORM`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FAIL-FREE-DELETION-01 -- KILLED IN THE CLOSURE-PRESERVING FORM
Removing a proper nonempty portion of a core cannot preserve closure:
that would contradict the definition of minimality. The smallest known
certificate is N=2200. Deleting 13 from {3,13} leaves N-3=13^3 outside
the remaining set; deleting its unique parent row/label 3 leaves
N-13=3^7 outside the remaining set. Ordered incidence is inherited under
restriction, but source-freeness and complete factor closure are not.
The forest theorem is a replacement for this naive recursive deletion;
it does not claim to turn deletion into a new smaller closed system.
```
