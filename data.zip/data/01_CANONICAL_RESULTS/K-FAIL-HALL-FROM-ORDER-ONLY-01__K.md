---
id: K-FAIL-HALL-FROM-ORDER-ONLY-01
logical_id: K-FAIL-HALL-FROM-ORDER-ONLY-01
version_id: K-FAIL-HALL-FROM-ORDER-ONLY-01@K
kind: canonical-result
run: K
title: "K fail hall from order only"
status: KILLED
status_raw: "KILLED IN ITS COMBINATORIAL FORM"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 425, line_end: 441}
metadata: {"stable_id": "K-FAIL-HALL-FROM-ORDER-ONLY-01", "version_id": "K-FAIL-HALL-FROM-ORDER-ONLY-01@K", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 425, "line_end": 441}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 425, "line_end": 441}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K fail hall from order only

*Run K - status `KILLED` (raw: `KILLED IN ITS COMBINATORIAL FORM`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FAIL-HALL-FROM-ORDER-ONLY-01 -- KILLED IN ITS COMBINATORIAL FORM
The assertion that strong connectivity, no self-edges, unique smaller
parents and distinct pure bases automatically imply a perfect matching
is false. A four-vertex countermodel is
  1 -> {2},
  2 -> {3,4},
  3 -> {1,2},
  4 -> {1}.
It is strongly connected and has distinct pure bases 2 and 1. Each
vertex has at most one smaller parent. But rows {1,3,4} have only the
two child labels {1,2}; also the two largest labels 3,4 have the same
unique parent 2. This is the smallest such abstract countermodel, by
the complete s=2,3 enumeration. It is NOT an arithmetic closed BAD set.
It invalidates a proof using only those listed graph axioms, not the
conjecture that actual cores always have perfect matchings. K14 gives
the precise missing arithmetic problem at size four.
```
