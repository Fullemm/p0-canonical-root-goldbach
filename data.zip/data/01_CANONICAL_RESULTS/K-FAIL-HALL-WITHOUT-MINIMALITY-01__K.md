---
id: K-FAIL-HALL-WITHOUT-MINIMALITY-01
logical_id: K-FAIL-HALL-WITHOUT-MINIMALITY-01
version_id: K-FAIL-HALL-WITHOUT-MINIMALITY-01@K
kind: canonical-result
run: K
title: "K fail hall without minimality"
status: KILLED
status_raw: "KILLED BY EXACT ARITHMETIC EXAMPLES"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 442, line_end: 466}
metadata: {"stable_id": "K-FAIL-HALL-WITHOUT-MINIMALITY-01", "version_id": "K-FAIL-HALL-WITHOUT-MINIMALITY-01@K", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 442, "line_end": 466}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 442, "line_end": 466}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K fail hall without minimality

*Run K - status `KILLED` (raw: `KILLED BY EXACT ARITHMETIC EXAMPLES`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FAIL-HALL-WITHOUT-MINIMALITY-01 -- KILLED BY EXACT ARITHMETIC EXAMPLES
For N=2200, the set S={3,13,1471} is active, closed and BAD:
  N-3=2197=13^3,
  N-13=2187=3^7,
  N-1471=729=3^6.
All labels are prime. Rows 13 and 1471 have only the child 3, violating
the matching condition. The set is not minimal: {3,13} is its core.
Its high source 1471 also shows why an arbitrary closed BAD set need
not have all labels below N/3, and why the no-repeated-pure-base lemma
must retain its low-label hypothesis.

There is also a counterexample with ALL labels low. For N=128 take
  S={3,5,7,11,13,23,29,37,41}.
The nine complete rows are
  N-3=125=5^3;     N-5=123=3*41;
  N-7=121=11^2;    N-11=117=3^2*13;
  N-13=115=5*23;   N-23=105=3*5*7;
  N-29=99=3^2*11;  N-37=91=7*13;
  N-41=87=3*29.
Rows {3,7,11,23,29,37} have child union {3,5,7,11,13}, six versus five.
This S is closed, BAD, active and low, but contains the proper eight-core
obtained by removing 37. Thus low support alone cannot replace minimality
in a proposed matching theorem. All rows and primes above were checked
by the exact SPF sieve.
```
