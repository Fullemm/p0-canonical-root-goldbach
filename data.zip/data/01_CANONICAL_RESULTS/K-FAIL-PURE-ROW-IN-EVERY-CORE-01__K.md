---
id: K-FAIL-PURE-ROW-IN-EVERY-CORE-01
logical_id: K-FAIL-PURE-ROW-IN-EVERY-CORE-01
version_id: K-FAIL-PURE-ROW-IN-EVERY-CORE-01@K
kind: canonical-result
run: K
title: "K fail pure row in every core"
status: KILLED
status_raw: "KILLED BY AN ACTUAL CORE"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 467, line_end: 486}
metadata: {"stable_id": "K-FAIL-PURE-ROW-IN-EVERY-CORE-01", "version_id": "K-FAIL-PURE-ROW-IN-EVERY-CORE-01@K", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 467, "line_end": 486}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 467, "line_end": 486}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K fail pure row in every core

*Run K - status `KILLED` (raw: `KILLED BY AN ACTUAL CORE`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FAIL-PURE-ROW-IN-EVERY-CORE-01 -- KILLED BY AN ACTUAL CORE
A compact full certificate is the ten-core at N=6142:
  S={3,5,7,13,17,19,157,227,409,877},
  N-3=6139=7*877,
  N-5=6137=17*19^2,
  N-7=6135=3*5*409,
  N-13=6129=3^3*227,
  N-17=6125=5^3*7^2,
  N-19=6123=3*13*157,
  N-157=5985=3^2*5*7*19,
  N-227=5915=5*7*13^2,
  N-409=5733=3^2*7^2*13,
  N-877=5265=3^4*5*13.
Every row has at least two distinct prime factors. Every label reaches
3, and 3 reaches every label using the displayed edges, proving strong
connectivity directly. This is a core with no pure row. The fourteen-core
at N=1928 is a second independently checked example. Therefore the
pure-row phenomenon at size three cannot simply be asserted for all sizes.
The replacement theorem is K-SPARSE-ROW-01, with its precise size bound.
```
