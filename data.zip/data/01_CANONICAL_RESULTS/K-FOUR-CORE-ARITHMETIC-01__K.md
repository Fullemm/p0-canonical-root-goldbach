---
id: K-FOUR-CORE-ARITHMETIC-01
logical_id: K-FOUR-CORE-ARITHMETIC-01
version_id: K-FOUR-CORE-ARITHMETIC-01@K
kind: canonical-result
run: K
title: "K four core arithmetic"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 200, line_end: 221}
metadata: {"stable_id": "K-FOUR-CORE-ARITHMETIC-01", "version_id": "K-FOUR-CORE-ARITHMETIC-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 200, "line_end": 221}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 200, "line_end": 221}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K four core arithmetic

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FOUR-CORE-ARITHMETIC-01 -- PROVED
In alternative (B), necessarily
  c=u+v+t*u*v, with t a positive ODD integer.     (K7)
In particular c>=ab+a+b. Thus if the third label of a four-core satisfies
c<ab+a+b, the core has a pure-power row.

Proof. From rows u and c, v divides c-u; from rows v and c, u divides
c-v. CRT gives c=u+v+t*u*v. Since c is odd and u+v is even, t is odd.
For two distinct odd primes u,v, u+v-uv<0, so positivity of c excludes
all negative t. QED.

The support of the last row sharpens the necessary location of d:
  G,H>0 => d=c+2*l*u*v for some l>=1;             (K8a)
  G,I>0 => d=v+2*l*u*c for some l>=1;             (K8b)
  H,I>0 => d=v+c+t'*v*c for a positive odd t'.    (K8c)
When all three exponents are positive, ALL three constraints apply.
For K8a, rows c,d share u and v, so their even parent difference is
divisible by 2uv. For K8b, rows v,d share u and c, so their difference
is divisible by 2uc. For K8c, rows u,d give d=u modulo v; K7 changes
this to d=c modulo v. Rows v,d give d=v modulo c. CRT and parity then
give K8c; v+c-vc<0 excludes a negative coefficient.
```
