---
id: K-FOUR-CORE-DICHOTOMY-01
logical_id: K-FOUR-CORE-DICHOTOMY-01
version_id: K-FOUR-CORE-DICHOTOMY-01@K
kind: canonical-result
run: K
title: "K four core dichotomy"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 159, line_end: 199}
metadata: {"stable_id": "K-FOUR-CORE-DICHOTOMY-01", "version_id": "K-FOUR-CORE-DICHOTOMY-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 159, "line_end": 199}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 159, "line_end": 199}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K four core dichotomy

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FOUR-CORE-DICHOTOMY-01 -- PROVED
Let S={a<b<c<d} be a core. Exactly one of the following alternatives holds:
(A) At least one full row is a proper prime power.
(B) After choosing an orientation (u,v)=(a,b) or (b,a), its COMPLETE rows
    have the form
      N-u = v^A * d^B,
      N-v = u^C * c^D,
      N-c = u^E * v^F,
      N-d = u^G * v^H * c^I,                      (K6)
    where A,B,C,D,E,F>=1, G,H,I>=0, and at least two of G,H,I are positive.
Thus there are exactly eight possible complete-support patterns in (B):
two orientations times the four supports {u,v},{u,c},{v,c},{u,v,c} for
the last row. Exponents are not bounded by this result.

Conversely, any distinct odd primes a<b<c<d, one such orientation and
exponents satisfying all four equalities K6 for a common N give a core.
Thus (B) is an exact arithmetic normal form for the pure-free four-core
class, not merely a list of selected edges that may have other factors.

Proof of necessity.
Let d's unique parent be r. If r=c, then rows a and b exclude d. Unless
one is pure, both contain c, contradicting uniqueness of a smaller parent
of c. Hence r belongs to {a,b}; call it u and call the other small label v.
Since neither v nor c is the parent of d, row c can only use u,v, and
must use both if no row is pure. Row v can only use u,c, so likewise uses
both. The smaller parent of c is now v, so row u cannot also contain c.
It already contains d and must have a second factor: the only possible
one is v. Row d excludes d and has at least two factors in {u,v,c}.
These are precisely K6 with the specified signs of the exponents.

Proof of sufficiency.
Each row in K6 has at least two distinct prime factors and is composite.
Its own label is absent. If any label divided N, its row equality would
force it to divide a product of powers of OTHER distinct primes, which
is impossible. Hence all labels are active. The graph contains u->v,
v->u, v->c, c->u,v and u->d; every possible nonempty last-row support
in K6 returns to {u,v,c}. It is therefore strongly connected and closed,
and so minimal. Every label has an incoming edge from a composite row,
which also implies every label is below N/3. N is automatically even
because each label and each product in its row equality are odd. QED.
```
