---
id: K-FOUR-HALL-DEFECT-01
logical_id: K-FOUR-HALL-DEFECT-01
version_id: K-FOUR-HALL-DEFECT-01@K
kind: canonical-result
run: K
title: "K four hall defect"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 333, line_end: 406}
metadata: {"stable_id": "K-FOUR-HALL-DEFECT-01", "version_id": "K-FOUR-HALL-DEFECT-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 333, "line_end": 406}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 333, "line_end": 406}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K four hall defect

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FOUR-HALL-DEFECT-01 -- PROVED
A four-core fails to have a perfect row-to-factor matching if and only if
its labels can be named r,b,x,y so that its COMPLETE rows have the form
  N-r = b^e,
  N-b = r^alpha * x^beta * y^gamma,
  N-x = r^u * b^v,
  N-y = r^w * b^z,                               (K14)
with e>=2, alpha>=0, beta,gamma>=1, u,w>=1, v,z>=0,
u+v>=2, w+z>=2, and v+z>=1. The labels are distinct odd primes, and
max{r,b,x,y} must belong to {x,y}; name y the largest if convenient.
No perfect-matching obstruction for four-cores remains outside this
explicit family. The family itself is NOT proved empty.

Proof of necessity.
If a perfect matching fails, there is a nonempty row subset R whose union
of child labels T has |T|<|R| (the finite Hall condition). The needed
direction also follows directly: start from an unmatched row in a maximum
matching, and follow alternating paths. All reached child vertices are
matched, since an unmatched one would give an augmenting path. Their
matched rows are reached too, while the starting row is unmatched. The
reached rows and their complete neighbor set therefore give |R|>|T|.

One row cannot have zero children. Two rows with only one possible child
would be distinct pure powers of the same prime, contrary to
K-NO-REPEATED-PURE-BASE-01. The full set of four rows has all four labels
as neighbors by source-freeness. Thus a deficient subset has exactly
three rows and exactly two possible child labels.

Since S has four labels, R and T intersect. If they contained both labels
of T in common, T would itself be a closed nonempty proper subset,
contradicting minimality. Hence R intersect T consists of a single label r.
Write T={r,b}, R={r,x,y}. The row of r must be pure in b. To avoid a
second pure row in b, BOTH x and y must have r as a child. If neither
had b as a child, their rows would both be pure in r, again impossible.
All appearances of x and y must come from the only row outside R, namely
b. This gives precisely K14 and its exponent conditions.

If r were the largest label, its two smaller parents x,y would contradict
K-ORDERED-FOREST-01. If b were the largest label, its parent r would
exclude appearances in rows x,y, forcing v=z=0, which was just excluded.
Therefore the largest label is x or y. This proves necessity.

Proof of sufficiency.
The first, third and fourth rows have only the two possible child labels
r,b, so those three rows cannot receive distinct representatives. All
rows are composite, closed and exclude their own prime label, giving
activity. The graph contains r->b, b->x,y and x,y->r, so is strongly
connected. Thus any prime solution of K14 is indeed a core without a
perfect matching. As before low labels follow from composite incoming
rows. The exponent signs are part of the statement, not guessed edges.
QED.

The Hall criterion is classical: P. Hall, On Representatives of Subsets,
J. London Math. Soc. 10 (1935), 26-30,
https://doi.org/10.1112/jlms/s1-10.37.26
The publisher's bibliographic record was checked. A scan of the original
paper was located, but the web tool did not retrieve it; no claim is made
to have inspected that scan's contents.
The alternating-path argument above is included to make the particular
direction used in this proof self-contained. The application to K14 is
the present result; no novelty claim about matching theory is made.

Further necessary constraints for K14:
  N=b^e+r,
  x*y divides N-b, so x*y<N,
  r divides y-x, and 2*r divides y-x.
If v,z>0 then 2*r*b divides y-x. These are necessary arithmetic filters;
they do not replace any complete factorization in K14.

SAVE POINT K3: the four-core matching problem has been reduced to an
explicit complete-factor family, rather than an unsupported induction.

8. HOSTILE CHECKS AND FAILED ROUTES
```
