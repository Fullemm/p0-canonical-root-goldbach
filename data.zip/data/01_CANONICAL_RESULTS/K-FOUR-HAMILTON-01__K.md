---
id: K-FOUR-HAMILTON-01
logical_id: K-FOUR-HAMILTON-01
version_id: K-FOUR-HAMILTON-01@K
kind: canonical-result
run: K
title: "K four hamilton"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 222, line_end: 237}
metadata: {"stable_id": "K-FOUR-HAMILTON-01", "version_id": "K-FOUR-HAMILTON-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 222, "line_end": 237}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 222, "line_end": 237}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K four hamilton

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-FOUR-HAMILTON-01 -- PROVED
Every pure-free four-core has a directed cycle visiting ALL four labels,
and therefore has a perfect row-to-factor matching. In K6, if H>0 use
  u -> d -> v -> c -> u.
If H=0, then G,I>0 and one can use
  u -> d -> c -> v -> u.
Each edge follows from a strictly positive exponent in a complete row.
This proves a matching theorem for the entire pure-free four-core branch,
without assuming that such a branch is arithmetically realizable.

These are equalities for the labels in an actual core; they are not
congruence-programming constructions of complete closed BAD sets.
They leave exponential Diophantine conditions K6 unsolved.

6. THREE-CORE REFINEMENT AND THE PURE-SQUARE BRANCH
```
