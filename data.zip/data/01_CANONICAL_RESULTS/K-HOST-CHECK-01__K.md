---
id: K-HOST-CHECK-01
logical_id: K-HOST-CHECK-01
version_id: K-HOST-CHECK-01@K
kind: canonical-result
run: K
title: "K host check"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 135, line_end: 158}
metadata: {"stable_id": "K-HOST-CHECK-01", "version_id": "K-HOST-CHECK-01@K", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 135, "line_end": 158}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 135, "line_end": 158}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K host check

*Run K - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-HOST-CHECK-01 -- VERIFIED COMPUTATION
An independent SPF sieve and minimal forward-closure computation recovered
all six known cores. Their full rows are recorded in
  nowe/core_probe_20260907K_results.txt
with reproducible code in
  nowe/core_probe_20260907K_code.txt
Both auxiliary files are plain TXT; Python executes the code TXT directly.
No probable-prime tests or external packages are used.

For each core, increasing-parent uniqueness and the indegree bound were
checked for every label. All pure rows have distinct prime bases.
Numbers of pure rows are 2,1,1,0,2,0 on the six hosts, respectively.
In particular a universal theorem forcing a pure row in EVERY core is
FALSE: N=1928 and N=6142 already refute it.

All six incidence graphs have perfect row-to-factor matchings. This is
only a six-host observation; it is not promoted to a universal theorem.
An exhaustive audit of all 4096 loop-free digraphs on FOUR ordered labels
finds 342 that are strongly connected and have at most one smaller parent
per child. Exactly eight of those have no row with only one child. These
are graph patterns, not 342 or eight arithmetic cores.

5. FOUR-CORE NORMAL FORM
```
