---
id: K-NO-REPEATED-PURE-BASE-01
logical_id: K-NO-REPEATED-PURE-BASE-01
version_id: K-NO-REPEATED-PURE-BASE-01@K
kind: canonical-result
run: K
title: "K no repeated pure base"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 122, line_end: 134}
metadata: {"stable_id": "K-NO-REPEATED-PURE-BASE-01", "version_id": "K-NO-REPEATED-PURE-BASE-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 122, "line_end": 134}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 122, "line_end": 134}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K no repeated pure base

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-NO-REPEATED-PURE-BASE-01 -- PROVED
In a core, two distinct rows cannot be proper powers of the same prime.
Indeed every row is in (2N/3,N), so the ratio of any two rows is less
than 3/2. Distinct powers of an odd prime have ratio at least 3. This is
a contradiction. More generally no row properly divides another row.
This uses low labels and applies to every closed BAD set entirely below
N/3; it is not asserted for arbitrary added high source rows.

SAVE POINT K1: ordered forest, universal sparse-row bound and exact scope
saved before proceeding with the four-core arithmetic classification.

4. COMPUTATIONAL CHECKS AT SAVE POINT K1
```
