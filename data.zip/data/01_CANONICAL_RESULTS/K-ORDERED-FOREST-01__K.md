---
id: K-ORDERED-FOREST-01
logical_id: K-ORDERED-FOREST-01
version_id: K-ORDERED-FOREST-01@K
kind: canonical-result
run: K
title: "K ordered forest"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 57, line_end: 84}
metadata: {"stable_id": "K-ORDERED-FOREST-01", "version_id": "K-ORDERED-FOREST-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 57, "line_end": 84}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["K-ORDERED-FOREST"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 57, "line_end": 84}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K ordered forest

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-ORDERED-FOREST-01 -- PROVED
Let S={q_1<...<q_s} be any nonempty finite active set whose complete BAD rows are
supported in S. Draw i->j if q_j divides N-q_i. For each j there is at
most ONE parent i<j. Consequently the increasing edges form a rooted
forest, and the number of these increasing edges is at most s-1.
For a core the full indegree satisfies
  1 <= indeg(q_j) <= s-j+1.                         (K1)
In particular the largest, second largest, third largest labels have
indegree at most 1,2,3, respectively, for every core and every N.

Proof. Two different parents q_i,q_k<q_j would imply
q_j divides q_i-q_k, whereas 0<abs(q_i-q_k)<q_j. This is impossible.
The increasing-edge graph is acyclic because labels increase along its
edges; each vertex has indegree at most one in this graph. It is therefore
a rooted forest. There are at most s-1 increasing edges, since q_1 has no
smaller parent. For the full indegree of q_j there is at most one smaller
parent, no self-parent, and at most s-j larger parents. Source-freeness
supplies the lower bound for a core. QED.

The parity refinement of the master's residue bound is also valid:
  #{r in S : q^v divides N-r}
       <= 1+floor((max S-min S)/(2*q^v)).           (K2)
All parents are odd; their differences are even multiples of the odd
integer q^v. Thus every source-free label q>(max S-min S)/2 has exactly
one parent. This improves the threshold in the supplied suggestion by a
factor of two, but the underlying 2q parent-spacing identity is already
in the old archive; no novelty is claimed for that identity.
```
