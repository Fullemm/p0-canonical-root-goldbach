---
id: K-ORDERED-FOREST@P-R
logical_id: K-ORDERED-FOREST
version_id: K-ORDERED-FOREST@P-R
kind: historical-version
run: P-R
title: "K ordered forest"
status: SUPERSEDED
status_raw: "each label has at most one parent of smaller index"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 105, line_end: 106}
metadata: {"stable_id": "K-ORDERED-FOREST", "version_id": "K-ORDERED-FOREST@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 105, "line_end": 106}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "K-ORDERED-FOREST-01", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 105, "line_end": 106}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: K-ORDERED-FOREST-01
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# K ordered forest

*Run P-R - status `SUPERSEDED` (raw: `each label has at most one parent of smaller index`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `K-ORDERED-FOREST-01` (run `P-R2`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
  D9  K-ORDERED-FOREST     each label has at most one parent of smaller index.
                                                                        PROVED
```
