---
id: K-SCOPE-AUDIT-01
logical_id: K-SCOPE-AUDIT-01
version_id: K-SCOPE-AUDIT-01@K
kind: canonical-result
run: K
title: "K scope audit"
status: PROVED WITH REPAIR
status_raw: "PROVED WITH REPAIR / EXPLICIT LIMITS"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 497, line_end: 581}
metadata: {"stable_id": "K-SCOPE-AUDIT-01", "version_id": "K-SCOPE-AUDIT-01@K", "status": "PROVED WITH REPAIR", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 497, "line_end": 581}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 497, "line_end": 581}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K scope audit

*Run K - status `PROVED WITH REPAIR` (raw: `PROVED WITH REPAIR / EXPLICIT LIMITS`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-SCOPE-AUDIT-01 -- PROVED WITH REPAIR / EXPLICIT LIMITS
* The square theorem was restricted to U=2 in the forced row K9; the
  broader initial wording was not supported by its proof. The correction
  and the surviving exponent filters are recorded above.
* A perfect matching and a Hamilton cycle are distinct notions. The
  latter implies the former. The counts 22 and 50 above are different;
  no converse was silently used.
* K6 classifies full support patterns of the pure-free four-core branch,
  not prime/exponent solutions, and not all four-cores.
* K14 exactly classifies possible four-core matching defects, but is
  not a proof that any such defect is arithmetically realized or excluded.
* K5 bounds distinct factors, not multiplicities. Exponents may be large.
* The sharp abstract forest examples are not CRT constructions of actual
  cores. They are only countermodels to graph-only deductions.
* The current six-host computations were independently rerun. The much
  larger J census and two-core search were not rerun and remain attributed
  to their source, with their original finite domains.

9. RELATION TO GOLDBACH AND ROOT EXCEPTIONALISM

The new results concern complete closed BAD sets, not selected paths.
They hold without choosing p_0 and so constrain the common obstruction
faced by every upper root. They neither disprove a p_0-specific mechanism
nor identify a universally successful class of ranks.

The work does not prove Goldbach, host finiteness, nonexistence of any
new core size, or an effective all-N bound for K6, K9, K12 or K14.
Even a future proof that all cores have perfect matchings would not
exclude the six known hosts: all six core graphs already have matchings.
Additional arithmetic would still be needed to exclude large hosts or
to ensure a GOOD escape for the chosen root.

There is nonetheless a concrete improvement over the audited master:
the top-element lemma now has an all-ranks indegree bound, a full ordered
forest budget, and a size-only sparse-row consequence. At size four the
pure-free branch has an exact eight-pattern normal form and a proved
Hamilton/matching property. Failure of a universal four-core matching
theorem has been isolated into the complete-factor family K14. The
three-core forced-square branch has a more restrictive exact system.
These are structural advances and residual problems, not a complete
classification of arithmetic cores.

10. NEXT FRONTIER

Priority 1: attack K14 arithmetically. It captures EVERY possible
four-core failure of the matching condition. It combines three complete
rows supported in {r,b}, one of them the pure power b^e, with a fourth
row containing both remaining prime labels x,y. The constraints xy<N,
the full row differences, and exact valuations must be used together.
A proof that K14 has no prime solution would settle the matching theorem
for all four-cores. It would NOT yet exclude all four-cores.

Priority 2: use the exact K6/K7/K8 system for the pure-free four-core
branch, keeping each of its four possible last-row supports separate.
The lower bounds c>=ab+a+b and the different d identities are genuine
arithmetic restrictions that an abstract graph does not supply.

Priority 3: the U=2 three-core branch is the single system K12 with
T>=max(5,2V+1). Any finite search should first prove that its prime and
exponent domain is complete. Increasing a numerical cutoff alone does
not close this branch and is not the proposed next step.

No density theorem for hosts or deterministic low-Goldbach deficiency
was derived. The host-rarity route remains separate and open.

INPUT / ARTIFACT INTEGRITY
Input master_ai.tex SHA256:
  84dd17e70f345d3d0679557c9b6932ead1b56be76f462e05dae9b6ea285a90c9
Input raw J checkpoint SHA256:
  c37c0901dc12a197185bd54bdd2500aa0cb96f4e22a2502e5efc0be0ad0e7fe6
The latter matches the hash quoted by the audited master. Neither input
was edited. The main master was searched for the ordered forest,
triangular sparsity, Hamilton and four-core Hall formulations. No matching
statement was located; the old three-core normal form was located and
explicitly credited above. This is an archive check, not a literature-wide
novelty claim.

New artifacts, all TXT in nowe:
  goldbach_checkpoint_2026-09-07K.txt  -- this complete research checkpoint;
  core_probe_20260907K_code.txt      -- reproducible exact verification;
  core_probe_20260907K_results.txt   -- full six-core arithmetic and audits.
Proofs were saved at K1, K2 and K3 during the work. No subagent, PDF output
or TeX output was used. All completed verification assertions passed.
END CURRENT CHECKPOINT -- 2026-09-07K
```
