---
id: K-SPARSE-ROW-01
logical_id: K-SPARSE-ROW-01
version_id: K-SPARSE-ROW-01@K
kind: canonical-result
run: K
title: "K sparse row"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 85, line_end: 103}
metadata: {"stable_id": "K-SPARSE-ROW-01", "version_id": "K-SPARSE-ROW-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 85, "line_end": 103}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["K-SPARSE-ROW"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 85, "line_end": 103}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K sparse row

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-SPARSE-ROW-01 -- PROVED
Write w_i=number of distinct prime factors of N-q_i, i.e. full outdegree,
and d=min_i w_i. Then
  sum_(i=1,...,s) max(0,w_i-i+1) <= s-1,          (K3)
  d*(d+1)/2 <= s-1,                              (K4)
  d <= floor((sqrt(8*s-7)-1)/2).                  (K5)
In particular a core of size 2 or 3 has a pure-prime-power row; every core
of size 4,5,6 has a row supported on at most TWO distinct primes. The
general conclusion is an O(sqrt(s)) distinct-factor row, independent of N
and of the actual sizes of the prime labels. Multiplicities remain
unrestricted: this is a bound on omega, not on Omega.

Proof. Row i has at most i-1 smaller children, no self-child, and hence
at least max(0,w_i-i+1) larger children. Sum and apply K-ORDERED-FOREST-01
to get K3. Since every row has at least d children, the first d rows
contribute at least d+(d-1)+...+1=d(d+1)/2 to the left of K3. This proves
K4 and solving the quadratic yields K5. BADness makes a one-factor row
a proper prime power rather than a prime. QED.
```
