---
id: K-SPARSE-ROW-SHARPNESS-01
logical_id: K-SPARSE-ROW-SHARPNESS-01
version_id: K-SPARSE-ROW-SHARPNESS-01@K
kind: canonical-result
run: K
title: "K sparse row sharpness"
status: PROVED
status_raw: "PROVED, COMBINATORIAL SCOPE ONLY"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 104, line_end: 121}
metadata: {"stable_id": "K-SPARSE-ROW-SHARPNESS-01", "version_id": "K-SPARSE-ROW-SHARPNESS-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 104, "line_end": 121}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 104, "line_end": 121}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K sparse row sharpness

*Run K - status `PROVED` (raw: `PROVED, COMBINATORIAL SCOPE ONLY`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-SPARSE-ROW-SHARPNESS-01 -- PROVED, COMBINATORIAL SCOPE ONLY
The triangular bound cannot be improved using just strong connectivity,
no self-edges and uniqueness of a smaller parent.
For every integer d>=1 put s=1+d(d+1)/2. There is a strongly connected
ordered digraph on 1,...,s, satisfying all those incidence conditions,
with every row having exactly d distinct children.

Construction. Give vertex 1 the children 2,...,d+1. For i=2,...,d give
vertex i all smaller vertices 1,...,i-1 and then a fresh disjoint block
of d-i+1 labels larger than d+1. These fresh blocks exactly exhaust the
remaining labels up to s. For every i>d give the children 1,...,d.
Each vertex other than 1 receives exactly one increasing edge. Vertex 1
reaches every other vertex via the increasing tree, and every other vertex
has an edge to 1, so the graph is strongly connected. All degrees are d.
For d=1 this is the two-cycle. This construction does NOT assert the
existence of primes and a common N realizing all its full factor rows.
Any stronger arithmetic sparsity theorem must use additional arithmetic.
```
