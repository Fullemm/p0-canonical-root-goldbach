---
id: K-SPARSE-ROW@P-R
logical_id: K-SPARSE-ROW
version_id: K-SPARSE-ROW@P-R
kind: historical-version
run: P-R
title: "P7 was labelled a strengthening of"
status: SUPERSEDED
status_raw: "It is not: K bounds"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 63, line_end: 104}
metadata: {"stable_id": "K-SPARSE-ROW", "version_id": "K-SPARSE-ROW@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 63, "line_end": 104}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "K-SPARSE-ROW-01", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 63, "line_end": 104}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: K-SPARSE-ROW-01
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 107, style: NUMBERED-ID-LINE}
---

# P7 was labelled a strengthening of

*Run P-R - status `SUPERSEDED` (raw: `It is not: K bounds`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `K-SPARSE-ROW-01` (run `P-R2`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
R5.  P7 was labelled a strengthening of K-SPARSE-ROW.  It is not: K bounds
     min_i omega(N-q_i) by about sqrt(2s), while P7's bound on the same
     quantity is floor(s/2), which is weaker for s >= 6.  REPAIR: P7 is
     reclassified as COMPLEMENTARY (it localises index and support; it does not
     improve the sparsity bound).  No combined strengthening is claimed.

R6.  P4's coprimality proof said the three gcd cases were "identical".  They are
     not: gcd(a,b) and gcd(a,c) follow from one size argument, but gcd(b,c)
     needs a separate treatment and, in the sub-case gcd(b,c) = 2 with a = 2, a
     parity argument.  REPAIR: full proof given.

R7.  purecore.c used MAXW = 4096 and treated a closure overflow as a rejection,
     which is an unproved completeness assumption.  REPAIR: MAXW raised to
     200000, overflows counted and printed, and the "large child" branch (dead
     code by thm:postJ-basin) instrumented as well.  The census is reported only
     with an explicit certificate that both counters are zero.

R8.  Every phrase implying that the class s = 3 is settled for all N is replaced
     by the bounded statement.  All-N existence of a three-element core is OPEN.

--------------------------------------------------------------------------------
1.  INPUT / CURRENT STATE
--------------------------------------------------------------------------------

Master v1.4 (27910 lines).  Read: ch:nav, ch:state, ch:notation, sec:blow,
sec:six, ch:postJ in full, ch:postKLO in full, sec:postKLO-frontier.

Dependencies used, with their status in the master:
  D1  thm:postJ-basin      every prime factor of a BAD row is < N/3;
                           r fails <=> PF(N-r) subseteq B_N;
                           p in B_N <=> N-p in Gamma_{B_N}.        REPAIR/PROVED
  D2  thm:postJ-core       cores = terminal SCCs; strongly connected,
                           source-free, |S| >= 2.                        PROVED
  D3  thm:postJ-autoactivity  q | N-p with p active => q active, q != p. PROVED
  D4  thm:postJ-top        parents of q lie in one class mod q, spaced by
                           2q; max S divides exactly one row of a core.  PROVED
  D5  thm:postJ-three-core a 3-core has N-q_1 = q_2^a or N-q_2 = q_1^b.  PROVED
  D6  thm:postJ-cycle      two-cycle: pq | N-p-q, so pq < N if p,q < N/3. PROVED
  D7  cor:postJ-two-core-census   only N = 2200 has a two-element core,
                           for even N <= 1e24.                        VERIFCOMP
  D8  thm:L-four-matching  every core with |S| <= 4 has a perfect matching.
                                                                        PROVED
```
