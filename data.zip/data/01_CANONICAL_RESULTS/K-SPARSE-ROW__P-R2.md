---
id: K-SPARSE-ROW@P-R2
logical_id: K-SPARSE-ROW
version_id: K-SPARSE-ROW@P-R2
kind: historical-version
run: P-R2
title: "P7 was labelled a strengthening of"
status: SUPERSEDED
status_raw: "It is not: K bounds"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 72, line_end: 162}
metadata: {"stable_id": "K-SPARSE-ROW", "version_id": "K-SPARSE-ROW@P-R2", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 72, "line_end": 162}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "K-SPARSE-ROW-01", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 72, "line_end": 162}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: K-SPARSE-ROW-01
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
supersedes_runs: [P-R]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 165, style: NUMBERED-ID-LINE}
---

# P7 was labelled a strengthening of

*Run P-R2 - status `SUPERSEDED` (raw: `It is not: K bounds`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `K-SPARSE-ROW-01` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
R5.  P7 was labelled a strengthening of K-SPARSE-ROW.  It is not: K bounds
     min_i omega(N-q_i) by about sqrt(2s), while P7's bound on the same
     quantity is floor(s/2), which is weaker for s >= 6.  REPAIR: P7 is
     reclassified as COMPLEMENTARY (it localises index and support; it does not
     improve the sparsity bound).  No combined strengthening is claimed.

R6.  P4's coprimality proof said the three gcd cases were "identical".  They are
     not: gcd(a,b) and gcd(a,c) follow from one size argument, but gcd(b,c)
     needs a separate treatment and, in the sub-case gcd(b,c) = 2 with a = 2, a
     parity argument.  REPAIR: full proof given.

R7.  purecore.c used MAXW = 4096 and treated a closure overflow as a rejection,
     which is an unproved completeness assumption.  REPAIR: MAXW raised to
     200000, overflows counted and printed, and the "large child" branch (dead
     code by thm:postJ-basin) instrumented as well.  The census is reported only
     with an explicit certificate that both counters are zero.

R8.  Every phrase implying that the class s = 3 is settled for all N is replaced
     by the bounded statement.  All-N existence of a three-element core is OPEN.

--- round 2 ---

R9.  E5-R's CONCLUSION line read "no even N <= 1e10 has a core containing a pure
     prime-power row whose partner lies below sqrt(N)".  That contradicts the
     experiment's own output, which REPORTS exactly such cores at
     N = 128, 1718, 1862 and 2200.  The sentence confused "the search found
     nothing new" with "no such object exists".
     REPAIR: the conclusion now reads "no NEW host in the pure-row/small-partner
     class for even N <= 1e10; the four known hosts in that class are recovered
     and are the only ones".

R10. P1b asserted, for ANY closed BAD set, both that the base of a pure row is
     below sqrt N and that for m = 2 the base lies in (sqrt(2N/3), sqrt N).
     Only the first half is universal.  The window needs N - q_i > 2N/3, i.e.
     the PARTNER q_i < N/3, which holds for source-free sets (hence cores) but
     not in general.
     COUNTEREXAMPLE (verified here): N = 128, q = 103, 128 - 103 = 25 = 5^2.
     S = core u {103} = {3,5,7,11,13,23,29,41,103} is a closed BAD set with a
     pure row of base 5 and exponent 2.  Universal half: 5 < sqrt(128) = 11.314,
     true.  Window half: 5 > sqrt(2*128/3) = 9.238, FALSE.  Reason: the partner
     103 exceeds N/3 = 42.67, so N - 103 = 25 < 2N/3 = 85.33.
     REPAIR: P1b is split into P1b (universal) and P1c (hypothesised).  The
     justification of m >= 2 is also corrected: it follows from compositeness of
     the row alone, not from any size comparison with 2N/3.

R11. The header of threecore.c still described the program as a "COMPLETE search
     for closed BAD sets of size 3", i.e. it carried the very over-scoping that
     R2 removed from the prose.
     REPAIR: the header now states that the box is exhaustive for three-element
     CORES via P3a, names minimality as load-bearing, and carries the standing
     witness N = 2200, S = {3,13,1471} as the object the box cannot see.
     Output labels changed from "TWO-CORE"/"THREE-CORE" to
     "TWO-ELEMENT-SET"/"THREE-ELEMENT-SET", since what a hit verifies is a
     closed BAD set of that size, while what the box decides is the core class.

R12. The computational domain was described as "all even N <= X".  Neither
     program contains an N <= X filter; both enumerate a BOX in (p, m, q).
     REPAIR: the domain is now stated as the box itself --
         Q = p^m <= X (p odd prime, m >= 2);  q odd prime, q != p, q^2 < Q + q --
     together with the two facts that make it usable: it COVERS every even
     N <= X (because Q = N - q < N <= X), and it additionally tests some N in
     (X, X + sqrt X], which is extra coverage rather than a gap.  The prime list
     runs to sqrt(X) + 2, which covers both the bases (p^2 <= X) and the largest
     admissible partner (q^2 - q < X).
     Both source files were corrected and re-run; output is unchanged
     (threecore at X = 3e9: 16 169 954 candidates, 2 hits, both N = 2200;
     purecore2 at X = 2e8: 1 480 664 candidates, 6 hits, overflows 0,
     large-child events 0).

--------------------------------------------------------------------------------
1.  INPUT / CURRENT STATE
--------------------------------------------------------------------------------

Master v1.4 (27910 lines).  Read: ch:nav, ch:state, ch:notation, sec:blow,
sec:six, ch:postJ in full, ch:postKLO in full, sec:postKLO-frontier.

Dependencies used, with their status in the master:
  D1  thm:postJ-basin      every prime factor of a BAD row is < N/3;
                           r fails <=> PF(N-r) subseteq B_N;
                           p in B_N <=> N-p in Gamma_{B_N}.        REPAIR/PROVED
  D2  thm:postJ-core       cores = terminal SCCs; strongly connected,
                           source-free, |S| >= 2.                        PROVED
  D3  thm:postJ-autoactivity  q | N-p with p active => q active, q != p. PROVED
  D4  thm:postJ-top        parents of q lie in one class mod q, spaced by
                           2q; max S divides exactly one row of a core.  PROVED
  D5  thm:postJ-three-core a 3-core has N-q_1 = q_2^a or N-q_2 = q_1^b.  PROVED
  D6  thm:postJ-cycle      two-cycle: pq | N-p-q, so pq < N if p,q < N/3. PROVED
  D7  cor:postJ-two-core-census   only N = 2200 has a two-element core,
                           for even N <= 1e24.                        VERIFCOMP
  D8  thm:L-four-matching  every core with |S| <= 4 has a perfect matching.
                                                                        PROVED
```
