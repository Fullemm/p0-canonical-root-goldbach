---
id: K-THREE-CYCLE-01
logical_id: K-THREE-CYCLE-01
version_id: K-THREE-CYCLE-01@K
kind: canonical-result
run: K
title: "K three cycle"
status: PROVED
status_raw: "PROVED (REFINEMENT OF THE ARCHIVED NORMAL FORM)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 238, line_end: 271}
metadata: {"stable_id": "K-THREE-CYCLE-01", "version_id": "K-THREE-CYCLE-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 238, "line_end": 271}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 238, "line_end": 271}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K three cycle

*Run K - status `PROVED` (raw: `PROVED (REFINEMENT OF THE ARCHIVED NORMAL FORM)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-THREE-CYCLE-01 -- PROVED (REFINEMENT OF THE ARCHIVED NORMAL FORM)
The master already records the general three-core pure-row normal form.
The following forced positive exponent and directed cycle are worth making
explicit. In every three-core, orient the two smaller labels as u,v and
call the largest c, so that the row of v is pure in u. Then
  N-v=u^U,
  N-u=v^V*c^W,
  N-c=u^Z*v^T,                                  (K9)
where U>=2, W>=1, V,Z>=0, T>=1, V+W>=2, Z+T>=2, and 0<=Z<U.
In particular every three-core contains the directed cycle
  v -> u -> c -> v.
There are eight full support patterns: two orientations and the choices
whether V and Z vanish. No assertion of arithmetic realizability of all
eight patterns is made.

Proof. The audited top-element argument gives the first two rows with
W>=1. If T were zero, the last row would be another proper power of u,
contradicting K-NO-REPEATED-PURE-BASE-01. Thus T>=1. Since c>v,
  u^Z*v^T=N-c<N-v=u^U,
which forces Z<U. Positivity of W,T supplies the displayed cycle.
The full equations and sign conditions conversely imply activity,
compositeness, closure and strong connectivity exactly as in K6.

Additional exact relations, useful for a targeted Diophantine attack:
  N=u^U+v,
  c=v+u^Z*(u^(U-Z)-v^T),
  v_u(c-v)=Z,                                   (K10)
  u^U+v-u=v^V*c^W.
Here v_u denotes the exact prime valuation, including value zero.
Indeed u does not divide u^(U-Z)-v^T. If V>0, then
  ord_v(u) divides U-1,
by reducing the last equality modulo v and dividing by the unit u.
These conditions retain the whole final cofactor and do not replace K9.
```
