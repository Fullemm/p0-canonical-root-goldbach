---
id: K-THREE-PURE-SQUARE-01
logical_id: K-THREE-PURE-SQUARE-01
version_id: K-THREE-PURE-SQUARE-01@K
kind: canonical-result
run: K
title: "K three pure square"
status: PROVED
status_raw: "PROVED, FOR THE FORCED SMALL-PARENT ROW"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 272, line_end: 305}
metadata: {"stable_id": "K-THREE-PURE-SQUARE-01", "version_id": "K-THREE-PURE-SQUARE-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 272, "line_end": 305}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 272, "line_end": 305}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K three pure square

*Run K - status `PROVED` (raw: `PROVED, FOR THE FORCED SMALL-PARENT ROW`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-THREE-PURE-SQUARE-01 -- PROVED, FOR THE FORCED SMALL-PARENT ROW
Assume the forced pure row N-v=u^U selected in K9 has U=2. Then, with
a<b<c the core labels, its COMPLETE rows necessarily are
  N-a=b^2,
  N-b=a^V*c,
  N-c=a^T,                                      (K11)
with V>=1 and T>=2. In this branch the square is the power of the middle
label, and the largest label occurs to exponent exactly 1. Equivalently
this entire U=2 branch of K9 is reduced to
  N=b^2+a,
  c=b^2+a-a^T,
  a^V*(b^2+a-a^T)=b^2-b+a,                      (K12)
with a<b<c odd primes and the stated exponents. Necessarily a divides
b-1. The equations are not claimed solved or uniformly bounded here.

Proof. In K9 assume U=2. Since c exceeds u and v, we have
  c^2>u^2+v-u=N-u;
if v<=u this is immediate, while for v>u use
c^2-u^2>(c-u)>v-u. Thus W=1 and BADness forces V>=1.
If u<v, then v*c>u^2+v-u: even v^2-(u^2+v-u)
=(v-u)*(v+u-1)>0. This contradicts N-u=v^V*c. So u=b and v=a.
If Z>0, the two rows u,c give a reciprocal edge pair u<->c, hence
  u*c divides N-u-c, with 0<N-u-c<N.
But N=u^2+v and u*c>=u*(u+2)>u^2+v=N because v<u.
This is impossible. Consequently Z=0 and N-c=v^T with T>=2.
Finally reduce N-u=v^V*c modulo v: v divides u^2-u, and distinctness
of the primes gives u=1 modulo v. This proves K11 and K12. QED.

Scope repair at proof audit: the initial wording said ANY pure-square
row, but the proof starts with U=2. A possible square N-u=c^2 in the
OTHER row is not covered. The theorem has therefore been restricted to
the forced small-parent pure row. No exclusion of that other square
branch is claimed. This repair was made before any final conclusion.
```
