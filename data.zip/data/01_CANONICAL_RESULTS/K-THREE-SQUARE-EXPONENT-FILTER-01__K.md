---
id: K-THREE-SQUARE-EXPONENT-FILTER-01
logical_id: K-THREE-SQUARE-EXPONENT-FILTER-01
version_id: K-THREE-SQUARE-EXPONENT-FILTER-01@K
kind: canonical-result
run: K
title: "K three square exponent filter"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07K.txt", line: 306, line_end: 332}
metadata: {"stable_id": "K-THREE-SQUARE-EXPONENT-FILTER-01", "version_id": "K-THREE-SQUARE-EXPONENT-FILTER-01@K", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 306, "line_end": 332}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07K.txt", "line": 306, "line_end": 332}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# K three square exponent filter

*Run K - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
K-THREE-SQUARE-EXPONENT-FILTER-01 -- PROVED
In the K11/K12 branch one necessarily has
  a^V < b < a^(T-V) < c,
  T>=2V+1, and T>=5.                             (K13)
If V=1, additionally b=1 modulo a^2 and b>=2a^2+1.

Proof. Because a<b<c,
  a^V*c=N-b=b^2-b+a<b^2,
so a^V<b. Subtracting the two rows supported in a gives
  c*(a^V-1)=a^T-b.
If T<=V the right side is less than a^V-1, impossible since c>1.
Also c>b implies a^T>b*a^V, hence b<a^(T-V). Dividing the displayed
identity by a^V gives a^(T-V)=c-(c-b)/a^V<c. The strict inequalities
a^V<b<a^(T-V) imply T>2V.
For V=1, write b=1+k*a using a divides b-1. Then
  c=(b^2-b+a)/a=k*b+1.
Since N-c=a^T is divisible by a, reduction modulo a gives k=0 modulo a.
Therefore b=1 modulo a^2. As b is odd, a is odd, and b>1, the positive
coefficient in b=1+l*a^2 is even, so b>=2a^2+1. Every core row exceeds
2N/3, so a^T=N-c>2N/3>(2/3)*b^2>(8/3)*a^4. Thus T>=5 when V=1.
For V>=2 the inequality T>=2V+1 already gives T>=5. QED.

SAVE POINT K2: exact four-core support classification, label constraints,
and the refined three-core/square branch saved with complete proofs.

7. EXACT REMAINING OBSTRUCTION TO A FOUR-CORE MATCHING THEOREM
```
