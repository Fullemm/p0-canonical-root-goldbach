---
id: L-BOUNDED-EXPONENT-HEIGHT-01
logical_id: L-BOUNDED-EXPONENT-HEIGHT-01
version_id: L-BOUNDED-EXPONENT-HEIGHT-01@L
kind: canonical-result
run: L
title: "L bounded exponent height"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 212, line_end: 219}
metadata: {"stable_id": "L-BOUNDED-EXPONENT-HEIGHT-01", "version_id": "L-BOUNDED-EXPONENT-HEIGHT-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 212, "line_end": 219}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 212, "line_end": 219}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L bounded exponent height

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-BOUNDED-EXPONENT-HEIGHT-01 -- PROVED
Every K14 solution with 2<=e<=E, E>=7, satisfies
  N <= floor((E-1)/2)^E + floor((7^E-1)/6^E).
Indeed b<=(e-v-1)/2<=(E-1)/2 and r<(7/6)^e<=(7/6)^E,
while N=b^e+r. The displayed integer bound follows directly. It is a
theorem about ALL N at bounded exponent, not an empirically chosen
height cutoff. It does not give a uniform height bound when e varies.
```
