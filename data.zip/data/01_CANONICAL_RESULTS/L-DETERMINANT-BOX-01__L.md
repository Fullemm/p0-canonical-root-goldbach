---
id: L-DETERMINANT-BOX-01
logical_id: L-DETERMINANT-BOX-01
version_id: L-DETERMINANT-BOX-01@L
kind: canonical-result
run: L
title: "L determinant box"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 81, line_end: 111}
metadata: {"stable_id": "L-DETERMINANT-BOX-01", "version_id": "L-DETERMINANT-BOX-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 81, "line_end": 111}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 81, "line_end": 111}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L determinant box

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-DETERMINANT-BOX-01 -- PROVED
Put t=e-v and define the positive integer
  D=(e-z)*u-(e-v)*w.
Then
  1<=D,  r^D < (x/(x-1))^t,                     (L3)
  x<=t<=e,
  r*(x-1)^t < x^t.                             (L4)
Therefore, for EVERY fixed e, both prime labels x,r belong to a completely
explicit FINITE set, independent of N and of the size of the other prime b.

Proof. Let a=u-w>0 and d=z-v>0. The exact row ratios give
  (N-x)/(N-y)=r^a/b^d,
  (N-r)/(N-y)=b^(e-z)/r^w.
Both ratios are >1 because y>x,r. Raising the first to e-z and the second
to d and multiplying cancels b exactly:
  r^D=((N-x)/(N-y))^(e-z)*((N-r)/(N-y))^d.
Thus D is a positive integer. From xy<N we have y<N/x and therefore
  N/(N-y)<x/(x-1).
Both ratios are smaller than this, and the two positive exponents sum
to e-z+d=e-v=t. This proves L3 and the last inequality of L4.
For x<=t one can use natural logarithms: r>=3 and log 3>1, while
log(x/(x-1))<1/(x-1). Hence 1<t/(x-1), giving x<t+1 and x<=t.
This step uses only the elementary inequality exp(1)<3. QED.

An exact enumeration of the necessary label box uses no floating point:
for each 0<=v<=e-3, set t=e-v; enumerate odd primes x<=t and odd primes
r!=x satisfying r*(x-1)^t<x^t. Possible D are exactly the positive
integers satisfying r^D*(x-1)^t<x^t. For each candidate z in
[v+1,e-2], one additionally requires gcd(e-z,t) to divide D.
The last condition follows from D=(e-z)u-t*w; it is not sufficient.
```
