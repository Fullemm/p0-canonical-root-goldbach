---
id: L-EXPONENT-100-01
logical_id: L-EXPONENT-100-01
version_id: L-EXPONENT-100-01@L
kind: canonical-result
run: L
title: "L exponent 100"
status: VERIFIED COMPUTATION
status_raw: "EXACT COMPUTATION, FIRST IMPLEMENTATION COMPLETE"
audit: SOURCE-RECORDED-CODE-AND-INDEPENDENT-AUDIT; NOT-RERUN-BY-ASTRA
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 220, line_end: 242}
metadata: {"stable_id": "L-EXPONENT-100-01", "version_id": "L-EXPONENT-100-01@L", "status": "VERIFIED COMPUTATION", "scope": "Complete proved parameter boxes for 2<=e<=100, all N within those boxes", "assumptions": ["L height/parameter reduction", "Exact finite enumeration"], "statement": "No complete K14 system in the e<=100 parameter boxes. Later L results exclude the remaining exponent range separately.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 220, "line_end": 242}, "depends_on": [], "consequences": [], "does_not_imply": ["This record alone is not all-exponent matching"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 220, "line_end": 242}, "proof_provenance": [], "computation": ["hall_complete_exponent_20260908L"], "concepts": ["enumeration-box", "cycle-cover", "pure-row"], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-RECORDED-CODE-AND-INDEPENDENT-AUDIT; NOT-RERUN-BY-ASTRA", "metadata_completeness": "CURATED"}
---

# L exponent 100

*Run L - status `VERIFIED COMPUTATION` (raw: `EXACT COMPUTATION, FIRST IMPLEMENTATION COMPLETE`) - audit `SOURCE-RECORDED-CODE-AND-INDEPENDENT-AUDIT; NOT-RERUN-BY-ASTRA`*

> Verification: **SOURCE-RECORDED-CODE-AND-INDEPENDENT-AUDIT; NOT-RERUN-BY-ASTRA**. Metadata coverage: CURATED.

## Current scoped statement

No complete K14 system in the e<=100 parameter boxes. Later L results exclude the remaining exponent range separately.

**Assumptions:** L height/parameter reduction; Exact finite enumeration.

**Does not imply:** This record alone is not all-exponent matching.

## Source transcript (historical wording; apply current metadata)

```
L-EXPONENT-100-01 -- EXACT COMPUTATION, FIRST IMPLEMENTATION COMPLETE
The complete L5/L6 procedure finished for every integer 2<=e<=100:
  bounded (e,k,b,x,r) candidates:       2,631,811;
  candidates with k dividing N-b:       370,300;
  also satisfying r dividing N-x:           48;
  with complete row N-x=r^u*b^v:              0;
  complete K14 systems:                       0.
All labels b,x,r were proved prime by an exact smallest-prime-factor
sieve. All comparisons and factorizations used integers. No probable-
prime decisions or floating-point bounds were used. In fact all cases
failed before computing or testing the primality of y.

Subject to the proof of the complete parameter box, this excludes every
four-core matching defect with e<=100 for ALL N. Hence any such defect
would have e>=101. This does not exclude all four-cores or prove that
all four-cores have perfect matchings. The exponent is still unbounded.
An independent implementation will now audit the finite enumeration.

SAVE POINT L3: the all-N height theorem and first completed e<=100
exclusion have been saved. Reproducible code and its complete per-e
counts are hall_complete_exponent_20260908L_code.txt and
hall_complete_exponent_20260908L_results.txt in this directory.
```
