---
id: L-EXPONENT-ORIENTATION-01
logical_id: L-EXPONENT-ORIENTATION-01
version_id: L-EXPONENT-ORIENTATION-01@L
kind: canonical-result
run: L
title: "L exponent orientation"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 44, line_end: 71}
metadata: {"stable_id": "L-EXPONENT-ORIENTATION-01", "version_id": "L-EXPONENT-ORIENTATION-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 44, "line_end": 71}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 44, "line_end": 71}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L exponent orientation

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-EXPONENT-ORIENTATION-01 -- PROVED
Every solution of L0 with x<y=max S satisfies
  u>w>=1,  0<=v<z.                               (L1)
Thus the largest label y CANNOT have a pure r-power row. In particular
the entire z=0 branch of K14 is excluded for every N and every exponent.

Proof. Suppose instead v>z. The row interval then forces w>u. Since
N-x>N-y, we have b^(v-z)>r^(w-u). Both powers are odd, hence
  y-x=r^u*b^z*(b^(v-z)-r^(w-u))>=2*r^u*b^z.
If x>r, subtract the row N-r=b^e to obtain
  x-r=b^v*(b^(e-v)-r^u)>=2*b^v.
The positive difference in parentheses is an even integer; e-v>=1.
It follows that
  xy>4*r^u*b^(v+z)>=4*(N-x)>8N/3>N,
contrary to xy<N.

If x<r, the reverse subtraction gives
  r-x=b^v*(r^u-b^(e-v))>=2*b^v,
so r>b^v and r^u>b^(e-v). Since y>r,
  r^w*b^z=N-y<N-r=b^e,
so r^w<b^(e-z). Raising and comparing these inequalities gives
  e*(w-u)<wv-uz,
whereas r>b^v and r^w<b^(e-z) give wv+z<e. Consequently
  e*(w-u)<wv-uz<e,
which is impossible for the positive integer w-u. The labels x,r are
distinct, so the two cases exhaust the possibilities. Therefore v<z,
and the row interval forces u>w. QED.
```
