---
id: L-FIRST-EXPONENT-BOUND-01
logical_id: L-FIRST-EXPONENT-BOUND-01
version_id: L-FIRST-EXPONENT-BOUND-01@L
kind: canonical-result
run: L
title: "L first exponent bound"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 192, line_end: 211}
metadata: {"stable_id": "L-FIRST-EXPONENT-BOUND-01", "version_id": "L-FIRST-EXPONENT-BOUND-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 192, "line_end": 211}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 192, "line_end": 211}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L first exponent bound

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-FIRST-EXPONENT-BOUND-01 -- PROVED
No four-core matching defect has e<=10. From L5, k is odd, k>=7 and
k<=e. For e<=10 only k=7 or 9 could occur. At k=9, k-1=8 has no odd
prime divisor b. At k=7, x=7,b=3 and alpha=0. For e<=10, L6 gives
r<(7/6)^10<5 (exactly 7^10<5*6^10), whereas r is an odd prime distinct
from b=3 and x=7. No such r exists. This is an all-N exclusion, not a
bounded numerical search.

SAVE POINT L2: the exact small-cofactor theorem and elementary effective
finiteness for fixed e have been saved. The earlier v=0 caveat is now
resolved at fixed e by L5; it remains relevant only if L5 is not used.

COMPUTATION BEFORE L2 (PRESERVED WITH ITS CORRECT SCOPE)
The first exact implementation used only L1-L4 plus necessary congruences,
for every 2<=e<=20. It found no v>0 full row systems and left three v=0
modular possibilities: (e,x,r)=(11,7,5),(17,7,5),(17,11,5). These were
only congruence survivors, not solutions. The complete K14 row and L5
now supply a strictly stronger exact decision procedure. Its independent
verification and final results will be recorded below.
```
