---
id: L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01
logical_id: L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01
version_id: L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01@L
kind: canonical-result
run: L
title: "L fixed exponent effective finiteness"
status: PROVED
status_raw: "PROVED, ELEMENTARY"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 168, line_end: 191}
metadata: {"stable_id": "L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01", "version_id": "L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 168, "line_end": 191}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 168, "line_end": 191}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L fixed exponent effective finiteness

*Run L - status `PROVED` (raw: `PROVED, ELEMENTARY`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-FIXED-EXPONENT-EFFECTIVE-FINITENESS-01 -- PROVED, ELEMENTARY
For every fixed e, ALL four-core matching defects L0 form an explicitly
bounded finite arithmetic problem. No external Thue, S-unit or logarithmic-
form theorem is needed for this result.

A complete procedure is:
1. Enumerate odd integers 7<=k<=e.
2. Enumerate odd prime divisors b of k-1 and prime divisors x of k.
3. Enumerate odd primes r distinct from b,x with
     r*(k-1)^e < k^e.
   Retain only k=r^alpha*x^beta with alpha>=0,beta>=1.
4. Set N=b^e+r. The row N-x must be exactly r^u*b^v with u>=2,
   0<=v<=e-3. Remove the factors r,b exactly and reject any residual.
   Require k<=e-v. This determines u,v, rather than scanning them.
5. Set y=(N-b)/k, which must be an integer and exceed r,b,x. The row
   N-y must be exactly r^w*b^z with 1<=w<u and v<z<=e-2.
6. Check primality of y and all remaining domain conditions. Every actual
   solution occurs in this list. Exact integer filters may reject cases
   before any primality decision for a large y is required.

The key distinctions are fixed e versus fixed N and finite support size
versus fixed support labels. This theorem bounds moving prime labels at
fixed e. It does NOT bound e itself or prove the entire family empty.
```
