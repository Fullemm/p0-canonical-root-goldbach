---
id: L-FORBIDDEN-THREE-ROW-BLOCK-01
logical_id: L-FORBIDDEN-THREE-ROW-BLOCK-01
version_id: L-FORBIDDEN-THREE-ROW-BLOCK-01@L
kind: canonical-result
run: L
title: "L forbidden three row block"
status: PROVED
status_raw: "PROVED, ALL N, NOT SIZE-RESTRICTED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 310, line_end: 370}
metadata: {"stable_id": "L-FORBIDDEN-THREE-ROW-BLOCK-01", "version_id": "L-FORBIDDEN-THREE-ROW-BLOCK-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 310, "line_end": 370}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 310, "line_end": 370}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L forbidden three row block

*Run L - status `PROVED` (raw: `PROVED, ALL N, NOT SIZE-RESTRICTED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-FORBIDDEN-THREE-ROW-BLOCK-01 -- PROVED, ALL N, NOT SIZE-RESTRICTED
The new proof actually does not require the whole b row to have support
{r,x,y}. For distinct odd primes r,b,x,y<N, it already excludes
  N-r=b^e, N-x=r^u*b^v, N-y=r^w*b^z, x*y | N-b,
with the same positivity/compositeness conditions e>=2, u,w>=1,
v,z>=0, u+v,w+z>=2, v+z>=1. Arbitrary additional prime factors of N-b
are allowed. The three displayed equalities must still be COMPLETE.

Reason: the specified composite incoming rows already force all four
labels below N/3 and the largest into {x,y}. The proof only uses the
integer k=(N-b)/y, x|k, and the exact three narrow rows. It never needs
k=r^alpha*x^beta in the decisive contradiction. Thus the same argument
excludes this complete-row block inside larger graphs as well. Minimality
is needed to reduce a four-core Hall defect to the block, not to exclude
the block arithmetically. The extension is proved explicitly in the
standalone theorem file, Section 6.

SAVE POINT L6: the stronger local obstruction has been saved. It is not
a ban on merely selecting these edges in a graph with extra factors in
the three restricted rows.

FINAL AUDIT AND RESEARCH FRONTIER
The standard-library proof audit enumerated all loop-free directed graphs
at sizes 2,3,4, retained strong connectivity, unique smaller parents and
distinct pure bases, and reproduced 1,8,266 admissible graphs. The 22
four-vertex matching failures all have K14 with y the largest label.
Two exact sparse-polynomial expansions confirmed that the residual in
each decisive identity is precisely N-k*y-b. Endpoint inequalities and
a positive-coefficient monotonicity certificate were checked with integers.
All audit assertions passed. No second agent was used.

The priority formerly called 'attack K14 for unbounded e' is RESOLVED.
Do not retain e>100 as an open K14 branch. The computer enumeration was
superseded by the all-exponent proof, although its exact certificate
remains valid. The separately archived K checkpoint is historical.

Current sensible next steps:
1. Apply the forbidden complete-row block to Hall defects of size five
   and larger. The extra factors allowed in the parent b row make this
   stronger than just a theorem about four-element cores.
2. Determine which five-vertex abstract Hall defects survive all proved
   arithmetic restrictions, then derive their COMPLETE row systems.
3. Keep the existence of matching four-cores and the three-core systems
   separate. Neither was excluded by the matching theorem.

Relation to roots: these are restrictions on common BAD obstructions,
valid without selecting p_0. They do not show that any rank p_k is always
successful. No estimate for host density or prime mirror escape follows
merely from the existence of a matching.

ARTIFACTS, ALL PLAIN TXT IN nowe
goldbach_checkpoint_2026-09-08L.txt -- research history and current status.
goldbach_four_core_matching_theorem_2026-09-08L.txt -- self-contained proof.
hall_exponent_probe_20260908L_code.txt / _results.txt -- early e<=20 filters.
hall_complete_exponent_20260908L_code.txt / _results.txt -- complete e<=100.
hall_independent_audit_20260908L_code.txt / _results.txt -- second enumeration.
hall_four_core_proof_audit_20260908L_code.txt / _results.txt -- graph/algebra audit.
No source master, historical checkpoint, or user attachment was edited.
No PDF or TeX artifact was generated. No literature-wide novelty claim.
END COMPLETED RESEARCH RUN L -- 2026-09-08
```
