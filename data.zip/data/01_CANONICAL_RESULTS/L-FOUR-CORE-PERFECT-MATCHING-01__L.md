---
id: L-FOUR-CORE-PERFECT-MATCHING-01
logical_id: L-FOUR-CORE-PERFECT-MATCHING-01
version_id: L-FOUR-CORE-PERFECT-MATCHING-01@L
kind: canonical-result
run: L
title: "L four core perfect matching"
status: PROVED
status_raw: "PROVED, ELEMENTARY, ALL N"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 276, line_end: 309}
metadata: {"stable_id": "L-FOUR-CORE-PERFECT-MATCHING-01", "version_id": "L-FOUR-CORE-PERFECT-MATCHING-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 276, "line_end": 309}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 276, "line_end": 309}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L four core perfect matching

*Run L - status `PROVED` (raw: `PROVED, ELEMENTARY, ALL N`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-FOUR-CORE-PERFECT-MATCHING-01 -- PROVED, ELEMENTARY, ALL N
Every nonempty inclusion-minimal active closed BAD set of size at most
four has a perfect matching from its rows q to distinct factors of N-q.
Equivalently its factor graph has a cover by disjoint directed cycles.
Thus a minimal BAD core failing Hall's matching condition must have at
least five labels. A Hamilton cycle is not asserted for every four-core.

Proof status: the L4 identities were rederived directly from
  k*(N-y)=(k-1)*N+b,
first substituting N=r^u*b^v+x and then N=b^e+r. Both signs are positive,
and the first bracket is an integer multiple of b. There is no estimate
of a possibly signed or noninteger remainder. The complete dependency
chain and the reduction of every four-core Hall defect to K14 were
reproved in the separate self-contained proof file named at the top.

The short new argument, after the previously saved L1/L5/L6, is:
  h=(k-1)/b;
  r^w*b^v <= h*x+1 = ((k-1)*x+b)/b < k^2/b;
  b^z <= (k-1)*r+b < (k-1)*k^2/b+b < k^3/b;
  N < (3/2)*(N-y)=(3/2)*r^w*b^z < k^5/6;
  6*3^e < e^5.
The last inequality fails for every integer e>=8, since it fails at 8
and (6*3^e)/e^5 increases thereafter. But L6 already forces e>=8:
for e<=7 it gives 3<=r^D<(7/6)^7<3. This is the contradiction.

No computation, floating-point estimate, conjecture about prime gaps,
fixed-support assumption, or external effective Diophantine theorem
is needed. The separate exact e<=100 computation and its independent
48-case audit are retained as reproducible supporting checks, not as
premises of the proof.

SAVE POINT L5: the unbounded K14 exclusion and universal matching theorem
for core size <=4 are saved with a complete standalone elementary proof.
```
