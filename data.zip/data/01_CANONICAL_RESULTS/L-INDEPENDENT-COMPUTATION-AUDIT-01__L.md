---
id: L-INDEPENDENT-COMPUTATION-AUDIT-01
logical_id: L-INDEPENDENT-COMPUTATION-AUDIT-01
version_id: L-INDEPENDENT-COMPUTATION-AUDIT-01@L
kind: canonical-result
run: L
title: "L independent computation audit"
status: VERIFIED COMPUTATION
status_raw: "PASSED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-AUDIT-PASSED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 243, line_end: 275}
metadata: {"stable_id": "L-INDEPENDENT-COMPUTATION-AUDIT-01", "version_id": "L-INDEPENDENT-COMPUTATION-AUDIT-01@L", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 243, "line_end": 275}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 243, "line_end": 275}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L independent computation audit

*Run L - status `VERIFIED COMPUTATION` (raw: `PASSED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-INDEPENDENT-COMPUTATION-AUDIT-01 -- PASSED
A second implementation used a bytearray Eratosthenes sieve, trial
division of small k,k-1, and direct residue-class enumeration
  r=b-b^e modulo k.
It reproduced exactly 370300 candidates with k|(N-b) and the same total
of 48 with r|(N-x). All 48 had a residual factor after exact extraction
of r and b from N-x; 36 also failed u>=2. The complete 48-case certificate
is saved in hall_independent_audit_20260908L_results.txt. No y primality
test was required. This independently confirms the e<=100 computation.

SAVE POINT L4 -- NEW ALGEBRAIC ROUTE, UNDER FINAL PROOF AUDIT
Set h=(k-1)/b, a positive even integer. Exact substitution of the full
rows into N-b=k*y gives two positive integer identities:

  r^w*b^v * [k*b^(z-v)-(k-1)*r^(u-w)] = b*(h*x+1),
  b^z * [k*r^w-(k-1)*b^(e-z)] = b*(h*r+1).

In the first, the bracket is positive and divisible by b (z>v and
b|(k-1)). Hence r^w*b^v <= h*x+1. In the second, the bracket is positive
and nonzero modulo b (k=1 modulo b and r!=b). Hence
  z=1+v_b(h*r+1),  b^z<=b*(h*r+1).
These yield r^w<k^2/b and b^z<k^3/b, because x<=k and b<k.
Thus N<(3/2)*r^w*b^z<k^5/6, using y<N/3 and b>=3.
Since N>b^e>=3^e and k<=e, necessarily 6*3^e<e^5.
For e>=8 the reverse inequality holds, starting with
  6*3^8=39366 > 8^5=32768
and increasing the ratio at each step. Therefore e<=7.
But k>=7 and r>=3 in L6 imply
  3<=(r^D)<(7/6)^e<=(7/6)^7<3,
a contradiction. This would exclude K14 for every N, with no computed
cutoff. The proof and the underlying Hall normal form are being audited
before promoting this implication to the final theorem below.
```
