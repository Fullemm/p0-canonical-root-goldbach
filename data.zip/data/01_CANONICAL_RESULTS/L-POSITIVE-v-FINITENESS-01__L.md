---
id: L-POSITIVE-v-FINITENESS-01
logical_id: L-POSITIVE-v-FINITENESS-01
version_id: L-POSITIVE-v-FINITENESS-01@L
kind: canonical-result
run: L
title: "L POSITIVE v FINITENESS"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 112, line_end: 133}
metadata: {"stable_id": "L-POSITIVE-v-FINITENESS-01", "version_id": "L-POSITIVE-v-FINITENESS-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 112, "line_end": 133}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 112, "line_end": 133}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L POSITIVE v FINITENESS

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-POSITIVE-v-FINITENESS-01 -- PROVED
For fixed e the whole v>0 branch is a finite exact arithmetic problem,
without any prior N cutoff. In that branch
  v_b(r-x)=v,
so b must be an odd prime divisor of the nonzero fixed integer |r-x|.
After L4 there are only finitely many x,r,v and thus finitely many b,N.
For each such candidate N=b^e+r, one can check the COMPLETE row N-x,
then enumerate w<u and v<z<=e-2 to obtain y=N-r^w*b^z. All remaining
row and primality conditions are then finite exact decisions.

Proof of the valuation identity: N-x=b^e+r-x has b-valuation v<e;
subtracting b^e leaves r-x with exactly that valuation. This proof does
not treat a moving B_N as one fixed finite alphabet.

SAVE POINT L1: orientation, removal of z=0, valuation cap and finite
label box have been saved before using them in computations.

OPEN AT THIS SAVE POINT
The v=0 branch has N-x=r^u, so b^e=r^u-r+x with u>=2. Its prime b is
not bounded merely by divisibility of r-x. No complete arithmetic
classification of L0 or Goldbach proof is claimed at this stage.
```
