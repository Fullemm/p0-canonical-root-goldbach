---
id: L-ROW-INTERVAL-01
logical_id: L-ROW-INTERVAL-01
version_id: L-ROW-INTERVAL-01@L
kind: canonical-result
run: L
title: "L row interval"
status: PROVED
status_raw: "PROVED / REUSED ELEMENTARY INPUT"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 32, line_end: 43}
metadata: {"stable_id": "L-ROW-INTERVAL-01", "version_id": "L-ROW-INTERVAL-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 32, "line_end": 43}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 32, "line_end": 43}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L row interval

*Run L - status `PROVED` (raw: `PROVED / REUSED ELEMENTARY INPUT`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-ROW-INTERVAL-01 -- PROVED / REUSED ELEMENTARY INPUT
All four row integers are in (2N/3,N), so their pairwise ratios are <3/2.
No row properly divides another. In particular u!=w, v!=z and
  (u-w)*(v-z)<0.
Also v,z<e: an exponent at least e would make that row >=3*b^e>N.
For reciprocal active labels p,q, the familiar product bound improves by
parity to
  2pq divides N-p-q,
and therefore N>=2pq+p+q when p,q<N/3. Indeed pq divides the positive
even integer N-p-q, and pq is odd. This parity refinement is elementary;
no claim of historical novelty is made.
```
