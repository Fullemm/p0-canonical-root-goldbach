---
id: L-SMALL-INTEGER-COFACTOR-01
logical_id: L-SMALL-INTEGER-COFACTOR-01
version_id: L-SMALL-INTEGER-COFACTOR-01@L
kind: canonical-result
run: L
title: "L small integer cofactor"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 134, line_end: 167}
metadata: {"stable_id": "L-SMALL-INTEGER-COFACTOR-01", "version_id": "L-SMALL-INTEGER-COFACTOR-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 134, "line_end": 167}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 134, "line_end": 167}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L small integer cofactor

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-SMALL-INTEGER-COFACTOR-01 -- PROVED
The remaining COMPLETE row N-b makes the preceding finite-label result
substantially stronger. Define the positive integer k=(N-b)/y. Then
  x<=k<=t=e-v,
  gamma=1,
  k=r^alpha*x^beta, beta>=1,
  2b divides k-1,
  b<=(k-1)/2<=(e-v-1)/2.                        (L5)
Moreover
  1<=D,  r^D < (k/(k-1))^t.                     (L6)
In particular k>=7 and r<(7/6)^e. All of b,x,r are now explicitly bounded
by e alone, including the previously unresolved v=0 branch.

Proof. The determinant identity L3 gives
  3<=r^D<(N/(N-y))^t.
Since (1+1/t)^t<exp(1)<3, it follows that N/(N-y)>1+1/t and hence
  y>N/(t+1).
Therefore k=(N-b)/y<N/y<t+1. As k is an integer, k<=t. The full row N-b
contains x and y, so x divides k and k>=x.

Also y>N/(t+1)>=N/(e+1)>3^e/(e+1)>e>=k for e>=2; the elementary
inequality 3^e>e(e+1) follows by induction starting at e=2. Thus y cannot
divide k, and the exponent gamma in N-b=r^alpha*x^beta*y^gamma is exactly
one. Consequently k=r^alpha*x^beta.

By z>=1 the row N-y is divisible by b, so N=y modulo b. Reducing the
equality N-b=k*y modulo b yields (k-1)*y=0 modulo b. Since y and b are
distinct primes, b divides k-1. The quotient k is odd (both N-b and y
are odd), so 2b divides k-1. Hence k>=2b+1>=7 and the stated b bound.

Finally N-y=((k-1)*N+b)/k, and each of (N-x)/(N-y),(N-r)/(N-y) is
strictly less than k/(k-1). Insert these two bounds in the determinant
identity to obtain L6. Since t<=e and k>=7, it gives r<(7/6)^e. QED.
```
