---
id: L-VALUATION-CAP-01
logical_id: L-VALUATION-CAP-01
version_id: L-VALUATION-CAP-01@L
kind: canonical-result
run: L
title: "L valuation cap"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08L.txt", line: 72, line_end: 80}
metadata: {"stable_id": "L-VALUATION-CAP-01", "version_id": "L-VALUATION-CAP-01@L", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 72, "line_end": 80}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08L.txt", "line": 72, "line_end": 80}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# L valuation cap

*Run L - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
L-VALUATION-CAP-01 -- PROVED
In the same domain,
  y<(b^(e-1)-1)/2,
  1<=z<=e-2,  0<=v<=e-3.                        (L2)
Indeed b and y are reciprocal by z>=1 and gamma>=1. Thus
N>=2by+b+y. Since N=b^e+r and r<y, this yields b^e>2by+b and the
displayed y bound. Now b^z divides y-r and 0<y-r<y<b^(e-1), so
z<=e-2; L1 then bounds v. This is stronger than just z<e.
```
