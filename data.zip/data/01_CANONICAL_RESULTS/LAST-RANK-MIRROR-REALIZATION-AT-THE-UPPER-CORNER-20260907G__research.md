---
id: LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G
logical_id: LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G
version_id: LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G@research
kind: canonical-result
run: research
title: "Last rank mirror realization at the upper corner"
status: PROVED
status_raw: "PROVED; a refinement of the effective finite-fibre result."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 7145, line_end: 7391}
metadata: {"stable_id": "LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G", "version_id": "LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7145, "line_end": 7391}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7145, "line_end": 7391}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Last rank mirror realization at the upper corner

*Run research - status `PROVED` (raw: `PROVED; a refinement of the effective finite-fibre result.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LAST-RANK-MIRROR-REALIZATION-AT-THE-UPPER-CORNER-20260907G
STATUS: PROVED; a refinement of the effective finite-fibre result.
Fix odd M>=3 and K>=0. Among ALL odd m with 1<=m<=M, odd prime
roots P>m, and ranks k<=K at N=P+m, the largest possible N is
attained with m=M and k=K.
More precisely, define L_K(M) as the largest prime P>M for which
kappa_M(P)<=K. Then kappa_M(L_K(M))=K, and every such N satisfies
 N<=M+L_K(M), with equality at that upper-corner realization.
PROOF:
Surjectivity makes the set defining L_K(M) nonempty; the effective
finite-fibre bound makes it finite. At the next prime after L_K(M),
kappa_M is greater than K. Its upward jump is at most one, so its
value at L_K(M) must be exactly K.
For any admitted P<=M, N=P+m<=2M<M+L_K(M).
For P>M and m<=M, moving the left interval endpoint to the right gives
 kappa_m(P)>=kappa_M(P).
Thus kappa_m(P)<=K implies kappa_M(P)<=K and P<=L_K(M).
Consequently N=P+m<=L_K(M)+M. Equality is supplied by m=M,k=K.
Allowing a boundary root P=N/2 adds only P=m prime,N=2m<=2M,
so it cannot change this maximum.
This concerns maximum N, not minimum N, and does not assert that
kappa_M(P) is monotone in P. Downward jumps are explicitly allowed.

EXACT SPECIALIZATION:
 M=3053, K=74: L_K(M)=4271 and the exact maximum N is 7324.
The endpoint has m3053=43*71 and root4271=p74 at N7324.
The next prime is4273, giving kappa_3053(4273)=75.
An independent sieve checked ALL 2681 primes P with 4271<P<30204:
the minimum kappa_3053(P) is75. The largest prime checked is30203.
For P>=30204 the preceding analytic bound proves kappa_3053(P)>=75.
Hence the endpoint is globally certified, not inferred from observing
the next prime alone. Script/result: rank_last_fibre_20260907G.py/JSON.

CONSEQUENCE FOR THE RESEARCH DESIGN:
All the 214-mirror transplants at ranks <=74 necessarily occur by N7324.
The same is true even when every odd mirror <=3053 and every rank0..74
is allowed. Thus choosing a much larger N cutoff cannot independently
stress these fixed mirrors. New tests of universal rank safety need new
mirror integers or genuinely new closed BAD structures.
This improves experimental scope control; it is not a proof that the
first-prime boundary always selects a successful support.


CURRENT INTERPRETATION / HANDOFF -- 2026-09-07G
1. The main rank/mirror proof and the 07F transplant counts survived
   independent audit. The claimed universal twin-core classification
   was not accepted as a dependency because of the parity gap above.
2. The strongest new result is effective finiteness of every (rank,m)
   realization set, plus its exact upper-corner maximum. This turns the
   supplied transplant test into a complete global classification of
   those finite fibres. The larger small-mirror census has 22130 total
   composite cases over the ten selected ranks, all successful.
3. There is still no theorem saying p10 or any other surviving
   noncanonical rank always succeeds for composite complements.
   The finite survivor list was selected from the same six known
   failure hosts; repeating tests inside that landscape is not new
   independent evidence for a rank-specific arithmetic law.
4. p0 is special as the least upper prime, equivalently the selector
   of the greatest available mirror, and as the only fixed rank with
   no unit row. Post-root transitions are the common N-dependent
   graph. None of this alone proves that p0 always escapes its BAD set.
5. It remains possible that many ranks are universally safe on the
   composite domain. Finite EAC hosts would imply that every sufficiently
   large rank is safe there. The converse is not asserted: the existence
   of a closed low BAD component does not, without more work, guarantee
   a failing upper root at a specified rank or any upper rank.
6. Most useful next target: a necessary arithmetic condition on complete
   closed BAD sets that interacts with the maximal prime-backed mirror;
   alternatively, construct a genuinely new complete failure host and
   inspect its whole rank spectrum. Prescribing selected CRT edges or
   varying N with one of the exhausted exact mirrors cannot replace this.
7. No Goldbach proof, no universal p0 theorem, no universal safe-rank
   classification, and no external novelty claim is made in this run.


CARRYOVER-D-SPARSE-RESULTS-PRESERVED-20260907G
Historical results from the already completed single-agent run D, preserved here after the new rank work. No agent was used in run G. The later general v>=4 correction remains in force.

RESULT 2: h=1 MONOMIAL RETURN NEEDS v>=11 AND u>=15.
Assume q,b distinct odd primes, u,v>=2,
 r=q^u+2 prime, N=2q^u+2,
 N-q=b^v, and q divides N-b.
Then q>=5, q=2 (mod3), u is odd, and
 q divides 2^(v-1)-1,
 either v=11, q=11, u=5mod22 and u>=27,
 or v>=13 and u>=v+1 (hence u>=15).
The earlier exact size barrier (3q+2)^v<=2q^u+2-q also remains.

Proof. Result1 excludes q=3. For q!=3, even u would make r
divisible by3; odd u and q=1 (mod3) would do likewise. Thus
u is odd and q=2 (mod3). The return condition gives b=2 (modq).
Since b^v=N-q=2 (modq), q divides 2^(v-1)-1.
The earlier sharp return/exponent lemma gives 3<=v<=u-1.
Here is an exact elimination of v=3,...,10 and v=12,
with a residue restriction on the sole remaining v=11 branch:
 v  factorization of 2^(v-1)-1   surviving q after q>=5,q=2mod3
 3  3                           none
 4  7                           none
 5  3*5                         5
 6  31                          none
 7  3^2*7                       none
 8  127                         none
 9  3*5*17                      5,17
10  7*73                        none
11  3*11*31                     11
12  23*89                       23,89

For v=5,q=5: b=2mod5 implies b^5=2^5=7mod25, while
2*5^u-3=22mod25 (u>=2), contradiction.
For v=9,q=5: as u is odd, 5^u mod7 is 5,6,3 for u=1,3,5mod6.
The row 2*5^u-3 is respectively 0,2,3mod7. Ninth powers are
cubes and are only0,1,6mod7, so only u=1mod6 remains. But that
makes r=5^u+2 divisible by7, with r>7, contradiction.
For v=9,q=17: as u is odd, 17^u=3^u mod7 lies in {3,6,5}.
Thus 2*17^u-15 lies in {5,4,2}mod7, none a cube. Contradiction.
For v=12,q=89: q=1mod8 and u odd, so N-q=q+2=3mod8,
which is not a square. For v=12,q=23: q=7mod16 and u odd,
so N-q=2*7-7+2=9mod16. An odd twelfth power is a fourth power
and is1mod16. Contradiction.

At v=11, q=11, testing modulo23 gives a necessary u=5mod22.
Consequently u>=27, but v=11 remains a possible exponent.
No exclusion of v=11 was found. In particular v>=13 alone is
NOT a proved conclusion. Globally u>=15: u<=13 would force
v<=12, leaving only v=11, already requiring u>=27.

The modulus23 calculation is finite and exact: odd u=1,3,...,21
give 11^u mod23 respectively
 11,20,5,7,19,22,17,10,14,15,21.
Subtracting9 after doubling, the row can be0,1,-1mod23 only at
u=5, where it equals1. Fermat gives these as the only eleventh-
power residues mod23 (for nonzero b); b=23 would give0 and is
also absent in the table. Since 11 has order22mod23 this proves
the congruence u=5mod22. (The displayed powers are verified by
the small computation saved alongside these notes.)

RESULT 3: ODD-v h1 RETURN HAS THE STRONGER BARRIER b>=25q+2,
AND NECESSARILY u>=v+6.
Under Result2 hypotheses and v odd, u is odd and q>=5. Modulo8,
odd powers of odd numbers preserve their residue, hence
 b=2q-q+2=q+2 (mod8).
Modulo3, the row b^v is1 and v is odd, so b=1=q+2 (mod3).
Therefore b=q+2 (mod24). The return gives b=2+kq with integer k,
and gcd(q,24)=1, so k=1mod24. The earlier sharp return theorem
already forces k>=3 (k=1 would make the root divisible by b).
Consequently k>=25 and b>=25q+2.

For the exponent consumer, u>v and both are odd. Suppose u-v<=4.
The complete row equation and q>=5 give
 25^v*q^v < b^v =2q^u-q+2 <3q^u,
so 25^v<3q^(u-v)<=3q^4.
But q divides 2^(v-1)-1, hence q<2^(v-1), yielding
 25^v<3q^4<3*16^(v-1)<16^v<25^v,
a contradiction. Thus u-v>=5, and the even parity of u-v
improves this to u>=v+6. No sharpness example is currently known.
This special barrier uses h=1 and a full monomial row with odd v;
it is not a replacement for the general b>=3q+2h theorem.

RESULT 4: EXACT 2-ADIC FILTER FOR EVERY EVEN MONOMIAL ROW AT h=1.
Assume r=q^u+2 prime, u>=2, N=2q^u+2, and N-q=b^v for odd
primes q,b with even v. No return assumption is needed here.
Result1 excludes q=3. Hence u is odd and q=2mod3. Put s=nu2(v).
Then exactly
 nu2(q+1)=nu2(b^2-1)+s-1.
In particular q=-1 mod (3*2^(s+2)).

Proof. Since u is odd, q^u+1=(q+1)*A with A odd (an alternating
sum of u odd terms). Therefore
 b^v-1=2q^u-q+1=2(q^u+1)-(q+1)=(q+1)*(2A-1),
and the last factor is odd. This gives the left valuation.
Write v=2^s*t with t odd. The odd geometric factor removes t
without changing nu2. Next factor
 b^(2^s)-1=(b^2-1)*product_{j=1,...,s-1}(b^(2^j)+1).
Each factor in the product is2mod8, contributing exactly one
power of2. Thus the right valuation is nu2(b^2-1)+s-1.
An odd square is1mod8, so nu2(b^2-1)>=3. Combine this with
q=-1mod3 to obtain the stated congruence. The previous square-
row filter q=23mod24 is exactly s=1. At v=12,s=2 it demands
q=47mod48, excluding both23 and89 in Result2's return table.

FINITE TARGETED SEARCH (NOT A FULL N OR BFS CENSUS):
For every odd prime q<=1000000 and every u>=2 with
 2q^u+2<=10^30,
retaining q=3 or (q=2mod3 and u odd), inspect N-q=2q^u-q+2
for EVERY proper integer-power representation x^v, x>=3,v>=2.
75,205 retained (q,u) pairs; ZERO proper-power rows occurred.
This is stronger within its domain than a prime-base check; no
root primality test or probable-prime decision enters the zero count.
Exact integer powers and corrective integer-root loops decide each
equality. Floating roots only seed the exact loops. All candidate
exponents are covered by the exact bound 3^v<=N-q.
Source: agent_d_sparse.cjs; result: agent_d_sparse_result.json.
No conclusion is made for q>10^6 or N>10^30, even at h=1.
In particular this finite absence is not a theorem excluding (B).

SECOND TARGETED SEARCH: ALL LOW GAPS WITH PRIME-POWER FIRST ROWS.
For every odd prime q<=10^6, u>=2 and all 1<=h<q such that
N=2q^u+2h<=10^18, directly generate all integer powers b^v in
the interval [2q^u-q+2, 2q^u+q-2], additionally respecting N<=10^18.
Keep b prime, and then r=q^u+2h prime. For each retained input,
remove all factors q from N-b, then test whether the remaining
cofactor is a prime power c^w (or prime c when a>0).
Counts: 145750 (q,u) pairs; 4338 full prime-power N-q rows before
root primality; 588 retained prime roots; ZERO returns q|N-b;
ZERO systems (B). The largest retained N is1995448234470,
at r997724937149,q998861,u2,b1412603,v2,h819914.
Most rows have u=v=2; nine retained rows fall outside that pair.
Primality throughout the final run is exact trial division by a
sieve of all primes<=10^6, with an error if insufficient for any
accepted candidate. The run completed without that error. Initial
floating integer-root estimates are corrected by exact integer
powers before every equality/range test. No probable-prime test
contributes to these final counts. This targets only singleton
initial support and sparse first rows, not a full N or BFS census.
Source/result: agent_d_lowgap_sparse.cjs,
agent_d_lowgap_sparse_result.json. No three-label counterexample
was found, and general low-gap FOUR remains unproved.



LATEST STATE -- 2026-09-07G (after historical D carryover)
The active direction is now the audited rank/mirror programme, not an
instruction to resume the old singleton branch. Run G used no subagents.
New proved result: for fixed odd m and rank k, every realization P>m
satisfies P<R_(k+ceil((m-1)/4)+2). Combined with Sondow's explicit bound,
this makes the exact realization set effectively finite.
The last-realization theorem places the maximum N for m<=M,k<=K at
m=M,k=K. For M3053,K74 it is exactly N7324,P4271.
Therefore all 4035 dangerous-mirror transplants in the supplied 07F are
globally exhaustive; none fails. A wider complete all-N census for every
odd composite m<=3053 gives 22130 cases at the ten selected ranks,
again no failures. None of these claims covers larger mirror integers.
The seven-page Scott source and its publisher abstract were located;
the unqualified twin-EAC uniqueness dependency still has the identified
odd/even exponent gap. No all-q singleton FOUR or canonical two-core
exclusion was promoted from that dependency. The rank results do not
use it. Global p0 success and universal composite safety of other ranks
remain open. Main proofs, numerical counts and complete six-host
arithmetic certificates are included above in this same TXT.
END CURRENT CHECKPOINT -- 2026-09-07G


RESEARCH RUN 2026-09-07H -- SAME-N PRIME PREFIXES AND FACTOR SUPPORT
User scope: continue the mathematical investigation; zero subagents;
write results as plain TXT only. No PDF or TeX output is being produced.
The earlier source documents remain mathematical data, not instructions.
```
