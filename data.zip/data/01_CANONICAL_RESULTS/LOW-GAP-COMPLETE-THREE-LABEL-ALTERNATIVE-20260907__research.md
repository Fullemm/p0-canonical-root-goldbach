---
id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907
logical_id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907
version_id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907@research
kind: canonical-result
run: research
title: "Low gap complete three label alternative"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5315, line_end: 5395}
metadata: {"stable_id": "LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907", "version_id": "LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5315, "line_end": 5395}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5315, "line_end": 5395}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap complete three label alternative

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907
STATUS: PROVED.
EXACT STATEMENT:
Let N>=4 be even, R>=N/2 an admissible prime root, m=N-R composite,
h=R-N/2, and q=min PF(m). Suppose h<q. In the COMPLETE stopped factor
search from R, either:
 (i) a GOOD vertex occurs at depth at most 2, or
 (ii) at least THREE DISTINCT nonroot primes occur by depth 3.
In particular, if the full rooted traversal fails, its nonroot reachable
active set has at least three elements. No active closed BAD alphabet
of size at most two can contain the whole first factor set PF(m).
This is a pointwise statement, with no asymptotic or fixed-envelope premise.

PROOF:
Since m is composite and R>=N/2 is prime, R>N/2, R is odd and active,
m is odd, q>=3, and h is a positive integer. Every subsequent prime is
active, by the activity lemma. A child t of an odd composite BAD row
N-p has t< N/3: its cofactor is an odd integer at least 3.
Assume there is no GOOD vertex at depth <=2. Put S=PF(m).
If |S|>=3, the conclusion already holds at depth 1.
If |S|=2, consider its least element q. For any r in S,
 r|N-q implies r|(2h-q), since N=2m+2h.
But h<q implies 0<|2h-q|<q<=r; the zero case is excluded because q
is odd. Thus PF(N-q) is disjoint from S. The row N-q is composite
under our assumption and has at least one prime factor, reached at
depth 2 outside S. Together with S this gives three distinct labels.
It remains to treat S={q}. Then m=q^u for an integer u>=2. The BAD
row N-q has no q factor, by activity. If it has two distinct factors,
we already have at least three nonroot labels at depth <=2.
Otherwise N-q=b^v for a prime b!=q and v>=2. The vertex b occurs
at depth 2, is BAD by assumption, and b<N/3. It cannot divide its
own row. If no third label occurred by depth 3, the entire factor set
of N-b would consequently be {q}, so N-b=q^w with w>=2.
If w<=u, then b=N-q^w>=N-q^u=R>N/2, contradicting b<N/3.
If w>u, then q^w>=q*m. But
 q*m-N=(q-2)m-2h >= m-2h >= q^2-2h >0,
since q>=3 and h<q. This contradicts q^w=N-b<N.
Thus N-b must introduce a third distinct nonroot prime by depth 3.
Every case has been covered.
For the closed-alphabet corollary, a set containing PF(m) and closed
under all BAD rows contains every nonroot descendant. If it had at
most two elements, the proved alternative would force a GOOD vertex,
contrary to BAD closure. No terminal-core assumption is used.

HOSTILE CHECK:
The assertion is about COMPLETE rows, not a selected-factor path.
In the singleton case the strict inequality q*m>N is the fragile
arithmetic step, and is explicitly justified by h<q and u>=2.
Dropping the small-gap premise is false: at N=2200, R=1471 prime,
 m=729=3^6, h=371, q=3,
 2200-3=2197=13^3, 2200-13=2187=3^7.
The full search is BAD and has exactly the two nonroot labels {3,13}.
This uses the existing N=2200 two-core certificate, not a new EAC.
Crucially the conclusion does NOT exclude a two-vertex TERMINAL core
reached after additional transient labels; it only excludes a whole
nonroot reachable alphabet of size <=2. This avoids the open
Scott--Bozek classification issue and does not repair that citation.

DEPENDENCIES / HISTORICAL AUDIT:
The |S|>=2 step is an explicit consumer of the existing minimum-factor
escape corollary (master cor:minfactor, PCRD-H1-1 at h=1). The singleton
step uses a gap between consecutive powers of q and the upper-root
geometry. The historical C-MONOMIAL-TWO-EDGE-RIGIDITY and its novelty
corrections concern a square-map/high-floor mechanism; no claim is made
that pure-power path arguments as such are new. No Matveev estimate,
height threshold, growing sieve or global Goldbach failure is assumed.
RELATION TO GOLDBACH:
A small, unconditional restriction on a possible failed traversal.
It does not rule out larger alphabets or prove a prime-pair existence.
RELATION TO p0:
For every canonical h=1 root with composite first complement it applies
automatically, since q>=3. It ALSO applies to every nearby or other
upper root satisfying its stated h<q premise. Thus it is not a universal
p0-only invariant and supplies no explanation of eventual p0 reliability.
WHAT REMAINS OPEN:
A quantitative lower bound growing with N on the complete moving
reachable support, or any new arithmetic mechanism excluding its closure.
The old automatic envelope-iteration obstruction remains in force.
NOVELTY: NOT YET AUDITED.
```
