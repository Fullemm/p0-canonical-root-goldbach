---
id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE@research
logical_id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE
version_id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE@research
kind: historical-version
run: research
title: "Low gap complete three label alternative"
status: SUPERSEDED
status_raw: "if h<min PF(N-R), either"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5885, line_end: 5952}
metadata: {"stable_id": "LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE", "version_id": "LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5885, "line_end": 5952}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5885, "line_end": 5952}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Low gap complete three label alternative

*Run research - status `SUPERSEDED` (raw: `if h<min PF(N-R), either`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE-20260907` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
3. LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE: if h<min PF(N-R), either
   GOOD occurs by depth 2 or at least three distinct nonroot labels
   occur by depth 3. A whole closed BAD nonroot alphabet of size <=2
   is excluded in that domain. This also applies to nearby roots.
4. Canonical first-support BAD cycles can have arbitrary prescribed
   length. Same-N acyclicity reverses between p0 and p1 at N=344 and
   N=1268. Exact root-rank corrections, million-input lift checks and
   the explicit canonical valuation-embedding example are recorded above.

=========================
CURRENT FRONTIER
=========================
Binary Goldbach is not proved, and no universal p0 success theorem was
obtained. The new embedding result explains why inherited finite graph
patterns and their internal valuations cannot provide certain universal
p0 distinctions; it does NOT control the extra factors whose presence
prevents the transplant from remaining closed. The exact conjugacy makes
root 2 an equivalent starting point in the h=1 subfamily, but gives no
mechanism forcing that root to succeed when P=N/2+1 is prime.
A possible large, moving, completely closed active BAD reachable set is
still unexcluded. Earlier support-height bounds remain lower constraints,
not contradictory upper bounds. The earlier asymptotic frontier is also
unchanged: the large-label-product AND large-cofactor-product region at
radius three is not controlled here. Shallow BADness is compatible with
later success, and none of it is a global Goldbach counterexample.

=========================
p0 STATUS
=========================
Found a nontrivial all-generation equivalence for canonical h=1, but its
partner is root 2, not a nearby upper root, and it does not cover all p0.
Found a precise hereditary graph/valuation no-go and additional same-N
structural non-dominance witnesses. The small-gap support restriction is
shared by nearby roots satisfying the same premise. Canonical first-
support acyclicity holds at h=1 but fails for other h, even infinitely
often with arbitrarily long cycles. No convincing explanation of the
empirical eventual reliability of p0 has been established.

=========================
EXACT NEXT QUESTION
=========================
Can complete factor search from 2 fail at N=2(P-1) with P>=5 prime
and P-2 composite? Equivalently, can there exist such a P and a finite
set C of odd primes below 2(P-1)/3 such that
 PF(P-2) is contained in C,
 and for EVERY q in C the integer 2(P-1)-q is composite with its ENTIRE
 prime support contained in C?
This is the exact d=2 obstruction left by the proved conjugacy. A
solution must use complete support or another feature not preserved
by the canonical valuation embedding. Showing selected BAD cycles,
reproducing finite internal valuations, or merely increasing a support-
height lower bound does not answer it. A counterexample would refute
canonical h=1 traversal success, not by itself binary Goldbach.


======================================================================
CONTINUATION IN LOCAL WORKSPACE -- 2026-09-07
======================================================================
SOURCE AND SCOPE:
The preceding checkpoint was copied intact from the supplied Downloads
file goldbach_research_checkpoint_2026-09-05 (3).txt. Its latest entries
already extend through 2026-09-07 and supersede the earlier master where
they explicitly correct it. This continuation uses the documents as
research data, not as instructions. All new research files are in nowe.
Only one independent subagent was used. No PDF or TeX output is produced.
The immediate focus is complete-support restrictions, rather than another
transplant of selected edges or an unsupported all-N conclusion.
```
