---
id: LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C
logical_id: LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C
version_id: LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C@research
kind: canonical-result
run: research
title: "FAIL-"
status: KILLED
status_raw: "REFUTED by an exact counterexample; the earlier three-label"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5953, line_end: 5995}
metadata: {"stable_id": "LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C", "version_id": "LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C@research", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5953, "line_end": 5995}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5953, "line_end": 5995}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `KILLED` (raw: `REFUTED by an exact counterexample; the earlier three-label`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: LOW-GAP-FIVE-LABEL-OVERGENERALIZATION-20260907C
STATUS: REFUTED by an exact counterexample; the earlier three-label
theorem and the stated rank-0-through-6 finite experiment are unaffected.
CLAIM / ROUTE:
Strengthen LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE by replacing THREE
with FIVE for every upper prime root with h<min PF(N-r).
WHY IT LOOKED PROMISING:
The old experiment found no fewer than five nonroot labels by depth 3
under complete BADness through depth 2, at ranks 0,...,6 and N<=200000.
EXACT COUNTEREXAMPLE:
 N=44670, r=22469, m=N-r=22201=149^2, h=134<149.
 N-149=44521=211^2.
 N-211=44459=23*1933.
 N-23=44647 prime; N-1933=42737 prime.
All displayed prime labels, the root and the two prime complements are
prime by independent trial division through the integer square root.
Thus complete BADness holds at depths 0,1,2. The distinct nonroot
labels discovered through depth 3 are exactly {149,211,23,1933}:
depth 1 is {149}, depth 2 is {211}, depth 3 is {23,1933}.
The complete FIFO search, ascending factors and testing on dequeue,
succeeds at depth 3 after four tests r,149,211,23. No branch is omitted.
The exact upper rank is 12, since the primes at or above N/2=22335
through r are
 22343,22349,22367,22369,22381,22391,22397,
 22409,22433,22441,22447,22453,22469.
This explains why the earlier rank-restricted experiment missed it.
WHAT SURVIVES:
The proved bound THREE. The possibility of a universal FOUR under the
same low-gap hypotheses remains under investigation. FIVE for p0 itself,
or for ranks at most six outside the tested range, is not decided by
this noncanonical example. No five-label theorem for those roots is
claimed. The observed five-label minimum was already explicitly empirical.
RELATION TO p0 / GOLDBACH:
An exact boundary of a candidate strengthening, not a failed canonical
traversal. This N has many Goldbach representations, including those above.
REPRODUCTION:
Discovered by the single independent agent in a targeted singleton-
first-support scan, with scratch source agent_scan_singles.cjs. The
displayed arithmetic is a self-contained certificate; the domain and
results of any larger scan are recorded separately after verification.
NOVELTY: no literature-priority claim.
```
