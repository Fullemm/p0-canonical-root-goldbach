---
id: LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C
logical_id: LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C
version_id: LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C@research
kind: canonical-result
run: research
title: "Low gap monomial return exponent drop"
status: PROVED
status_raw: "PROVED, as a consumer of the preceding two elementary lemmas."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6098, line_end: 6136}
metadata: {"stable_id": "LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C", "version_id": "LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6098, "line_end": 6136}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6098, "line_end": 6136}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap monomial return exponent drop

*Run research - status `PROVED` (raw: `PROVED, as a consumer of the preceding two elementary lemmas.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-MONOMIAL-RETURN-EXPONENT-DROP-20260907C
STATUS: PROVED, as a consumer of the preceding two elementary lemmas.
EXACT STATEMENT:
Assume m=q^u, u>=2, 0<h<q, r=q^u+2h prime, N=2q^u+2h,
and N-q=b^v for a prime b and integer v>=2.
If q divides N-b (a BAD return q->b->q), necessarily
 3<=v<=u-1, hence u>=4.
More precisely (3q+2h)^v <= 2q^u+2h-q.
In particular neither m=q^2 nor m=q^3 can have such a return when
the complete row N-q has only one distinct prime factor.
PROOF:
q is the minimum first factor automatically. Since N-q is composite,
q is BAD. The condition q|N-b also makes b BAD: b<N/3 and N-b>q,
so q is a proper factor. Apply the sharp return bound b>=3q+2h.
If v>=u, then
 b^v >= (3q+2h)^u > (3q)^u >= 9q^u
 > 2q^u+2h-q=N-q,
where 2h-q<q<=q^u. This is impossible. Thus v<=u-1.
The square-row lemma excludes v=2. The remaining inequalities follow.
HOSTILE CHECK:
The conclusion concerns a direct return to q, not absence of all
later returns or full BAD closure. The assumption that N-q is a
COMPLETE prime power is essential; choosing one divisor of a
multifactor row does not satisfy it. At N=80 a squarefree multifactor
row has a return at the sharp size threshold, as recorded above.
No root minimality within the upper primes was used.
WHAT REMAINS OPEN:
Longer return paths, branching rows, and singleton-support roots with
u>=4 remain possible. Even an acyclic initial segment need not succeed.
NOVELTY: no literature-priority claim.

ADDITIONAL HOSTILE BOUNDARY OF THE RETURN LEMMA:
The sharpened lattice applies to RECIPROCAL edges. It is not a correction
asserting that all parents of q exceed 3q+2h. At N=344, r=173, h=1,
m=171=3^2*19, q=3, the label b=5=q+2h is a genuine parent of q,
since 344-5=3*113, but q->b is absent since 344-3=11*31.
The prime-root contradiction needs the second divisibility b|(N-q).
```
