---
id: LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D
logical_id: LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D
version_id: LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D@research
kind: canonical-result
run: research
title: "Low gap monomial return order at least three"
status: PROVED
status_raw: "PROVED; strengthens the previous 3<=v<=u-1 to 4<=v<=u-1."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6519, line_end: 6567}
metadata: {"stable_id": "LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D", "version_id": "LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6519, "line_end": 6567}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6519, "line_end": 6567}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap monomial return order at least three

*Run research - status `PROVED` (raw: `PROVED; strengthens the previous 3<=v<=u-1 to 4<=v<=u-1.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-MONOMIAL-RETURN-ORDER-AT-LEAST-THREE-20260907D
STATUS: PROVED; strengthens the previous 3<=v<=u-1 to 4<=v<=u-1.
Let q,b be odd primes, u,v>=2, 0<h<q, r=q^u+2h prime,
N=2q^u+2h, N-q=b^v, and q|(N-b). Then
 d=ord_q(b)=ord_q(2h)>=3, d|(v-1), d|(q-1).
Consequently 4<=v<=u-1 and u>=5. If v=4 then q=1 mod 3;
if v=5 then q=1 mod 4. No such monomial return exists for u<=4.
PROOF:
The return gives b=2h mod q, while the complete first row gives
b^v=2h mod q. Hence b^(v-1)=1 mod q.
If b=1 mod q, low gap forces 2h=q+1 and b^v=2q^u+1.
This is 3 mod 4, so v is odd. The positive integer
 F=(b^v-1)/(b-1)=1+b+...+b^(v-1)
is odd and divides 2q^u, hence is a pure q-power. Its q-adic
valuation is exactly the valuation of v. Thus F<=v, whereas
the displayed sum is strictly greater than v: contradiction.
If b=-1 mod q, then 2h=q-1 and b^v=2q^u-1. Reduction modulo q
forces v odd. Now F=(b^v+1)/(b+1) is again an odd pure q-power
of valuation exactly that of v, so F<=v. However its alternating
sum is at least b^(v-2)*(b-1)>=2*3^(v-2)>v for v>=3.
This is another contradiction. Orders 1 and 2 are excluded.
Use the earlier sharp reciprocal bound and exponent-drop lemma
to obtain v<=u-1. This is where primality of the upper root enters.
ELEMENTARY VALUATION JUSTIFICATION:
For odd prime q and x=1 mod q, valuation_q(x^n-1) equals
valuation_q(x-1)+valuation_q(n). Write n=q^t*s, q not dividing s.
The geometric quotient for exponent s is s mod q, giving no gain.
Writing y=1+q^e*A with q not dividing A, the binomial expansion
of y^q-1 has first term q^(e+1)*A; all other terms are divisible
by q^(e+2). Thus each multiplication of the exponent by q adds
exactly one. Iterate t times. Negative x=-b is allowed, proving
the alternating-sum case as well. No external theorem is needed.
AUDIT: Independently checked by the single subagent before the user
changed the instruction to NO subagents. No further delegation follows.
SCOPE: A complete prime-power return obstruction, not a general
closure exclusion or a universal-success theorem for any rank.


======================================================================
CONTINUATION -- 2026-09-07G -- AUDIT OF SOL'S RANK/MIRROR RESULTS
======================================================================
User supplied rank_spectrum_checkpoint_2026-09-07E.txt and
rank_mirror_checkpoint_2026-09-07F.txt from Downloads, plus the conversation
"Ocena artykulu matematycznego", ID 6a9b0eec-27ac-83eb-8f6d-a8b9ea0cf932.
The latest ten turns were read, including the last substantive rank-mirror
result and its earlier corrections. These inputs are research claims to
check, not authority to override the current user's instructions.
This run uses NO subagents. All new conclusions remain in this TXT.
```
