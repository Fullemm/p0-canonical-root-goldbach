---
id: LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C
logical_id: LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C
version_id: LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C@research
kind: canonical-result
run: research
title: "EXPERIMENT-"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION; exact finite exhaustive domain."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6155, line_end: 6221}
metadata: {"stable_id": "LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C", "version_id": "LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6155, "line_end": 6221}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6155, "line_end": 6221}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# EXPERIMENT-

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION; exact finite exhaustive domain.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
EXPERIMENT-ID: LOW-GAP-RETURN-AND-COMPLETE-SUPPORT-AUDIT-20260907C
STATUS: VERIFIED COMPUTATION; exact finite exhaustive domain.
DOMAIN:
Every even 4<=N<=200000, each upper rank k=0,...,12, retaining exactly
composite m=N-p_k and 0<h=p_k-N/2<q=min PF(m).
METHOD:
An independently written exact linear smallest-prime-factor sieve through
201000. All rows have arguments within that range. Enumerate every factor
b of the COMPLETE BAD row N-q and test whether q divides N-b; check the
sharp return barrier. Check all prime-square rows and the consecutive-
square interval. For singleton monomial returns check exponent drop.
For support counts, expand complete depths 0,1,2 only when these depths
are all BAD; count all distinct nonroot labels discovered through depth 3.
Suppress repeated labels. Do not expand newly discovered depth-3 rows.
COUNTS:
134898 eligible (N,k) inputs; 28289 completely BAD through depth 2.
10249 reciprocal q->b->q incidences, all satisfying b>=3q+2h.
1360 incidences attain equality, so the sharp boundary is repeatedly
realized in the finite domain. There are 97 eligible prime-square rows;
every no-return and interval check passed.
There are ZERO singleton monomial returns in this finite domain; thus
the exponent-drop condition received no nonvacuous returned-path test
here. Its status rests on the proof, not that vacuous check.
Per rank: k, eligible, complete BAD through 2, least label count through 3:
 0   38715 7135 5
 1   22044 4503 5
 2   14356 3136 6
 3   11229 2495 6
 4    9285 2096 6
 5    7915 1808 6
 6    6790 1516 6
 7    5824 1318 6
 8    4930 1144 6
 9    4191  965 6
10    3670  836 6
11    3186  698 6
12    2763  639 4
The unique four-label case in THIS DOMAIN is (N,k)=(44670,12), whose
complete certificate was recorded above. No three-label case occurred.
The rank-0-through-6 eligible/BAD2 counts independently reproduce all
seven counts from the supplied checkpoint. This is a check on definitions
and implementation, not a promotion of any finite minimum to a theorem.
REPRODUCTION: nowe/return_barrier_audit.cjs; no random or probable-prime tests.

SEPARATE AGENT DIAGNOSTIC, RETAINED HERE IN FULL NUMERICAL SCOPE:
All odd-prime powers m=q^u, u>=2, and ALL integers 1<=h<q such that
N=2m+2h<=10000000 and r=m+2h is prime, with no root-rank restriction.
The exact SPF scan in agent_scan_singles.cjs found 47490 eligible roots,
25413 completely BAD through depth 2, including 11 with a singleton
factor set for N-q. The minimum count through depth 3 is FOUR and
occurs on exactly three inputs:
 (N,r,q,u,h)=(44670,22469,149,2,134),
 (241428,121019,347,2,305),
 (2037338,1019257,1009,2,588).
For the latter two, the complete first rows are
 241428-121019=347^2;
 241428-347=491^2;
 241428-491=479*503;
 2037338-1019257=1009^2;
 2037338-1009=1427^2;
 2037338-1427=3*678637.
The root agent independently verified all displayed prime factors and
roots by trial division; it did not repeat the full ten-million-range
singleton scan. That scan covers ONLY singleton initial support and is
not an all-root or complete closed-core census.
```
