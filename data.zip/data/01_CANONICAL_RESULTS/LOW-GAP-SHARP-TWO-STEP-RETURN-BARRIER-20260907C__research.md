---
id: LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C
logical_id: LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C
version_id: LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C@research
kind: canonical-result
run: research
title: "Low gap sharp two step return barrier"
status: PROVED
status_raw: "PROVED, elementary pointwise statement."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5996, line_end: 6059}
metadata: {"stable_id": "LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C", "version_id": "LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5996, "line_end": 6059}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5996, "line_end": 6059}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap sharp two step return barrier

*Run research - status `PROVED` (raw: `PROVED, elementary pointwise statement.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-SHARP-TWO-STEP-RETURN-BARRIER-20260907C
STATUS: PROVED, elementary pointwise statement.
EXACT STATEMENT:
Let N be even and r>=N/2 a prime upper root with composite complement
m=N-r. Put h=r-N/2 and q=min PF(m), and assume 0<h<q.
Suppose q and an odd prime b are BAD and form an actual two-cycle:
 b divides N-q, and q divides N-b.
Then
 b=2h+(2j+1)q for an integer j>=1;
 in particular b>=3q+2h.
The numerical lower bound is sharp, both for canonical roots and for
noncanonical upper roots. It bounds a two-cycle through the minimum
first child; it is not a no-cycle theorem for the whole reached graph.

PROOF:
The BAD root is odd, m is odd, r>N/2, and q>=3. Every child of an
active prime is active: if t divides both N-p and N then t divides p,
forcing t=p and contradicting activity of p. Since r is an upper
nondiagonal prime, it is active; so q,b are active and b!=q.
Because q divides m, N=2m+2h is congruent to 2h modulo q.
The return edge b->q gives b=2h+kq for an integer k. The primes b,q
are odd, so k is odd. Since 0<2h<2q and b>0, k<=-3 is impossible.
If k=-1, then b=2h-q<q and the other edge q->b gives
 b divides N-q=2m+b.
Thus b divides m, contradicting the minimality of q.
If k=1, then b=q+2h, and
 N-q=2m+2h-q=2(m+2h)-b=2r-b.
Hence b divides 2r, so b=r because b is odd and r is prime.
This is impossible: a prime factor b of the odd composite row N-q
satisfies b< N/3<r. Thus k>=3, proving the assertion.

SHARPNESS / EXACT CERTIFICATES:
Canonical case: N=80, r=p0=41, h=1, m=39=3*13, q=3.
 N-3=77=7*11; N-11=69=3*23.
Thus b=11=3q+2h is an actual BAD two-cycle partner.
The child 13 is GOOD (80-13=67 prime), so this cycle does not cause
full BFS failure or even complete first-front BADness.
Noncanonical case: N=1638, r=p1=823, p0=821, h=4,
 m=815=5*163, q=5.
 N-5=1633=23*71; N-23=1615=5*17*19.
Here b=23=3q+2h again. The root ranks are exact: 819 is composite,
820 and 822 are even, and 821 and 823 are prime.
All displayed factors, roots and prime complements were checked by
integer trial division / exact sieve lookup.

HISTORICAL AUDIT:
The underlying odd parent lattice p=2h+ell*q is already present in
the Biblia, proposition prop:v73-parent-lattice (near line 45279 in
the supplied file). It is not claimed as new. This consumer removes
the two closest positive candidates in the small-gap setting:
ell=-1 by complete first-support minimality, ell=1 by primality of
the upper root. An exact-string search for 3q+2h and its reordered
forms in the master, Biblia, core, failure log and input checkpoint
found no earlier version. This is a selective corpus check, not a
literature priority audit.
RELATION TO p0:
The bound applies automatically at h=1 but is shared by every upper
prime root satisfying h<q. Its sharp p1 example prevents interpreting
its sharpness as a p0-only signature. It is an actual two-step return
restriction, but it does not force a GOOD child or prevent longer cycles.
RELATION TO GOLDBACH: no prime-pair existence conclusion.
NOVELTY: not externally audited; no priority claim.
```
