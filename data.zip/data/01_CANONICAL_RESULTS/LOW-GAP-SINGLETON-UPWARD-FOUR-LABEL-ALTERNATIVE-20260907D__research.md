---
id: LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D
logical_id: LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D
version_id: LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D@research
kind: canonical-result
run: research
title: "Low gap singleton upward four label alternative"
status: PROVED
status_raw: "PROVED; consumer of complete prime supports."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6455, line_end: 6482}
metadata: {"stable_id": "LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D", "version_id": "LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6455, "line_end": 6482}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6455, "line_end": 6482}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap singleton upward four label alternative

*Run research - status `PROVED` (raw: `PROVED; consumer of complete prime supports.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-SINGLETON-UPWARD-FOUR-LABEL-ALTERNATIVE-20260907D
STATUS: PROVED; consumer of complete prime supports.
EXACT STATEMENT:
Let r=q^u+2h be prime, u>=2, q odd prime, 0<h<q, N=2q^u+2h.
Suppose N-q is composite, has at least two distinct prime factors,
and EVERY prime factor of N-q exceeds q. Then either a GOOD vertex
is reached by depth 2 from r, or at least FOUR distinct nonroot
prime labels occur by depth 3 in the complete stopped search.
PROOF:
The first frontier is {q}. If PF(N-q) has at least three elements,
the claim holds by depth 2. Otherwise write PF(N-q)={b,c}, q<b<c.
Assume no GOOD vertex occurs through depth 2 and at most three
nonroot labels are discovered through depth 3. All q,b,c are BAD
and their COMPLETE rows must be supported on {q,b,c}.
The row N-b cannot have b as a factor by activity. It cannot have
c as a factor either: c already divides N-q, so this would give
c|(b-q), with 0<b-q<c. Thus N-b=q^v for an integer v>=2.
If v<=u, then b=N-q^v>=N-q^u=r>N/2, contradicting b<N/3,
since b is a factor of the odd composite row N-q.
If v>=u+1, then q^v>=q*q^u>N, because
 q*q^u-N=(q-2)q^u-2h >= q^u-2h>0.
This contradicts q^v=N-b<N. Both cases are impossible.
SCOPE:
The proof uses COMPLETE factors and their ordering, not one chosen
large child. The assumption that all factors of N-q exceed q is
essential to the displayed three-label exclusion and is not silently
assumed for a general singleton first support.
```
