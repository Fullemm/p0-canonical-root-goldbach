---
id: LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C
logical_id: LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C
version_id: LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C@research
kind: canonical-result
run: research
title: "Low gap square row no return"
status: PROVED
status_raw: "PROVED; independent elementary lemma supplied by the one agent"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6060, line_end: 6097}
metadata: {"stable_id": "LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C", "version_id": "LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6060, "line_end": 6097}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6060, "line_end": 6097}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap square row no return

*Run research - status `PROVED` (raw: `PROVED; independent elementary lemma supplied by the one agent`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-SQUARE-ROW-NO-RETURN-20260907C
STATUS: PROVED; independent elementary lemma supplied by the one agent
and checked by the root agent.
EXACT STATEMENT:
Under the same root, gap and minimum-factor hypotheses, suppose
 N-q=b^2 for a prime b.
Then q does not divide N-b, and
 (b-1)^2 < N-b < b^2.
PROOF:
Since m is composite and q is its least prime factor, m>=q^2.
Consequently b^2=2m+2h-q>q^2, hence b>q.
If q divided N-b, then b=N=2h (mod q). The equation b^2=N-q
also gives b^2=N=b (mod q). Since b!=q is prime, this implies
b=1 (mod q) and 2h=1 (mod q). The only even integer strictly
between 0 and 2q in this residue class is q+1. Thus 2h=q+1.
But then b^2=2m+1=3 (mod 4), impossible because m is odd.
Finally N-b=b^2+q-b<b^2, and subtraction of (b-1)^2 leaves
q+b-1>0. This proves the strict interval and the no-return assertion.

COMPLETE-SUPPORT CONSEQUENCE:
If PF(m)={q}, N-q=b^2, and no GOOD vertex occurs through depth 2,
then either at least FOUR distinct nonroot primes are discovered by
depth 3, or the next COMPLETE row is
 N-b=c^w with a new prime c!=q,b and an ODD exponent w>=3.
Indeed q is excluded by the lemma, b by activity. Two distinct factors
of N-b introduce two new labels. Otherwise it is a prime power; its
exponent is at least two by BADness and cannot be even because N-b
lies strictly between consecutive integer squares.
Thus a three-label square bottleneck would satisfy the exact system
 2q^u+2h=q+b^2=b+c^w,
 u>=2, w>=3 odd, 0<h<q, q^u+2h prime.
This system has NOT been excluded. It is an obstruction to completing
a universal FOUR-label proof, not a claimed counterexample to FOUR.
The child c need not be BAD because its row is at depth 3.
RELATION TO p0: shared under the stated gap condition.
NOVELTY: no literature-priority claim.
```
