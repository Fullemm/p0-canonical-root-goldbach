---
id: LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C
logical_id: LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C
version_id: LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C@research
kind: canonical-result
run: research
title: "Low gap three label exact obstruction split"
status: PROVED
status_raw: "PROVED finite-support reduction; the resulting Diophantine"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6295, line_end: 6429}
metadata: {"stable_id": "LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C", "version_id": "LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6295, "line_end": 6429}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6295, "line_end": 6429}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Low gap three label exact obstruction split

*Run research - status `PROVED` (raw: `PROVED finite-support reduction; the resulting Diophantine`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: LOW-GAP-THREE-LABEL-EXACT-OBSTRUCTION-SPLIT-20260907C
STATUS: PROVED finite-support reduction; the resulting Diophantine
systems are unresolved, so this is NOT a four-label theorem.
EXACT STATEMENT:
Fix a prime upper root r with composite m=N-r, 0<h<q=min PF(m),
and no GOOD vertex through depth 2. If the complete nonroot support
discovered through depth 3 has at most three labels, then it has
exactly three, and at least one of the following holds:

(A) There is a closed active BAD set C of exactly three primes that
    contains PF(m); the whole nonroot reachable set is C.

(B) There are distinct odd primes q,b,c and integers u,v>=2,
    a>=0,w>=1,a+w>=2 satisfying the COMPLETE row equations
      m=q^u,
      N-q=b^v,
      N-b=q^a*c^w,
      N=2q^u+2h, 0<h<q, r=q^u+2h prime.
    The row N-c is not constrained; c is first discovered at depth 3.
    If a>0, then 3<=v<=u-1. If v=2, then a=0 and w is odd>=3.

Conversely, (A) in the stated low-gap root domain yields no GOOD and
exactly three discovered nonroot labels by depth 3; and a system (B)
with the listed hypotheses yields no GOOD through depth 2 and exactly
three labels through depth 3. Cases (A) and (B) may overlap.

PROOF OF EXHAUSTIVENESS:
Let S=PF(m). Minimum-factor escape gives PF(N-q) disjoint from S:
any common prime t would divide 2h-q, a nonzero integer of absolute
value <q<=t. The old LOW-GAP-COMPLETE-THREE-LABEL-ALTERNATIVE proves
that at least three labels occur. If |S|>=3, expansion of the BAD
row at q adds an outside label by depth 2, giving at least four.
Therefore |S|<=2 in a three-label case.
If |S|=2, PF(N-q) must be a singleton {b}, or at least four labels
are already present. The three labels S union {b} are all reached
by depth 2. Since no GOOD occurs there, all three rows are expanded,
and no child outside this set is discovered by depth 3. Thus it is
a complete closed active BAD set C, giving (A).
If |S|=1, write m=q^u, u>=2, and T=PF(N-q). If |T|>=3, at least
four labels occur. If |T|=2, then {q} union T consists of three
BAD labels reached by depth 2; expanding all three again proves (A).
Finally |T|=1 gives N-q=b^v, v>=2. Activity gives b!=q. Under the
three-label count the entire support of N-b lies in {q,c}, where c
is the sole new label. The earlier three-label theorem ensures c
really occurs. Hence N-b=q^a*c^w, w>=1, with a+w>=2 by BADness.
The sharp monomial return lemma applies when a>0. If v=2, the
square-row lemma gives a=0 and excludes an even w. This proves (B).
For the converse in (A), closure and BADness prevent any GOOD or
fourth label, while the old three-label theorem forces three labels
by depth 3. In (B), the complete rows show exactly the successive
fronts {q}, {b}, {c}, with a possible repeated q in the last row.
The root and q,b are BAD; the status of c is immaterial through depth 2.

HOSTILE CHECK:
Case (A) is a statement about the entire reachable set, not just a
terminal SCC of size three. No classification of three-vertex cores
or of two-vertex terminal cores is assumed. In (B), requiring N-c
to be BAD or supported on {q,b,c} would be an extra, unjustified
condition. The reduction explicitly retains the full cofactors in
both expanded rows. A selected path alone would not establish it.
RELATION TO p0:
The reduction is shared by all low-gap roots; in the h=1 square
subcase one can add u odd>=3 and q=23 (mod 24). It does not prove
that even one of the reduced configurations exists for p0, nor that
all are impossible. The five-label counterexample with r=p12 has
FOUR labels and therefore lies outside this three-label obstruction.
NOVELTY: no literature priority claim; this is a precise consumer of
the existing three-label theorem and the new reciprocal-row lemmas.


======================================================================
END-OF-RUN CHECKPOINT -- 2026-09-07C
======================================================================
STRONGEST RESULTS OF THIS LOCAL CONTINUATION:
1. Sharp reciprocal-edge bound b>=3q+2h for a low-gap return
   q->b->q through the minimum first factor. Complete proof and sharp
   p0 and p1 examples are recorded. The root's primality excludes
   the candidate b=q+2h; minimum-factor arithmetic excludes b=2h-q.
2. For m=q^u and complete prime-power row N-q=b^v, a return forces
   3<=v<=u-1. Thus u=2 and u=3 prohibit this immediate monomial return.
   The separate square-row lemma forces the next row between two
   consecutive squares and coprime to q.
3. The unrestricted low-gap FIVE-label strengthening is false at
   N=44670, r=p12=22469. Both depth-3 endpoints are GOOD. The old
   rank-0-through-6 experiment remains correct within its exact domain.
4. A precise reduction of the open FOUR-label strengthening to a full
   three-label closed world or an explicit complete prime-power system.
5. A modular-subgroup explanation was tested and found uninformative
   at five of the six known hosts, where the failed support generates
   the whole unit group. The necessary subgroup lemma is retained.

VALIDATION:
One subagent supplied an independent counterexample search and proof
audit; no additional agents were created. The root checked the exact
certificates independently and ran the new return/support audit across
134898 eligible rank-0-through-12 inputs. All 10249 reciprocal-edge
checks passed; 1360 attain equality. Proofs are elementary and use no
new external sieve, prime-tuple, height or classification theorem.
The supplied TXT's complete previous contents remain above this run.

CURRENT LIMIT:
Neither binary Goldbach nor universal p0 reachability is proved.
The new return restrictions use the primality of an upper root and a
small numerical gap; they are not properties unique to the canonical
selector. No general bound of FOUR, let alone FIVE, on the depth-3
nonroot support has been proved. The earlier asymptotic radius-three
large-product obstruction and moving closed-support obstruction are
unchanged. Finite counts are not all-N theorems or literature novelty.

EXACT NEXT QUESTIONS:
Local: can either configuration in LOW-GAP-THREE-LABEL-EXACT-
OBSTRUCTION-SPLIT occur? In its singleton square branch the remaining
equations are 2q^u+2h=q+b^2=b+c^w with w odd>=3; in h=1 also u is
odd>=3 and q=23 (mod 24). These equations still need an actual
Diophantine exclusion or a checked example.
Global: the h=1 full-BFS question from the previous checkpoint remains
the same: can a complete closed active BAD set contain PF(P-2) when
N=2(P-1) and P is prime? Excluding only immediate two-cycles, or only
three-label worlds, does not settle this moving-support problem.

FINAL INDEPENDENT AUDIT:
The same single subagent checked the strengthened reciprocal bound,
the exponent-drop consumer, and the exhaustive three-label split,
including both converses and the unconstrained status of the depth-3
prime c. No correction was needed. This is an internal independent
proof check, not external peer review or a novelty audit.


======================================================================
CONTINUATION -- 2026-09-07D
======================================================================
Same mathematical definitions and TXT checkpoint. At most one subagent
is used in this continuation. New claims below do not supersede the
earlier caveats about complete closure or universal p0 success.
```
