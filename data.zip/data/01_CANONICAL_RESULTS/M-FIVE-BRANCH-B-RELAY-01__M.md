---
id: M-FIVE-BRANCH-B-RELAY-01
logical_id: M-FIVE-BRANCH-B-RELAY-01
version_id: M-FIVE-BRANCH-B-RELAY-01@M
kind: canonical-result
run: M
title: "M five branch b relay"
status: PROVED
status_raw: "PROVED EXACT NORMAL FORM"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 93, line_end: 187}
metadata: {"stable_id": "M-FIVE-BRANCH-B-RELAY-01", "version_id": "M-FIVE-BRANCH-B-RELAY-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 93, "line_end": 187}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 93, "line_end": 187}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M five branch b relay

*Run M - status `PROVED` (raw: `PROVED EXACT NORMAL FORM`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-FIVE-BRANCH-B-RELAY-01 -- PROVED EXACT NORMAL FORM
This is the branch that directly extends the former K14 problem. Let
  R={r,x,y}, T={r,b}, S={r,b,c,x,y}.
The COMPLETE rows of every such five-core, after the L exclusion, are
  N-r=b^e,
  N-x=r^u*b^v,
  N-y=r^w*b^z,
  N-b=r^alpha*c^delta*x^beta*y^gamma,
  N-c=r^lambda*b^mu*x^nu*y^xi.                   (M1)

All five labels are distinct odd primes. Required conditions are
  e>=2; u,w>=1; v,z>=0;
  u+v>=2, w+z>=2, v+z>=1;
  delta>=1;
  all alpha,beta,gamma,lambda,mu,nu,xi>=0;
  alpha+delta+beta+gamma>=2;
  lambda+mu+nu+xi>=2;
  beta+nu>=1, gamma+xi>=1;
  beta*gamma=0.                                  (M2)
The equations concern positive integers N-q, and N is even.

Necessity. The first three rows and their signs follow from the same
minimal-Hall argument as K14. Only rows b,c can supply x,y, giving the
two coverage inequalities. Only b can supply c, because r,x,y are
restricted to {r,b} and c cannot supply itself. Thus delta>=1.
If beta and gamma were both positive, x*y would divide N-b and the
L forbidden-three-row-block theorem would apply. Hence beta*gamma=0.
The remaining conditions express compositeness and complete support.

Sufficiency. Any prime solution of (M1),(M2) is a five-core without a
perfect matching. The rows r,x,y have only two neighbors r,b. They
provide x,y->r->b. The row b reaches c. Because b cannot contain both
x,y, the coverage conditions force c to reach at least one of them,
so c returns to r. Every label is reached from r through b,c, using
the coverage conditions, and every label returns to r. Thus the graph
is strongly connected and closed, all rows are composite, and self-
label exclusion gives activity. Low labels follow from incoming rows.
Minimality follows from strong connectivity. QED.

Interpretation: a five-core defect of this type must use the extra label
c to supply at least one missing child x or y. The common-parent version
is impossible by L. This is an exact surviving arithmetic family, NOT
a proof that the family has any prime solution.

IMPORTANT GUARD AGAINST OVEREXTENSION
Do not automatically import u>w, v<z or k<=e from L into the whole M1
family. The L orientation proof used x*y<N, supplied there by a single
parent containing both x and y. In M1 the factors can be split between
the rows at b and c. Coverage alone does not imply x*y<N.
If nu,xi>=1, the row at c does give x*y<N; in that SUBBRANCH the earlier
orientation argument applies after naming y=max{r,b,x,y}. Even then
the congruence b|(k-1) is not available for k=(N-c)/y: modulo b one gets
  (k-1)*y=-c modulo b,
which is nonzero. Thus the decisive small-b step of L does not transfer.

SAVE POINT M2: exact branch B, its automatic strong-connectivity proof,
and the precise failed transfer of the L argument are saved.

OTHER TWO BRANCHES: COMPLETE ROW SYSTEMS TO KEEP SEPARATE

A has R={x,y,z}, T={a,b}. Its rows are
  N-x=a^u1*b^v1, N-y=a^u2*b^v2, N-z=a^u3*b^v3,
  N-a=b^A*x^B*y^C*z^D,
  N-b=a^E*x^F*y^G*z^H.
All exponents are nonnegative; every row must be composite. Each of
a,b appears in at least two of the three R rows. There is at most one
pure a row and at most one pure b row. Coverage requires
B+F,C+G,D+H>=1. Strong connectivity must ALSO be imposed; these sign
and coverage conditions alone do not imply it. For a pure-free graph,
all six u_i,v_i are positive. No branch-A prime solution is asserted.

C has R={a,b,x,y}, T={a,b,c}. Its rows are
  N-a=b^A*c^B,
  N-b=a^C*c^D,
  N-x=a^U*b^V*c^W,
  N-y=a^P*b^Q*c^J,
  N-c=a^alpha*b^beta*x^gamma*y^delta.
Exponents are nonnegative, every row is composite, gamma,delta>=1,
and B+D>=1 (otherwise {a,b} would be closed). Every neighbor in
{a,b,c} must appear in at least two of the first four rows. Strong
connectivity and, when classifying a minimal type-C witness, absence
of a smaller deficient subset must still be imposed. No prime solution
or all-N exclusion of branch C is asserted.

CURRENT FRONTIER
The shortest direct continuation of the successful L method is M1,
starting with its subbranch where the c row contains both x,y. It keeps
the pure row and three two-base rows, but changes one essential modular
identity. Any next argument must control the additional prime c, not
silently treat it as a bounded constant or omit its outgoing factors.
The pure-free parts of A,C remain a separate obstruction, so excluding
M1 alone would still not prove matching for all five-cores.

No statement here proves Goldbach, host finiteness, or p_0/p_k success.
The work is on necessary structure of their common BAD obstruction.
```
