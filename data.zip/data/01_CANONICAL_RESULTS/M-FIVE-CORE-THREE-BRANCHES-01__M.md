---
id: M-FIVE-CORE-THREE-BRANCHES-01
logical_id: M-FIVE-CORE-THREE-BRANCHES-01
version_id: M-FIVE-CORE-THREE-BRANCHES-01@M
kind: canonical-result
run: M
title: "M five core three branches"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 47, line_end: 60}
metadata: {"stable_id": "M-FIVE-CORE-THREE-BRANCHES-01", "version_id": "M-FIVE-CORE-THREE-BRANCHES-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 47, "line_end": 60}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 47, "line_end": 60}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M five core three branches

*Run M - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-FIVE-CORE-THREE-BRANCHES-01 -- PROVED
Every five-core matching failure has a minimal witness of exactly one
of the following three possible intersection types:
  A: |R|=3, |T|=2, |R intersect T|=0;
  B: |R|=3, |T|=2, |R intersect T|=1;
  C: |R|=4, |T|=3, |R intersect T|=2.
This assertion lists the possible type of any chosen minimal witness;
it does not initially assume that a graph has only one such witness.

Proof. The witness size is 3 or 4. Put m=|R|, so |T|=m-1. Since there
are five labels, |R intersect T|>=2m-6. Since T is not contained in R,
the intersection is at most m-2. For m=3 this gives 0 or 1; for m=4 it
gives exactly 2. QED.
```
