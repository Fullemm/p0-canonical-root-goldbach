---
id: M-FIVE-GRAPH-CENSUS-01
logical_id: M-FIVE-GRAPH-CENSUS-01
version_id: M-FIVE-GRAPH-CENSUS-01@M
kind: canonical-result
run: M
title: "M five graph census"
status: FINITE CENSUS
status_raw: "COMPLETE FINITE SUPPORT AUDIT"
audit: SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 61, line_end: 92}
metadata: {"stable_id": "M-FIVE-GRAPH-CENSUS-01", "version_id": "M-FIVE-GRAPH-CENSUS-01@M", "status": "FINITE CENSUS", "scope": "All 15^5 ordered loopless nonempty five-row support graphs", "assumptions": ["Ordered parents", "Distinct pure bases", "Strong connectivity", "Specified L exclusions"], "statement": "759375 input graphs; 3868 survive specified matching-failure filters, before later M/N deletions.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 61, "line_end": 92}, "depends_on": [], "consequences": [], "does_not_imply": ["Graphs are not arithmetic cores", "Not arbitrary core size", "Counts belong to stated filter stage"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 61, "line_end": 92}, "proof_provenance": [], "computation": ["hall_five_core_frontier_20260908M"], "concepts": ["cycle-cover", "support", "enumeration-box"], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA", "metadata_completeness": "CURATED"}
---

# M five graph census

*Run M - status `FINITE CENSUS` (raw: `COMPLETE FINITE SUPPORT AUDIT`) - audit `SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA`*

> Verification: **SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA**. Metadata coverage: CURATED.

## Current scoped statement

759375 input graphs; 3868 survive specified matching-failure filters, before later M/N deletions.

**Assumptions:** Ordered parents; Distinct pure bases; Strong connectivity; Specified L exclusions.

**Does not imply:** Graphs are not arithmetic cores; Not arbitrary core size; Counts belong to stated filter stage.

## Source transcript (historical wording; apply current metadata)

```
M-FIVE-GRAPH-CENSUS-01 -- COMPLETE FINITE SUPPORT AUDIT
The program hall_five_core_frontier_20260908M_code.txt enumerated every
choice of five nonempty rows with no self-edge, 15^5=759375 graphs on
the ordered vertex set {0,1,2,3,4}. It retained only unique smaller
parents, distinct pure bases and strong connectivity. Results:
  ordered-parent graphs:                       53955;
  also distinct pure bases:                     38361;
  also strongly connected:                      25504;
  with a perfect matching:                      21216;
  without a perfect matching:                    4288;
  matching failures excluded by L local theorem:   420;
  matching failures still abstractly admissible:  3868.

Of the 3868 surviving graphs, 102 have no pure row. Minimal-witness
signature sets in this exact enumeration were:
  only type A: 1216 graphs;
  only type B: 1312 graphs;
  only type C: 1340 graphs.
No surviving graph in this enumeration had minimal witnesses of more
than one type. This last statement is a finite graph observation here,
not a separately proved general theorem for larger core sizes.

The 3868 graphs are NOT 3868 arithmetic cores, prime solutions, or
potential Goldbach counterexamples. They are complete support patterns
that survive the specified necessary conditions. No arithmetic existence
has been demonstrated. All graphs and all their minimal Hall witnesses
are saved in hall_five_core_frontier_20260908M_results.txt, encoded as
five row bitmasks and (row-set mask, neighbor-set mask) pairs.

SAVE POINT M1: the exact three-branch reduction and the complete five-
vertex graph census have been saved before choosing a Diophantine branch.
```
