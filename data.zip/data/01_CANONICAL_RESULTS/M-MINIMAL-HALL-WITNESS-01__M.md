---
id: M-MINIMAL-HALL-WITNESS-01
logical_id: M-MINIMAL-HALL-WITNESS-01
version_id: M-MINIMAL-HALL-WITNESS-01@M
kind: canonical-result
run: M
title: "M minimal hall witness"
status: PROVED
status_raw: "PROVED, GENERAL CORE SIZE"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 26, line_end: 46}
metadata: {"stable_id": "M-MINIMAL-HALL-WITNESS-01", "version_id": "M-MINIMAL-HALL-WITNESS-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 26, "line_end": 46}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 26, "line_end": 46}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M minimal hall witness

*Run M - status `PROVED` (raw: `PROVED, GENERAL CORE SIZE`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-MINIMAL-HALL-WITNESS-01 -- PROVED, GENERAL CORE SIZE
Let R be an inclusion-minimal deficient row subset in a core, and T its
complete neighbor set. Then:
  |T|=|R|-1;
  every label of T has at least TWO parents inside R;
  T is not a subset of R.

Proof. Removing any row from R leaves a nondeficient set by minimality,
so |T|>=|R|-1. Deficiency gives equality. If a child appeared in just
one row r of R, deleting that row would leave at most |T|-1=|R|-2
neighbors for |R|-1 rows, again deficient. Finally, if T were a subset
of R, the rows at the labels of T would have all their factors in T.
This would be a nonempty proper closed BAD subset, contradicting core
minimality. Here R is proper, because a core has an incoming edge at
every label and its full row set cannot be deficient. QED.

One- and two-row deficient witnesses are already impossible, by nonempty
rows and the no-repeated-pure-base fact. The maximum label in R union T
cannot lie in T: it would have two smaller parents from R. This uses
the ordered-parent lemma, not an assumption of random graph structure.
```
