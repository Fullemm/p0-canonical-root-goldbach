---
id: M-NO-SHARED-LARGEST-CHILD-01
logical_id: M-NO-SHARED-LARGEST-CHILD-01
version_id: M-NO-SHARED-LARGEST-CHILD-01@M
kind: canonical-result
run: M
title: "M no shared largest child"
status: PROVED
status_raw: "PROVED, ELEMENTARY, ALL N"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 255, line_end: 271}
metadata: {"stable_id": "M-NO-SHARED-LARGEST-CHILD-01", "version_id": "M-NO-SHARED-LARGEST-CHILD-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 255, "line_end": 271}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 255, "line_end": 271}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M no shared largest child

*Run M - status `PROVED` (raw: `PROVED, ELEMENTARY, ALL N`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-NO-SHARED-LARGEST-CHILD-01 -- PROVED, ELEMENTARY, ALL N
In M1/M2, name x<y=max{r,b,x,y}. If nu,xi>=1, then gamma=0:
the b row cannot also contain the larger narrow-row label y.

Proof. The c row supplies xy<N, so the orientation and determinant
arguments give y>N/(e+1)>e. If gamma>=1, the b row would contain both
c and y (delta>=1). Then c*y<=N-b<N, giving c<N/y<e+1 and hence c<=e.
Thus both b<y and c<y. But y would divide both N-b and N-c, giving
two distinct smaller parents of y, which is impossible. QED.

The same proof is local and permits arbitrary additional factors in
N-b and N-c: three COMPLETE rows N-r=b^e, N-x=r^u*b^v,
N-y=r^w*b^z with the usual signs cannot coexist with
  x*y | N-c and c*y | N-b,
when the five primes are distinct and y=max{r,b,x,y}. No full five-label
closure is required for that local forbidden pattern.
```
