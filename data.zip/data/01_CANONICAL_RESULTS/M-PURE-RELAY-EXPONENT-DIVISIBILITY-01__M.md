---
id: M-PURE-RELAY-EXPONENT-DIVISIBILITY-01
logical_id: M-PURE-RELAY-EXPONENT-DIVISIBILITY-01
version_id: M-PURE-RELAY-EXPONENT-DIVISIBILITY-01@M
kind: canonical-result
run: M
title: "M pure relay exponent divisibility"
status: PROVED
status_raw: "PROVED, ELEMENTARY, ALL N"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 272, line_end: 286}
metadata: {"stable_id": "M-PURE-RELAY-EXPONENT-DIVISIBILITY-01", "version_id": "M-PURE-RELAY-EXPONENT-DIVISIBILITY-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 272, "line_end": 286}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 272, "line_end": 286}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M pure relay exponent divisibility

*Run M - status `PROVED` (raw: `PROVED, ELEMENTARY, ALL N`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-PURE-RELAY-EXPONENT-DIVISIBILITY-01 -- PROVED, ELEMENTARY, ALL N
In the pure-relay case N-b=c^delta, delta>=2, it is impossible that
delta divides e. This lemma does not use the M3 finite height bound.

Proof. The pure b row contains neither x nor y, so coverage forces
nu,xi>=1. Hence r<(3/2)^e. If e=m*delta, put B=b^m, an odd integer.
Then
  c^delta-B^delta=r-b,
  r<(3/2)^e<3^(e/2)<=B^(delta-1),
  b<=B<=B^(delta-1).
Thus |r-b|<B^(delta-1). If c!=B, factoring the difference of delta-th
powers gives |c^delta-B^delta|>=B^(delta-1), a contradiction. If c=B,
the primality of c and B=b^m forces m=1 and c=b, also impossible.
QED.
```
