---
id: M-PURE-RELAY-RESIDUAL-01
logical_id: M-PURE-RELAY-RESIDUAL-01
version_id: M-PURE-RELAY-RESIDUAL-01@M
kind: canonical-result
run: M
title: "M pure relay residual"
status: PROVED
status_raw: "PROVED WITH M4'S FINITE CHECK"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 287, line_end: 373}
metadata: {"stable_id": "M-PURE-RELAY-RESIDUAL-01", "version_id": "M-PURE-RELAY-RESIDUAL-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 287, "line_end": 373}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 287, "line_end": 373}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M pure relay residual

*Run M - status `PROVED` (raw: `PROVED WITH M4'S FINITE CHECK`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-PURE-RELAY-RESIDUAL-01 -- PROVED WITH M4'S FINITE CHECK
Every hypothetical branch-B solution with N-b a pure c power must have
  N-r=b^e with e ODD,
  N-b=c^2.
Indeed pure relay forces nu,xi>=1; M4 excludes delta>=3; compositeness
excludes delta=1; and the preceding elementary lemma excludes even e
when delta=2. This is a surviving necessary family, not a solution or
an exclusion of the odd-e case.

SAVE POINT M5: the local ban on a shared largest child and the exact
pure-relay residual have been saved. The latter distinguishes its
elementary ingredient from the separate finite-computation ingredient.

FINAL AUDIT -- SAVE POINT M6
The independent support audit checked all 3868 graphs surviving L.
Every minimal witness has the proved cardinalities and every neighbor
has at least two witness parents. All 1312 type-B witnesses satisfy
M1/M2. Directly enumerating the 120 possible support patterns satisfying
M1/M2 in a fixed naming confirmed that EVERY one is strongly connected
and Hall deficient, as the written sufficiency proof states. Ordered
prime realizability was not inferred from this direct support count.

The new M local ban on the shared largest child excludes 88 further
ordered type-B graphs. The remaining abstract support counts are now
  A: 1216; B: 1224; C: 1340; total: 3780.
The earlier 3868 count is the state immediately after L, before M's
additional theorem. These totals count graphs, not arithmetic solutions.

The relay height search now includes the complete 66-candidate exact
rejection certificate in hall_relay_high_power_20260908M_results.txt.
Every certificate tuple records the exact extraction of r and b from
N-x. A separately parameterized larger domain of 455 candidates also
contains no complete x row. All final assertions in the graph, normal-
form and finite arithmetic audits passed.

WHAT IS NOW SETTLED
* K14 is empty for all N, and every core of size <=4 has a matching (L).
* The five-core Hall frontier has the three complete witness types A/B/C.
* Type B has the exact relay system M1/M2 with a proved converse.
* In its common-c subbranch, delta<=2 and gamma=0 are necessary.
* Its pure-relay subbranch has N-b=c^2 and odd e in N-r=b^e.

WHAT REMAINS OPEN
* All-N exclusion or realization of the odd-e pure-square relay branch.
* The nonpure type-B cases with delta=1,2 and common-c coverage.
* The type-B cases where x and y have split parents b,c; the xy<N
  orientation/cofactor argument must not be used there without proof.
* Types A and C, including their pure-free support patterns.
* Existence of three-/four-cores, matching in all larger cores, host
  density/finiteness, Goldbach, and universal success of p_0 or p_k.

NEXT MATHEMATICAL TARGET
For the shortest surviving pure-relay branch write explicitly
  N-r=b^e, e odd;
  N-b=c^2;
  N-x=r^u*b^v;
  N-y=r^w*b^z;
  N-c=r^lambda*b^mu*x^nu*y, nu>=1.
Here x<y=max{r,b,x,y}, u>w>=1, v<z<e,
  k=r^lambda*b^mu*x^nu<=e-v,
  r^D<(k/(k-1))^(e-v), D=(e-z)u-(e-v)w>=1,
  c^2-b^e=r-b.
Every displayed factorization is complete. This residual involves a
square close to an ODD power, with a controlled but moving prime r.
Do not call it a solved Pell equation with fixed discriminant or a fixed
S-unit problem. Its parameters still vary. A new arithmetic argument
is needed; another arbitrary N cutoff would not close it.

NEW ARTIFACTS, ALL TXT IN nowe
goldbach_checkpoint_2026-09-08M.txt -- this full updated research state.
hall_five_core_frontier_20260908M_code.txt / _results.txt -- complete census.
hall_five_normal_form_audit_20260908M_code.txt / _results.txt -- support audit.
hall_relay_high_power_20260908M_code.txt / _results.txt -- two finite searches.

All statements distinguish proofs, complete finite computations and open
branches. No subagent, PDF output or TeX output was used. Original master
and historical input checkpoints were not edited. No literature-wide
priority claim is made.
Input integrity was checked again at the end of the run:
master_ai.tex SHA256:
  84dd17e70f345d3d0679557c9b6932ead1b56be76f462e05dae9b6ea285a90c9
raw J checkpoint SHA256:
  c37c0901dc12a197185bd54bdd2500aa0cb96f4e22a2502e5efc0be0ad0e7fe6
Both match the pre-research hashes. The complete L proof TXT SHA256 is
  5e1c9239a12617852d65e94422d29b1de79ad86f5781f7b5b39765f3bae9611f.
END COMPLETED RESEARCH RUN M -- 2026-09-08
```
