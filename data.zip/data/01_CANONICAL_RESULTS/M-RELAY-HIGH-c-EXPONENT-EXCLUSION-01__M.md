---
id: M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01
logical_id: M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01
version_id: M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01@M
kind: canonical-result
run: M
title: "M RELAY HIGH c EXPONENT EXCLUSION"
status: PROVED
status_raw: "PROVED WITH EXACT FINITE CHECK"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 230, line_end: 254}
metadata: {"stable_id": "M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01", "version_id": "M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 230, "line_end": 254}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 230, "line_end": 254}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M RELAY HIGH c EXPONENT EXCLUSION

*Run M - status `PROVED` (raw: `PROVED WITH EXACT FINITE CHECK`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-RELAY-HIGH-c-EXPONENT-EXCLUSION-01 -- PROVED WITH EXACT FINITE CHECK
There is NO prime solution of M1/M2 with nu,xi>=1 and delta>=3, for
any N. Proof: M3 bounds e<=13 and N<=2227757. The exact enumeration
hall_relay_high_power_20260908M_code.txt covered the resulting entire
parameter range in two ways:
  A: enumerate the small integer k, then recover y=(N-c)/k;
  B: omit k, enumerate w,z of the y row, and factor N-c directly.
Method A had 66 bounded (e,k,x,r,b) candidates. Method B had 455 bounded
(e,b,r,x) candidates in a larger necessary domain. Neither method found
even one complete row N-x=r^u*b^v with u>=2 and v<=e-2. Consequently
neither reached a full system or needed to test a candidate y.
All small-label primality decisions used exact SPF factorization. The
all-N conclusion uses the proved M3 bound; it is not an extrapolation
from a scan. The two searches and their exact counts are reproducible
in the code and results TXT files named above.

Technical guard: here v<=e-2, rather than the K14-only cap v<=e-3.
The latter used reciprocity b<->y and cannot be imported into M1 without
checking the relevant row support. Both new searches use the weaker,
valid v<=e-2 bound. Their r bound is r<(3/2)^e, not the former (7/6)^e.

SAVE POINT M4: the entire common-c, delta>=3 subbranch is excluded.
Unlike the main L theorem, this particular exclusion currently includes
a finite exact computation in its proof.
```
