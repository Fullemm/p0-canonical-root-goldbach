---
id: M-RELAY-HIGH-c-EXPONENT-HEIGHT-01
logical_id: M-RELAY-HIGH-c-EXPONENT-HEIGHT-01
version_id: M-RELAY-HIGH-c-EXPONENT-HEIGHT-01@M
kind: canonical-result
run: M
title: "M RELAY HIGH c EXPONENT HEIGHT"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08M.txt", line: 188, line_end: 229}
metadata: {"stable_id": "M-RELAY-HIGH-c-EXPONENT-HEIGHT-01", "version_id": "M-RELAY-HIGH-c-EXPONENT-HEIGHT-01@M", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 188, "line_end": 229}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08M.txt", "line": 188, "line_end": 229}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# M RELAY HIGH c EXPONENT HEIGHT

*Run M - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
M-RELAY-HIGH-c-EXPONENT-HEIGHT-01 -- PROVED
Consider the exact family M1/M2 with nu,xi>=1 (the c row contains both
x,y) and delta>=3 (c^3 divides N-b). Then
  e<=13, N<=2227757.                              (M3)
This is an all-N theorem, not a numerical cutoff chosen for convenience.

Proof. Name x<y=max{r,b,x,y}, allowing c to be anywhere in the order.
The complete rows at r,x,y and x*y<N, supplied by N-c, permit the L
orientation argument, giving u>w>=1 and v<z<e. Put t=e-v and
  k=(N-c)/y, D=(e-z)*u-(e-v)*w.
The same determinant argument yields
  x<=k<=t<=e,
  3<=r^D<(k/(k-1))^t.
In particular k>=3 and r<(3/2)^e. Also y>e>=k, so xi=1 and
  k=r^lambda*b^mu*x^nu.
Since b|(N-y), reduction of N-c=k*y modulo b shows that b does NOT
divide k-1: otherwise b would divide the distinct prime c.

The two exact identities now have c on their right-hand sides:
  r^w*b^v*[k*b^(z-v)-(k-1)*r^(u-w)] = (k-1)*x+c,
  b^z*[k*r^w-(k-1)*b^(e-z)] = (k-1)*r+c.
Both brackets are positive integers. Thus
  r^w*b^v <= (k-1)*x+c <= e*(e-1)+c < e^2+c,
  b^z <= (k-1)*r+c < e*(c+e^2).
Here r<=r^w<=r^w*b^v. Since y<N/3, these imply
  N < (3e/2)*(c+e^2)^2.
The assumption delta>=3 gives c^3<=N-b<N.
If c>=e^2, then N<6e*c^2<6e*N^(2/3), hence N<216e^3.
If c<=e^2, then N<6e^5. Consequently
  N < max(216e^3,6e^5).
For e>=6 the maximum is 6e^5. But 3^e<N, while
  3^14=4782969 > 6*14^5=3226944,
and 3^e/e^5 increases for every e>=14. Thus e<=13. The displayed
height bound, increasing with e, is then at most
  max(216*13^3,6*13^5)=2227758.
The strict inequality gives M3. QED.

SAVE POINT M3: the complete all-N reduction for the nu,xi>=1, delta>=3
subbranch is saved before its finite arithmetic enumeration. This result
does not yet apply to delta=1,2 or to split-parent coverage nu*xi=0.
END CURRENT RUN M CHECKPOINT -- 2026-09-08
```
