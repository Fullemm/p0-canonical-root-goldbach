---
id: MATVEEV-SLACK-20260907J
logical_id: MATVEEV-SLACK-20260907J
version_id: MATVEEV-SLACK-20260907J@J
kind: canonical-result
run: J
title: "basins"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 741, line_end: 759}
metadata: {"stable_id": "MATVEEV-SLACK-20260907J", "version_id": "MATVEEV-SLACK-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 741, "line_end": 759}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 741, "line_end": 759}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1099, style: ID-TABLE}
---

# basins

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
      basins?          MATVEEV-SLACK-20260907J   STATUS: VERIFIED COMPUTATION
For each host, T9 with the pair realising the minimal gap d in S:
(LHS below uses the sharper log((N-q_2)/d) rather than T9's log((2N/3)/d);
 that only makes the reported slack smaller, i.e. the verdict conservative.)
   N      s   d   LHS = log((N-q2)/d)   prod log q      RHS (Matveev)     RHS/LHS
  128    10   2        4.119            8.49e3          1.45e28          3.5e27  [full B_N]
  128     8   2        4.119            8.30e2          5.75e23          1.4e23  [core]
  1718   55   2        6.753            6.52e36         8.26e130         1.2e130 [full]
  1718   28   2        6.753            4.42e16         3.52e69          5.2e68  [core]
  1862   21   2        6.834            3.94e12         3.94e54          5.8e53  [core]
  1928   14   2        6.868            2.36e7          1.74e38          2.5e37  [core]
  2200    2  10        5.388            2.82            6.21e9           1.1e9   [core]
  6142   10   2        8.029            8.23e4          1.73e29          2.2e28  [core]
The Matveev-certifiable inequality is satisfied with 9 to 159 orders of
magnitude of slack on every real basin, INCLUDING the smallest possible core
(s = 2 at N = 2200).  No plausible improvement of the constants -- the 30^{s+3}
factor is structural -- can bring this route within reach.  Direct exhaustive
Diophantine search (X3) beats it by 10^9 already at s = 2.
```
