---
id: MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B
logical_id: MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B
version_id: MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B@research
kind: canonical-result
run: research
title: "Multigeneration cofactor adversarial scan"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION; no asymptotic conclusion inferred."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4670, line_end: 5052}
metadata: {"stable_id": "MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B", "version_id": "MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4670, "line_end": 5052}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4670, "line_end": 5052}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Multigeneration cofactor adversarial scan

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION; no asymptotic conclusion inferred.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: MULTIGENERATION-COFACTOR-ADVERSARIAL-SCAN-20260906B
STATUS: VERIFIED COMPUTATION; no asymptotic conclusion inferred.
DOMAIN AND METHOD:
Exhaustive primes P in [1000,2000) and [10000,20000), respectively
135 and 1033 starts. For each, N=2(P-1), same-N roots k=0,1,2,5.
Enumerate every SIMPLE stopped successful path of lengths 1 through 4;
these need not be shortest paths if another branch succeeds earlier.
Stop expansion at GOOD vertices, and exclude repeated labels within
one path. Exact SPF sieve through 1,000,100. No factor-size exclusions.
The diagnostic's depth 4 is fixed independently of asymptotic D(X).
The small-product diagnostic uses the exact integer test product^10
<=X^9, i.e. epsilon=1/10, so floating-point comparisons do not decide
membership.

CHECKS AND RESULTS:
22,562 actual successful paths passed every affine-identity, exact-
modulus, reduced-coefficient-integrality, and gcd-compatibility check.
For all canonical paths the final gcd e was exactly 1. For 2,320 paths
with small cofactor product, the progression variable was >=1, all
actual prime values exceeded their leading coefficients, every form
was primitive, and every pair determinant was nonzero.
There were 4,767 depth-three-or-four paths where e failed to divide
at least one earlier partial product A_j. Thus the proof of integer
reduced coefficients is indispensable; division of each A_j by e
would be an actual error.
Maximum observed e was 85, at P=10343, N=20684, Q=p5=10427, h=85,
path Q -> 13 -> 7 -> 29 -> 3. Its cofactor product is
11,437,574,202,585. This large-product path is outside the cofactor
sieve domain, and its progression variable is t=0. It is evidence of
the exact large-modulus obstruction, not a counterexample to the bound.

NONREDUNDANCY WITNESS:
P=1279, N=2556, Q=p5=1301, h=23 admits
 1301 -> 251 -> 461 -> 419,       N-419=2137 prime.
All three edge cofactors equal 5. Hence A=125 while the label product
is 48,482,909. The new cofactor-product count includes this type of
configuration even though the earlier label-product count does not.
Its exact forms at t=10 are
 P=125t+29, Q=125t+51, q1=25t+1, q2=45t+11,
 q3=41t+9, g=209t+47.
An actual finite example inside an asymptotically sparse region is
expected and does not contradict the theorem.

At X=10000, among all depth-three-or-four successful paths, 14,200
had both products large, 1046 had only the label product small, and
58 had only the cofactor product small. These finite multiplicity
counts identify regions tested by the two arguments; they are not
counts of exceptional starts, convergence evidence, or proof that the
residual region has positive asymptotic density.

BEGIN DIAGNOSTIC SOURCE audit_cofactor_paths_20260906b.py
import numpy as np
from math import isqrt,gcd,prod
from collections import Counter
from itertools import combinations
import json
LIMIT=1000100
spf=np.zeros(LIMIT+1,dtype=np.int32)
for p in range(2,isqrt(LIMIT)+1):
 if spf[p]==0:
  v=spf[p*p::p];v[v==0]=p
primes=np.flatnonzero(spf[2:]==0)+2
ip=np.zeros(LIMIT+1,dtype=np.bool_);ip[primes]=True

def pf(n):
 out=[]
 while n>1:
  p=int(spf[n]) or n;out.append(p)
  while n%p==0:n//=p
 return out

stats=Counter();domains={};witness={};max_e=(0,None)
for X in [1000,10000]:
 inds=np.flatnonzero((primes>=X)&(primes<2*X))
 local=Counter()
 for idx in inds:
  P=int(primes[idx]);x=P-1;N=2*x
  for k in [0,1,2,5]:
   Q=int(primes[idx+k]);h=Q-x
   def visit(path,aa):
    global max_e
    u=path[-1];d=len(aa)
    if ip[N-u]:
     if d==0:
      local['direct_GOOD_roots']+=1;return
     local[f'success_paths_depth_{d}']+=1
     AP=[1];CP=[1]
     for a in aa:
      CP.append(2*AP[-1]-CP[-1]);AP.append(AP[-1]*a)
     A=AP[-1];C=CP[-1];e=gcd(A,C);mod=A//e
     assert h%e==0
     if k==0:assert e==1
     residue=((-1)**(d+1)*(h//e)*pow(C//e,-1,mod))%mod if mod>1 else 0
     if residue==0:residue=mod
     assert (x-residue)%mod==0
     t=(x-residue)//mod
     forms=[(mod,residue+1)]
     values=[P]
     if k:
      forms.append((mod,residue+h));values.append(Q)
     for j in range(1,d+1):
      assert AP[j]*path[j]==CP[j]*x+(-1)**j*h
      assert CP[j]*mod%AP[j]==0
      assert (CP[j]*residue+(-1)**j*h)%AP[j]==0
      forms.append((CP[j]*mod//AP[j],(CP[j]*residue+(-1)**j*h)//AP[j]))
      values.append(path[j])
     last_u,last_v=forms[-1]
     forms.append((2*mod-last_u,2*residue-last_v));values.append(N-u)
     assert all(z>0 for z,b in forms)
     assert [z*t+b for z,b in forms]==values
     assert gcd(mod,C//e)==1 and len(set(values))==len(values)
     stats['all_affine_and_modulus_checks']+=1
     M=prod(path[1:]);small_A=A**10<=X**9;small_M=M**10<=X**9
     if small_A:
      assert t>=1 and all(v>z for v,(z,b) in zip(values,forms))
      assert all(gcd(z,b)==1 for z,b in forms)
      assert all(z*d-w*b!=0 for (z,b),(w,d) in combinations(forms,2))
      stats['short_cofactor_product_full_filter_checks']+=1
     rec={'X':X,'P':P,'N':N,'k':k,'Q':Q,'h':h,'path':path,'cofactors':aa,'label_product':M,'cofactor_product':A,'C_d':C,'e':e,'modulus':mod,'residue':residue,'t':t,'prime_forms':forms,'prime_values':values}
     if e>max_e[0]:max_e=(e,rec)
     if d>=3:
      local[f'depth3or4_small_label_{small_M}_small_cofactor_{small_A}']+=1
      if small_A and not small_M:witness.setdefault('large_labels_small_cofactors_depth3or4',rec)
      if e>1 and any(z%e for z in AP[1:-1]):
       stats['e_does_not_divide_all_earlier_partial_products_depth3or4']+=1
       witness.setdefault('reduced_earlier_coefficients_require_proof',rec)
     return
    if d==4:return
    for q in pf(N-u):
     if q in path:continue
     visit(path+[q],aa+[(N-u)//q])
   visit([Q],[])
 domains[str(X)]={'prime_starts':len(inds),'counts':dict(local)}
print(json.dumps({'domain':'Exhaustive primes in [X,2X), X=1000,10000; roots k=0,1,2,5; all SIMPLE stopped successful paths through length 4, not only shortest paths. No size exclusions. Exact SPF through 1,000,100. Small-product flag is exact product^10<=X^9, i.e. epsilon=1/10. This diagnostic depth is fixed independently of the asymptotic D(X).','intervals':domains,'audit':dict(stats),'witnesses':witness,'maximum_e':max_e},indent=2))
END DIAGNOSTIC SOURCE
BEGIN DIAGNOSTIC OUTPUT
{
  "domain": "Exhaustive primes in [X,2X), X=1000,10000; roots k=0,1,2,5; all SIMPLE stopped successful paths through length 4, not only shortest paths. No size exclusions. Exact SPF through 1,000,100. Small-product flag is exact product^10<=X^9, i.e. epsilon=1/10. This diagnostic depth is fixed independently of the asymptotic D(X).",
  "intervals": {
    "1000": {
      "prime_starts": 135,
      "counts": {
        "success_paths_depth_1": 270,
        "success_paths_depth_2": 394,
        "success_paths_depth_3": 582,
        "depth3or4_small_label_False_small_cofactor_False": 1313,
        "direct_GOOD_roots": 143,
        "success_paths_depth_4": 791,
        "depth3or4_small_label_True_small_cofactor_False": 54,
        "depth3or4_small_label_False_small_cofactor_True": 6
      }
    },
    "10000": {
      "prime_starts": 1033,
      "counts": {
        "success_paths_depth_4": 9541,
        "depth3or4_small_label_False_small_cofactor_False": 14200,
        "success_paths_depth_2": 3342,
        "success_paths_depth_3": 5763,
        "depth3or4_small_label_True_small_cofactor_False": 1046,
        "success_paths_depth_1": 1879,
        "direct_GOOD_roots": 835,
        "depth3or4_small_label_False_small_cofactor_True": 58
      }
    }
  },
  "audit": {
    "all_affine_and_modulus_checks": 22562,
    "short_cofactor_product_full_filter_checks": 2320,
    "e_does_not_divide_all_earlier_partial_products_depth3or4": 4767
  },
  "witnesses": {
    "reduced_earlier_coefficients_require_proof": {
      "X": 1000,
      "P": 1013,
      "N": 2024,
      "k": 1,
      "Q": 1019,
      "h": 7,
      "path": [
        1019,
        3,
        43,
        283
      ],
      "cofactors": [
        335,
        47,
        7
      ],
      "label_product": 36507,
      "cofactor_product": 110215,
      "C_d": 30821,
      "e": 7,
      "modulus": 15745,
      "residue": 1012,
      "t": 0,
      "prime_forms": [
        [
          15745,
          1013
        ],
        [
          15745,
          1019
        ],
        [
          47,
          3
        ],
        [
          669,
          43
        ],
        [
          4403,
          283
        ],
        [
          27087,
          1741
        ]
      ],
      "prime_values": [
        1013,
        1019,
        3,
        43,
        283,
        1741
      ]
    },
    "large_labels_small_cofactors_depth3or4": {
      "X": 1000,
      "P": 1279,
      "N": 2556,
      "k": 5,
      "Q": 1301,
      "h": 23,
      "path": [
        1301,
        251,
        461,
        419
      ],
      "cofactors": [
        5,
        5,
        5
      ],
      "label_product": 48482909,
      "cofactor_product": 125,
      "C_d": 41,
      "e": 1,
      "modulus": 125,
      "residue": 28,
      "t": 10,
      "prime_forms": [
        [
          125,
          29
        ],
        [
          125,
          51
        ],
        [
          25,
          1
        ],
        [
          45,
          11
        ],
        [
          41,
          9
        ],
        [
          209,
          47
        ]
      ],
      "prime_values": [
        1279,
        1301,
        251,
        461,
        419,
        2137
      ]
    }
  },
  "maximum_e": [
    85,
    {
      "X": 10000,
      "P": 10343,
      "N": 20684,
      "k": 5,
      "Q": 10427,
      "h": 85,
      "path": [
        10427,
        13,
        7,
        29,
        3
      ],
      "cofactors": [
        789,
        2953,
        713,
        6885
      ],
      "label_product": 7917,
      "cofactor_product": 11437574202585,
      "C_d": 3317803385,
      "e": 85,
      "modulus": 134559696501,
      "residue": 10342,
      "t": 0,
      "prime_forms": [
        [
          134559696501,
          10343
        ],
        [
          134559696501,
          10427
        ],
        [
          170544609,
          13
        ],
        [
          91076481,
          7
        ],
        [
          377318817,
          29
        ],
        [
          39032981,
          3
        ],
        [
          269080360021,
          20681
        ]
      ],
      "prime_values": [
        10343,
        10427,
        13,
        7,
        29,
        3,
        20681
      ]
    }
  ]
}
END DIAGNOSTIC OUTPUT

FINAL HOSTILE AUDIT 2026-09-06B:
The radius-two pair proof retains the two independent degeneracies:
gcd(b,2a-1)|h in CC and r|(2a-1), r|h in CL. Both occur in actual
successful paths. The cofactor-chain proof uses final integrality to
justify all earlier affine forms, rather than assuming reductions
commute with partial products. The growing-k sieve constants, the
factorial sum, the h-average of the exact gcd, and the prime-gap prefix
consumer are written explicitly. Parameters epsilon,c,kappa in the
dual theorem are FIXED; no uniformity as they approach their endpoints
is claimed. The only asymptotic variable in that theorem is X.
No independent external referee audit or literature novelty audit has
been performed. Computational checks test algebra and scope, not the
asymptotic sieve theorem. All original corpus files are unchanged.

=========================
STRONGEST NEW RESULTS
=========================
```
