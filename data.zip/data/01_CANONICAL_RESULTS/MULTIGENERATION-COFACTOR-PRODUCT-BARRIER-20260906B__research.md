---
id: MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B
logical_id: MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B
version_id: MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B@research
kind: canonical-result
run: research
title: "Multigeneration cofactor product barrier"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4387, line_end: 4520}
metadata: {"stable_id": "MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B", "version_id": "MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4387, "line_end": 4520}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4387, "line_end": 4520}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Multigeneration cofactor product barrier

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: MULTIGENERATION-COFACTOR-PRODUCT-BARRIER-20260906B
STATUS: PROVED.
EXACT STATEMENT:
Fix epsilon in (0,1) and c in (0,1). Write L=log X, l=loglog X, and
 D=floor(c*l/log l).
For all but o(X/L) primes P in [X,2X], N=2(P-1), the root P is BAD
and every simple successful stopped path
 P=q_0 -> q_1 -> ... -> q_d,       1<=d<=D,
has
 product_(j=1..d) a_j > X^(1-epsilon),
where a_j=(N-q_(j-1))/q_j is the integer cofactor of the actual edge.
In fact the exceptional count is <=X*L^(-2+c+o(1)).
This is complementary to, not a restatement of, the earlier barrier
on product q_j: a large prime child has a small cofactor.

The following uniform pair version is part of the theorem. For
3<=H<=L^2, the number of pairs of primes (P,Q) with
 X<=P<=2X, P<Q, h=Q-P+1<=H,
for which the Q-rooted stopped traversal at N=2(P-1) has a simple
successful path of length <=D with cofactor product <=X^(1-epsilon)
(or Q is directly GOOD), is
 <=H*X*L^(-3+c+o(1)).                                    (CFPAIR)
The o(1) is uniform over the stated H range, depending only on fixed
epsilon,c. No fixed alphabet, support-size bound, or closed-core
hypothesis is used.

PROOF:
Put x=P-1, so N=2x and Q=x+h. For a successful stopped path of positive
length, all earlier vertices are BAD. Activity propagates to all
children: if a prime q divides both N and N-u, it also divides u;
for prime active u this is impossible. All labels are odd, and proper
prime factors of a composite odd row are <N/3. Thus the path labels
q_1,...,q_d are <N/3, while g=N-q_d>2N/3>Q for large X. For a simple
path, the required prime values q_1,...,q_d,P,Q,g are all distinct,
except that Q=P when h=1; in that case we include that form only once.
The cofactors are odd integers >=3.

Fix d and an ordered tuple of cofactors a_1,...,a_d with
 A=A_d=product a_j<=X^(1-epsilon).
Use C_j from COFACTOR-CHAIN-EXACT-MODULUS. If e=gcd(C_d,A) does not
divide h there are no integer paths. Otherwise let x_0 in [1,A/e]
represent its unique compatible class, and set
 M=A/e,       x=x_0+M*t.
All q_j=(C_j*x+(-1)^j*h)/A_j are integer affine forms in t, with
positive leading coefficients C_j*M/A_j. In particular the last
coefficient is C_d/e, coprime to M. Also g=2x-q_d has positive leading
coefficient (2A-C_d)/e: indeed C_d<=2A_(d-1)<=2A/3.
Since x>=X-1, M<=A<=X^(1-epsilon), and h<=L^2, the progression variable
satisfies 1<=t<=2X/M=2eX/A for large X. Every required prime value is
larger than its leading coefficient. For q_j, subtracting that
coefficient gives
 [C_j*(x-M)+(-1)^j*h]/A_j>0,
because C_j>=1 and x-M>h. For g the same assertion follows from
(2-C_d/A)*(x-M)-(-1)^d*h/A>0. For P,Q it is immediate.
All q_j also exceed X/(2A)>=X^epsilon/2: the first row x-h is >=X/2
and all subsequent rows are >2N/3; divide by a_j<=A. Hence all variable
prime values exceed k=d+2 or d+3 when X is sufficiently large.

Discard any imprimitive or zero-determinant form tuple. It has no
actual solution by DISTINCT-PRIME-FORMS-DEGENERACY-FILTER, whose
coefficient and distinctness hypotheses were just verified. For all
remaining tuples, the two coprime leading coefficients M and C_d/e
ensure nu(ell)>=1 at every prime. The coefficients and constants of
P,Q,q_j,g are bounded in absolute value by 10X^2, uniformly in j,d,h:
C_j<=2A_(j-1), x_0<=A/e, and h<=L^2 suffice. Thus the growing-form
sieve applies, with log(2eX/A)>=epsilon*L.

CANONICAL CASE h=1:
Compatibility forces e=1. There are k=d+2 forms: P, all q_j, and g.
For each cofactor tuple the sieve gives at most
 2^(d+3)*(d+2)!*(2X/A)*(C*l)^(d+1)/(epsilon*L)^(d+2).
Sum 1/A over all ordered cofactor tuples of product at most
X^(1-epsilon). The harmonic-simplex lemma bounds this by L^d/d!.
Therefore the total at depth d is at most
 C_epsilon*(X/L^2)*(d+3)^3*(C_epsilon*l)^(d+2).             (CF0d)
This bound is deliberately loose in a fixed power of l; the key
factorial ratio (d+2)!/d! is only quadratic in d.

LATER-ROOT PAIRS:
For h>=3 there are k=d+3 forms, including the extra prime P=x+1 and
Q=x+h separately. The fixed tuple, fixed compatible h bound has the
same shape with d+3 in place of d+2, and the progression length carries
its full factor e:
 2^(d+4)*(d+3)!*(2eX/A)*(C*l)^(d+2)/(epsilon*L)^(d+3).
For the chosen cofactor tuple e is fixed and depends on that tuple,
not on h. Sum over all compatible odd 3<=h<=H. Crucially,
 sum_(h<=H; e|h) e <= e*floor(H/e)<=H.
This includes every compatible gcd with no growing divisor loss.
Now sum 1/A using the ordered-simplex bound. The depth-d pair count is
at most
 C_epsilon*(H*X/L^3)*(d+3)^3*(C_epsilon*l)^(d+2).           (CFPd)
It was essential to average the actual reduced modulus; setting e=1
for later roots would have omitted valid paths.

SUM OVER DEPTH:
For D=floor(c*l/log l),
 log[sum_(d=1..D)(d+3)^3*(C_epsilon*l)^(d+2)]
 <=(D+2)*log(C_epsilon*l)+O(log(D+3))=(c+o(1))*l.
Thus that sum is L^(c+o(1)). Summing (CF0d) and (CFPd) proves the
claimed bounds for positive path lengths. Direct canonical success
has the previously proved O(X/L^2) count. Direct later-root success
requires P, P+h-1, P-h-1 prime; these are three primitive forms with
nonzero determinants for h>=3 and nu>=1. The same fixed-three-form
sieve gives O(H*X*l^2/L^3), absorbed by (CFPAIR).
Finally X*L^(-2+c+o(1))=o(X/L) because c<1. This proves the theorem.

HOSTILE CHECK:
1. The bound controls all cofactor sequences of short product, not just
   a chosen transcript. It remains a restriction on successful paths,
   not a proof of full BFS failure.
2. A simple path is used to ensure distinct variable prime forms. The
   proof does not sieve repeated forms as independent prime conditions.
3. The growing factorial in FKL is cancelled by an explicitly proved
   volume bound for ORDERED tuples, not by an illicit d! symmetry.
4. For later roots, reduced earlier coefficients are integers because
   of final-to-earlier congruence compatibility, not because e divides
   every partial product A_j.
5. The e factor is averaged before the cofactor tuples are summed.
   No uncontrolled average of a moving gcd is hidden in the estimate.
6. Short cofactor product gives a polynomially long progression. When
   the product is larger, the proof makes no estimate for those paths.
7. This uses the full explicit growing-k FKL bound; a fixed-k big-O
   sieve assertion alone would not justify D tending to infinity.
DEPENDENCIES: Exact cofactor modulus; harmonic-simplex bound; growing
prime-form sieve; activity; no prime-pair lower bound or global failure.
RELATION TO GOLDBACH: A restriction on shallow successful routes. A
closed BAD core has no successful path, so this theorem alone cannot
contradict its existence.
RELATION TO p0: The pair theorem prepares a same-N extension. The h=1
coprimality is arithmetically special but not a success mechanism.
WHAT REMAINS OPEN: Paths with both large label product and large
cofactor product; complete radius three; eventual reachability.
NOVELTY: NOT YET AUDITED.
```
