---
id: MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B
logical_id: MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B
version_id: MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B@research
kind: canonical-result
run: research
title: "Multigeneration label product pair count"
status: PROVED
status_raw: "PROVED; same-N extension of the previous label-product barrier."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4521, line_end: 4561}
metadata: {"stable_id": "MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B", "version_id": "MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4521, "line_end": 4561}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4521, "line_end": 4561}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Multigeneration label product pair count

*Run research - status `PROVED` (raw: `PROVED; same-N extension of the previous label-product barrier.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: MULTIGENERATION-LABEL-PRODUCT-PAIR-COUNT-20260906B
STATUS: PROVED; same-N extension of the previous label-product barrier.
EXACT STATEMENT:
For fixed epsilon,c in (0,1), D=floor(c*l/log l), 3<=H<=L^2,
the number of prime pairs P<Q, P in [X,2X], h=Q-P+1<=H, such that
Q is GOOD or a simple successful path from Q of length d<=D has
M=product_(j=1..d)q_j<=X^(1-epsilon), is
 <=H*X*L^(-3+c+o(1)),
uniformly over H. The analogous canonical count is
 <=X*L^(-2+c+o(1)), as in the previously audited theorem.

PROOF OF THE PAIR EXTENSION:
Fix h and a tuple of distinct odd prime labels q_1,...,q_d with the
specified product bound. Put x=P-1. The actual edges impose
 x=h modulo q_1,
 2x=q_(j-1) modulo q_j for j>=2.
CRT gives one class x=x_0+M*t, 1<=x_0<=M, and
1<=t<=2X/M for actual starts. The three necessary prime forms are
 P=x+1,       Q=x+h,       g=2x-q_d.
Their positive leading coefficients are M,M,2M and are smaller than
actual prime values. The determinants, up to sign, are
 M*(h-1),       M*(q_d+2),       M*(q_d+2h),
all nonzero. Imprimitive forms have no actual prime solutions since
the values exceed the leading coefficients. Their Delta is bounded by
a fixed power of X uniformly in d,h: only three forms are present.
The fixed-three-form sieve with the general singular-series bound
O(l^3) gives O_epsilon(X*l^3/(M*L^3)). All path primes are <2X.
Sum ordered tuples, dropping distinctness and the product cutoff only
in the positive reciprocal sum. It is at most
 (sum_(q<=2X prime)1/q)^d <=(l+O(1))^d.
Sum d<=D and h<=H. The result is at most
 O_epsilon(H*X*l^3/L^3)*(l+O(1))^D
 =H*X*L^(-3+c+o(1)).
Direct GOOD roots are included by the three-form count already proved
in the cofactor theorem. For h=1 P=Q, so the canonical proof correctly
uses only TWO prime forms and has the stated one-logarithm weaker count.
HOSTILE CHECK: No extra prime condition is counted at h=1. The varying
path length does not enter the Delta bound because the modulus M itself
is bounded; no infinite-rank sieve is invoked here.
NOVELTY: NOT YET AUDITED.
```
