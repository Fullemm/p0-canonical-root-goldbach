---
id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906
logical_id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906
version_id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906@research
kind: canonical-result
run: research
title: "Multigeneration success path product barrier"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2610, line_end: 2685}
metadata: {"stable_id": "MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906", "version_id": "MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2610, "line_end": 2685}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2610, "line_end": 2685}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Multigeneration success path product barrier

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906
STATUS: PROVED.
EXACT STATEMENT:
Fix epsilon,delta in (0,1). Let
 D(X)=floor((1-delta)*loglog X/logloglog X).
For all but o(X/log X) primes P in [X,2X], N=2(P-1), every successful
stopped path P -> q_1 -> ... -> q_d with 1<=d<=D(X) satisfies
 product_(i=1..d) q_i > X^(1-epsilon),
after deleting cycles if necessary. Equivalently no simple successful
path of those lengths has product <=X^(1-epsilon). The root is also
BAD outside o(X/log X) exceptions.
Consequently, if success occurs by depth D, any simple successful path
of length d<=D contains some label >X^((1-epsilon)/d).
This is a growing-depth restriction on actual successful paths with
moving prime labels, not on an alphabet held fixed through an iteration.

PROOF:
A successful stopped path has only BAD vertices before its GOOD endpoint.
Deleting a cycle shortens it and decreases the product of its labels,
so it is enough to count simple paths. The labels q_1,...,q_d are then
distinct odd primes <N/3<2X. Put M=product q_i. The edge conditions are
 P=2 modulo q_1,
 2P=2+q_(i-1) modulo q_i, i=2,...,d.
By CRT they specify exactly one residue class A modulo M. Choose
1<=A<=M and write P=A+M*t. Since M<=X^(1-epsilon)<X, t>=1 and
 t<=2X/M. The final GOOD condition says that
 g=2P-2-q_d
is prime. Sieve the two forms A+M*t and 2A-2-q_d+2M*t.
They have determinant -M*(2+q_d), which is nonzero. If the first
form is imprimitive, any common prime divisor belongs to {q_i};
then a prime P in this class would equal that q_i, impossible since
all path labels are <N/3<P. If the second form is imprimitive, its
odd fixed prime divisor also belongs to {q_i}; but g>2N/3 is larger
than all q_i, also impossible. Thus every contributing class has two
primitive forms. Their Delta is 2M^3*(q_d+2), bounded by a fixed power
of X. Apply the general r=2 sieve consumer, retaining its l^2 singular-
series bound, with z=2X/M>=2X^epsilon. Uniformly in d and the labels
this counts at most
 O_epsilon(X*(loglog X)^2/(M*(log X)^2)).
There is no dependence on d in that constant: there are still only TWO
prime forms, and Delta and the FKL B parameter have uniform bounds.
Let H_X=sum_(q<=2X prime)1/q. Dropping restrictions on distinctness and
on the product only increases the reciprocal sum, so for a given d
 sum_(eligible q_1,...,q_d)1/(q_1*...*q_d)<=H_X^d.
The elementary Euler-product bound proved above gives
 H_X<=loglog X+O(1). Summing d=1,...,D costs at most 2H_X^D for large X.
The total exception bound, relative to X/log X, is therefore
 O_epsilon((loglog X)^2*H_X^D/log X).
Now H_X^D<=(log X)^(1-delta+o(1)), so this tends to zero.
The prime root-complement case adds O(X/(log X)^2) exceptions, already
proved above. This establishes the result and its maximum-label corollary.

HOSTILE CHECK:
No claim is made that a typical complete BFS remains within this product
budget. The theorem constrains successful paths only; large-product
paths remain possible, and are the precise missing class in this count.
The product excludes the initial prime P, which would otherwise make
the condition vacuous. It includes the final GOOD label, and simple
paths are required to use pairwise coprime prime moduli. Cycle deletion
justifies that reduction for the existence question.
This is not an iteration of H1-ALL-BRANCH-INJECTIVE-ESCAPE. It replaces
that mechanism with one simultaneous CRT modulus and a prime-pair
upper bound; it has its own explicit size restriction M<X^(1-epsilon).
At radius two the preceding four-switch theorem also treats large-
product paths except for a negligible band. No analogous full treatment
has been proved here for growing D or even for radius three.
DEPENDENCIES: CRT; the uniform two-form sieve consumer; PNT only to
interpret density among prime P. No prime-tuple lower bound.
RELATION TO GOLDBACH: Gives a quantitative necessary size condition on
shallow successful paths, not an obstruction to all successful paths.
RELATION TO p0: Nonlocal path constraint in the h=1 family. It is not
proved to distinguish p0 from p1 for the same N.
WHAT REMAINS OPEN: Count paths whose label product is large, especially
at three or more generations.
NOVELTY: NOT YET AUDITED.
```
