---
id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER@research
logical_id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER
version_id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER@research
kind: historical-version
run: research
title: "Multigeneration success path product barrier"
status: SUPERSEDED
status_raw: "up to depth"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3327, line_end: 3329}
metadata: {"stable_id": "MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER", "version_id": "MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3327, "line_end": 3329}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3327, "line_end": 3329}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Multigeneration success path product barrier

*Run research - status `SUPERSEDED` (raw: `up to depth`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER-20260906` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
3. MULTIGENERATION-SUCCESS-PATH-PRODUCT-BARRIER: up to depth
   (1-delta)loglog X/logloglog X, successful simple paths must have
   product of nonroot labels >X^(1-epsilon), outside o(X/log X) starts.
```
