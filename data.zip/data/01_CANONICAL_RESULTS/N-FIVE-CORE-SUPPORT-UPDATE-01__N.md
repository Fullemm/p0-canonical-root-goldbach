---
id: N-FIVE-CORE-SUPPORT-UPDATE-01
logical_id: N-FIVE-CORE-SUPPORT-UPDATE-01
version_id: N-FIVE-CORE-SUPPORT-UPDATE-01@N
kind: canonical-result
run: N
title: "N five core support update"
status: FINITE CENSUS
status_raw: "COMPLETE FINITE GRAPH AUDIT"
audit: SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 213, line_end: 290}
metadata: {"stable_id": "N-FIVE-CORE-SUPPORT-UPDATE-01", "version_id": "N-FIVE-CORE-SUPPORT-UPDATE-01@N", "status": "FINITE CENSUS", "scope": "Same five-label support census after M/N exclusions", "assumptions": ["Specified all-N complete-row exclusions applied to support patterns"], "statement": "3566 surviving support graphs (1216 A,1010 B,1340 C), including 102 pure-free.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 213, "line_end": 290}, "depends_on": [], "consequences": [], "does_not_imply": ["No prime realizations", "Multiplicity restrictions are additional"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 213, "line_end": 290}, "proof_provenance": [], "computation": ["hall_five_after_relay_20260908N"], "concepts": ["cycle-cover", "support", "enumeration-box"], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA", "metadata_completeness": "CURATED"}
---

# N five core support update

*Run N - status `FINITE CENSUS` (raw: `COMPLETE FINITE GRAPH AUDIT`) - audit `SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA`*

> Verification: **SOURCE-RECORDED-CODE-AND-OUTPUT; NOT-RERUN-BY-ASTRA**. Metadata coverage: CURATED.

## Current scoped statement

3566 surviving support graphs (1216 A,1010 B,1340 C), including 102 pure-free.

**Assumptions:** Specified all-N complete-row exclusions applied to support patterns.

**Does not imply:** No prime realizations; Multiplicity restrictions are additional.

## Source transcript (historical wording; apply current metadata)

```
N-FIVE-CORE-SUPPORT-UPDATE-01 -- COMPLETE FINITE GRAPH AUDIT
In a five-core type-B witness the b row must contain c. If it is pure,
it has the form N-b=c^delta with delta>=2, and coverage forces both x,y
to be children of c. The new local theorem therefore excludes every
such pure b-row support pattern. Applying this to the complete M census
removes 214 further ordered graphs, after M's previous 88 removals.
The current surviving support counts are
  type A: 1216;
  type B: 1010;
  type C: 1340;
  total: 3566, including 102 graphs with no pure row.
The 214 deletions are distinct from M's 88. Every remaining graph and
its minimal Hall witnesses is saved in
  hall_five_after_relay_20260908N_results.txt.
Multiplicities are not encoded by support graphs: the new restriction
delta=1 on NONPURE common-c b rows is additional arithmetic information,
and was not incorrectly counted as more support-graph deletions.

SAVE POINT N5: the independent certificate, self-contained all-N proof,
and exact five-core support update have all been saved.

CURRENT EXACT COMMON-c RESIDUAL
When N-c contains both x and y, the complete type-B family now reduces to
  N-r=b^e;
  N-x=r^u*b^v;
  N-y=r^w*b^z;
  N-b=c*r^alpha*x^beta;
  N-c=r^lambda*b^mu*x^nu*y.
Here the five labels are distinct odd primes, x<y=max{r,b,x,y},
  e>=2, u>w>=1, 0<=v<z<e;
  alpha,beta>=0, alpha+beta>=1;
  lambda,mu>=0, nu>=1;
  k=r^lambda*b^mu*x^nu<=e-v;
  D=(e-z)u-(e-v)w>=1, r^D<(k/(k-1))^(e-v).
The conditions gamma=0 and exponent_c(N-b)=1 use M and N respectively.
The exponent e is NOT required to be odd in this nonpure residual.
The previous odd-e condition belonged only to the pure-square branch,
which is now entirely excluded.

WHY THE PRESENT ARGUMENT STOPS HERE
The decisive step used the integer M=(N-b)/c^2 to force either J>=3
or N-y>2c^2. With only one factor c in N-b, that dichotomy is unavailable.
One cannot silently reuse c<(k-1)(r+2x), the bound e<=26, or the finite
parameter box for this remaining linear-c family. Controlling the extra
factor r^alpha*x^beta requires a new argument.
In split-parent type-B cases, xy need not divide N-c at all, so the
orientation/cofactor setup also needs separate justification. Types A
and C and their pure-free cases remain separate open branches.

RELATION TO ROOTS AND GOLDBACH
The new theorem bans a complete arithmetic pattern even inside larger
factor graphs. This is stronger in scope than just deleting a handful
of small numerical hosts. It remains a restriction on BAD obstructions,
valid without selecting p_0. It does not prove that all cores have a
matching, that any root rank always escapes, or that Goldbach holds.

ARTIFACTS -- ALL PLAIN TXT IN nowe
goldbach_checkpoint_2026-09-08N.txt -- this updated research state.
goldbach_square_divisor_relay_theorem_2026-09-08N.txt -- full local proof.
hall_pure_square_certificate_20260908N_code.txt / _results.txt -- eleven-pair proof certificate.
hall_square_divisor_relay_20260908N_code.txt / _results.txt -- first complete arithmetic audit.
hall_square_divisor_independent_20260908N_code.txt / _results.txt -- independent seven-case audit.
hall_five_after_relay_20260908N_code.txt / _results.txt -- updated full graph list.

No subagents, PDF output, TeX output or additional library installation
were used. All final verification assertions passed. Historical input
checkpoints and the source master were not edited. The claims are local
to this research programme; no literature-wide priority claim is made.
Input integrity was checked at the end of run N. The master and raw J
hashes still match their pre-research values:
  master_ai.tex:
  84dd17e70f345d3d0679557c9b6932ead1b56be76f462e05dae9b6ea285a90c9
  goldbach_checkpoint_2026-09-07J.txt:
  c37c0901dc12a197185bd54bdd2500aa0cb96f4e22a2502e5efc0be0ad0e7fe6
The self-contained N theorem TXT has SHA256:
  b07864e8ae0de07d8ace8471df09113fb2be18297d0088357b6b373591bef908.
END COMPLETED RESEARCH RUN N -- 2026-09-08
```
