---
id: N-INDEPENDENT-ARITHMETIC-AUDIT-01
logical_id: N-INDEPENDENT-ARITHMETIC-AUDIT-01
version_id: N-INDEPENDENT-ARITHMETIC-AUDIT-01@N
kind: canonical-result
run: N
title: "N independent arithmetic audit"
status: VERIFIED COMPUTATION
status_raw: "PASSED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-AUDIT-PASSED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 194, line_end: 212}
metadata: {"stable_id": "N-INDEPENDENT-ARITHMETIC-AUDIT-01", "version_id": "N-INDEPENDENT-ARITHMETIC-AUDIT-01@N", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 194, "line_end": 212}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 194, "line_end": 212}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# N independent arithmetic audit

*Run N - status `VERIFIED COMPUTATION` (raw: `PASSED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
N-INDEPENDENT-ARITHMETIC-AUDIT-01 -- PASSED
The second implementation used trial division for all prime decisions,
directly enumerated all 13289 bounded triples (e,b,r), and recovered
possible x from x=N modulo r^2, 3<=x<=e. It extracted b before r, reversing
the first implementation's factor order. Exactly seven candidates survived
the r^2 condition, and all had an extra residual factor in N-x:
  (e,b,r,x,N,u,v,residual)
  (5,3,7,5,250,2,0,5)
  (11,3,17,7,177164,2,0,613)
  (17,3,19,13,129140182,2,1,119243)
  (22,3,19,5,31381059628,2,0,86928143)
  (23,3,5,7,94143178832,2,0,3765727153)
  (24,3,5,11,282429536486,2,1,3765727153)
  (25,3,5,23,847288609448,2,2,3765727153)
They agree exactly with the u>=2 subset of the first 108-case certificate.
Every equality N-x=r^u*b^v*residual was checked with integers. Both
methods found zero complete x rows. Therefore the all-N theorem stated
at N4 is now fully established with its exact finite-certification step.
```
