---
id: N-ODD-RESIDUAL-PRODUCT-01
logical_id: N-ODD-RESIDUAL-PRODUCT-01
version_id: N-ODD-RESIDUAL-PRODUCT-01@N
kind: canonical-result
run: N
title: "N odd residual product"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 35, line_end: 51}
metadata: {"stable_id": "N-ODD-RESIDUAL-PRODUCT-01", "version_id": "N-ODD-RESIDUAL-PRODUCT-01@N", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 35, "line_end": 51}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 35, "line_end": 51}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# N odd residual product

*Run N - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
N-ODD-RESIDUAL-PRODUCT-01 -- PROVED
Define the positive odd integers
  P=k*b^(z-v)-(k-1)*r^(u-w),
  Q=k*r^w-(k-1)*b^(e-z).
They are positive by the two exact identities
  r^w*b^v*P=c+(k-1)*x,
  b^z*Q=c+(k-1)*r.
They are odd because k,b,r are odd and k-1 is even. Hence the integer
  J=b^v*P*Q
is positive and odd. Multiplying the identities gives
  J*(N-y)=(c+(k-1)*x)*(c+(k-1)*r).                (N1)
J cannot equal one: its right side is strictly greater than c^2,
whereas N-y=c^2+b-y<c^2 because y>b. Therefore
  J>=3.                                           (N2)
This uses complete rows and the square relation; it is not a heuristic
estimate of the sizes of P,Q.
```
