---
id: N-PURE-SQUARE-EXCLUSION-01
logical_id: N-PURE-SQUARE-EXCLUSION-01
version_id: N-PURE-SQUARE-EXCLUSION-01@N
kind: canonical-result
run: N
title: "N pure square exclusion"
status: PROVED
status_raw: "PROVED, ELEMENTARY WITH AN EXPLICIT TABLE"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 74, line_end: 120}
metadata: {"stable_id": "N-PURE-SQUARE-EXCLUSION-01", "version_id": "N-PURE-SQUARE-EXCLUSION-01@N", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 74, "line_end": 120}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 74, "line_end": 120}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# N pure square exclusion

*Run N - status `PROVED` (raw: `PROVED, ELEMENTARY WITH AN EXPLICIT TABLE`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
N-PURE-SQUARE-EXCLUSION-01 -- PROVED, ELEMENTARY WITH AN EXPLICIT TABLE
The pure-square relay branch is empty for every N.

Normalize N4 by (9/4)^e. The required inequality becomes
  (2/3)*(4/3)^e < (e-1)^2*(1+2e*(2/3)^e)^2.
For e>2 the sequence 2e*(2/3)^e decreases. For e>=8,
  (4/3)*((e-1)/e)^2 >= (4/3)*(7/8)^2 > 1.
Thus the ratio of the left to the right side increases for e>=8.
At e=23 the reverse inequality holds, as the exact integer comparison
  13249474533898474022240256 > 12974697675033235338420300
shows after multiplying N4 by 3*4^23. Hence e<=22, and odd e gives e<=21.

For each odd e<=21 put R_e=floor((3^e-1)/2^e) and
C_e=(e-1)*(R_e+2e). Then r<=R_e and c<C_e. Also c>b: since
c^2=b^e+r-b>b^2-b>(b-1)^2, integer c>=b, and distinctness excludes
c=b. Therefore b^e<N=c^2+b<c^2+c<C_e^2.
This leaves only the following eleven (e,b) pairs. In each row the
interval contains every possible c^2=b^e+r-b even if r is allowed to
be any integer from 3 to R_e. The last column is the FIRST odd square
at or above the lower endpoint and already exceeds the upper endpoint.

 e   b       lower          upper        first odd square
 3   3          27             27                    49
 3   5         123            123                   169
 5   3         243            247                   289
 5   5        3123           3127                  3249
 7   3        2187           2201                  2209
 9   3       19683          19718                 19881
11   3      177147         177230                177241
13   3     1594323        1594514               1595169
15   3    14348907       14349341              14356521
17   3   129140163      129141145             129163225
19   3  1162261467     1162263680            1162332649

At e=21, C_e^2=10116336400<3^21, so no odd prime b is possible.
The complete per-e base bounds and the eleven rows are reproduced in
hall_pure_square_certificate_20260908N_results.txt. They use integer
roots and squares only. No prime search over N and no probable-prime
decision is involved. This is a short finite arithmetic certificate
included explicitly in the proof, not an extrapolated computation. QED.

Together with M's exclusion of delta>=3, this already excludes every
pure N-b=c^delta relay in branch B. A stronger argument below aims to
avoid separating the pure and nonpure b rows.

SAVE POINT N2: the remaining pure-square branch is completely excluded.
```
