---
id: N-PURE-SQUARE-c-BOUND-01
logical_id: N-PURE-SQUARE-c-BOUND-01
version_id: N-PURE-SQUARE-c-BOUND-01@N
kind: canonical-result
run: N
title: "N PURE SQUARE c BOUND"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 52, line_end: 73}
metadata: {"stable_id": "N-PURE-SQUARE-c-BOUND-01", "version_id": "N-PURE-SQUARE-c-BOUND-01@N", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 52, "line_end": 73}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 52, "line_end": 73}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# N PURE SQUARE c BOUND

*Run N - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
N-PURE-SQUARE-c-BOUND-01 -- PROVED
Every hypothetical solution satisfies
  c<(k-1)*(r+2*x)<=(e-1)*(r+2*e).                (N3)

Proof. Since y<N/3, equations N1/N2 imply
  2*c^2 < 2*N < 3*(N-y)
         <= (c+(k-1)*x)*(c+(k-1)*r).
Set A=(k-1)*x and B=(k-1)*r. Thus
  c^2-(A+B)*c-A*B<0.
This upward quadratic has one positive root, strictly below 2*A+B,
because substituting 2*A+B gives 2*A^2>0. Hence c<2*A+B, proving N3.
QED.

Consequently the following exact necessary inequality holds:
  (2/3)*3^e < (e-1)^2*((3/2)^e+2*e)^2.          (N4)
Indeed c^2=b^e+r-b>b^e-b>=(2/3)*b^e>=(2/3)*3^e, while N3 and the
bound r<(3/2)^e give the stated upper bound for c^2.

SAVE POINT N1: the positive odd residual product and the new all-N bound
on c have been saved before determining the complete exponent range.
The exact all-exponent implication of N4 is being checked next.
```
