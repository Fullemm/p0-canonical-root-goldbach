---
id: N-SQUARE-DIVISOR-RELAY-EXCLUSION-01
logical_id: N-SQUARE-DIVISOR-RELAY-EXCLUSION-01
version_id: N-SQUARE-DIVISOR-RELAY-EXCLUSION-01@N
kind: canonical-result
run: N
title: "N square divisor relay exclusion"
status: PROVED
status_raw: "ALL-N PROOF, FIRST EXACT AUDIT PASSED"
audit: SOURCE-ALL-N-PROOF-AND-AUDIT-LOCATED; PARAMETER-REDUCTION-NOT-FULLY-RECHECKED-BY-ASTRA
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 150, line_end: 193}
metadata: {"stable_id": "N-SQUARE-DIVISOR-RELAY-EXCLUSION-01", "version_id": "N-SQUARE-DIVISOR-RELAY-EXCLUSION-01@N", "status": "PROVED", "scope": "All N; local forbidden complete-row block, not just a finite N scan", "assumptions": ["Five distinct odd primes r,b,c,x,y<N", "Complete N-r=b^e, N-x=r^u*b^v, N-y=r^w*b^z", "e>=2,u,w>=1,v,z>=0,u+v,w+z>=2,v+z>=1", "x*y divides N-c; c^2 divides N-b"], "statement": "No such system exists. The proof gives e<=26 and an exhaustive finite parameter box with zero valid complete rows. Additional factors in N-b and N-c are allowed.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 150, "line_end": 193}, "depends_on": ["N-INDEPENDENT-ARITHMETIC-AUDIT-01"], "consequences": [], "does_not_imply": ["Does not exclude every five-core", "Not merely a tested N range"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 150, "line_end": 193}, "proof_provenance": [], "computation": ["hall_square_divisor_relay_20260908N", "hall_square_independent_20260908N"], "concepts": ["pure-row", "closure", "row-degree", "enumeration-box"], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-ALL-N-PROOF-AND-AUDIT-LOCATED; PARAMETER-REDUCTION-NOT-FULLY-RECHECKED-BY-ASTRA", "metadata_completeness": "CURATED"}
---

# N square divisor relay exclusion

*Run N - status `PROVED` (raw: `ALL-N PROOF, FIRST EXACT AUDIT PASSED`) - audit `SOURCE-ALL-N-PROOF-AND-AUDIT-LOCATED; PARAMETER-REDUCTION-NOT-FULLY-RECHECKED-BY-ASTRA`*

> Verification: **SOURCE-ALL-N-PROOF-AND-AUDIT-LOCATED; PARAMETER-REDUCTION-NOT-FULLY-RECHECKED-BY-ASTRA**. Metadata coverage: CURATED.

## Current scoped statement

No such system exists. The proof gives e<=26 and an exhaustive finite parameter box with zero valid complete rows. Additional factors in N-b and N-c are allowed.

**Assumptions:** Five distinct odd primes r,b,c,x,y<N; Complete N-r=b^e, N-x=r^u*b^v, N-y=r^w*b^z; e>=2,u,w>=1,v,z>=0,u+v,w+z>=2,v+z>=1; x*y divides N-c; c^2 divides N-b.

**Does not imply:** Does not exclude every five-core; Not merely a tested N range.

## Source transcript (historical wording; apply current metadata)

```
N-SQUARE-DIVISOR-RELAY-EXCLUSION-01 -- ALL-N PROOF, FIRST EXACT AUDIT PASSED
The normalized N5 inequality is reversed at e=27:
  137370551967459378662586974208
    > 118151915494870852277858423820.
These are respectively 12^27 and
3*26^2*(3^27+81*2^27)*(3^27+27*2^27). Its increasing ratio for e>=8
therefore gives e<=26, without an odd-e assumption.

For every 2<=e<=26, define exact integers
  R_e=floor((3^e-1)/2^e),
  H_e=3*(e-1)^2*(R_e+3e)*(R_e+e).
Every solution must have r<=R_e, N<H_e, b^e<H_e, and x<=e.
The complete arithmetic search through this PROVED parameter box found:
  bounded (e,b,r,x) candidates: 88325;
  with r dividing N-x:            108;
  with N-x exactly r^u*b^v,
       u>=2 and v<=e-2:              0.
No assumption on the other prime factors of N-b or N-c was used in
this search. The 108 last candidates have an exact factor-extraction
certificate in hall_square_divisor_relay_20260908N_results.txt.

Thus, subject to the independent audit now being performed, the proof
excludes the entire square-divisor common-c relay, not just the pure
or delta=2 cases. In the five-core common-c branch the remaining exponent
of c in N-b is exactly ONE, not one or two. Pure relay is impossible.

LOCAL FORM OF THE THEOREM
No even N has distinct odd primes r,b,c,x,y<N with
  N-r=b^e,
  N-x=r^u*b^v,
  N-y=r^w*b^z,
  x*y dividing N-c,
  c^2 dividing N-b,
where e>=2, u,w>=1, v,z>=0, u+v,w+z>=2 and v+z>=1.
The three equalities must be COMPLETE. Arbitrary additional factors
in N-b and N-c are permitted. To apply the proof, all five labels are
low because each has a specified incoming composite row. The unique
smaller-parent lemma places max{r,b,x,y} in {x,y}; rename it y.
The determinant and cofactor proof only needs x*y|N-c, not full support
of that row. This verifies the stated local scope of the theorem.

SAVE POINT N4: the complete parameter reduction and the first successful
all-N square-divisor exclusion are saved with a reproducible certificate.
```
