---
id: N-SQUARE-DIVISOR-RELAY-HEIGHT-01
logical_id: N-SQUARE-DIVISOR-RELAY-HEIGHT-01
version_id: N-SQUARE-DIVISOR-RELAY-HEIGHT-01@N
kind: canonical-result
run: N
title: "N square divisor relay height"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08N.txt", line: 121, line_end: 149}
metadata: {"stable_id": "N-SQUARE-DIVISOR-RELAY-HEIGHT-01", "version_id": "N-SQUARE-DIVISOR-RELAY-HEIGHT-01@N", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 121, "line_end": 149}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08N.txt", "line": 121, "line_end": 149}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# N square divisor relay height

*Run N - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
N-SQUARE-DIVISOR-RELAY-HEIGHT-01 -- PROVED
The same method extends to ANY common-c relay with c^2 dividing N-b,
even if N-b has additional prime factors. Put
  M=(N-b)/c^2, an odd positive integer.
The three narrow complete rows and x*y|N-c still give positive odd P,Q
and the exact identity
  J*(N-y)=(c+(k-1)*x)*(c+(k-1)*r), J=b^v*P*Q.
If M=1, J>=3 as proved above. If M>=3, J>=1 and
N-y>(2/3)*N>(2/3)*M*c^2>=2*c^2. In either case the right side is >2c^2.
Thus the SAME bound c<(k-1)*(r+2x) holds.

Since J>=1 and N<(3/2)*(N-y), setting A=(k-1)x, B=(k-1)r gives
  N < (3/2)*(c+A)*(c+B)
    < 3*(3A+B)*(A+B)
    = 3*(k-1)^2*(r+3x)*(r+x)
    < 3*(e-1)^2*((3/2)^e+3e)*((3/2)^e+e).       (N5)
Consequently b^e<N is bounded by the right side, without any bound on
the extra factor M or its prime exponents.

Dividing 3^e<N by (9/4)^e gives the necessary inequality
  (4/3)^e < 3*(e-1)^2*(1+3e*(2/3)^e)*(1+e*(2/3)^e).
The ratio again increases for e>=8 by the same monotonicity argument.
Its endpoint at e=27 will be checked exactly next; if the reverse
inequality holds there, it proves e<=26 for the WHOLE square-divisor
subbranch. This new implication does not assume e is odd.

SAVE POINT N3: the square-divisor relay height bound is saved before
its complete arithmetic audit. The extra factors of N-b were retained.
```
