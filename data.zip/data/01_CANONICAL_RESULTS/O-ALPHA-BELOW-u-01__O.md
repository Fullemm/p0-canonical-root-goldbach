---
id: O-ALPHA-BELOW-u-01
logical_id: O-ALPHA-BELOW-u-01
version_id: O-ALPHA-BELOW-u-01@O
kind: canonical-result
run: O
title: "O ALPHA BELOW u"
status: PROVED
status_raw: "PROVED, WHOLE COMMON-c RESIDUAL"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 19, line_end: 38}
metadata: {"stable_id": "O-ALPHA-BELOW-u-01", "version_id": "O-ALPHA-BELOW-u-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 19, "line_end": 38}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 19, "line_end": 38}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O ALPHA BELOW u

*Run O - status `PROVED` (raw: `PROVED, WHOLE COMMON-c RESIDUAL`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-ALPHA-BELOW-u-01 -- PROVED, WHOLE COMMON-c RESIDUAL
Every solution has
  alpha<u,
  2*r^alpha divides b-x,                         (O1)
  r^alpha <= |b-x|/2.

Proof. If alpha>=u, r^u divides both N-x and N-b, hence 2*r^u divides
the nonzero even integer b-x. Also b^v divides r-x because v<e and
N-x=b^e+r-x; thus 2*b^v divides r-x, including v=0. Consequently
  N-x=r^u*b^v <= |b-x|*|r-x|/4
      < (b+e)*((3/2)^e+e)/4
      <= b*e*(3/2)^e/2.
Here b+e<=b*e and e<=(3/2)^e for e>=3. On the other hand
  b*e*(3/2)^e/2 < (2/3)*b^e,
because b>=3 and 9e<4*2^e for every e>=3. The latter holds at e=3,
27<32, and 2^e/e increases thereafter. This contradicts
N-x>2N/3>(2/3)*b^e. Therefore alpha<u. Both N-x and N-b now are
divisible by r^alpha; their difference yields the second assertion,
using odd r and the even difference b-x. QED.
```
