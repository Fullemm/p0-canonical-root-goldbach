---
id: O-FIXED-beta-EFFECTIVE-FINITENESS-01
logical_id: O-FIXED-beta-EFFECTIVE-FINITENESS-01
version_id: O-FIXED-beta-EFFECTIVE-FINITENESS-01@O
kind: canonical-result
run: O
title: "O FIXED beta EFFECTIVE FINITENESS"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 129, line_end: 164}
metadata: {"stable_id": "O-FIXED-beta-EFFECTIVE-FINITENESS-01", "version_id": "O-FIXED-beta-EFFECTIVE-FINITENESS-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 129, "line_end": 164}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 129, "line_end": 164}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O FIXED beta EFFECTIVE FINITENESS

*Run O - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-FIXED-beta-EFFECTIVE-FINITENESS-01 -- PROVED
For any fixed nonnegative beta the entire common-c residual has an
explicit finite all-N parameter box. This is finiteness at fixed beta,
not a proof that beta is bounded. The moving labels are bounded as well.

Put R=r^alpha and A=R*x^beta. By O1, write b=x+R*j with j a nonzero
even integer. Since b*h=R*x^beta*(k-1)+1,
  R*(x^beta*(k-1)-j*h)=x*h-1.
The bracket is a positive even integer. Just as before, this gives
  b <= x*(R*x^beta*(k-1)+1)/(2R+1)
    <= (k-1)*x^(beta+1)/2 < e^(beta+2)/2.        (O6)
Also
  h < [e^beta*(e-1)*(e+3)+2]/6 < e^(beta+2)/3.

If alpha>=1, then r<=R<=|b-x|/2<e^(beta+2)/4. Substituting these
bounds in O4 gives
  N < e^(4*beta+9)/192,
  192*3^e < e^(4*beta+9).                        (O7)
For every fixed beta the last inequality bounds e effectively: for
q=4*beta+9, the ratio 3^e/e^q increases for e>=q and tends to infinity.
This follows from (1+1/e)^q<3 for e>=q; it gives an explicit terminating
integer search for an endpoint, after which monotonicity proves exclusion.

If alpha=0, then beta>=1, A=x^beta and L=A*(k-1)+1<A*k<=e^(beta+1).
Using the exact O4 expression with h=L/b gives instead
  N < (3/8)*L^2*x*r/b <= L^2*x*r/8
    < e^(2*beta+3)*(3/2)^e/8,
  8*2^e < e^(2*beta+3).                          (O8)
For fixed beta this again bounds e effectively. With q=2*beta+3, the
ratio 2^e/e^q increases for e>=2q, since (1+1/e)^q<sqrt(3)<2 there,
and tends to infinity. Once e is bounded, O8 bounds N and hence every
prime label. No external fixed-alphabet S-unit theorem is being used.

This argument gives a principled next step: decide beta=1 in its complete
all-N box, rather than increasing a cutoff on N.
```
