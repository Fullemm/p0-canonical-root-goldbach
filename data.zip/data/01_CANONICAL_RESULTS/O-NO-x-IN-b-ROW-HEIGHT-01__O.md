---
id: O-NO-x-IN-b-ROW-HEIGHT-01
logical_id: O-NO-x-IN-b-ROW-HEIGHT-01
version_id: O-NO-x-IN-b-ROW-HEIGHT-01@O
kind: canonical-result
run: O
title: "O NO x IN b ROW HEIGHT"
status: PROVED
status_raw: "PROVED PARAMETER BOUND"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 64, line_end: 97}
metadata: {"stable_id": "O-NO-x-IN-b-ROW-HEIGHT-01", "version_id": "O-NO-x-IN-b-ROW-HEIGHT-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 64, "line_end": 97}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 64, "line_end": 97}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O NO x IN b ROW HEIGHT

*Run O - status `PROVED` (raw: `PROVED PARAMETER BOUND`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-NO-x-IN-b-ROW-HEIGHT-01 -- PROVED PARAMETER BOUND
In the beta=0 branch, A=R=r^alpha with alpha>=1. Then
  b<=x*(k-1)/2 <= e*(e-1)/2,
  r<=R<e^2/4,
  h<e^2/3,
  N<e^9/192.                                    (O5)
In particular e<=19.

Proof. By O1, b=x+R*j for a nonzero even integer j, allowed to be
negative. From b*h=R*(k-1)+1 one obtains
  R*(k-1-j*h)=x*h-1.
The right side is positive. The factor k-1-j*h is a positive EVEN
integer, hence at least two. Therefore 2R<=x*h-1, giving
  b <= x*(R*(k-1)+1)/(2R+1) <= x*(k-1)/2,
where the last inequality uses k>=3. This proves the b bound without
assuming the sign of b-x. Since x<=e and e>=3,
  R<=|b-x|/2 < max(b,x)/2 <= e*(e-1)/4 < e^2/4.
Also
  h=(R*(k-1)+1)/b
   < (e-1)/2 + e*(e-1)/(2b) + 1/b
   <= (e^2+2e-1)/6 < e^2/3.
Here R< (b+x)/2, b>=3 and x<=e were used. Inserting these bounds and
b<e^2/2, x<=e, r<e^2/4 into O4 gives N<e^9/192.

Since 3^e<N, necessarily 192*3^e<e^9. This inequality fails at e=20:
  192*3^20=669462604992 > 20^9=512000000000.
The ratio 3^e/e^9 increases for e>=8, since 3*(8/9)^9>1. Thus checking
the exact e=20 endpoint proves e<=19. The monotonicity endpoint is
3*8^9=402653184 > 9^9=387420489. The complete finite parameter box
is treated next.

SAVE POINT O2: beta=0 is reduced to a proved polynomial height bound,
without bounding c in advance or importing the square-divisor bound.
```
