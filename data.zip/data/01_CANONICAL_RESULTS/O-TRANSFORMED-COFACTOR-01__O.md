---
id: O-TRANSFORMED-COFACTOR-01
logical_id: O-TRANSFORMED-COFACTOR-01
version_id: O-TRANSFORMED-COFACTOR-01@O
kind: canonical-result
run: O
title: "O transformed cofactor"
status: PROVED
status_raw: "PROVED, WHOLE COMMON-c RESIDUAL"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 39, line_end: 63}
metadata: {"stable_id": "O-TRANSFORMED-COFACTOR-01", "version_id": "O-TRANSFORMED-COFACTOR-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 39, "line_end": 63}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 39, "line_end": 63}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O transformed cofactor

*Run O - status `PROVED` (raw: `PROVED, WHOLE COMMON-c RESIDUAL`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-TRANSFORMED-COFACTOR-01 -- PROVED, WHOLE COMMON-c RESIDUAL
Put A=r^alpha*x^beta and L=A*(k-1)+1. Substituting c=(N-b)/A in
N-c=k*y gives the exact identity
  A*k*(N-y)=L*N-b.                               (O2)
Since b|(N-y), N=b^e+r and b does not divide r, reduction modulo b
shows b|L. Write L=b*h, with h a positive odd integer.

Subtract L*(N-x) and L*(N-r), respectively, from O2:
  r^w*b^v*P = L*x-b=b*(h*x-1),
  b^z*Q = L*r-b=b*(h*r-1),                       (O3)
where
  P=A*k*b^(z-v)-L*r^(u-w),
  Q=A*k*r^w-L*b^(e-z).
Both P,Q are positive EVEN integers, since the right sides are positive
and each bracket is the difference of odd integers. Further b divides
P, as z-v>=1 and b|L. Hence P>=2b and Q>=2. It follows that
  r^w*b^v <= (h*x-1)/2,
  b^z <= b*(h*r-1)/2,
  N < (3/8)*b*h^2*x*r.                           (O4)
The last inequality uses N<(3/2)*(N-y) and b^v>=1. No estimate or
factor restriction on P,Q was omitted. QED.

SAVE POINT O1: the r-adic bound and the transformed positive-even
cofactor identities are saved before applying them to beta=0.
```
