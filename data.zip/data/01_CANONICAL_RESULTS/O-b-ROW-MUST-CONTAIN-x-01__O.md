---
id: O-b-ROW-MUST-CONTAIN-x-01
logical_id: O-b-ROW-MUST-CONTAIN-x-01
version_id: O-b-ROW-MUST-CONTAIN-x-01@O
kind: canonical-result
run: O
title: "O b ROW MUST CONTAIN x"
status: PROVED
status_raw: "PROVED, ALL N, SHORT EXACT CERTIFICATE"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 98, line_end: 128}
metadata: {"stable_id": "O-b-ROW-MUST-CONTAIN-x-01", "version_id": "O-b-ROW-MUST-CONTAIN-x-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 98, "line_end": 128}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 98, "line_end": 128}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O b ROW MUST CONTAIN x

*Run O - status `PROVED` (raw: `PROVED, ALL N, SHORT EXACT CERTIFICATE`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-b-ROW-MUST-CONTAIN-x-01 -- PROVED, ALL N, SHORT EXACT CERTIFICATE
The beta=0 branch is impossible. Thus beta>=1 in the common-c linear
residual; the complete b row must contain x as well as c.

Proof. The polynomial height bound and e<=19 leave the following
possible prime b values, obtained from the exact inequality
  192*b^e<e^9:
  e=3: b=3;
  e=4,...,9: b in {3,5};
  e=10,...,19: b=3.
All endpoints can be checked with integer powers; a complete per-e
certificate is produced by the small verification script below.

If b=5, then e<=9 and the prime x<=e is distinct from b, so x=3 or 7.
But 2*r^alpha divides b-x and r^alpha>=3, whereas |b-x|=2. Impossible.
If b=3, the prime x<=19 is one of 5,7,11,13,17,19. The positive odd
prime power R=r^alpha, with r!=3 and alpha>=1, must divide
  |b-x|/2 = 1,2,4,5,7,8, respectively.
Only two cases remain:
  (b,x,r,alpha)=(3,13,5,1) or (3,17,7,1).
Because x divides k and x<=k<=e<=19, respectively k=13 or k=17.
But the necessary congruence b|r^alpha*(k-1)+1 now requires
  3|61 or 3|113,
both false. This excludes every beta=0 solution for every N. QED.

No prime or N search is part of this final contradiction. The finite
certificate consists of elementary integer-power bounds and the two
displayed congruences. The excluded exponent range was proved first.

SAVE POINT O3: the whole missing-x branch is excluded; beta>=1 is proved.
```
