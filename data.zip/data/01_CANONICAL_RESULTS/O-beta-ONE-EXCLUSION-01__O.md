---
id: O-beta-ONE-EXCLUSION-01
logical_id: O-beta-ONE-EXCLUSION-01
version_id: O-beta-ONE-EXCLUSION-01@O
kind: canonical-result
run: O
title: "O beta ONE EXCLUSION"
status: PROVED
status_raw: "PROVED, ALL N, EXACT SHORT CERTIFICATES"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 175, line_end: 210}
metadata: {"stable_id": "O-beta-ONE-EXCLUSION-01", "version_id": "O-beta-ONE-EXCLUSION-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 175, "line_end": 210}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 175, "line_end": 210}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O beta ONE EXCLUSION

*Run O - status `PROVED` (raw: `PROVED, ALL N, EXACT SHORT CERTIFICATES`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-beta-ONE-EXCLUSION-01 -- PROVED, ALL N, EXACT SHORT CERTIFICATES
There is no beta=1 solution. Together with O3, this proves beta>=2.

For alpha>=1, enumerate the proved e<=38 box with
192*b^e<e^13, x prime <=e, R=r^alpha dividing |b-x|/2, x|k, k odd <=e,
and b|R*x*(k-1)+1. Only the following four cofactor tuples remain:
  (b,x,r,alpha,k)=(3,17,7,1,17), (3,29,13,1,29),
                  (5,19,7,1,19), (7,13,3,1,13).
In every case b does not divide r-x, so v=0 and N-x=r^u.
The first two cases fail modulo 3: r^u=1 modulo 3 but N-x=2 modulo 3.
The third has 7^u=5^e-12. Modulo 4, u must be even; modulo 5 an even
power of 7 is 1 or 4, whereas the right side is 3. The fourth has
3^u=7^e-10: modulo 8 the left side is 1 or 3, the right side 5 or 7.
Thus all four cases are impossible, independently of their remaining
exponents. The finite cofactor enumeration and all residues are included
in hall_beta_one_certificate_20260908O_code.txt / _results.txt.

For alpha=0, e<=17 and 8*b^e<e^5*R_e, R_e=floor((3^e-1)/2^e).
The base box permits b=3 except that b=5 is also possible at e=4.
Imposing x|k, k odd <=e and b|x*(k-1)+1 leaves only
  (b,x,k)=(3,5,5), (3,11,11), (3,17,17).
These are excluded without factoring any large number:
* x=5: L=21, so O4 gives N<2205*r/8. As r<(5/4)^e and N>3^e,
  necessarily 8*(12/5)^e<2205. At e=7 the reverse inequality holds,
  8*12^7>2205*5^7, and it continues to hold for every larger e.
  Thus e<=6; but then r<(5/4)^6<7, with r an odd prime distinct from
  b=3 and x=5, which is impossible.
* x=11: e<=17 gives r<(11/10)^17<7, so r=5. The exact O4 bound gives
  N<111^2*11*5/8<3^11, contrary to N>3^e and e>=k=11.
* x=17: e=17 and r<(17/16)^17<3, impossible for an odd prime r.
All endpoint comparisons were checked with integer powers. QED.

SAVE POINT O5: beta=1 is excluded for ALL N. The common-c b row must
contain x^2, in addition to its single factor c. The bounds e<=38 and
e<=17 were proved only under beta=1 and do not apply to beta>=2.
```
