---
id: O-beta-ONE-PARAMETER-BOUND-01
logical_id: O-beta-ONE-PARAMETER-BOUND-01
version_id: O-beta-ONE-PARAMETER-BOUND-01@O
kind: canonical-result
run: O
title: "O beta ONE PARAMETER BOUND"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08O.txt", line: 165, line_end: 174}
metadata: {"stable_id": "O-beta-ONE-PARAMETER-BOUND-01", "version_id": "O-beta-ONE-PARAMETER-BOUND-01@O", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 165, "line_end": 174}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08O.txt", "line": 165, "line_end": 174}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# O beta ONE PARAMETER BOUND

*Run O - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
O-beta-ONE-PARAMETER-BOUND-01 -- PROVED
For beta=1, O7 gives e<=38 in the alpha>=1 branch. The exact endpoint
192*3^39>39^13 and monotonicity for e>=13 certify this bound.
For beta=1, O8 gives e<=17 in the alpha=0 branch, since
  8*2^18=2097152 > 18^5=1889568,
and 2^e/e^5 increases for e>=8.

SAVE POINT O4: both beta=1 branches now have proved all-N finite boxes.
Their final cofactor and congruence certificates are being checked next.
```
