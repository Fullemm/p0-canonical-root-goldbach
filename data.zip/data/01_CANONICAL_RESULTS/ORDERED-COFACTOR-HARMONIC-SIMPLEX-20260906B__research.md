---
id: ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B
logical_id: ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B
version_id: ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B@research
kind: canonical-result
run: research
title: "Ordered cofactor harmonic simplex"
status: PROVED
status_raw: "PROVED; elementary counting lemma."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4314, line_end: 4336}
metadata: {"stable_id": "ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B", "version_id": "ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4314, "line_end": 4336}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4314, "line_end": 4336}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Ordered cofactor harmonic simplex

*Run research - status `PROVED` (raw: `PROVED; elementary counting lemma.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: ORDERED-COFACTOR-HARMONIC-SIMPLEX-20260906B
STATUS: PROVED; elementary counting lemma.
EXACT STATEMENT:
For every integer d>=1 and Y>=1,
 sum_(a_1,...,a_d>=3; product a_j<=Y) 1/(product a_j)
 <= (max(log Y-d*log 2,0))^d/d! <= (log Y)^d/d!
(the last expression used for Y>=1). Restricting the a_j to odd
integers preserves the bound. The tuples are ORDERED; their factorial
saving is not an unjustified division by permutations.
PROOF:
For each integer a>=3,
 1/a <= integral_(a-1)^a dt/t.
The boxes product_j[a_j-1,a_j] have disjoint interiors. If product a_j
is at most Y, every point of its box has all coordinates >=2 and
product coordinates <=Y. Integrate product_j dt_j/t_j over the union
of boxes, then over this larger region. In variables u_j=log t_j-log2
it is the simplex u_j>=0, sum u_j<=log Y-d log2. Its volume is exactly
the claimed expression. A negative right endpoint gives an empty
region. This proves the bound with no symmetry assumption.
IMPLICATION: Cancels the factorial cost of sieving d+O(1) prime forms
when summing over all short-product cofactor sequences.
NOVELTY: NOT YET AUDITED; standard volume method.
```
