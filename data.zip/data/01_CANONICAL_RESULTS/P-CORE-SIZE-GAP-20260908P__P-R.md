---
id: P-CORE-SIZE-GAP-20260908P@P-R
logical_id: P-CORE-SIZE-GAP-20260908P
version_id: P-CORE-SIZE-GAP-20260908P@P-R
kind: historical-version
run: P-R
title: "P6.  CORE-SIZE GAP"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION / SCOPE.  (Restated.)"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 442, line_end: 451}
metadata: {"stable_id": "P-CORE-SIZE-GAP-20260908P", "version_id": "P-CORE-SIZE-GAP-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 442, "line_end": 451}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-CORE-SIZE-GAP-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 442, "line_end": 451}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 958, style: ID-TABLE}
---

# P6.  CORE-SIZE GAP

*Run P-R - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION / SCOPE.  (Restated.)`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-CORE-SIZE-GAP-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P6.  CORE-SIZE GAP                     ID: P-CORE-SIZE-GAP-20260908P
     STATUS: VERIFIED COMPUTATION / SCOPE.  (Restated.)
================================================================================
The observed core sizes over all known hosts are 2, 8, 10, 14, 21, 28.  No core
of size 3, 4, 5, 6 or 7 has been exhibited, and E1 proves none of size 3 exists
for even N <= 1e12.  Runs L, M, N, O analyse sizes 4 and 5.  This is a priority
observation, not a refutation: the K--O theorems are correct, and nothing here
shows that a core of size 4 or 5 cannot exist for some larger N.

================================================================================
```
