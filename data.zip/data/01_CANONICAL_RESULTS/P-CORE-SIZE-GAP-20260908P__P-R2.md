---
id: P-CORE-SIZE-GAP-20260908P
logical_id: P-CORE-SIZE-GAP-20260908P
version_id: P-CORE-SIZE-GAP-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P6.  CORE-SIZE GAP"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION / SCOPE.  (Restated.)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 521, line_end: 530}
metadata: {"stable_id": "P-CORE-SIZE-GAP-20260908P", "version_id": "P-CORE-SIZE-GAP-20260908P@P-R2", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 521, "line_end": 530}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-CORE-SIZE-GAP-20260908P@P", "P-CORE-SIZE-GAP-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 521, "line_end": 530}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1085, style: ID-TABLE}
---

# P6.  CORE-SIZE GAP

*Run P-R2 - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION / SCOPE.  (Restated.)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
P6.  CORE-SIZE GAP                     ID: P-CORE-SIZE-GAP-20260908P
     STATUS: VERIFIED COMPUTATION / SCOPE.  (Restated.)
================================================================================
The observed core sizes over all known hosts are 2, 8, 10, 14, 21, 28.  No core
of size 3, 4, 5, 6 or 7 has been exhibited, and E1 proves none of size 3 exists
for even N <= 1e12.  Runs L, M, N, O analyse sizes 4 and 5.  This is a priority
observation, not a refutation: the K--O theorems are correct, and nothing here
shows that a core of size 4 or 5 cannot exist for some larger N.

================================================================================
```
