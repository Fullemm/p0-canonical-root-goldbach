---
id: P-CORE-SIZE-GAP-20260908P@P
logical_id: P-CORE-SIZE-GAP-20260908P
version_id: P-CORE-SIZE-GAP-20260908P@P
kind: historical-version
run: P
title: "P6.  REGIME MISMATCH"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION / SCOPE"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 420, line_end: 445}
metadata: {"stable_id": "P-CORE-SIZE-GAP-20260908P", "version_id": "P-CORE-SIZE-GAP-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 420, "line_end": 445}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-CORE-SIZE-GAP-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 420, "line_end": 445}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 781, style: ID-TABLE}
---

# P6.  REGIME MISMATCH

*Run P - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION / SCOPE`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-CORE-SIZE-GAP-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P6.  REGIME MISMATCH                     ID: P-CORE-SIZE-GAP-20260908P
     STATUS: VERIFIED COMPUTATION / SCOPE
--------------------------------------------------------------------------------
The observed core sizes over all known hosts are
        2, 8, 10, 14, 21, 28.
No core of size 3, 4, 5, 6 or 7 has ever been exhibited, and section 4 proves
none of size 3 exists for any even N <= 1e12.  Runs L, M, N, O analyse sizes 4
and 5 exclusively.  Therefore, even a complete classification of Hall defects at
size five would not constrain a single known host, and the branch-by-branch
enumeration (3566 surviving support graphs at s = 5 after N) grows with s while
the arithmetic regime of the real hosts starts at s = 8.  This is a scope
observation, not a proof that the K--O results are wrong; they are correct and
they are about an empirically vacant size range.

================================================================================
4.  COMPUTATIONAL EXPERIMENTS
================================================================================

Environment: Python 3 + sympy 1.14 (exact integers throughout) for the
verifications; C compiled with gcc -O3, 64-bit and __int128 arithmetic, for the
searches.  Primality: deterministic Miller-Rabin with the 7-base set
{2, 325, 9375, 28178, 450775, 9780504, 1795265022}, valid for all n < 2^64.
No floating point enters any arithmetic decision (doubles are used only as a
first guess for integer roots, then corrected exactly).

--------------------------------------------------------------------------------
```
