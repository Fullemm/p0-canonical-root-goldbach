---
id: P-CYCLE-COVER-EMPTY-20260908P
logical_id: P-CYCLE-COVER-EMPTY-20260908P
version_id: P-CYCLE-COVER-EMPTY-20260908P@P
kind: canonical-result
run: P
title: "P cycle cover empty"
status: SUPERSEDED
status_raw: "PROVED (a) + VERIFIED COMPUTATION (b,c)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 367, line_end: 419}
metadata: {"stable_id": "P-CYCLE-COVER-EMPTY-20260908P", "version_id": "P-CYCLE-COVER-EMPTY-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 367, "line_end": 419}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-CYCLE-COVER-SCOPE-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 367, "line_end": 419}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-CYCLE-COVER-SCOPE-R-20260908P
supersession_reason: "wrong quantifier: computed by maximising over cycle covers where the statement required a minimum; conclusion also over-general (claimed the whole exit route empty)"
supersession_witness: "N=6142 admits the involution {3,877},{5,17},{7,409},{13,227},{19,157} with cycle products 2631, 85, 2863, 2951, 2983 -- every one below N = 6142."
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 780, style: ID-TABLE}
---

# P cycle cover empty

*Run P - status `SUPERSEDED` (raw: `PROVED (a) + VERIFIED COMPUTATION (b,c)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-CYCLE-COVER-SCOPE-R-20260908P` (run `P-R2`).
>
> **Defect:** wrong quantifier: computed by maximising over cycle covers where the statement required a minimum; conclusion also over-general (claimed the whole exit route empty)
>
> **Witness:** N=6142 admits the involution {3,877},{5,17},{7,409},{13,227},{19,157} with cycle products 2631, 85, 2863, 2951, 2983 -- every one below N = 6142.

## Source transcript (historical wording; apply current metadata)

```
     ID: P-CYCLE-COVER-EMPTY-20260908P    STATUS: PROVED (a) + VERIFIED COMPUTATION (b,c)
--------------------------------------------------------------------------------
CONTEXT.  D6 (thm:postJ-cycle) says a 2-cycle {p,q} in Gamma_N with p,q < N/3
satisfies pq | N-p-q and hence pq < N.  D8 and the whole K--O programme aim at
"every core has a perfect matching", i.e. a cycle cover, and the master's own
closing warning names "additional arithmetic of the matched cycle cover" as the
required exit.  The only known arithmetic of a cycle is the size bound D6.

(a) WHY D6 IS ISOLATED (proved).  For a cycle q_1 -> q_2 -> ... -> q_L -> q_1
(meaning q_{i+1} | N - q_i) the congruences are N = q_i mod q_{i+1}, which by
CRT determine N modulo M_C = prod q_i.  For L = 2 the residue is exactly
q_1 + q_2, a number far below M_C; since N = q_1 + q_2 would make both labels
GOOD, N > q_1+q_2 forces M_C <= N - q_1 - q_2 < N.  For L >= 3 no such small
residue exists: the CRT residue of a generic triple is of size comparable to
M_C itself.  Certificates (exact CRT, this run):
     {199,149,233}: N = 988069  mod 6908683   (sum = 581)
     {331,109,113}: N = 505219  mod 4076927   (sum = 553)
     {397,281,131}: N = 1653239 mod 14613967  (sum = 809)
     {227,307,109}: N = 6858914 mod 7596101   (sum = 643)
     {271,167,107}: N = 4482718 mod 4842499   (sum = 545)
     {127,241,239}: N = 6868145 mod 7315073   (sum = 607)
So the mechanism behind D6 does not exist for L >= 3.

(b) EXPLICIT COUNTEREXAMPLES (verified computation).  Searching every even N in
[100000, 100400) for cycles inside the composite-complement subgraph on primes
< N/3 (all labels active, all rows composite):
     L = 2:  324 cycles,  max (prod q_i)/N = 0.498   at N=100348, {199,251}
     L = 3:  595 cycles,  max (prod q_i)/N = 9.374e4 at N=100224, {1613,3181,1831}
     L = 4:  875 cycles,  max (prod q_i)/N = 3.367e9 at N=100362,
                                             {467,19979,2593,13967}
Thus the L = 2 bound is sharp and genuinely isolated: at L = 3 the product
already exceeds N by five orders of magnitude.

(c) ON THE REAL CORES (verified computation).  For each of the six hosts, all
perfect matchings of the core were enumerated, decomposed into cycles, and the
maximum cycle product recorded:
     N=128   |core|=8   1 matching   max cycle product 2.3023e4      > N
     N=1718  |core|=28  6 matchings  max cycle product 1.2592e46     > N
     N=1862  |core|=21  6 matchings  max cycle product 3.5070e24     > N
     N=1928  |core|=14  7 matchings  max cycle product 1.2402e23     > N
     N=2200  |core|=2   1 matching   max cycle product 39            <= N
     N=6142  |core|=10  6 matchings  max cycle product 1.8894e12     > N
Cycle-length profiles: [4,4], [25,3], [13,3,5], [14], [2], [8,2].  Real cores
are essentially single long cycles; the only core whose cover obeys a product
bound is the two-element one.

CONCLUSION.  A theorem "every core has a perfect matching" would yield a cycle
cover whose cycles carry no product, height or size constraint whatsoever.  The
master's warning is upgraded here from a caution to a verified obstruction: the
stated exit route of the K--O programme is empty.  Any future use of a matching
must extract something other than cycle size -- and nothing else is known.

--------------------------------------------------------------------------------
```
