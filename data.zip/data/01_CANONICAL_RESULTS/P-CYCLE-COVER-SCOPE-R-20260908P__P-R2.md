---
id: P-CYCLE-COVER-SCOPE-R-20260908P
logical_id: P-CYCLE-COVER-SCOPE-R-20260908P
version_id: P-CYCLE-COVER-SCOPE-R-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P cycle cover scope r"
status: MIXED
status_raw: "(a) PROVED, (b) VERIFIED COMPUTATION, (c) PROVED + VERIFIED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 441, line_end: 520}
metadata: {"stable_id": "P-CYCLE-COVER-SCOPE-R-20260908P", "version_id": "P-CYCLE-COVER-SCOPE-R-20260908P@P-R2", "status": "MIXED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 441, "line_end": 520}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-CYCLE-COVER-EMPTY-20260908P", "P-CYCLE-COVER-SCOPE-R-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 441, "line_end": 520}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1084, style: ID-TABLE}
---

# P cycle cover scope r

*Run P-R2 - status `MIXED` (raw: `(a) PROVED, (b) VERIFIED COMPUTATION, (c) PROVED + VERIFIED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
     ID: P-CYCLE-COVER-SCOPE-R-20260908P
     STATUS: (a) PROVED, (b) VERIFIED COMPUTATION, (c) PROVED + VERIFIED
     This REPLACES P5 of checkpoint P, whose part (c) was computed with the
     wrong quantifier and whose conclusion was over-general.
================================================================================
CONTEXT.  D6 says a 2-cycle {p,q} with p,q < N/3 satisfies pq | N-p-q, hence
pq < N.  The K--O programme aims at "every core has a perfect matching", i.e. a
cycle cover, and the master's closing warning names "additional arithmetic of
the matched cycle cover" as the required exit.

(a) THE LONGER-CYCLE ANALOGUE OF D6 IS FALSE.  KILLED CLAIM, stated precisely:
       for a cycle q_1 -> q_2 -> ... -> q_L -> q_1 in Gamma_N with all labels
       active, below N/3, and all rows composite, one has prod q_i < N.
    This is TRUE for L = 2 (D6) and FALSE for L >= 3.
    WHY D6 IS SPECIAL (proof).  The cycle congruences are N = q_i mod q_{i+1},
    which by CRT determine N modulo M_C = prod q_i.  For L = 2 the residue is
    exactly q_1 + q_2, far below M_C; since N = q_1 + q_2 would make both labels
    GOOD, N exceeds that residue and hence M_C <= N - q_1 - q_2 < N.  For L >= 3
    the CRT residue is generic and no such argument exists.  Exact certificates
    (CRT computed here):
       {199,149,233}: N = 988069  mod 6908683   (sum 581)
       {331,109,113}: N = 505219  mod 4076927   (sum 553)
       {397,281,131}: N = 1653239 mod 14613967  (sum 809)
       {227,307,109}: N = 6858914 mod 7596101   (sum 643)
       {271,167,107}: N = 4482718 mod 4842499   (sum 545)
       {127,241,239}: N = 6868145 mod 7315073   (sum 607)

(b) EXPLICIT COUNTEREXAMPLES (verified computation).  Every even N in
    [100000, 100400), vertices = primes p < N/3 with p not dividing N and N-p
    composite, edges p -> q iff q | N-p; all cycles of length 2, 3, 4:
       L = 2:  324 cycles,  max (prod q_i)/N = 0.498   at N=100348, {199,251}
       L = 3:  595 cycles,  max (prod q_i)/N = 9.374e4 at N=100224,
                                                        {1613,3181,1831}
       L = 4:  875 cycles,  max (prod q_i)/N = 3.367e9 at N=100362,
                                                        {467,19979,2593,13967}

(c) WHAT SURVIVES: THE PRODUCT CRITERION.  Call a core INVOLUTIVE if it admits a
    perfect matching all of whose cycles have length 2 (an involution).

    THEOREM (product criterion).  Let S be a core with |S| = s and let f be ANY
    perfect matching of S, with cycles C_1, ..., C_m.  Since every cycle has
    length at least 2 (a length-1 cycle would need q | N-q, impossible by D3),
        m  <=  floor(s/2).
    If every cycle of f satisfied prod_{q in C_j} q < N, then
        prod_{q in S} q  =  prod_j prod_{q in C_j} q  <  N^m  <=  N^{floor(s/2)}.
    CONTRAPOSITIVE.  If
        prod_{q in S} q  >=  N^{floor(s/2)}
    then EVERY perfect matching of S contains a cycle whose product is at least
    N; in particular S is not involutive.
    CONVERSELY, if S is involutive then all m = s/2 cycles are 2-cycles, D6
    applies to each, and unconditionally
        prod_{q in S} q  <  N^{s/2}.

    DATA (exact, this run; the criterion and the exhaustive matching enumeration
    agree in all six cases):
       N      s   floor(s/2)   prod S      N^{floor(s/2)}   prod S >= ?  involutive?
       128    8       4        4.106e8     2.684e8          YES          no
       1718   28     14        4.607e51    1.951e45         YES          no
       1862   21     10        3.987e39    5.010e32         YES          no
       1928   14      7        1.240e23    9.903e22         YES          no
       2200    2      1        39          2.200e3          no           YES {3,13}
       6142   10      5        5.636e15    8.741e18         no           YES
    The N = 6142 involution is {3,877},{5,17},{7,409},{13,227},{19,157} with
    products 2631, 85, 2863, 2951, 2983, all below N = 6142.
    So the four non-involutive cores are non-involutive for a PROVED reason, not
    merely because an enumeration found no involution; and the two involutive
    ones give a genuine global height bound -- at N = 6142 the involution yields
    prod S < N^5 = 8.74e18 against the trivial bound (N/3)^{10} = 1.29e33, an
    improvement of 17 orders of magnitude.

CONCLUSION (correctly scoped).  The exit route of the K--O programme is NOT
empty: the 2-cycles of any cover carry D6, and an involutive cover gives a real
height bound.  What IS dead is the hope that the SAME bound holds for longer
cycles, and with it any argument that would treat a cycle cover uniformly.
Since "every core is involutive" is refuted by the product criterion at
N = 128, 1718, 1862, 1928, a matching theorem alone still cannot deliver a
uniform bound; the correct residual question is stated in section 9, FR-1.
Checkpoint P claimed more than this and is withdrawn on that point.

================================================================================
```
