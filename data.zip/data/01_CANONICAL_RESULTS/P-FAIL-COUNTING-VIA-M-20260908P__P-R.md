---
id: P-FAIL-COUNTING-VIA-M-20260908P@P-R
logical_id: P-FAIL-COUNTING-VIA-M-20260908P
version_id: P-FAIL-COUNTING-VIA-M-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail counting via m"
status: SUPERSEDED
status_raw: "The covering inequality"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 815, line_end: 818}
metadata: {"stable_id": "P-FAIL-COUNTING-VIA-M-20260908P", "version_id": "P-FAIL-COUNTING-VIA-M-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 815, "line_end": 818}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-COUNTING-VIA-M-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 815, "line_end": 818}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 967, style: ID-TABLE}
---

# P fail counting via m

*Run P-R - status `SUPERSEDED` (raw: `The covering inequality`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-COUNTING-VIA-M-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F4.  P-FAIL-COUNTING-VIA-M-20260908P.  The covering inequality
s <= |M| + (P/2) sum_{mu in M} 1/mu, from P2-R(iv) plus D4, is true but
numerically vacuous: at N = 6142 it reads 10 <= 385.
```
