---
id: P-FAIL-COUNTING-VIA-M-20260908P
logical_id: P-FAIL-COUNTING-VIA-M-20260908P
version_id: P-FAIL-COUNTING-VIA-M-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P fail counting via m"
status: AUDITED ASSESSMENT
status_raw: "The covering inequality"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 939, line_end: 942}
metadata: {"stable_id": "P-FAIL-COUNTING-VIA-M-20260908P", "version_id": "P-FAIL-COUNTING-VIA-M-20260908P@P-R2", "status": "AUDITED ASSESSMENT", "scope": "Stated covering inequality and six-host diagnostic", "assumptions": ["P2-R normal form and parent spacing"], "statement": "The inequality is true but too weak at N=6142 (10<=385).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 939, "line_end": 942}, "depends_on": [], "consequences": [], "does_not_imply": ["Does not prove the inequality false", "No theorem that every related counting idea fails"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": ["P-FAIL-COUNTING-VIA-M-20260908P@P", "P-FAIL-COUNTING-VIA-M-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 939, "line_end": 942}, "proof_provenance": [], "computation": [], "concepts": ["least-factor-attractor", "ordered-parents"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1095, style: ID-TABLE}
---

# P fail counting via m

*Run P-R2 - status `AUDITED ASSESSMENT` (raw: `The covering inequality`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

The inequality is true but too weak at N=6142 (10<=385).

**Assumptions:** P2-R normal form and parent spacing.

**Does not imply:** Does not prove the inequality false; No theorem that every related counting idea fails.

## Source transcript (historical wording; apply current metadata)

```
F4.  P-FAIL-COUNTING-VIA-M-20260908P.  The covering inequality
s <= |M| + (P/2) sum_{mu in M} 1/mu, from P2-R(iv) plus D4, is true but
numerically vacuous: at N = 6142 it reads 10 <= 385.
```
