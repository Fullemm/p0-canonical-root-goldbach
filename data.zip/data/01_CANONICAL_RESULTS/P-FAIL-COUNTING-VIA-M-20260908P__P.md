---
id: P-FAIL-COUNTING-VIA-M-20260908P@P
logical_id: P-FAIL-COUNTING-VIA-M-20260908P
version_id: P-FAIL-COUNTING-VIA-M-20260908P@P
kind: historical-version
run: P
title: "P fail counting via m"
status: SUPERSEDED
status_raw: "The covering inequality"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 648, line_end: 772}
metadata: {"stable_id": "P-FAIL-COUNTING-VIA-M-20260908P", "version_id": "P-FAIL-COUNTING-VIA-M-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 648, "line_end": 772}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-COUNTING-VIA-M-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 648, "line_end": 772}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 787, style: ID-TABLE}
---

# P fail counting via m

*Run P - status `SUPERSEDED` (raw: `The covering inequality`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-COUNTING-VIA-M-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F4.  P-FAIL-COUNTING-VIA-M-20260908P.  The covering inequality
s <= |M| + (P/2) sum_{mu in M} 1/mu, obtained from P2(iv) plus the spacing
lemma D4, is true but numerically vacuous: at N = 6142 it reads 10 <= 385.
Because P = max S can be close to N/3, no useful bound on s follows.

F5.  Baker/Matveev on the s = 3 system.  With s = 3 the constant
A(S) = 1.4 * 30^6 * 3^{4.5} * prod log q exceeds 1e11 * prod log q, so
thm:postJ-fixedS is vacuous by more than ten orders of magnitude on any 3-core.
The elementary route (P3a + E1) beats it completely, exactly as the two-core
case did in run J.

================================================================================
7.  RELATION TO GOLDBACH
================================================================================

Unchanged.  By cor:postJ-ssr, excluding self-smooth representations for all
large N implies binary Goldbach and is therefore strictly stronger, so nothing
in this run can be a step towards Goldbach through host nonexistence.

What the run does do is sharpen the boundary of the FINITE part of the host
problem.  The complete classes are now:
        s = 2 : only N = 2200, complete for all even N <= 1e24  (run J);
        s = 3 : empty, complete for all even N <= 1e12          (this run),
                confirmed independently to 1e10 by the closure test E5;
and the reason both are decidable is the same: a forced pure prime-power row
whose partner is provably below sqrt N.  For s >= 4 no pure row is forced
(\tid{K-FAIL-PURE-ROW-IN-EVERY-CORE-01}: the cores at N = 1928 and N = 6142 have
none), so this exact mechanism stops.

P5 additionally removes the only stated bridge from the matching programme to
any global statement; nothing in K--O now points at Goldbach even conditionally.

================================================================================
8.  RELATION TO p_0 EXCEPTIONALITY
================================================================================

None of P1--P6 mentions the selector.  The audited J verdict stands: outside the
host set every upper root with composite mirror succeeds for an ambient reason,
the composite-mirror canonical case occurs at exactly three of the six known
hosts (1862, 1928, 6142), and each is won by a single escape edge.

One indirect consequence.  A new host would supply a fourth selector-informative
case, and E1 shows that no such host arises from a three-element core below
1e12.  Combined with the J two-core census to 1e24 and the J purepower probe to
1e17, the searchable small-core shapes are now exhausted well past any range in
which a new host could be found by scanning.  If a fourth selector datum is
ever to be obtained, it will have to come from a core of size at least four,
i.e. from exactly the regime where the pure-row mechanism fails.

================================================================================
9.  EXACT NEW FRONTIER
================================================================================

F-A  (four-element cores; the natural continuation of P3a).
P8 splits s = 4 exactly:
   branch (I)  a pure row at index 1 or 2  ->  partner < sqrt N by P1
               ->  DECIDED by the E1 method on any finite range;
   branch (II) rows 1 and 2 both two-prime, cross pattern in q_3, q_4
               ->  the genuinely new object.
The missing lemma for arbitrary core size is (Q-A) restricted to cores (P9):
      in a MINIMAL closed BAD set, can a label above sqrt N carry a pure row?
P9 kills every closure-only proof of it by exhibiting four such rows inside
non-minimal closed BAD sets.

F-B  (bounding |M|).  Empirically |M| = 2,4,6,6,7,10 while s = 2,8,10,14,21,28.
If |M| were bounded by an absolute constant, or by O(log N / log log N), the
covering structure of P2(iv) would become strong.  Precise question:
      (Q-B)  is there an all-N upper bound for |S cap [3, sqrt N]| over closed
             BAD sets?
Note P2 gives the reverse budget (large labels are nearly matched to rows), so a
bound on |M| would bound the "irregular" part of the incidence structure.

F-C  (analytic rarity, unchanged from J NEXT-3).  Still the only identified
route that is not equivalent to an every-N Goldbach statement.

F-D  (what to do with K--O).  The M/N/O local relay exclusions
(\tid{N-SQUARE-RELAY}, \tid{O-beta-0/1}, \tid{O-beta-2-REPAIR}) are correct
arithmetic and should be kept as local forbidden blocks.  What should NOT be
continued is the pursuit of "every core has a perfect matching" as a goal: by
P5 its consequence set is empty.

================================================================================
10.  RECOMMENDED NEXT ATTACK
================================================================================

NEXT-1  Settle (Q-A) FOR CORES: can a label above sqrt N have a pure row inside
        a MINIMAL closed BAD set?  P9 settles the question negatively for
        closed BAD sets in general (four exact counterexamples), so any proof
        must consume minimality.  A positive answer extends the E1 search of
        section 4 to branch (I) of P8 and to every larger core size that forces
        a pure row; a counterexample kills that extension and is equally
        valuable.  Concretely: exhibit or exclude a core containing q > sqrt N
        with N - q = r^m, r in M, m >= 2.

NEXT-2  Attack branch (II) of P8 -- the two-prime cross pattern
        N-q_1 = q_2^a q_4^{a'}, N-q_2 = q_1^b q_3^{b'} (and its mirror).  This
        is the exact residual four-core object once branch (I) is handled by E1.
        In parallel push E1 itself from 1e12 to 1e14.  Cost scales as
        2X/(log X)^2; 1e14 is roughly 200x the 1e12 run and is a single
        overnight job.  Do NOT extend it further than that without a new idea:
        the return per CPU-hour falls off and the class is already decided far
        beyond any census range.

NEXT-3  Attack (Q-B).  A bound on |M| is the only structural quantity in P2
        that is not already controlled, and every core statistic in the corpus
        (sparse row, ordered forest, incidence budget) becomes quantitative once
        |M| is bounded.

NEXT-4  Bookkeeping for the master:
        (a) record P5 next to the K--O closing warning: the exit route is not
            merely insufficient, it is empty;
        (b) record P6 (core-size gap 3..7) beside sec:postKLO-frontier;
        (c) record P1 as a general lemma in the core layer -- it is short and it
            is what made s = 3 decidable.

NOT RECOMMENDED
        Continuing the beta-ladder of run O.  Even completing branch B
        common-c leaves branch B split-parent, types A and C, and then s >= 6,
        and the terminal theorem of that whole chain has, by P5, no arithmetic
        consequence.  If the Hall structure is to be used at all, it must first
        be shown to imply something other than a cycle cover.

================================================================================
STABLE IDS INTRODUCED IN THIS RUN
================================================================================
```
