---
id: P-FAIL-CYCLE-PRODUCT-20260908P
logical_id: P-FAIL-CYCLE-PRODUCT-20260908P
version_id: P-FAIL-CYCLE-PRODUCT-20260908P@P
kind: canonical-result
run: P
title: "P fail cycle product"
status: SUPERSEDED
status_raw: "\"The two-cycle bound pq < N generalises"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 632, line_end: 635}
metadata: {"stable_id": "P-FAIL-CYCLE-PRODUCT-20260908P", "version_id": "P-FAIL-CYCLE-PRODUCT-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 632, "line_end": 635}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 632, "line_end": 635}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P
supersession_reason: "F1 re-scoped to F1-R after the P5 quantifier repair"
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 784, style: ID-TABLE}
---

# P fail cycle product

*Run P - status `SUPERSEDED` (raw: `"The two-cycle bound pq < N generalises`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-FAIL-LONGCYCLE-PRODUCT-R-20260908P` (run `P-R2`).
>
> **Defect:** F1 re-scoped to F1-R after the P5 quantifier repair

## Source transcript (historical wording; apply current metadata)

```
F1.  P-FAIL-CYCLE-PRODUCT-20260908P.  "The two-cycle bound pq < N generalises
to longer cycles."  FALSE; see P5.  Maximum observed (prod q_i)/N is 9.4e4 at
L = 3 and 3.4e9 at L = 4, and 1.3e46 on the core of N = 1718.
```
