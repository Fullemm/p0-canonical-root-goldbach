---
id: P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P@P-R
logical_id: P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P
version_id: P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail every core involutive"
status: SUPERSEDED
status_raw: "KILLED: \"every core is"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 826, line_end: 952}
metadata: {"stable_id": "P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P", "version_id": "P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 826, "line_end": 952}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 826, "line_end": 952}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 969, style: ID-TABLE}
---

# P fail every core involutive

*Run P-R - status `SUPERSEDED` (raw: `KILLED: "every core is`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F6 (NEW).  P-FAIL-EVERY-CORE-INVOLUTIVE-20260908P.  KILLED: "every core is
involutive".  Refuted by the product criterion P5-R(c) at N = 128, 1718, 1862,
1928, where prod S >= N^{s/2}.

--------------------------------------------------------------------------------
7.  RELATION TO GOLDBACH
--------------------------------------------------------------------------------

Unchanged.  By cor:postJ-ssr, excluding self-smooth representations for all
large N implies binary Goldbach and is strictly stronger, so nothing here is a
step towards Goldbach through host nonexistence.

What the run does is sharpen the boundary of the FINITE part of the host
problem.  The bounded complete classes are now:
        two-element cores : only N = 2200, for all even N <= 1e24     (run J);
        three-element cores: none, for all even N <= 1e12             (this run),
                             independently confirmed to 1e10 by E5-R (different test).
Both are decidable for the same reason: a forced pure prime-power row whose
partner is provably below sqrt N.  For s >= 4 no pure row is forced
(\tid{K-FAIL-PURE-ROW-IN-EVERY-CORE-01}), so the mechanism stops at branch (I)
of P8-R.  All-N statements for s = 3 and above remain OPEN.

--------------------------------------------------------------------------------
8.  RELATION TO p_0 EXCEPTIONALITY
--------------------------------------------------------------------------------

None of P1--P9 mentions the selector.  The audited J verdict stands: outside the
host set every upper root with composite mirror succeeds for an ambient reason;
the composite-mirror canonical case occurs at exactly three of the six known
hosts (1862, 1928, 6142), each won by a single escape edge.

Indirect consequence, correctly scoped.  A new host would supply a fourth
selector-informative case.  E1-R and E5-R show that within their boxes no new
host arises with a three-element core, or with any core carrying a pure row
whose partner is below sqrt N.  Hosts of the N = 1928 / N = 6142 type (pure-free
cores) are NOT covered by either box and remain the only shape in which a new
host could still be found by a directed search.

--------------------------------------------------------------------------------
9.  NEW BINDING FRONTIER (supersedes the frontier of checkpoint P)
--------------------------------------------------------------------------------

FR-1  (PRIMARY).  INVOLUTIVE COVERS -- the correct repair of the K--O exit.
      Define a core to be involutive if it has a perfect matching that is an
      involution.  P5-R(c) gives: involutive => prod_{q in S} q < N^{s/2}, and
      the contrapositive refutes involutivity at four of the six known cores.
      The three questions, in order of value:
        (1)  Characterise involutive cores arithmetically.  Is
             prod_{q in S} q < N^{floor(s/2)} also SUFFICIENT, or is there a
             second obstruction?  On the six known cores the criterion is
             exactly equivalent to involutivity, with no false positive and no
             false negative -- which is either a theorem waiting to be proved or
             a six-point coincidence.
        (2)  For a NON-involutive core, is there any invariant of a cover that
             replaces the product bound?  P5-R(a) shows the naive size bound
             fails for L >= 3; the CRT residue of a long cycle is the only other
             visible datum and it is generic.
        (3)  Does D8 (matching at |S| <= 4) upgrade to an INVOLUTION at
             |S| <= 4?  If yes, small cores inherit prod S < N^{s/2} outright.
      This replaces the K--O goal "every core has a perfect matching", which by
      P5-R has no uniform consequence, with a goal that does.

FR-2  (Q-A) FOR CORES.  Can a label above sqrt N carry a pure row inside a
      MINIMAL closed BAD set?  P9 kills every closure-only and every
      source-freeness-only proof by four explicit counterexamples, so a proof
      must consume TERMINALITY of the SCC.  A positive answer extends the E5-R
      box to branch (I) of every core size; a counterexample kills that
      extension.  Either way the box of section 4 becomes exactly delimited.

FR-3  BRANCH (II) OF P8-R.  The residual four-core object:
        N - q_1 = q_2^a q_4^{a'},  N - q_2 = q_1^b q_3^{b'}   (and its mirror),
      with a,b,a',b' >= 1.  Attack it with P1 (q_1, q_2 < sqrt N), P2-R (at most
      one large label per row) and D4.  Note P1 already forces both partners
      below sqrt N, so only the two free upper labels are unbounded.

FR-4  BOUND |M|.  Empirically |M| = |S cap [3,sqrt N]| equals 2,4,6,6,7,10 while
      s = 2,8,10,14,21,28.  Is there an all-N upper bound for |M| over cores?
      P2-R makes every core statistic quantitative once |M| is bounded, and F4
      shows the reverse (covering) inequality is vacuous without such a bound.

FR-5  ANALYTIC RARITY (unchanged from run J, NEXT-3).  Still the only identified
      route that is not equivalent to an every-N Goldbach statement.

FR-6  DIRECTED SEARCH FOR A PURE-FREE HOST.  The E1-R/E5-R boxes cannot see the
      N = 1928 / N = 6142 shape.  A search targeting pure-free cores -- e.g. via
      branch (II) of P8-R, or via P7-R's localised low-support row -- is the only
      remaining directed way to a seventh host, and a seventh host is the single
      most informative datum available to the whole project (section 8).

--------------------------------------------------------------------------------
10.  RECOMMENDED NEXT ATTACK
--------------------------------------------------------------------------------

NEXT-1  FR-1(3): try to upgrade D8 from "perfect matching" to "involution" for
        |S| <= 4.  This is a small, self-contained combinatorial question with a
        clear payoff (prod S < N^{s/2} for small cores) and it reuses the L-run
        machinery rather than extending the beta-ladder.

NEXT-2  FR-2: settle (Q-A) for cores using terminality.

NEXT-3  FR-3: branch (II) of P8-R.

NEXT-4  Push E1-R from 1e12 to 1e14 (cost scales as 2X/(log X)^2, roughly 200x,
        one overnight job) and E5-R correspondingly.  Do not go further without
        a new idea.

NEXT-5  Bookkeeping for the master:
        (a) record P5-R next to the K--O closing warning: the longer-cycle
            analogue of D6 is false, but 2-cycles and involutive covers survive
            and give prod S < N^{s/2};
        (b) record P1 as a general lemma in the core layer;
        (c) record P2-R with its hypothesis max S < N/3 and the N = 128
            counterexample, so the hypothesis is never dropped again;
        (d) record P6 (core-size gap 3..7) beside sec:postKLO-frontier;
        (e) record R2's example {3,13,1471} at N = 2200 as the standing witness
            that "closed BAD set of size 3" and "3-core" are different objects.

NOT RECOMMENDED
        Continuing the beta-ladder of run O without first settling FR-1(2).  If
        no invariant replaces the product bound for non-involutive cores, then
        completing the Hall enumeration yields a theorem whose only arithmetic
        consequence is confined to involutive cores -- which the product
        criterion shows is a proper subclass.

--------------------------------------------------------------------------------
STABLE IDS
--------------------------------------------------------------------------------
```
