---
id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R
logical_id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P
version_id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail longcycle product r"
status: SUPERSEDED
status_raw: "KILLED, precisely: the statement"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 801, line_end: 806}
metadata: {"stable_id": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P", "version_id": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 801, "line_end": 806}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 801, "line_end": 806}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 964, style: ID-TABLE}
---

# P fail longcycle product r

*Run P-R - status `SUPERSEDED` (raw: `KILLED, precisely: the statement`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F1-R.  P-FAIL-LONGCYCLE-PRODUCT-R-20260908P.  KILLED, precisely: the statement
"every cycle of length L >= 3 in Gamma_N with labels below N/3 and composite
rows satisfies prod q_i < N".  Counterexamples with ratio 9.4e4 (L=3) and 3.4e9
(L=4).  NOT killed: D6 itself, the 2-cycles inside any cover, or cycle
arithmetic in general.
```
