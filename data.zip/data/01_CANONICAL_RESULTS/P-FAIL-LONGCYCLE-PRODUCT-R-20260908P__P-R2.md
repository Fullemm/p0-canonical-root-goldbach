---
id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P
logical_id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P
version_id: P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P fail longcycle product r"
status: KILLED
status_raw: "KILLED, precisely: the statement"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 925, line_end: 930}
metadata: {"stable_id": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P", "version_id": "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R2", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 925, "line_end": 930}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-FAIL-CYCLE-PRODUCT-20260908P", "P-FAIL-LONGCYCLE-PRODUCT-R-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 925, "line_end": 930}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1092, style: ID-TABLE}
---

# P fail longcycle product r

*Run P-R2 - status `KILLED` (raw: `KILLED, precisely: the statement`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
F1-R.  P-FAIL-LONGCYCLE-PRODUCT-R-20260908P.  KILLED, precisely: the statement
"every cycle of length L >= 3 in Gamma_N with labels below N/3 and composite
rows satisfies prod q_i < N".  Counterexamples with ratio 9.4e4 (L=3) and 3.4e9
(L=4).  NOT killed: D6 itself, the 2-cycles inside any cover, or cycle
arithmetic in general.
```
