---
id: P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R
logical_id: P-FAIL-MAXMIN-OVER-COVERS-20260908P
version_id: P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail maxmin over covers"
status: SUPERSEDED
status_raw: "KILLED"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 819, line_end: 825}
metadata: {"stable_id": "P-FAIL-MAXMIN-OVER-COVERS-20260908P", "version_id": "P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 819, "line_end": 825}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 819, "line_end": 825}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 968, style: ID-TABLE}
---

# P fail maxmin over covers

*Run P-R - status `SUPERSEDED` (raw: `KILLED`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F5 (NEW, this run's own error).  P-FAIL-MAXMIN-OVER-COVERS-20260908P.  KILLED:
the claim of checkpoint P that every perfect matching of every real core has a
cycle of product above N.  It was produced by maximising instead of minimising
over covers.  Two of the six cores have an all-2-cycle cover.  Recorded so the
error is not repeated: when a claim is universally quantified over covers, the
computation must minimise the witness quantity, not maximise it.
```
