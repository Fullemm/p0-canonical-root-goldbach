---
id: P-FAIL-MAXMIN-OVER-COVERS-20260908P
logical_id: P-FAIL-MAXMIN-OVER-COVERS-20260908P
version_id: P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P fail maxmin over covers"
status: KILLED
status_raw: "KILLED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 943, line_end: 949}
metadata: {"stable_id": "P-FAIL-MAXMIN-OVER-COVERS-20260908P", "version_id": "P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R2", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 943, "line_end": 949}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-FAIL-MAXMIN-OVER-COVERS-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 943, "line_end": 949}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1096, style: ID-TABLE}
---

# P fail maxmin over covers

*Run P-R2 - status `KILLED` (raw: `KILLED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
F5 (NEW, this run's own error).  P-FAIL-MAXMIN-OVER-COVERS-20260908P.  KILLED:
the claim of checkpoint P that every perfect matching of every real core has a
cycle of product above N.  It was produced by maximising instead of minimising
over covers.  Two of the six cores have an all-2-cycle cover.  Recorded so the
error is not repeated: when a claim is universally quantified over covers, the
computation must minimise the witness quantity, not maximise it.
```
