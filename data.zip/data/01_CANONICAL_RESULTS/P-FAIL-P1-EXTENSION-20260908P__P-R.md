---
id: P-FAIL-P1-EXTENSION-20260908P@P-R
logical_id: P-FAIL-P1-EXTENSION-20260908P
version_id: P-FAIL-P1-EXTENSION-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail p1 extension"
status: SUPERSEDED
status_raw: "KILLED: \"the argument of P1 iterates to"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 811, line_end: 814}
metadata: {"stable_id": "P-FAIL-P1-EXTENSION-20260908P", "version_id": "P-FAIL-P1-EXTENSION-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 811, "line_end": 814}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-P1-EXTENSION-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 811, "line_end": 814}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 966, style: ID-TABLE}
---

# P fail p1 extension

*Run P-R - status `SUPERSEDED` (raw: `KILLED: "the argument of P1 iterates to`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-P1-EXTENSION-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F3.  P-FAIL-P1-EXTENSION-20260908P.  KILLED: "the argument of P1 iterates to
q_3, q_4, ...".  P1 uses that all prime factors of N - q_1 exceed q_1, true only
for the minimum.  The correct general statement is P2-R(iv).
```
