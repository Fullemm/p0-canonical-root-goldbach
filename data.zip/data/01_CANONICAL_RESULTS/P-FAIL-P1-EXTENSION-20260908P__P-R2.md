---
id: P-FAIL-P1-EXTENSION-20260908P
logical_id: P-FAIL-P1-EXTENSION-20260908P
version_id: P-FAIL-P1-EXTENSION-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P fail p1 extension"
status: KILLED
status_raw: "KILLED: \"the argument of P1 iterates to"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 935, line_end: 938}
metadata: {"stable_id": "P-FAIL-P1-EXTENSION-20260908P", "version_id": "P-FAIL-P1-EXTENSION-20260908P@P-R2", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 935, "line_end": 938}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-FAIL-P1-EXTENSION-20260908P@P", "P-FAIL-P1-EXTENSION-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 935, "line_end": 938}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1094, style: ID-TABLE}
---

# P fail p1 extension

*Run P-R2 - status `KILLED` (raw: `KILLED: "the argument of P1 iterates to`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
F3.  P-FAIL-P1-EXTENSION-20260908P.  KILLED: "the argument of P1 iterates to
q_3, q_4, ...".  P1 uses that all prime factors of N - q_1 exceed q_1, true only
for the minimum.  The correct general statement is P2-R(iv).
```
