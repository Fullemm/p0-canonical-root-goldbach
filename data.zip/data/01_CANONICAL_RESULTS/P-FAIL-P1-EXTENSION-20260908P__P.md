---
id: P-FAIL-P1-EXTENSION-20260908P@P
logical_id: P-FAIL-P1-EXTENSION-20260908P
version_id: P-FAIL-P1-EXTENSION-20260908P@P
kind: historical-version
run: P
title: "P fail p1 extension"
status: SUPERSEDED
status_raw: "\"The argument of P1 iterates: q_3 <"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 642, line_end: 647}
metadata: {"stable_id": "P-FAIL-P1-EXTENSION-20260908P", "version_id": "P-FAIL-P1-EXTENSION-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 642, "line_end": 647}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-P1-EXTENSION-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 642, "line_end": 647}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 786, style: ID-TABLE}
---

# P fail p1 extension

*Run P - status `SUPERSEDED` (raw: `"The argument of P1 iterates: q_3 <`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-P1-EXTENSION-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F3.  P-FAIL-P1-EXTENSION-20260908P.  "The argument of P1 iterates: q_3 <
sqrt N, then q_4 < sqrt N, ..."  FALSE.  P1 uses that all prime factors of
N - q_1 exceed q_1, which holds only for the minimum.  For q_2 the row may
contain q_1 and the bound collapses.  The correct general statement is the
weaker P2(iv): every row's LEAST prime factor is below sqrt N.
```
