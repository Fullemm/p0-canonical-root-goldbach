---
id: P-FAIL-TWO-LEVEL-CORE-20260908P@P-R
logical_id: P-FAIL-TWO-LEVEL-CORE-20260908P
version_id: P-FAIL-TWO-LEVEL-CORE-20260908P@P-R
kind: historical-version
run: P-R
title: "P fail two level core"
status: SUPERSEDED
status_raw: "KILLED: \"rows of large labels are"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 807, line_end: 810}
metadata: {"stable_id": "P-FAIL-TWO-LEVEL-CORE-20260908P", "version_id": "P-FAIL-TWO-LEVEL-CORE-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 807, "line_end": 810}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 807, "line_end": 810}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 965, style: ID-TABLE}
---

# P fail two level core

*Run P-R - status `SUPERSEDED` (raw: `KILLED: "rows of large labels are`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F2.  P-FAIL-TWO-LEVEL-CORE-20260908P.  KILLED: "rows of large labels are
M-smooth".  At N = 128 the large label 13 divides the row of the large label 23;
at N = 1718 thirteen of eighteen large labels have a large parent.
```
