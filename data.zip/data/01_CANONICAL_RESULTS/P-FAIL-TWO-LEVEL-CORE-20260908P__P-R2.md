---
id: P-FAIL-TWO-LEVEL-CORE-20260908P
logical_id: P-FAIL-TWO-LEVEL-CORE-20260908P
version_id: P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P fail two level core"
status: KILLED
status_raw: "KILLED: \"rows of large labels are"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 931, line_end: 934}
metadata: {"stable_id": "P-FAIL-TWO-LEVEL-CORE-20260908P", "version_id": "P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 931, "line_end": 934}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-FAIL-TWO-LEVEL-CORE-20260908P@P", "P-FAIL-TWO-LEVEL-CORE-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 931, "line_end": 934}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1093, style: ID-TABLE}
---

# P fail two level core

*Run P-R2 - status `KILLED` (raw: `KILLED: "rows of large labels are`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
F2.  P-FAIL-TWO-LEVEL-CORE-20260908P.  KILLED: "rows of large labels are
M-smooth".  At N = 128 the large label 13 divides the row of the large label 23;
at N = 1718 thirteen of eighteen large labels have a large parent.
```
