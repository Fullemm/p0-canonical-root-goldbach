---
id: P-FAIL-TWO-LEVEL-CORE-20260908P@P
logical_id: P-FAIL-TWO-LEVEL-CORE-20260908P
version_id: P-FAIL-TWO-LEVEL-CORE-20260908P@P
kind: historical-version
run: P
title: "P fail two level core"
status: SUPERSEDED
status_raw: "\"Rows of large labels are M-smooth, so a"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 636, line_end: 641}
metadata: {"stable_id": "P-FAIL-TWO-LEVEL-CORE-20260908P", "version_id": "P-FAIL-TWO-LEVEL-CORE-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 636, "line_end": 641}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 636, "line_end": 641}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 785, style: ID-TABLE}
---

# P fail two level core

*Run P - status `SUPERSEDED` (raw: `"Rows of large labels are M-smooth, so a`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FAIL-TWO-LEVEL-CORE-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
F2.  P-FAIL-TWO-LEVEL-CORE-20260908P.  "Rows of large labels are M-smooth, so a
core is a two-level object (small labels generating large ones, large ones
feeding back only into small)."  FALSE.  At N = 128 the large label 13 divides
the row of the large label 23; at N = 1718 thirteen of the eighteen large labels
have a large parent.  Only N = 2200 and N = 6142 happen to be two-level.
```
