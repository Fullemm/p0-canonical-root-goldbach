---
id: P-FOUR-CORE-DICHOTOMY-20260908P
logical_id: P-FOUR-CORE-DICHOTOMY-20260908P
version_id: P-FOUR-CORE-DICHOTOMY-20260908P@P
kind: canonical-result
run: P
title: "P8.  FOUR-CORE DICHOTOMY"
status: SUPERSEDED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 301, line_end: 331}
metadata: {"stable_id": "P-FOUR-CORE-DICHOTOMY-20260908P", "version_id": "P-FOUR-CORE-DICHOTOMY-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 301, "line_end": 331}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FOUR-CORE-DICHOTOMY-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 301, "line_end": 331}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-FOUR-CORE-DICHOTOMY-R-20260908P
supersession_reason: "incomplete branch (I): pure rows with base q_3 or q_4 were omitted"
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 775, style: ID-TABLE}
---

# P8.  FOUR-CORE DICHOTOMY

*Run P - status `SUPERSEDED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-FOUR-CORE-DICHOTOMY-R-20260908P` (run `P-R2`).
>
> **Defect:** incomplete branch (I): pure rows with base q_3 or q_4 were omitted

## Source transcript (historical wording; apply current metadata)

```
P8.  FOUR-CORE DICHOTOMY                ID: P-FOUR-CORE-DICHOTOMY-20260908P
     STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S = {q_1<q_2<q_3<q_4} be a core.  Then exactly one of:

 (I)  one of rows 1, 2 is a pure prime power,
          N - q_1 = q_2^a  (a>=2)   or   N - q_2 = q_1^b  (b>=2),
      and then its partner is q_1 or q_2, hence < sqrt N by P1;
 (II) rows 1 and 2 each have exactly two distinct prime factors, in one of the
      two shapes
          (IIa)  N - q_1 = q_2^a q_4^{a'},   N - q_2 = q_1^b q_3^{b'},
          (IIb)  N - q_1 = q_2^a q_3^{a'},   N - q_2 = q_1^b q_4^{b'},
      with a, b >= 1 and a', b' >= 1.

PROOF.  By D4 the label q_4 divides exactly one internal row, hence at most one
of R_1, R_2.  By the ordered forest, q_3 has at most one parent of smaller
index, hence lies in at most one of R_1, R_2.  If neither q_3 nor q_4 lies in
R_1, then R_1 subseteq {q_2}, so R_1 = {q_2} and N - q_1 = q_2^a with a >= 2 by
BADness: case (I).  Symmetrically if neither lies in R_2.  Otherwise each of
R_1, R_2 contains exactly one of q_3, q_4, and they contain different ones,
giving (IIa) or (IIb); if in addition a = 0 (resp. b = 0) the row is pure with
partner q_1 (resp. q_2) and we are again in case (I).                      QED

CONSEQUENCE.  In branch (I) the E1 search method of section 4 applies verbatim
and decides that branch completely on any finite range.  Branch (II) is the
genuinely new object at s = 4: two two-prime rows with a cross pattern between
q_3 and q_4.  Note branch (II) is exactly where the two real pure-free cores
(N = 1928 and N = 6142, \tid{K-FAIL-PURE-ROW-IN-EVERY-CORE-01}) would live if
they had size four.

--------------------------------------------------------------------------------
```
