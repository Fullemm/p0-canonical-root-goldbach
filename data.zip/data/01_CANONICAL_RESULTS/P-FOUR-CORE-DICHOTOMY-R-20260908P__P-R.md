---
id: P-FOUR-CORE-DICHOTOMY-R-20260908P@P-R
logical_id: P-FOUR-CORE-DICHOTOMY-R-20260908P
version_id: P-FOUR-CORE-DICHOTOMY-R-20260908P@P-R
kind: historical-version
run: P-R
title: "P8-R.  FOUR-CORE DICHOTOMY"
status: SUPERSEDED
status_raw: "PROVED.  (Branch (I) repaired; reproved.)"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 484, line_end: 524}
metadata: {"stable_id": "P-FOUR-CORE-DICHOTOMY-R-20260908P", "version_id": "P-FOUR-CORE-DICHOTOMY-R-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 484, "line_end": 524}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-FOUR-CORE-DICHOTOMY-R-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 484, "line_end": 524}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 960, style: ID-TABLE}
---

# P8-R.  FOUR-CORE DICHOTOMY

*Run P-R - status `SUPERSEDED` (raw: `PROVED.  (Branch (I) repaired; reproved.)`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-FOUR-CORE-DICHOTOMY-R-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P8-R.  FOUR-CORE DICHOTOMY             ID: P-FOUR-CORE-DICHOTOMY-R-20260908P
     STATUS: PROVED.  (Branch (I) repaired; reproved.)
================================================================================
STATEMENT.  Let S = {q_1 < q_2 < q_3 < q_4} be a core.  Then exactly one of:

 (I)  at least one of R_1, R_2 is a singleton, i.e. one of the rows
          N - q_1 = z^a       or       N - q_2 = z^b
      is a pure prime power, where z is ANY of the remaining labels (q_2, q_3 or
      q_4 in the first case; q_1, q_3 or q_4 in the second) and a, b >= 2.
      Its PARTNER is q_1 or q_2, hence below sqrt N by P1; its BASE is below
      sqrt N by P1b.
 (II) |R_1| >= 2 and |R_2| >= 2.  Then necessarily
          q_2 in R_1,  q_1 in R_2,
      and R_1, R_2 contain exactly one of q_3, q_4 each, and different ones:
          (IIa)  N - q_1 = q_2^a q_4^{a'},   N - q_2 = q_1^b q_3^{b'},
          (IIb)  N - q_1 = q_2^a q_3^{a'},   N - q_2 = q_1^b q_4^{b'},
      with a, b, a', b' >= 1.

PROOF.  Suppose we are not in case (I), so |R_1| >= 2 and |R_2| >= 2.
By D4, q_4 divides exactly one row of the core and not its own, so q_4 lies in
at most one of R_1, R_2.  By D9, q_3 has at most one parent of smaller index, so
q_3 lies in at most one of R_1, R_2.
If R_1 contained both q_3 and q_4, then neither would lie in R_2, so
R_2 would be a nonempty subset of {q_1}, hence a singleton -- excluded.  So
|R_1 cap {q_3,q_4}| <= 1, and symmetrically |R_2 cap {q_3,q_4}| <= 1.
Since R_1 is a subset of {q_2,q_3,q_4} with |R_1| >= 2 and at most one element
in {q_3,q_4}, we get q_2 in R_1 and exactly one of q_3, q_4 in R_1; likewise
q_1 in R_2 and exactly one of q_3, q_4 in R_2.  Those two cannot be the same
label, by the at-most-one-of-R_1,R_2 property.  This is (IIa) or (IIb).    QED

WHAT WAS WRONG IN P.  Checkpoint P listed branch (I) as "N-q_1 = q_2^a or
N-q_2 = q_1^b", i.e. only pure rows with base q_2 resp. q_1, and then had to
re-route the cases R_1 = {q_3}, R_1 = {q_4}, R_2 = {q_3}, R_2 = {q_4} through a
remark.  The base plays no role in the search of section 4 -- only the partner
does -- so branch (I) is now stated by the partner alone.

CONSEQUENCE.  Branch (I) is decided on any finite range by the E5 method of
section 4 (which tests every N = p^m + q with q < sqrt N, whatever the base).
Branch (II) is the genuinely new object at s = 4.

================================================================================
```
