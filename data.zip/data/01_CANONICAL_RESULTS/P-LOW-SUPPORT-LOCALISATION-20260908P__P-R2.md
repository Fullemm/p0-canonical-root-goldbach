---
id: P-LOW-SUPPORT-LOCALISATION-20260908P
logical_id: P-LOW-SUPPORT-LOCALISATION-20260908P
version_id: P-LOW-SUPPORT-LOCALISATION-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P7-R.  LOW-SUPPORT ROW LOCALISATION"
status: PROVED
status_raw: "PROVED.  COMPLEMENTARY to K-SPARSE-ROW (not a strengthening)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 531, line_end: 562}
metadata: {"stable_id": "P-LOW-SUPPORT-LOCALISATION-20260908P", "version_id": "P-LOW-SUPPORT-LOCALISATION-20260908P@P-R2", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 531, "line_end": 562}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-LOW-SUPPORT-LOCALISATION-20260908P@P", "P-LOW-SUPPORT-LOCALISATION-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 531, "line_end": 562}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1086, style: ID-TABLE}
---

# P7-R.  LOW-SUPPORT ROW LOCALISATION

*Run P-R2 - status `PROVED` (raw: `PROVED.  COMPLEMENTARY to K-SPARSE-ROW (not a strengthening).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
P7-R.  LOW-SUPPORT ROW LOCALISATION    ID: P-LOW-SUPPORT-LOCALISATION-20260908P
     STATUS: PROVED.  COMPLEMENTARY to K-SPARSE-ROW (not a strengthening).
================================================================================
STATEMENT.  Let S be a core and k = floor(s/2) + 1.  Then there is an index
i <= k with
        PF(N - q_i)  subseteq  {q_1, ..., q_k} \ {q_i}.
In particular N - q_i is q_k-smooth and has at most k-1 distinct prime factors.

PROOF.  By D9 every label q_j has at most one parent of smaller index.  Fix
j > k.  Every row R_i with i <= k has index i <= k < j, so q_j occurs in at most
one of R_1, ..., R_k.  Summing over j = k+1, ..., s, the number of pairs (i,j)
with i <= k < j and q_j in R_i is at most s - k.  Since k = floor(s/2)+1 we have
s - k = ceil(s/2) - 1 < k, so by pigeonhole some i <= k has no such j.      QED

RELATION TO K-SPARSE-ROW (corrected from checkpoint P).  K bounds
d = min_i omega(N - q_i) by (sqrt(8s-7)-1)/2, of order sqrt(2s).  P7-R bounds
omega of ONE specific row by k - 1 = floor(s/2), which is WEAKER than K's bound
for s >= 6.  P7-R is therefore not a strengthening; its added content is
LOCALISATION -- the row index and the whole support lie in the lower half of the
label order, which K does not assert.  For s = 3, P7-R reproduces D5 exactly (a
pure row at index 1 or 2).  No combined strengthening of K and P7-R is claimed
here.

VERIFIED on the six cores (indices from 0; all rows meeting the conclusion):
  N=128  s=8  k=5  q_k=13: rows 0 (3->{5}), 2 (7->{11}), 3 (11->{3,13})
  N=1718 s=28 k=15 q_k=79: nine rows, e.g. 8 (37->{41})
  N=1862 s=21 k=11 q_k=83: five rows, e.g. 3 (13->{43})
  N=1928 s=14 k=8  q_k=71: four rows, e.g. 6 (53->{3,5})
  N=2200 s=2  k=2  q_k=13: both rows
  N=6142 s=10 k=6  q_k=19: rows 1 (5->{17,19}), 4 (17->{5,7})

================================================================================
```
