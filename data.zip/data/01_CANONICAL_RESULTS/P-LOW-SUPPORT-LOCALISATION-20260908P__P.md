---
id: P-LOW-SUPPORT-LOCALISATION-20260908P@P
logical_id: P-LOW-SUPPORT-LOCALISATION-20260908P
version_id: P-LOW-SUPPORT-LOCALISATION-20260908P@P
kind: historical-version
run: P
title: "P7.  LOW-SUPPORT ROW LOCALISATION"
status: SUPERSEDED
status_raw: "PROVED   (strengthens \\tid{K-SPARSE-ROW})"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 268, line_end: 300}
metadata: {"stable_id": "P-LOW-SUPPORT-LOCALISATION-20260908P", "version_id": "P-LOW-SUPPORT-LOCALISATION-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 268, "line_end": 300}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-LOW-SUPPORT-LOCALISATION-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 268, "line_end": 300}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 774, style: ID-TABLE}
---

# P7.  LOW-SUPPORT ROW LOCALISATION

*Run P - status `SUPERSEDED` (raw: `PROVED   (strengthens \tid{K-SPARSE-ROW})`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-LOW-SUPPORT-LOCALISATION-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P7.  LOW-SUPPORT ROW LOCALISATION       ID: P-LOW-SUPPORT-LOCALISATION-20260908P
     STATUS: PROVED   (strengthens \tid{K-SPARSE-ROW})
--------------------------------------------------------------------------------
STATEMENT.  Let S = {q_1 < ... < q_s} be a core and put k = floor(s/2) + 1.
Then there is an index i <= k with
        PF(N - q_i)  subseteq  {q_1, ..., q_k} \ {q_i}.
In particular N - q_i is q_k-smooth, has at most k-1 distinct prime factors, and
        Omega(N - q_i)  >=  log(2N/3) / log(q_k).

PROOF.  By the ordered-parent forest (\tid{K-ORDERED-FOREST}; equivalently D4
applied to increasing edges) every label q_j has at most one parent with a
smaller index: two smaller parents q_a, q_b would give q_j | q_a - q_b with
0 < |q_a - q_b| < q_j.  Fix j > k.  Every row R_i with i <= k has index i < j,
so q_j occurs in at most one of R_1, ..., R_k.  Summing over j = k+1, ..., s,
the number of pairs (i, j) with i <= k < j and q_j in R_i is at most s - k.
Since k = floor(s/2)+1 we have s - k <= k - 1 < k, so by pigeonhole at least one
i <= k has no such j, i.e. R_i is contained in {q_1, ..., q_k}\{q_i}.       QED

RELATION TO K-SPARSE-ROW.  K proves min_i omega(N - q_i) <= (sqrt(8s-7)-1)/2,
i.e. SOME row is sparse.  P7 additionally LOCALISES it: the sparse row occurs at
an index in the lower half, and its support lies in the lower half.  For s = 3
P7 returns exactly D5 (a pure row at index 1 or 2).  For s = 4, 5 it gives a row
of index <= 3 supported in {q_1,q_2,q_3}.

VERIFIED on the six cores (rows satisfying the conclusion, index from 0):
  N=128  s=8  k=5  q_k=13: rows 0 (3 -> {5}), 2 (7 -> {11}), 3 (11 -> {3,13})
  N=1718 s=28 k=15 q_k=79: nine rows, e.g. 8 (37 -> {41})
  N=1862 s=21 k=11 q_k=83: five rows, e.g. 3 (13 -> {43})
  N=1928 s=14 k=8  q_k=71: four rows, e.g. 6 (53 -> {3,5})
  N=2200 s=2  k=2  q_k=13: both rows
  N=6142 s=10 k=6  q_k=19: rows 1 (5 -> {17,19}), 4 (17 -> {5,7})

--------------------------------------------------------------------------------
```
