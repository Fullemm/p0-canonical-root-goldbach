---
id: P-PURE-BASE-SQRT-20260908P-R2
logical_id: P-PURE-BASE-SQRT-20260908P-R2
version_id: P-PURE-BASE-SQRT-20260908P-R2@P-R2
kind: canonical-result
run: P-R2
title: "P pure base sqrt"
status: PROVED
status_raw: "PROVED               (P1b, universal half)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 235, line_end: 242}
metadata: {"stable_id": "P-PURE-BASE-SQRT-20260908P-R2", "version_id": "P-PURE-BASE-SQRT-20260908P-R2@P-R2", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 235, "line_end": 242}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 235, "line_end": 242}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
body_pointer_note: "Stated as COROLLARY P1b inside the P1 section; the stable-ID table is the only place the ID string itself occurs."
---

# P pure base sqrt

*Run P-R2 - status `PROVED` (raw: `PROVED               (P1b, universal half)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY P1b (universal; no hypothesis on the partner).  Let S be a closed BAD
set and let N - q_i = q_j^m be a pure row.  Then m >= 2 and
        q_j  <=  N^{1/m}  <=  sqrt(N).
PROOF.  q_i is BAD, so N - q_i is composite; a composite prime power has
exponent m >= 2.  Then q_j^m = N - q_i < N gives q_j <= N^{1/m} <= sqrt N.  QED
Note that m >= 2 follows from COMPOSITENESS alone; checkpoint P-R derived it
from a size comparison with 2N/3, which is not available in general.
```
