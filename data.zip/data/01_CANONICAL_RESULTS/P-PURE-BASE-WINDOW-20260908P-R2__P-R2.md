---
id: P-PURE-BASE-WINDOW-20260908P-R2
logical_id: P-PURE-BASE-WINDOW-20260908P-R2
version_id: P-PURE-BASE-WINDOW-20260908P-R2@P-R2
kind: canonical-result
run: P-R2
title: "P pure base window"
status: PROVED
status_raw: "PROVED (hypothesised)(P1c, partner < N/3)"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 243, line_end: 265}
metadata: {"stable_id": "P-PURE-BASE-WINDOW-20260908P-R2", "version_id": "P-PURE-BASE-WINDOW-20260908P-R2@P-R2", "status": "PROVED", "scope": "Pure square row whose partner is below N/3", "assumptions": ["N-q_i=q_j^2", "q_i<N/3"], "statement": "sqrt(2N/3)<q_j<sqrt(N).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 243, "line_end": 265}, "depends_on": [], "consequences": [], "does_not_imply": ["Hypothesis is explicit, not an unproved conjecture", "Not for arbitrary upstream partners"], "killed_stronger_forms": [], "counterexamples": ["N=128, q_i=103, q_j=5"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 243, "line_end": 265}, "proof_provenance": [], "computation": [], "concepts": ["pure-row", "least-factor-attractor"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
body_pointer_note: "Stated as COROLLARY P1c inside the P1 section, together with the WHY-THE-HYPOTHESIS-IS-NECESSARY counterexample and the LOAD-BEARING? assessment."
---

# P pure base window

*Run P-R2 - status `PROVED` (raw: `PROVED (hypothesised)(P1c, partner < N/3)`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

sqrt(2N/3)<q_j<sqrt(N).

**Assumptions:** N-q_i=q_j^2; q_i<N/3.

**Does not imply:** Hypothesis is explicit, not an unproved conjecture; Not for arbitrary upstream partners.

## Source transcript (historical wording; apply current metadata)

```
COROLLARY P1c (the square window; HYPOTHESIS: the partner satisfies q_i < N/3,
which is automatic for source-free sets, hence for every core).  Under that
hypothesis N - q_i > 2N/3, so if m = 2 then
        sqrt(2N/3)  <  q_j  <  sqrt(N).
WHY THE HYPOTHESIS IS NECESSARY.  N = 128, q_i = 103: 128 - 103 = 25 = 5^2, and
S = {3,5,7,11,13,23,29,41,103} (the core together with 103) is a closed BAD set.
The base 5 satisfies P1b (5 < 11.314) but violates the window (5 < 9.238),
because 103 > N/3 = 42.67 makes N - 103 = 25 smaller than 2N/3 = 85.33.
On all pure rows of the six known cores the window does hold, as it must:
128-7 = 11^2 (11 > 9.24), 1718-37 = 41^2 (41 > 33.85), 1862-13 = 43^2
(43 > 35.23); the rows 128-3 = 5^3, 2200-3 = 13^3 and 2200-13 = 3^7 have m >= 3,
where no window is asserted.
LOAD-BEARING?  No.  P1b is used in P3a and P8-R only through its universal half,
and even that is a remark rather than a premise: the searches of section 4
enumerate every base p with p^2 <= X regardless, so their completeness rests on
the PARTNER bound of P1 alone.  P1c is used nowhere.

VERIFIED on the six hosts for both B_N and the core:
   N=128  q1=3  q2=5   N-q1=125  minPF=5      N=1928 q1=3 q2=5  N-q1=1925 minPF=5
   N=1718 q1=3  q2=5   N-q1=1715 minPF=5      N=2200 q1=3 q2=13 N-q1=2197 minPF=13
   N=1862 q1=3  q2=5   N-q1=1859 minPF=11     N=6142 q1=3 q2=5  N-q1=6139 minPF=7

================================================================================
```
