---
id: P-PURE-ROW-HOST-CENSUS-20260908P
logical_id: P-PURE-ROW-HOST-CENSUS-20260908P
version_id: P-PURE-ROW-HOST-CENSUS-20260908P@P
kind: canonical-result
run: P
title: "P pure row host census"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION (E5)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 783, line_end: 784}
metadata: {"stable_id": "P-PURE-ROW-HOST-CENSUS-20260908P", "version_id": "P-PURE-ROW-HOST-CENSUS-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 783, "line_end": 784}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-PURE-ROW-HOST-CENSUS-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 783, "line_end": 784}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R
superseded_by_id: P-PURE-ROW-HOST-CENSUS-R-20260908P
supersession_reason: "uncertified cap (E5 -> E5-R)"
body_pointer_note: "E5 of checkpoint P has no titled section; only the stable-ID line exists. The experiment itself is described in run P-R and, in final form, in P-R2 as E5-R2. Superseded twice (uncertified cap, then a conclusion contradicting its own reported hits)."
---

# P pure row host census

*Run P - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION (E5)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-PURE-ROW-HOST-CENSUS-R-20260908P` (run `P-R`).
>
> **Defect:** uncertified cap (E5 -> E5-R)

## Source transcript (historical wording; apply current metadata)

```
P-PURE-ROW-HOST-CENSUS-20260908P         VERIFIED COMPUTATION (E5)
P-FAIL-CYCLE-PRODUCT-20260908P           KILLED               (F1)
```
