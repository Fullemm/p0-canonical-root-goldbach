---
id: P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R
logical_id: P-PURE-ROW-HOST-CENSUS-R-20260908P
version_id: P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R
kind: historical-version
run: P-R
title: "P pure row host census r"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 631, line_end: 800}
metadata: {"stable_id": "P-PURE-ROW-HOST-CENSUS-R-20260908P", "version_id": "P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 631, "line_end": 800}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-PURE-ROW-HOST-CENSUS-R2-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 631, "line_end": 800}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-PURE-ROW-HOST-CENSUS-R2-20260908P
supersession_reason: "the conclusion contradicted its own reported hits: it listed hosts 128/1718/1862/2200 while claiming none exist; re-scoped to 'no NEW host in the class'"
supersession_witness: "Its own output table reports N = 128, 1718, 1862, 2200."
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 963, style: ID-TABLE}
---

# P pure row host census r

*Run P-R - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-PURE-ROW-HOST-CENSUS-R2-20260908P` (run `P-R2`).
>
> **Defect:** the conclusion contradicted its own reported hits: it listed hosts 128/1718/1862/2200 while claiming none exist; re-scoped to 'no NEW host in the class'
>
> **Witness:** Its own output table reports N = 128, 1718, 1862, 2200.

## Source transcript (historical wording; apply current metadata)

```
       ID: P-PURE-ROW-HOST-CENSUS-R-20260908P    STATUS: VERIFIED COMPUTATION
       (implementation repaired: closure cap certified, see R7)
================================================================================
SCOPE.  The box of P3a decides more than s = 3: every host whose core contains a
pure row N - q = p^m (m >= 2) with partner q < sqrt N is found, whatever the
core size, once the three-element test is replaced by a full forward-closure
test.  By P3 this covers every 3-core; by P8-R it covers branch (I) of every
4-core; empirically it covers four of the six known hosts.
ALGORITHM.  Same outer box; for each N = Q + q run the forward closure of q
starting from its unique child p, factoring each row by trial division plus
Pollard rho with deterministic Miller-Rabin, aborting on the first GOOD vertex.
If the closure exhausts, {q} together with the closure is a nonempty closed BAD
set, so N is a host.
REPAIR (R7).  The closure buffer is now 200000 entries, and TWO counters are
printed: closure overflows, and "large child" events (a prime factor of a BAD
row that is >= N/3, which thm:postJ-basin forbids, so the branch is dead code).
The census is valid only if both are zero.
VALIDATION.  On X = 1e7 and X = 2e8 the search returns exactly
     N = 128  via 128 - 3   = 5^3    (closure size 8  = core size)
     N = 128  via 128 - 7   = 11^2   (closure size 8)
     N = 1718 via 1718 - 37 = 41^2   (closure size 28 = core size)
     N = 1862 via 1862 - 13 = 43^2   (closure size 21 = core size)
     N = 2200 via 2200 - 3  = 13^3   (closure size 2)
     N = 2200 via 2200 - 13 = 3^7    (closure size 2)
and nothing else; overflows = 0, large-child events = 0.  It correctly misses
N = 1928 and N = 6142, whose cores have no pure row
(\tid{K-FAIL-PURE-ROW-IN-EVERY-CORE-01}).  Every recovered closure equals the
known core exactly -- an end-to-end check of P1, P3 and the implementation.
RESULT.  47 553 107 candidates tested for even N <= 1e10, with
     closure-overflows = 0   and   large-child-events = 0,
so both internal cut-offs are certified never to have fired and the search is
exact on its domain.  Exactly six hits: the same four hosts as in validation
(128 twice, 1718, 1862, 2200 twice), each with closure equal to its known core.
NO NEW HOST for any even N <= 1e10.  Output is byte-identical to the
uncertified run of checkpoint P, so the R7 repair changed no result -- it
supplied the missing proof that no result was lost.
CONCLUSION (exact scope).  No even N <= 1e10 has a core containing a pure
prime-power row whose partner lies below sqrt(N).  With P3 this independently
re-derives the s = 3 conclusion of E1-R up to 1e10 by a completely different
test (full closure instead of the three-element shape).

--------------------------------------------------------------------------------
4.7  REPRODUCIBLE CODE
--------------------------------------------------------------------------------

--- basin and core (Python 3 + sympy) ---
from sympy import primerange, isprime, factorint
def basin(N):
    lim=(N-1)//3
    ps=[p for p in primerange(3,lim+1) if N%p]
    fac={p:factorint(N-p) for p in ps}
    alive={p:(not isprime(N-p)) and N-p>1 for p in ps}
    ch=True
    while ch:
        ch=False
        for p in ps:
            if alive[p]:
                for q in fac[p]:
                    if not alive.get(q,False): alive[p]=False; ch=True; break
    return sorted(p for p in ps if alive[p])
def core(N,B):
    Bs=set(B); adj={p:[q for q in factorint(N-p) if q in Bs] for p in B}
    def fwd(p):
        seen={p}; st=[p]
        while st:
            v=st.pop()
            for w in adj[v]:
                if w not in seen: seen.add(w); st.append(w)
        return seen
    for p in B:
        F=fwd(p)
        if all(fwd(q)==F for q in F): return sorted(F)

--- all perfect matchings, and the CORRECT quantifier for E3-R ---
def matchings(N,S):
    cand={q:[r for r in S if (N-q)%r==0] for q in S}
    out=[]
    def rec(i,used,assign):
        if i==len(S): out.append(dict(assign)); return
        q=S[i]
        for r in cand[q]:
            if r in used: continue
            used.add(r); assign[q]=r; rec(i+1,used,assign); used.discard(r); del assign[q]
    rec(0,set(),{})
    return out
# for each matching decompose into cycles, take max cycle product;
# report MIN of that over all matchings (checkpoint P wrongly reported MAX).
# involutive  <=>  some matching has all cycles of length 2.

--- three-element search (C), inner logic of E1-R ---
/* p odd prime, Q = p^m <= X with m >= 2 ; q odd prime, q != p, q*q < Q+q */
N = Q + q;
Y = N - p;  Yp = Y;  while (Yp % q == 0) Yp /= q;
if (Yp == 1) { report_two_element(N,p,q); continue; }
z = primepower(Yp, &ez);
if (!z || z == p || z == q || z >= N/3) continue;
Z = N - z;  om = 0;
while (Z % p == 0) { Z /= p; om++; }
while (Z % q == 0) { Z /= q; om++; }
if (Z != 1 || om < 2) continue;
if (p >= N/3 || q >= N/3) continue;
report_three_element(N, p, q, z);
/* primepower(): trial division by odd primes < 512 with early exit on the
   first factor (if stripping it leaves 1 the number is a prime power, else
   reject); otherwise deterministic Miller-Rabin; otherwise test n = z^k for
   2 <= k <= log_512(n) by exact integer k-th roots. */

--- full closure test (C), inner logic of E5-R, with the R7 certificate ---
W = {p}; ovf = 0; bigchild = 0;
for (each v in W, while no GOOD found) {
    m = N - v; factor(m);
    for (each prime f | m) {
        if (N % f == 0) continue;                 /* cannot happen, D3 */
        if (isprime(N - f)) { GOOD; break; }
        if (f >= N/3) { bigchild++; GOOD; break; }/* cannot happen, D1 */
        if (f not in W && f != q) {
            if (|W| >= MAXW) { ovf++; print("OVERFLOW"); GOOD; break; }
            W += f; } } }
/* the census is exact only if ovf == 0 and bigchild == 0; both are printed. */

--------------------------------------------------------------------------------
5.  HOSTILE CHECKS
--------------------------------------------------------------------------------

HC1.  Were the audit's four counterexamples reproduced before repair?
Yes, all four, independently (section 0).  N=128 with 53; N=2200 with
{3,13,1471}; the five-2-cycle cover of the N=6142 core; and the omitted pure
bases in P8.  None was accepted on trust.

HC2.  Does P1 survive the P2 defect?
Yes.  P1's proof uses only closure, BADness of q_1 and D3; no hypothesis on
max S.  The counterexample of R1 satisfies P1 (q_1 = 3, q_2 = 5, 25 <= 125).

HC3.  Does E1-R's completeness argument still hold after R2?
Yes, on the correct domain.  The chain is D4 => P3 (dichotomy, uses minimality)
=> the pure row's partner is q_1 or q_2 => P1 gives partner < sqrt N => the
enumeration is exhaustive FOR CORES.  Minimality enters at D4, which is a core
statement; checkpoint P forgot to carry that hypothesis into the conclusion.

HC4.  Is P5-R(c) itself vulnerable to a quantifier slip?
The theorem is a one-directional implication (involutive => product bound), and
the data are used only through its contrapositive.  The involutive/non-involutive
labels were obtained twice: by exhaustive matching enumeration, and independently
by the product criterion.  They agree.

HC5.  Does the E5-R certificate really certify completeness?
It certifies that the implementation's two internal cut-offs never fired.  It
does not certify the arithmetic of Pollard rho, which is deterministic here but
unproved in running time; a non-terminating rho would hang, not silently drop a
candidate.  It also does not extend the SCOPE: hosts whose cores have no pure
row with a small partner (the N = 1928 and N = 6142 type) are outside the box.

HC6.  Quantifier discipline.
P1, P3, P4-R, P5-R(a),(c), P7-R, P8-R are for-all statements about closed BAD
sets or cores with the stated domain hypothesis attached.  P2-R carries an
explicit hypothesis whose necessity is demonstrated.  P3a is a for-all-N
reduction to a finite enumeration; E1-R and E5-R are that enumeration on
explicitly stated finite domains, with the conclusion restricted to cores.
E2, E3-R, E4 are finite computations with stated domains.  Nothing is promoted
from computation to theorem.

HC7.  What is NOT claimed anywhere in this document.
No Goldbach proof; no finiteness of the host set; no all-N nonexistence of
three-element cores; no impossibility of cycle arithmetic; no impossibility of a
matching-based bridge; no claim that the K--O theorems are wrong.

--------------------------------------------------------------------------------
6.  FAILED ROUTES DISCOVERED IN THIS RUN
--------------------------------------------------------------------------------
```
