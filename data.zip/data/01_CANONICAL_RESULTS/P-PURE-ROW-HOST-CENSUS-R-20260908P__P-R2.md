---
id: P-PURE-ROW-HOST-CENSUS-R-20260908P
logical_id: P-PURE-ROW-HOST-CENSUS-R-20260908P
version_id: P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P pure row host census r"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 720, line_end: 924}
metadata: {"stable_id": "P-PURE-ROW-HOST-CENSUS-R-20260908P", "version_id": "P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R2", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 720, "line_end": 924}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-PURE-ROW-HOST-CENSUS-20260908P", "P-PURE-ROW-HOST-CENSUS-R-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 720, "line_end": 924}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
---

# P pure row host census r

*Run P-R2 - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
       ID: P-PURE-ROW-HOST-CENSUS-R-20260908P    STATUS: VERIFIED COMPUTATION
       (implementation repaired: closure cap certified, see R7)
================================================================================
SCOPE.  The box of P3a decides more than s = 3: every host whose core contains a
pure row N - q = p^m (m >= 2) with partner q < sqrt N is found, whatever the
core size, once the three-element test is replaced by a full forward-closure
test.  By P3 this covers every 3-core; by P8-R it covers branch (I) of every
4-core; empirically it covers four of the six known hosts.
DOMAIN (stated as the enumeration box; the code has no N <= X filter).
   Q = p^m <= X with p an odd prime and m >= 2;  q an odd prime, q != p, with
   q^2 < Q + q.   Here X = 1e10.  The box covers every even N <= X and also
   tests some N in (X, X + sqrt X].  Prime list to sqrt(X) + 2.
ALGORITHM.  For each N = Q + q run the forward closure of q starting from its
unique child p, factoring each row by trial division plus Pollard rho with
deterministic Miller-Rabin, aborting on the first GOOD vertex.
If the closure exhausts, {q} together with the closure is a nonempty closed BAD
set, so N is a host.
REPAIR (R7).  The closure buffer is now 200000 entries, and TWO counters are
printed: closure overflows, and "large child" events (a prime factor of a BAD
row that is >= N/3, which thm:postJ-basin forbids, so the branch is dead code).
The census is valid only if both are zero.
VALIDATION.  On X = 1e7 and X = 2e8 the search returns exactly
     N = 128  via 128 - 3   = 5^3    (closure size 8  = core size)
     N = 128  via 128 - 7   = 11^2   (closure size 8)
     N = 1718 via 1718 - 37 = 41^2   (closure size 28 = core size)
     N = 1862 via 1862 - 13 = 43^2   (closure size 21 = core size)
     N = 2200 via 2200 - 3  = 13^3   (closure size 2)
     N = 2200 via 2200 - 13 = 3^7    (closure size 2)
and nothing else; overflows = 0, large-child events = 0.  It correctly misses
N = 1928 and N = 6142, whose cores have no pure row
(\tid{K-FAIL-PURE-ROW-IN-EVERY-CORE-01}).  Every recovered closure equals the
known core exactly -- an end-to-end check of P1, P3 and the implementation.
RESULT.  47 553 107 candidates tested over the box with X = 1e10, with
     closure-overflows = 0   and   large-child-events = 0,
so both internal cut-offs are certified never to have fired and the search is
exact on its domain.  Output is byte-identical to the uncertified run of
checkpoint P, so the R7 repair changed no result -- it supplied the missing
proof that none had been lost.
HITS.  Exactly six, and they are FOUR KNOWN HOSTS, each recovered with closure
equal to its known core:
     N = 128  via 128 - 3   = 5^3    (closure size 8)
     N = 128  via 128 - 7   = 11^2   (closure size 8)
     N = 1718 via 1718 - 37 = 41^2   (closure size 28)
     N = 1862 via 1862 - 13 = 43^2   (closure size 21)
     N = 2200 via 2200 - 3  = 13^3   (closure size 2)
     N = 2200 via 2200 - 13 = 3^7    (closure size 2)
CONCLUSION (exact scope, corrected -- see R9).  There is NO NEW host in the
pure-row/small-partner class for even N in the box: the only hosts whose core
contains a pure prime-power row with partner below sqrt(N) are the four already
known, 128, 1718, 1862 and 2200.  The result is a non-existence statement about
UNKNOWN hosts, not about such cores in general -- four of them exist and the
search returns all four.
WHAT IT DOES NOT SAY.  It says nothing about hosts whose core has no pure row
(the N = 1928 and N = 6142 type), nothing about non-minimal closed BAD sets with
a label above N/3, and nothing about N beyond the box.
CROSS-CHECK.  Combined with P3, the absence of any FIFTH hit re-derives the
s = 3 conclusion of E1-R up to 1e10 by a completely different test (full closure
instead of the three-element shape), since a three-element core would have
appeared here as a hit printing closure(|2|+q), i.e. two labels in the closure
plus the partner.  The only sizes printed were |1|+q (N = 2200, a two-element
core) and |7|, |27|, |20| plus q (the cores of 128, 1718, 1862).  None was
|2|+q.

--------------------------------------------------------------------------------
4.7  REPRODUCIBLE CODE
--------------------------------------------------------------------------------

--- basin and core (Python 3 + sympy) ---
from sympy import primerange, isprime, factorint
def basin(N):
    lim=(N-1)//3
    ps=[p for p in primerange(3,lim+1) if N%p]
    fac={p:factorint(N-p) for p in ps}
    alive={p:(not isprime(N-p)) and N-p>1 for p in ps}
    ch=True
    while ch:
        ch=False
        for p in ps:
            if alive[p]:
                for q in fac[p]:
                    if not alive.get(q,False): alive[p]=False; ch=True; break
    return sorted(p for p in ps if alive[p])
def core(N,B):
    Bs=set(B); adj={p:[q for q in factorint(N-p) if q in Bs] for p in B}
    def fwd(p):
        seen={p}; st=[p]
        while st:
            v=st.pop()
            for w in adj[v]:
                if w not in seen: seen.add(w); st.append(w)
        return seen
    for p in B:
        F=fwd(p)
        if all(fwd(q)==F for q in F): return sorted(F)

--- all perfect matchings, and the CORRECT quantifier for E3-R ---
def matchings(N,S):
    cand={q:[r for r in S if (N-q)%r==0] for q in S}
    out=[]
    def rec(i,used,assign):
        if i==len(S): out.append(dict(assign)); return
        q=S[i]
        for r in cand[q]:
            if r in used: continue
            used.add(r); assign[q]=r; rec(i+1,used,assign); used.discard(r); del assign[q]
    rec(0,set(),{})
    return out
# for each matching decompose into cycles, take max cycle product;
# report MIN of that over all matchings (checkpoint P wrongly reported MAX).
# involutive  <=>  some matching has all cycles of length 2.

--- three-element search (C), inner logic of E1-R ---
/* threecore.c header, corrected in P-R2 (repair R11/R12):
     EXHAUSTIVE FOR THREE-ELEMENT CORES via the P3a box, NOT for three-element
     closed BAD sets in general -- minimality is load-bearing, and the standing
     witness the box cannot see is N = 2200, S = {3,13,1471}, rows 13^3,3^7,3^6.
     Domain is the box Q = p^m <= X (m >= 2), q prime with q*q < Q+q; it covers
     every even N <= X and additionally tests some N in (X, X+sqrt X].  There is
     no explicit N <= X filter.  Hits are reported as TWO-ELEMENT-SET /
     THREE-ELEMENT-SET, since a hit verifies a closed BAD set of that size while
     the box decides the core class. */
/* p odd prime, Q = p^m <= X with m >= 2 ; q odd prime, q != p, q*q < Q+q */
N = Q + q;
Y = N - p;  Yp = Y;  while (Yp % q == 0) Yp /= q;
if (Yp == 1) { report_two_element(N,p,q); continue; }
z = primepower(Yp, &ez);
if (!z || z == p || z == q || z >= N/3) continue;
Z = N - z;  om = 0;
while (Z % p == 0) { Z /= p; om++; }
while (Z % q == 0) { Z /= q; om++; }
if (Z != 1 || om < 2) continue;
if (p >= N/3 || q >= N/3) continue;
report_three_element(N, p, q, z);
/* primepower(): trial division by odd primes < 512 with early exit on the
   first factor (if stripping it leaves 1 the number is a prime power, else
   reject); otherwise deterministic Miller-Rabin; otherwise test n = z^k for
   2 <= k <= log_512(n) by exact integer k-th roots. */

--- full closure test (C), inner logic of E5-R, with the R7 certificate ---
/* purecore2.c header, corrected in P-R2 (repair R9/R12): a run certifies
   "no host in the pure-row/small-partner class beyond those reported", never
   "no such core exists"; the four known hosts in the class ARE reported.
   Same box and same no-N-filter remark as threecore.c. */
W = {p}; ovf = 0; bigchild = 0;
for (each v in W, while no GOOD found) {
    m = N - v; factor(m);
    for (each prime f | m) {
        if (N % f == 0) continue;                 /* cannot happen, D3 */
        if (isprime(N - f)) { GOOD; break; }
        if (f >= N/3) { bigchild++; GOOD; break; }/* cannot happen, D1 */
        if (f not in W && f != q) {
            if (|W| >= MAXW) { ovf++; print("OVERFLOW"); GOOD; break; }
            W += f; } } }
/* the census is exact only if ovf == 0 and bigchild == 0; both are printed. */

--------------------------------------------------------------------------------
5.  HOSTILE CHECKS
--------------------------------------------------------------------------------

HC1.  Were the audit's four counterexamples reproduced before repair?
Yes, all four, independently (section 0).  N=128 with 53; N=2200 with
{3,13,1471}; the five-2-cycle cover of the N=6142 core; and the omitted pure
bases in P8.  None was accepted on trust.

HC2.  Does P1 survive the P2 defect?
Yes.  P1's proof uses only closure, BADness of q_1 and D3; no hypothesis on
max S.  The counterexample of R1 satisfies P1 (q_1 = 3, q_2 = 5, 25 <= 125).

HC3.  Does E1-R's completeness argument still hold after R2?
Yes, on the correct domain.  The chain is D4 => P3 (dichotomy, uses minimality)
=> the pure row's partner is q_1 or q_2 => P1 gives partner < sqrt N => the
enumeration is exhaustive FOR CORES.  Minimality enters at D4, which is a core
statement; checkpoint P forgot to carry that hypothesis into the conclusion.

HC4.  Is P5-R(c) itself vulnerable to a quantifier slip?
The theorem is a one-directional implication (involutive => product bound), and
the data are used only through its contrapositive.  The involutive/non-involutive
labels were obtained twice: by exhaustive matching enumeration, and independently
by the product criterion.  They agree.

HC5.  Does the E5-R certificate really certify completeness?
It certifies that the implementation's two internal cut-offs never fired.  It
does not certify the arithmetic of Pollard rho, which is deterministic here but
unproved in running time; a non-terminating rho would hang, not silently drop a
candidate.  It also does not extend the SCOPE: hosts whose cores have no pure
row with a small partner (the N = 1928 and N = 6142 type) are outside the box.

HC6.  Quantifier discipline.
P1, P3, P4-R, P5-R(a),(c), P7-R, P8-R are for-all statements about closed BAD
sets or cores with the stated domain hypothesis attached.  P2-R carries an
explicit hypothesis whose necessity is demonstrated.  P3a is a for-all-N
reduction to a finite enumeration; E1-R and E5-R are that enumeration on
explicitly stated finite domains, with the conclusion restricted to cores.
E2, E3-R, E4 are finite computations with stated domains.  Nothing is promoted
from computation to theorem.

HC7.  What is NOT claimed anywhere in this document.
No Goldbach proof; no finiteness of the host set; no all-N nonexistence of
three-element cores; no impossibility of cycle arithmetic; no impossibility of a
matching-based bridge; no claim that the K--O theorems are wrong.

--------------------------------------------------------------------------------
6.  FAILED ROUTES DISCOVERED IN THIS RUN
--------------------------------------------------------------------------------
```
