---
id: P-PURE-ROW-HOST-CENSUS-R2-20260908P
logical_id: P-PURE-ROW-HOST-CENSUS-R2-20260908P
version_id: P-PURE-ROW-HOST-CENSUS-R2-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P pure row host census r2"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION (E5-R, certified,"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1090, line_end: 1091}
metadata: {"stable_id": "P-PURE-ROW-HOST-CENSUS-R2-20260908P", "version_id": "P-PURE-ROW-HOST-CENSUS-R2-20260908P@P-R2", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 1090, "line_end": 1091}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-PURE-ROW-HOST-CENSUS-R-20260908P"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 1090, "line_end": 1091}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# P pure row host census r2

*Run P-R2 - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION (E5-R, certified,`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
P-PURE-ROW-HOST-CENSUS-R2-20260908P       VERIFIED COMPUTATION (E5-R, certified,
                                                                conclusion re-scoped)
```
