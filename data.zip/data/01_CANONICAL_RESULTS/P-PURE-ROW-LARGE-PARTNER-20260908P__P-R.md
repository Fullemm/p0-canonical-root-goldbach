---
id: P-PURE-ROW-LARGE-PARTNER-20260908P@P-R
logical_id: P-PURE-ROW-LARGE-PARTNER-20260908P
version_id: P-PURE-ROW-LARGE-PARTNER-20260908P@P-R
kind: historical-version
run: P-R
title: "P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION (counterexamples) / OPEN for cores.  UNCHANGED."
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 525, line_end: 560}
metadata: {"stable_id": "P-PURE-ROW-LARGE-PARTNER-20260908P", "version_id": "P-PURE-ROW-LARGE-PARTNER-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 525, "line_end": 560}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-PURE-ROW-LARGE-PARTNER-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 525, "line_end": 560}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 961, style: ID-TABLE}
---

# P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS

*Run P-R - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION (counterexamples) / OPEN for cores.  UNCHANGED.`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-PURE-ROW-LARGE-PARTNER-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS  ID: P-PURE-ROW-LARGE-PARTNER-20260908P
     STATUS: VERIFIED COMPUTATION (counterexamples) / OPEN for cores.  UNCHANGED.
================================================================================
QUESTION (Q-A).  If N - q = r^m is a pure row of a closed BAD set, must the
partner q be below sqrt N?  A positive answer for CORES would extend the E5
method to every core size that forces a pure row.

ANSWER for closed BAD sets: NO.  Exact counterexamples inside the known basins:
     N = 1718 : 1718 - 349  = 1369 = 37^2 ,  349  > sqrt(1718) = 41.4
     N = 1862 : 1862 - 181  = 1681 = 41^2 ,  181  > sqrt(1862) = 43.2
     N = 1928 : 1928 -  79  = 1849 = 43^2 ,   79  > sqrt(1928) = 43.9
     N = 6142 : 6142 - 1229 = 4913 = 17^3 , 1229  > sqrt(6142) = 78.4
In all four the partner lies in B_N but not in the core.  Refinement (exact):
two are sources of B_N (349 at N=1718 and 1229 at N=6142 have no parent at all),
but the other two are not -- 181 has parent 233 at N=1862, and 79 has parent 269
at N=1928, both alive in B_N.  They fail to be core elements because their
parents lie outside the terminal SCC.  So the right description is "upstream of
the core", not "source": a proof of (Q-A) for cores must use TERMINALITY, not
source-freeness, and certainly not closure alone.

ANSWER for cores: OPEN.  On all six known cores every pure row has its partner
in M:  128-3 = 5^3, 128-7 = 11^2, 1718-37 = 41^2, 1862-13 = 43^2,
2200-3 = 13^3, 2200-13 = 3^7; the cores at N = 1928 and N = 6142 have no pure
row at all.

--------------------------------------------------------------------------------
4.  COMPUTATIONAL EXPERIMENTS
--------------------------------------------------------------------------------

Environment: Python 3 + sympy 1.14 (exact integers) for verifications; C with
gcc -O3, 64-bit plus __int128, for the searches.  Primality: deterministic
Miller-Rabin with {2, 325, 9375, 28178, 450775, 9780504, 1795265022}, valid for
all n < 2^64.  No floating point enters an arithmetic decision (doubles only seed
integer roots, which are then corrected exactly).

================================================================================
```
