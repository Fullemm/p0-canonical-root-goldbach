---
id: P-PURE-ROW-LARGE-PARTNER-20260908P@P
logical_id: P-PURE-ROW-LARGE-PARTNER-20260908P
version_id: P-PURE-ROW-LARGE-PARTNER-20260908P@P
kind: historical-version
run: P
title: "P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION (counterexamples) / OPEN for cores"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 332, line_end: 366}
metadata: {"stable_id": "P-PURE-ROW-LARGE-PARTNER-20260908P", "version_id": "P-PURE-ROW-LARGE-PARTNER-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 332, "line_end": 366}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-PURE-ROW-LARGE-PARTNER-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 332, "line_end": 366}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 776, style: ID-TABLE}
---

# P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS

*Run P - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION (counterexamples) / OPEN for cores`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-PURE-ROW-LARGE-PARTNER-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P9.  (Q-A) IS FALSE FOR CLOSED BAD SETS  ID: P-PURE-ROW-LARGE-PARTNER-20260908P
     STATUS: VERIFIED COMPUTATION (counterexamples) / OPEN for cores
--------------------------------------------------------------------------------
QUESTION (Q-A).  If N - q = r^m is a pure row of a closed BAD set, must the
partner q be below sqrt N?  (A positive answer would extend the E1 method from
s = 3 to every core size that forces a pure row.)

ANSWER for closed BAD sets: NO.  Exact counterexamples inside the known basins:
     N = 1718 : 1718 - 349  = 1369 = 37^2 ,  349  > sqrt(1718) = 41.4
     N = 1862 : 1862 - 181  = 1681 = 41^2 ,  181  > sqrt(1862) = 43.2
     N = 1928 : 1928 -  79  = 1849 = 43^2 ,   79  > sqrt(1928) = 43.9
     N = 6142 : 6142 - 1229 = 4913 = 17^3 , 1229  > sqrt(6142) = 78.4
In all four the partner lies in B_N but NOT in the core.  Refinement (exact):
two of them are sources of B_N (349 at N=1718 and 1229 at N=6142 have no parent
at all below N/3), but the other two are NOT sources -- 181 has the parent 233
at N=1862, and 79 has the parent 269 at N=1928, both alive in B_N.  They fail to
be core elements because their unique parents lie outside the terminal SCC.  So
the correct description is "upstream of the core", not "source"; a proof of
(Q-A) for cores must use terminality, not source-freeness.

ANSWER for cores: OPEN.  On all six known cores every pure row has a partner in
M = S cap [3, sqrt N]:
     N=128  : 128-3 = 5^3 (partner 3), 128-7 = 11^2 (partner 7)
     N=1718 : 1718-37 = 41^2 (partner 37 < 41.4)
     N=1862 : 1862-13 = 43^2 (partner 13)
     N=2200 : both rows pure, partners 3 and 13
     N=1928, N=6142 : no pure row at all
SCOPE NOTE (important).  P9 shows that any proof of (Q-A) must use MINIMALITY of
the core, not merely closure.  This is the same lesson as
\tid{K-FAIL-HALL-WITHOUT-MINIMALITY-01}.  Do not attempt (Q-A) with closure
arguments alone; the four displayed rows are counterexamples to every such
attempt.

--------------------------------------------------------------------------------
P5.  CYCLE COVERS CARRY NO SIZE INFORMATION
```
