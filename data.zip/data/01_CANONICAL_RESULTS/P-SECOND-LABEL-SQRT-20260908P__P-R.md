---
id: P-SECOND-LABEL-SQRT-20260908P@P-R
logical_id: P-SECOND-LABEL-SQRT-20260908P
version_id: P-SECOND-LABEL-SQRT-20260908P@P-R
kind: historical-version
run: P-R
title: "P1.  SECOND-LABEL SQUARE BOUND"
status: SUPERSEDED
status_raw: "PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 150, line_end: 186}
metadata: {"stable_id": "P-SECOND-LABEL-SQRT-20260908P", "version_id": "P-SECOND-LABEL-SQRT-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 150, "line_end": 186}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-SECOND-LABEL-SQRT-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 150, "line_end": 186}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 953, style: ID-TABLE}
---

# P1.  SECOND-LABEL SQUARE BOUND

*Run P-R - status `SUPERSEDED` (raw: `PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-SECOND-LABEL-SQRT-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P1.  SECOND-LABEL SQUARE BOUND         ID: P-SECOND-LABEL-SQRT-20260908P
     STATUS: PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)
================================================================================
STATEMENT.  Let S be a closed BAD set with |S| >= 2, and q_1 < q_2 its two
smallest elements.  Then
        q_2^2  <=  N - q_1 ,        and     2N/3 < N - q_1 < N ,
hence
        q_1 < q_2 <= sqrt(N - q_1) < sqrt(N).
More generally, for every q in S the row N - q is composite, so
        min PF(N - q)  <=  sqrt(N - q)  <  sqrt(N),
and min PF(N - q) lies in S.

PROOF.  q_1 is BAD, so N - q_1 is composite and exceeds 1.  By closure every
prime factor of N - q_1 lies in S, and by D3 none equals q_1; hence every prime
factor is at least q_2.  A composite integer whose least prime factor is at
least q_2 is at least q_2^2.  For the second display, min S < N/3 by the
standing fact, so N - q_1 > 2N/3.  The general statement is the same argument
applied to an arbitrary q in S.                                            QED

REMARK.  No hypothesis on max S is used, so R1 does not touch P1.  The related
corpus statement \tid{V81-C2-RESIDUAL} bounds min R' for one derived world of
the v4.81 chain; P1 bounds the SECOND smallest label of an arbitrary closed BAD
set, which is what section 4 needs.  The argument is two lines and no priority
is claimed for the technique.

COROLLARY P1a.  Every closed BAD set has at least two labels below sqrt(N).
COROLLARY P1b.  The BASE of any pure row of any closed BAD set is below sqrt N:
  if N - q_i = q_j^m then q_j^m < N and q_j^m > 2N/3 forces m >= 2 (because
  q_j < N/3 by D1 applied to the row containing it), so q_j <= N^{1/m} <= sqrt N.
  If m = 2 then q_j lies in the window (sqrt(2N/3), sqrt N).

VERIFIED on the six hosts for both B_N and the core:
   N=128  q1=3  q2=5   N-q1=125  minPF=5      N=1928 q1=3 q2=5  N-q1=1925 minPF=5
   N=1718 q1=3  q2=5   N-q1=1715 minPF=5      N=2200 q1=3 q2=13 N-q1=2197 minPF=13
   N=1862 q1=3  q2=5   N-q1=1859 minPF=11     N=6142 q1=3 q2=5  N-q1=6139 minPF=7

================================================================================
```
