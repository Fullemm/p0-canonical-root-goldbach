---
id: P-SECOND-LABEL-SQRT-20260908P
logical_id: P-SECOND-LABEL-SQRT-20260908P
version_id: P-SECOND-LABEL-SQRT-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P1.  SECOND-LABEL SQUARE BOUND"
status: PROVED
status_raw: "PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 208, line_end: 265}
metadata: {"stable_id": "P-SECOND-LABEL-SQRT-20260908P", "version_id": "P-SECOND-LABEL-SQRT-20260908P@P-R2", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 208, "line_end": 265}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-SECOND-LABEL-SQRT-20260908P@P", "P-SECOND-LABEL-SQRT-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 208, "line_end": 265}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R, P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1078, style: ID-TABLE}
---

# P1.  SECOND-LABEL SQUARE BOUND

*Run P-R2 - status `PROVED` (raw: `PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
P1.  SECOND-LABEL SQUARE BOUND         ID: P-SECOND-LABEL-SQRT-20260908P
     STATUS: PROVED.  Domain: every closed BAD set.  (UNCHANGED from P.)
================================================================================
STATEMENT.  Let S be a closed BAD set with |S| >= 2, and q_1 < q_2 its two
smallest elements.  Then
        q_2^2  <=  N - q_1 ,        and     2N/3 < N - q_1 < N ,
hence
        q_1 < q_2 <= sqrt(N - q_1) < sqrt(N).
More generally, for every q in S the row N - q is composite, so
        min PF(N - q)  <=  sqrt(N - q)  <  sqrt(N),
and min PF(N - q) lies in S.

PROOF.  q_1 is BAD, so N - q_1 is composite and exceeds 1.  By closure every
prime factor of N - q_1 lies in S, and by D3 none equals q_1; hence every prime
factor is at least q_2.  A composite integer whose least prime factor is at
least q_2 is at least q_2^2.  For the second display, min S < N/3 by the
standing fact, so N - q_1 > 2N/3.  The general statement is the same argument
applied to an arbitrary q in S.                                            QED

REMARK.  No hypothesis on max S is used, so R1 does not touch P1.  The related
corpus statement \tid{V81-C2-RESIDUAL} bounds min R' for one derived world of
the v4.81 chain; P1 bounds the SECOND smallest label of an arbitrary closed BAD
set, which is what section 4 needs.  The argument is two lines and no priority
is claimed for the technique.

COROLLARY P1a.  Every closed BAD set has at least two labels below sqrt(N).

COROLLARY P1b (universal; no hypothesis on the partner).  Let S be a closed BAD
set and let N - q_i = q_j^m be a pure row.  Then m >= 2 and
        q_j  <=  N^{1/m}  <=  sqrt(N).
PROOF.  q_i is BAD, so N - q_i is composite; a composite prime power has
exponent m >= 2.  Then q_j^m = N - q_i < N gives q_j <= N^{1/m} <= sqrt N.  QED
Note that m >= 2 follows from COMPOSITENESS alone; checkpoint P-R derived it
from a size comparison with 2N/3, which is not available in general.

COROLLARY P1c (the square window; HYPOTHESIS: the partner satisfies q_i < N/3,
which is automatic for source-free sets, hence for every core).  Under that
hypothesis N - q_i > 2N/3, so if m = 2 then
        sqrt(2N/3)  <  q_j  <  sqrt(N).
WHY THE HYPOTHESIS IS NECESSARY.  N = 128, q_i = 103: 128 - 103 = 25 = 5^2, and
S = {3,5,7,11,13,23,29,41,103} (the core together with 103) is a closed BAD set.
The base 5 satisfies P1b (5 < 11.314) but violates the window (5 < 9.238),
because 103 > N/3 = 42.67 makes N - 103 = 25 smaller than 2N/3 = 85.33.
On all pure rows of the six known cores the window does hold, as it must:
128-7 = 11^2 (11 > 9.24), 1718-37 = 41^2 (41 > 33.85), 1862-13 = 43^2
(43 > 35.23); the rows 128-3 = 5^3, 2200-3 = 13^3 and 2200-13 = 3^7 have m >= 3,
where no window is asserted.
LOAD-BEARING?  No.  P1b is used in P3a and P8-R only through its universal half,
and even that is a remark rather than a premise: the searches of section 4
enumerate every base p with p^2 <= X regardless, so their completeness rests on
the PARTNER bound of P1 alone.  P1c is used nowhere.

VERIFIED on the six hosts for both B_N and the core:
   N=128  q1=3  q2=5   N-q1=125  minPF=5      N=1928 q1=3 q2=5  N-q1=1925 minPF=5
   N=1718 q1=3  q2=5   N-q1=1715 minPF=5      N=2200 q1=3 q2=13 N-q1=2197 minPF=13
   N=1862 q1=3  q2=5   N-q1=1859 minPF=11     N=6142 q1=3 q2=5  N-q1=6139 minPF=7

================================================================================
```
