---
id: P-SECOND-LABEL-SQRT-20260908P@P
logical_id: P-SECOND-LABEL-SQRT-20260908P
version_id: P-SECOND-LABEL-SQRT-20260908P@P
kind: historical-version
run: P
title: "P1.  SECOND-LABEL SQUARE BOUND"
status: SUPERSEDED
status_raw: "PROVED"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 99, line_end: 142}
metadata: {"stable_id": "P-SECOND-LABEL-SQRT-20260908P", "version_id": "P-SECOND-LABEL-SQRT-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 99, "line_end": 142}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-SECOND-LABEL-SQRT-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 99, "line_end": 142}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 773, style: ID-TABLE}
---

# P1.  SECOND-LABEL SQUARE BOUND

*Run P - status `SUPERSEDED` (raw: `PROVED`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-SECOND-LABEL-SQRT-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P1.  SECOND-LABEL SQUARE BOUND          ID: P-SECOND-LABEL-SQRT-20260908P
     STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S be a closed BAD set with |S| >= 2 and let q_1 < q_2 be its two
smallest elements.  Then
        q_2^2  <=  N - q_1  <  N ,
hence
        q_1 < q_2 <= sqrt(N - q_1) < sqrt(N).
More generally, for every q in S,
        min PF(N-q)  <=  sqrt(N-q)  <  sqrt(N),
and min PF(N-q) lies in S; so every row of S has its least prime factor in
S cap [3, sqrt N).

PROOF.  Since q_1 is BAD, N - q_1 is composite and > 1.  By closure every prime
factor of N - q_1 lies in S, and by auto-activity (D3) none of them equals q_1;
therefore every prime factor of N - q_1 is at least q_2.  A composite integer
all of whose prime factors are >= q_2 is at least q_2^2.  Hence
q_2^2 <= N - q_1 < N.  The general statement is the same argument applied to an
arbitrary q in S: N-q is composite, so its least prime factor is at most
sqrt(N-q), and it lies in S by closure.                                     QED

REMARK (relation to the corpus).  The master contains a superficially similar
statement, \tid{V81-C2-RESIDUAL}: the primitive residual world R' satisfies
min R' < sqrt N.  That is a statement about the MINIMUM of one particular
derived world in the v4.81 chain.  P1 bounds the SECOND smallest label of an
arbitrary closed BAD set and is what makes section 4 a complete search.  No
priority is claimed; the argument is two lines.

COROLLARY P1a.  Every closed BAD set has at least two labels below sqrt(N).
COROLLARY P1b.  If S is closed and BAD and N - q_1 = q_j^m is a pure prime
power, then q_j >= q_2 and q_j^m > 2N/3, so m >= 2 and q_j < sqrt(N).
  (If m = 2 then q_j lies in the narrow window (sqrt(2N/3), sqrt N).)
COROLLARY P1c.  The base of ANY pure row of any closed BAD set is < sqrt(N):
  N - q_i = q_j^m with m >= 2 and q_j^m < N gives q_j <= N^{1/m} <= sqrt(N).

VERIFIED on the six known hosts, for both the full basin B_N and its core:
   N=128  q1=3  q2=5   N-q1=125  minPF=5
   N=1718 q1=3  q2=5   N-q1=1715 minPF=5
   N=1862 q1=3  q2=5   N-q1=1859 minPF=11
   N=1928 q1=3  q2=5   N-q1=1925 minPF=5
   N=2200 q1=3  q2=13  N-q1=2197 minPF=13   (here q_2^2 = 169 <= 2197, sharp-ish)
   N=6142 q1=3  q2=5   N-q1=6139 minPF=7

--------------------------------------------------------------------------------
```
