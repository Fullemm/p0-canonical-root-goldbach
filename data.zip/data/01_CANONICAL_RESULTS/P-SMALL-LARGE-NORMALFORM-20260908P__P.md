---
id: P-SMALL-LARGE-NORMALFORM-20260908P
logical_id: P-SMALL-LARGE-NORMALFORM-20260908P
version_id: P-SMALL-LARGE-NORMALFORM-20260908P@P
kind: canonical-result
run: P
title: "P2.  SMALL/LARGE ROW NORMAL FORM"
status: SUPERSEDED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 143, line_end: 192}
metadata: {"stable_id": "P-SMALL-LARGE-NORMALFORM-20260908P", "version_id": "P-SMALL-LARGE-NORMALFORM-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 143, "line_end": 192}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-SMALL-LARGE-NORMALFORM-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 143, "line_end": 192}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-SMALL-LARGE-NORMALFORM-R-20260908P
supersession_reason: "stated without the hypothesis max S < N/3"
supersession_witness: "N=128, S = core u {53} = {3,5,7,11,13,23,29,41,53} is a closed BAD set with 128-53 = 75 = 3*5^2. Since 53 > N/3 = 42.67 the small/large partition fails, and N-53 = 75 < 2N/3 = 85.3 so clause (iii) fails too."
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 777, style: ID-TABLE}
---

# P2.  SMALL/LARGE ROW NORMAL FORM

*Run P - status `SUPERSEDED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-SMALL-LARGE-NORMALFORM-R-20260908P` (run `P-R2`).
>
> **Defect:** stated without the hypothesis max S < N/3
>
> **Witness:** N=128, S = core u {53} = {3,5,7,11,13,23,29,41,53} is a closed BAD set with 128-53 = 75 = 3*5^2. Since 53 > N/3 = 42.67 the small/large partition fails, and N-53 = 75 < 2N/3 = 85.3 so clause (iii) fails too.

## Source transcript (historical wording; apply current metadata)

```
P2.  SMALL/LARGE ROW NORMAL FORM        ID: P-SMALL-LARGE-NORMALFORM-20260908P
     STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S be a closed BAD set.  Put
        M = S cap [3, sqrt N],        L = S cap (sqrt N, N/3).
Then S = M u L, |M| >= 2, and for every q in S the row factors uniquely as
        N - q  =  c_q * lambda_q,
where
   (i)   c_q is Gamma_M-smooth (all its prime factors lie in M);
   (ii)  lambda_q is 1 or a single prime l in L, occurring to the FIRST power;
   (iii) if lambda_q = l then c_q = (N-q)/l lies in the interval
             ( 2N/(3l),  N/l )  which is contained in ( 0, sqrt N );
   (iv)  min PF(N-q) lies in M.
Consequently no row contains two large labels, and every row is
(M-smooth) x (at most one large prime).

PROOF.  (ii) If l, l' > sqrt N both divided N-q then N-q >= l l' > N, but
N - q < N.  The same inequality gives v_l(N-q) = 1.  (i) The prime factors of
N-q below sqrt N lie in S by closure, hence in M.  (iii) is
2N/3 < N-q < N divided by l.  (iv) is P1.                                   QED

COROLLARY P2a (large-label incidence budget).  Let
   indeg(l) = #{ q in S : l | N-q }.  Then
        sum_{l in L} indeg(l)  <=  |S|,
because each row contributes at most one large label, and every l in L has
indeg(l) >= 1 in a core (source-freeness).  Hence
        #{ l in L : indeg(l) >= 2 }  <=  |M|.

COROLLARY P2b.  If |M| = 2, say M = {q_1,q_2}, then every row is
q_1^a q_2^b l or q_1^a q_2^b, and the row of q_1 is q_2^a l or q_2^a
(no q_1 by auto-activity), likewise for q_2.

VERIFIED on all six cores (exact computation):
   N     s   sqrtN  |M| |L|   M                              incidences  #indeg>=2
   128   8    11     4   4    {3,5,7,11}                          4          0
   1718  28   41    10  18    {3,5,7,11,13,17,29,31,37,41}       19          1
   1862  21   43     7  14    {3,5,11,13,17,41,43}               15          1
   1928  14   43     6   8    {3,5,7,11,13,17}                    8          0
   2200  2    46     2   0    {3,13}                              0          0
   6142  10   78     6   4    {3,5,7,13,17,19}                    4          0
In every case: at most one large label per row, all large exponents equal 1,
min PF of every row in M, incidences <= s, and #indeg>=2 is 0 or 1 (the proved
bound |M| is 2..10, so the truth is much sharper than the bound).
The observed |M| is small and stable (2 to 10) while |L| ranges 0 to 18.
NOTE (a natural guess that is FALSE): rows of large labels need NOT be
M-smooth.  Counterexamples inside the cores: at N=128, 13 | N-23 with 23 in L;
at N=1718 thirteen large labels have a large parent.  So the core is not a
two-level object; only N=2200 and N=6142 happen to be two-level.

--------------------------------------------------------------------------------
```
