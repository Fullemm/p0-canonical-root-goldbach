---
id: P-SMALL-LARGE-NORMALFORM-R-20260908P@P-R
logical_id: P-SMALL-LARGE-NORMALFORM-R-20260908P
version_id: P-SMALL-LARGE-NORMALFORM-R-20260908P@P-R
kind: historical-version
run: P-R
title: "P2-R.  SMALL/LARGE ROW NORMAL FORM"
status: SUPERSEDED
status_raw: "PROVED.  Domain: closed BAD sets with max S < N/3"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 187, line_end: 243}
metadata: {"stable_id": "P-SMALL-LARGE-NORMALFORM-R-20260908P", "version_id": "P-SMALL-LARGE-NORMALFORM-R-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 187, "line_end": 243}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-SMALL-LARGE-NORMALFORM-R-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 187, "line_end": 243}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 954, style: ID-TABLE}
---

# P2-R.  SMALL/LARGE ROW NORMAL FORM

*Run P-R - status `SUPERSEDED` (raw: `PROVED.  Domain: closed BAD sets with max S < N/3`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-SMALL-LARGE-NORMALFORM-R-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P2-R.  SMALL/LARGE ROW NORMAL FORM     ID: P-SMALL-LARGE-NORMALFORM-R-20260908P
     STATUS: PROVED.  Domain: closed BAD sets with max S < N/3
     (automatic for source-free sets, hence for every core).
     This REPLACES P2 of checkpoint P, which omitted the hypothesis.
================================================================================
HYPOTHESIS (necessary; see the counterexample below).  max S < N/3.

STATEMENT.  Put M = S cap [3, sqrt N] and L = S cap (sqrt N, N/3).  Then
S = M u L is a partition, |M| >= 2, and for every q in S the row factors
uniquely as
        N - q  =  c_q * lambda_q ,
where
   (i)   c_q is Gamma_M-smooth (every prime factor of c_q lies in M);
   (ii)  lambda_q is either 1 or a single prime l in L occurring to the FIRST
         power;
   (iii) if lambda_q = l then c_q = (N-q)/l lies in ( 2N/(3l), N/l ), which is
         contained in (0, sqrt N);
   (iv)  min PF(N - q) lies in M.
In particular no row contains two large labels.

PROOF.  S = M u L is a partition because max S < N/3 and no label equals
exactly sqrt N (labels are primes; if q^2 = N then q | N, contradicting
activity).  |M| >= 2 is P1a.  (ii): if l, l' > sqrt N both divided N - q then
N - q >= l l' > N, while N - q < N; the same inequality gives v_l(N-q) = 1.
(i): a prime factor of N - q below sqrt N lies in S by closure, hence in M; a
prime factor above sqrt N lies in S, hence in L since max S < N/3.  (iii): the
hypothesis gives q < N/3, so N - q > 2N/3; divide by l.  (iv) is P1.       QED

WHY THE HYPOTHESIS IS NECESSARY.  N = 128, S = {3,5,7,11,13,23,29,41,53} is a
closed BAD set (128 - 53 = 75 = 3 * 5^2).  Here 53 > N/3 = 42.67, so 53 is in
neither M nor L and the partition fails; and N - 53 = 75 < 2N/3 = 85.3, so (iii)
fails.  Checkpoint P asserted P2 without this hypothesis and was wrong.

COROLLARY P2a (large-label incidence budget; same hypothesis, plus
source-freeness).  With indeg(l) = #{q in S : l | N-q},
        sum_{l in L} indeg(l)  <=  |S| ,
since each row contributes at most one large label; and indeg(l) >= 1 for every
l in L by source-freeness.  Hence
        #{ l in L : indeg(l) >= 2 }  <=  |M|.

VERIFIED on all six cores (which satisfy the hypothesis):
   N     s   sqrtN |M| |L|  M                              incidences  #indeg>=2
   128   8    11    4   4   {3,5,7,11}                          4          0
   1718  28   41   10  18   {3,5,7,11,13,17,29,31,37,41}       19          1
   1862  21   43    7  14   {3,5,11,13,17,41,43}               15          1
   1928  14   43    6   8   {3,5,7,11,13,17}                    8          0
   2200  2    46    2   0   {3,13}                              0          0
   6142  10   78    6   4   {3,5,7,13,17,19}                    4          0
All four clauses hold in every case.  Observed |M| is small and stable (2 to 10)
while |L| ranges 0 to 18.

NOTE (a natural guess that is FALSE).  Rows of large labels need NOT be
M-smooth: at N = 128 the large label 13 divides the row of the large label 23,
and at N = 1718 thirteen of the eighteen large labels have a large parent.  Only
N = 2200 and N = 6142 happen to be two-level.

================================================================================
```
