---
id: P-THREE-CORE-COPRIME-EXPONENTS-20260908P
logical_id: P-THREE-CORE-COPRIME-EXPONENTS-20260908P
version_id: P-THREE-CORE-COPRIME-EXPONENTS-20260908P@P
kind: canonical-result
run: P
title: "P three core coprime exponents"
status: SUPERSEDED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 236, line_end: 267}
metadata: {"stable_id": "P-THREE-CORE-COPRIME-EXPONENTS-20260908P", "version_id": "P-THREE-CORE-COPRIME-EXPONENTS-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 236, "line_end": 267}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 236, "line_end": 267}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P
supersession_reason: "P4 -> P4-R: the gcd(b,c) = 1 argument was expanded to cover the parity sub-case; statement unchanged, proof completed"
---

# P three core coprime exponents

*Run P - status `SUPERSEDED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P` (run `P-R2`).
>
> **Defect:** P4 -> P4-R: the gcd(b,c) = 1 argument was expanded to cover the parity sub-case; statement unchanged, proof completed

## Source transcript (historical wording; apply current metadata)

```
     ID: P-THREE-CORE-COPRIME-EXPONENTS-20260908P     STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Suppose a 3-core has all three rows pure:
        N - q_1 = q_3^a,   N - q_2 = q_1^b,   N - q_3 = q_2^c
(this is sub-case (A) with R_1 = {q_3} and R_3 = {q_2}).  Then
        2 <= a < c < b,     gcd(a,b) = gcd(b,c) = gcd(a,c) = 1,
so in particular a >= 2, c >= 3, b >= 4, and (a,c,b) is a pairwise coprime
increasing triple.  Furthermore q_3 = max S <= N^{1/a} <= sqrt N, so ALL THREE
labels are below sqrt(N) and the three prime powers lie in (2N/3, N), pairwise
within q_3 <= sqrt N of one another:
        q_3^a - q_1^b = q_2 - q_1,
        q_1^b - q_2^c = q_3 - q_2,
        q_3^a - q_2^c = q_3 - q_1,     all positive and < q_3.

PROOF.  The three displayed differences are (N-q_1)-(N-q_2) etc., so they are
positive and bounded by q_3 - q_1 < q_3.  Since q_3^a = N-q_1 < N and a >= 2 we
get q_3 <= N^{1/a} <= sqrt N; the same for q_1^b, q_2^c gives q_1 <= N^{1/b},
q_2 <= N^{1/c}; with q_1 < q_2 < q_3 and all three powers within a factor 3/2 of
each other this forces b > c > a.
For coprimality: let g = gcd(a,b), x = q_3^{a/g}, y = q_1^{b/g}, so
x^g - y^g = q_2 - q_1 > 0 and x > y >= 2.  Then
x^g - y^g >= x^{g-1}(x-y) >= x^{g-1} = q_3^{a(g-1)/g}.
But x^g - y^g = q_2 - q_1 < q_3, so q_3^{a(g-1)/g} < q_3, i.e. a(g-1) < g.
With a >= 2 this gives 2(g-1) < g, i.e. g < 2, so g = 1.
The pairs (b,c) and (a,c) are handled identically, using
q_1^b, q_2^c > 2N/3 > (2/3) q_3^a and the same bound q_3 for the difference.  QED

REMARK.  This kills, for example, every pattern with a = 2 and b even -- in
particular the "difference of two squares" shape -- without any computation.


--------------------------------------------------------------------------------
```
