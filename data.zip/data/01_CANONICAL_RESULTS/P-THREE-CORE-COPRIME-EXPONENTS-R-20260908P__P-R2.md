---
id: P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P
logical_id: P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P
version_id: P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "P three core coprime exponents r"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 360, line_end: 440}
metadata: {"stable_id": "P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P", "version_id": "P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P@P-R2", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 360, "line_end": 440}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-THREE-CORE-COPRIME-EXPONENTS-20260908P", "P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 360, "line_end": 440}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
---

# P three core coprime exponents r

*Run P-R2 - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
     ID: P-THREE-CORE-COPRIME-EXPONENTS-R-20260908P    STATUS: PROVED
     (proof completed; the gcd(b,c) case now treated in full)
================================================================================
STATEMENT.  Suppose a 3-core has all three rows pure:
        N - q_1 = q_3^a,      N - q_2 = q_1^b,      N - q_3 = q_2^c .
Then, writing N >= 6,
   (1) a >= 2 and q_3 <= N^{1/a} <= sqrt N, so ALL THREE labels are below sqrt N;
   (2) gcd(a,b) = gcd(a,c) = gcd(b,c) = 1;
   (3) 2 <= a < c < b.
Moreover the three prime powers lie in (2N/3, N) and satisfy
        q_3^a - q_1^b = q_2 - q_1,   q_1^b - q_2^c = q_3 - q_2,
        q_3^a - q_2^c = q_3 - q_1,
all three differences positive and strictly below q_3.

PROOF.
Set A = q_3^a = N-q_1, B = q_1^b = N-q_2, C = q_2^c = N-q_3.  Since
q_1 < q_2 < q_3 we get A > B > C, and the three displayed differences are
(N-q_1)-(N-q_2) etc., hence positive and at most q_3 - q_1 < q_3.  All three
lie in (2N/3, N) because every label is below N/3 (D1, cores are source-free).

(1)  q_3 < N/3, so q_3^1 < 2N/3 < A; hence a >= 2.  Then q_3 = A^{1/a} <=
N^{1/a} <= sqrt N.  Since q_1 < q_2 < q_3 this bounds all three labels.

(2a) gcd(a,b) = 1.  Let g = gcd(a,b), x = q_3^{a/g}, y = q_1^{b/g}, so
x^g - y^g = A - B = q_2 - q_1 > 0 and x > y >= 2.  Using
x^g - y^g = (x-y) * sum_{i=0}^{g-1} x^i y^{g-1-i}  >=  1 * x^{g-1},
we get x^{g-1} <= q_2 - q_1 < q_3, i.e. q_3^{a(g-1)/g} < q_3, i.e.
a(g-1)/g < 1, i.e. a(g-1) < g.  With a >= 2 this gives 2g - 2 < g, so g < 2 and
g = 1.

(2b) gcd(a,c) = 1.  Identical with y = q_2^{c/g} and x^g - y^g = A - C =
q_3 - q_1 < q_3; the bound x^{g-1} <= q_3 - q_1 < q_3 again gives a(g-1) < g.
(The reason this repeats verbatim is that in BOTH cases the larger power is
A = q_3^a, so x is a power of q_3 and the exponent bookkeeping is the same.
This is NOT the situation in (2c).)

(2c) gcd(b,c) = 1.  Here the larger power is B = q_1^b, whose base q_1 is the
SMALLEST label, so the argument of (2a) is unavailable: q_1^{b(g-1)/g} < q_3
does not force g = 1, because q_1 may be far below q_3.  Argue instead by size.
Let g = gcd(b,c) >= 2, x = q_1^{b/g}, y = q_2^{c/g}, so
        x^g - y^g = B - C = q_3 - q_2,     x > y >= 2.
As above x^{g-1} <= x^g - y^g = q_3 - q_2 < q_3, while x^g = B = N - q_2 > 2N/3,
so x > (2N/3)^{1/g} and therefore
        (2N/3)^{(g-1)/g}  <  x^{g-1}  <  q_3  <=  N^{1/a}          (by (1)).
   * If g >= 3 then (g-1)/g >= 2/3 and 1/a <= 1/2, so
     (2/3)^{2/3} N^{2/3} < N^{1/2}, i.e. N^{1/6} < (3/2)^{2/3} = 1.3104,
     i.e. N < 1.3104^6 = 5.06.  Impossible for N >= 6.
   * If g = 2 and a >= 3 then (2N/3)^{1/2} < N^{1/3}, i.e.
     N^{1/6} < (3/2)^{1/2} = 1.2247, i.e. N < 3.38.  Impossible.
   * If g = 2 and a = 2, the size argument is inconclusive and we use parity.
     Here x = q_1^{b/2} and y = q_2^{c/2} are both ODD (powers of odd primes),
     so x - y is EVEN.  On the other hand
        (x - y)(x + y) = x^2 - y^2 = q_3 - q_2 < q_3 <= N^{1/2} = sqrt N,
     while x^2 = B > 2N/3 gives x > sqrt(2N/3), hence
        x + y > x > sqrt(2/3) * sqrt N = 0.81649 * sqrt N .
     Therefore
        x - y  <  sqrt N / (0.81649 sqrt N)  =  1.2248 ,
     so the positive integer x - y equals 1, which is odd -- contradicting that
     x - y is even.
   All three sub-cases are impossible, so g = 1.

(3)  b > c: from B > C, B = q_1^b, C = q_2^c and q_1 < q_2 we get
     b log q_1 = c log q_2 + log(B/C) > c log q_2 > c log q_1, so b > c.
     c >= a: B/C and A/C lie in (1, 3/2) because
     A/C = (N-q_1)/(N-q_3) = 1 + (q_3-q_1)/(N-q_3) < 1 + (N/3)/(2N/3) = 3/2.
     Writing c log q_2 = a log q_3 - eps with 0 < eps < log(3/2) and using
     log q_2 < log q_3,
        c  =  (a log q_3 - eps)/log q_2  >  (a log q_3 - eps)/log q_3
           =  a - eps/log q_3  >  a - log(3/2)/log 7  =  a - 0.2083,
     since q_3 >= 7 (three distinct odd primes).  As c is an integer, c >= a;
     and c = a is excluded by gcd(a,c) = 1 together with a >= 2.  Hence c > a.
     The same computation with A/B in place of A/C gives b >= a, which is
     implied by b > c > a.                                                 QED

REMARK.  (2) already kills, with no computation, every pattern with a = 2 and b
even -- in particular the difference-of-two-squares shape.  The all-pure
sub-case is empty in the search range of E1, so P4-R is at present a structural
statement with no known instance.

================================================================================
P5-R.  WHAT THE CYCLE COVER DOES AND DOES NOT GIVE
```
