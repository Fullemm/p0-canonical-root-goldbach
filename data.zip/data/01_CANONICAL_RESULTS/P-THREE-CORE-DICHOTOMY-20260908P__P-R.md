---
id: P-THREE-CORE-DICHOTOMY-20260908P@P-R
logical_id: P-THREE-CORE-DICHOTOMY-20260908P
version_id: P-THREE-CORE-DICHOTOMY-20260908P@P-R
kind: historical-version
run: P-R
title: "P3.  EXACT THREE-CORE DICHOTOMY"
status: SUPERSEDED
status_raw: "PROVED.  Domain: cores of size 3.  (UNCHANGED from P.)"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 244, line_end: 280}
metadata: {"stable_id": "P-THREE-CORE-DICHOTOMY-20260908P", "version_id": "P-THREE-CORE-DICHOTOMY-20260908P@P-R", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 244, "line_end": 280}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-THREE-CORE-DICHOTOMY-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R.txt", "line": 244, "line_end": 280}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
supersedes_runs: [P]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R.txt", line: 955, style: ID-TABLE}
---

# P3.  EXACT THREE-CORE DICHOTOMY

*Run P-R - status `SUPERSEDED` (raw: `PROVED.  Domain: cores of size 3.  (UNCHANGED from P.)`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-THREE-CORE-DICHOTOMY-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P3.  EXACT THREE-CORE DICHOTOMY        ID: P-THREE-CORE-DICHOTOMY-20260908P
     STATUS: PROVED.  Domain: cores of size 3.  (UNCHANGED from P.)
================================================================================
STATEMENT.  Let S = {q_1 < q_2 < q_3} be a core.  Then exactly one of:

 (A)  q_3 in R_1 and q_3 not in R_2.  Then R_2 = {q_1}, i.e.
          N - q_2 = q_1^b   with b >= 2;
      R_1 is {q_3} or {q_2,q_3}; R_3 is a nonempty subset of {q_1,q_2}.
      If R_1 = {q_3} then source-freeness forces q_2 in R_3.
 (B)  q_3 in R_2 and q_3 not in R_1.  Then R_1 = {q_2}, i.e.
          N - q_1 = q_2^a   with a >= 2;
      R_2 is {q_3} or {q_1,q_3}; R_3 is a nonempty subset of {q_1,q_2}.
      If R_2 = {q_3} then source-freeness forces q_1 in R_3.

In case (A) the pure row is N - q_2, with PARTNER q_2 and BASE q_1; in case (B)
it is N - q_1, with partner q_1 and base q_2.  In both cases partner and base
lie in {q_1, q_2}, hence are below sqrt N by P1.

PROOF.  By D4 the maximal label q_3 divides exactly one row of a core, and by D3
not its own; so q_3 lies in exactly one of R_1, R_2.  If q_3 is in R_1 then R_2
is a nonempty subset of {q_1,q_3} \ {q_3} = {q_1}, so N - q_2 is a power of q_1,
composite by BADness, so b >= 2.  Case (B) is symmetric.  The source-freeness
remarks are immediate.  The final sentence is P1 applied to q_1 < q_2.     QED

COROLLARY P3a (the search box).  Every even N carrying a THREE-ELEMENT CORE
satisfies
        N = p^m + q,     p, q distinct odd primes,  m >= 2,  q < sqrt(N),
with p^m > 2N/3 and (by P1b) p < sqrt(N) as well.  Hence enumerating all pairs
(prime power p^m <= X with m >= 2; prime q with q^2 < p^m + q) is a COMPLETE
decision procedure for the existence of a three-element CORE among even N <= X.
This is a theorem-produced box, not a numerical cutoff.
SCOPE.  It says nothing about three-element closed BAD sets that are not
minimal; N = 2200 with S = {3,13,1471} is exactly such a set and is invisible to
the box because 1471 > sqrt(2200).

================================================================================
P4-R.  EXPONENTS IN THE ALL-PURE THREE-CORE
```
