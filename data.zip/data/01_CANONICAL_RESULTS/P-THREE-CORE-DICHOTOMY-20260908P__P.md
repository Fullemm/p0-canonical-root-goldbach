---
id: P-THREE-CORE-DICHOTOMY-20260908P@P
logical_id: P-THREE-CORE-DICHOTOMY-20260908P
version_id: P-THREE-CORE-DICHOTOMY-20260908P@P
kind: historical-version
run: P
title: "P3.  EXACT THREE-CORE DICHOTOMY"
status: SUPERSEDED
status_raw: "PROVED  (sharpening of thm:postJ-three-core)"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 193, line_end: 235}
metadata: {"stable_id": "P-THREE-CORE-DICHOTOMY-20260908P", "version_id": "P-THREE-CORE-DICHOTOMY-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 193, "line_end": 235}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-THREE-CORE-DICHOTOMY-20260908P@P-R2", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 193, "line_end": 235}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 778, style: ID-TABLE}
---

# P3.  EXACT THREE-CORE DICHOTOMY

*Run P - status `SUPERSEDED` (raw: `PROVED  (sharpening of thm:postJ-three-core)`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Maintained version: `P-THREE-CORE-DICHOTOMY-20260908P@P-R2`; resolve the explicit selection before citing.

## Source transcript (historical wording; apply current metadata)

```
P3.  EXACT THREE-CORE DICHOTOMY         ID: P-THREE-CORE-DICHOTOMY-20260908P
     STATUS: PROVED  (sharpening of thm:postJ-three-core)
--------------------------------------------------------------------------------
STATEMENT.  Let S = {q_1 < q_2 < q_3} be a core.  Write R_i = PF(N - q_i).
Then exactly one of the following holds.

 (A)  q_3 in R_1 and q_3 not in R_2.  Then R_2 = {q_1}, i.e.
          N - q_2 = q_1^b   with b >= 2,
      and R_1 is {q_3} or {q_2,q_3}, and R_3 is a nonempty subset of {q_1,q_2}.
      If R_1 = {q_3} (so N - q_1 = q_3^a, a >= 2) then source-freeness forces
      q_2 in R_3.
 (B)  q_3 in R_2 and q_3 not in R_1.  Then R_1 = {q_2}, i.e.
          N - q_1 = q_2^a   with a >= 2,
      and R_2 is {q_3} or {q_1,q_3}, and R_3 is a nonempty subset of {q_1,q_2}.
      If R_2 = {q_3} (so N - q_2 = q_3^b) then source-freeness forces q_1 in R_3.

In case (A) the pure row is N - q_2 = q_1^b: its PARTNER is q_2 and its BASE is
q_1.  In case (B) the pure row is N - q_1 = q_2^a: partner q_1, base q_2.
In BOTH cases partner and base lie in {q_1,q_2}, hence are < sqrt(N) by P1.

PROOF.  By D4, the maximal label q_3 divides exactly one row of a core, and by
auto-activity it does not divide its own row; so q_3 lies in exactly one of
R_1, R_2.  If q_3 in R_1 then R_2 is a nonempty subset of {q_1,q_3} \ {q_3} =
{q_1}, so R_2 = {q_1} and N - q_2 is a power of q_1; BADness makes it composite,
so b >= 2.  Case (B) is symmetric.  The source-freeness remarks are immediate:
every label needs an incoming edge, and in the stated sub-cases only one
candidate row remains.  The final sentence is P1 applied to q_1 < q_2.    QED

COROLLARY P3a (the master's NEXT-1 becomes finite).
        Every even N carrying a three-element core satisfies
              N = p^m + q,      p, q distinct odd primes,  m >= 2,  q < sqrt(N),
        with p^m > 2N/3.  Moreover p < sqrt(N) as well (P1c).
Therefore enumerating all pairs (prime power p^m <= X with m >= 2, prime
q < sqrt(p^m + q)) is a COMPLETE decision procedure for the existence of a
three-element core among all even N <= X.  This is a theorem-produced box, not
a numerical cutoff.

REMARK.  D5 (thm:postJ-three-core) alone does not give a finite search: it says
a pure row exists but not that its partner is small.  P1 supplies exactly the
missing bound, and it is the second-smallest-label bound, not the smallest.

--------------------------------------------------------------------------------
P4.  EXPONENT COPRIMALITY IN THE ALL-PURE SUB-CASE
```
