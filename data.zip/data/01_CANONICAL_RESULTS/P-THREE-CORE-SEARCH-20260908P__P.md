---
id: P-THREE-CORE-SEARCH-20260908P
logical_id: P-THREE-CORE-SEARCH-20260908P
version_id: P-THREE-CORE-SEARCH-20260908P@P
kind: canonical-result
run: P
title: "E1.  COMPLETE THREE-CORE SEARCH"
status: SUPERSEDED
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 446, line_end: 578}
metadata: {"stable_id": "P-THREE-CORE-SEARCH-20260908P", "version_id": "P-THREE-CORE-SEARCH-20260908P@P", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 446, "line_end": 578}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "P-THREE-CORE-SEARCH-R-20260908P", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 446, "line_end": 578}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_run: P-R2
superseded_by_id: P-THREE-CORE-SEARCH-R-20260908P
supersession_reason: "over-scoped (E1 -> E1-R)"
supersession_witness: "N=2200, S = {3,13,1471} with rows 13^3, 3^7, 3^6; 1471 is a source lying above N/3, so the set is outside the intended domain."
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 782, style: ID-TABLE}
---

# E1.  COMPLETE THREE-CORE SEARCH

*Run P - status `SUPERSEDED` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `P-THREE-CORE-SEARCH-R-20260908P` (run `P-R2`).
>
> **Defect:** over-scoped (E1 -> E1-R)
>
> **Witness:** N=2200, S = {3,13,1471} with rows 13^3, 3^7, 3^6; 1471 is a source lying above N/3, so the set is outside the intended domain.

## Source transcript (historical wording; apply current metadata)

```
E1.  COMPLETE THREE-CORE SEARCH          ID: P-THREE-CORE-SEARCH-20260908P
     STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
DOMAIN.  All even N <= 1e12.  This is a COMPLETE decision of the three-element
class on that domain, by Corollary P3a; it is not a cutoff.
ALGORITHM.  For every odd prime p and every m >= 2 with Q = p^m <= X, and every
odd prime q != p with q^2 < Q + q  (equivalently q < sqrt N for N = Q + q):
   set N = Q + q;                       row of q is N-q = Q = p^m, support {p};
   Y = N - p;  strip all factors q from Y, giving Y';
     if Y' = 1 : {p,q} is a two-element closed BAD set (report);
     else Y' must be a prime power z^j with z prime, z not in {p,q}, z < N/3;
   then Z = N - z must satisfy: strip p and q from Z leaves 1, with
     Omega(Z) >= 2  (this also rejects the case where z is GOOD).
   Any surviving triple {p,q,z} is a three-element closed BAD set, so N is a
   host.  Activity of z is automatic by D3.
COST.  candidates(X) ~ 2X / (log X)^2.
RESULT.
   X = 1e8   :     818 200 candidates,  0 three-cores,  N=2200 (twice, both
                   orientations 3^7+13 and 13^3+3)
   X = 3e9   :  16 169 954 candidates,  0 three-cores,  N=2200 only
   X = 1e12  : 3 125 079 631 candidates,  0 three-cores,  N=2200 only
                   (both orientations 3^7+13 and 13^3+3, as at every smaller X)
No three-element closed BAD set exists for any even N <= 1e12.  This is
COMPLETE for the class, not a cutoff: by P3a every N carrying a three-element
core lies in the enumerated box.  Independent confirmation by E5 (a different
test, full closure) up to 1e10.  The two-core
census independently reproduces cor:postJ-two-core-census on its (smaller)
domain, which cross-validates the implementation.

--------------------------------------------------------------------------------
E2.  CYCLE CENSUS                        (certificates for P5(b))
     STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
DOMAIN.  Every even N in [100000, 100400).  Vertices: primes p < N/3 with
p !| N and N-p composite.  Edges p -> q iff q | N-p.  All cycles of length
2, 3, 4 enumerated exactly.  Numbers as in P5(b).

--------------------------------------------------------------------------------
E3.  CORE MATCHINGS AND CYCLE COVERS     (certificates for P5(c))
     STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
All perfect matchings of the six real cores enumerated by exact backtracking;
cycle decomposition and products as in P5(c).  Matching counts 1, 6, 6, 7, 1, 6.

--------------------------------------------------------------------------------
E4.  SMALL/LARGE VERIFICATION            (certificates for P1, P2)
     STATUS: VERIFIED COMPUTATION
     Table reproduced in P2.  All four assertions (at most one large label per
     row; large exponent 1; least prime factor in M; incidence budget) hold on
     all six cores and on the full basins.
--------------------------------------------------------------------------------

REPRODUCIBLE CODE
-----------------

--- basin and core (Python 3 + sympy), used by E3 and E4 ---
from sympy import primerange, isprime, factorint
def basin(N):
    lim=(N-1)//3
    ps=[p for p in primerange(3,lim+1) if N%p]
    fac={p:factorint(N-p) for p in ps}
    alive={p:(not isprime(N-p)) and N-p>1 for p in ps}
    ch=True
    while ch:
        ch=False
        for p in ps:
            if alive[p]:
                for q in fac[p]:
                    if not alive.get(q,False): alive[p]=False; ch=True; break
    return sorted(p for p in ps if alive[p])
def core(N,B):
    Bs=set(B); adj={p:[q for q in factorint(N-p) if q in Bs] for p in B}
    def fwd(p):
        seen={p}; st=[p]
        while st:
            v=st.pop()
            for w in adj[v]:
                if w not in seen: seen.add(w); st.append(w)
        return seen
    for p in B:
        F=fwd(p)
        if all(fwd(q)==F for q in F): return sorted(F)

--- all perfect matchings of a core (E3) ---
def matchings(N,S):
    cand={q:[r for r in S if (N-q)%r==0] for q in S}
    out=[]
    def rec(i,used,assign):
        if i==len(S): out.append(dict(assign)); return
        q=S[i]
        for r in cand[q]:
            if r in used: continue
            used.add(r); assign[q]=r; rec(i+1,used,assign); used.discard(r); del assign[q]
    rec(0,set(),{})
    return out
# cycle products: decompose f into cycles, take prod of labels in each cycle.

--- cycle census (E2) ---
# vertices V = [p prime, 3<=p<=(N-1)//3, N%p!=0, N-p composite]
# adj[p] = [q for q in factorint(N-p) if q in set(V)]
# enumerate directed cycles of length 2,3,4 with the smallest label first;
# record (prod of labels)/N.

--- complete three-core search (C), inner logic of E1 ---
/* p odd prime, Q = p^m <= X with m >= 2 ; q odd prime, q != p, q*q < Q+q */
N = Q + q;                       /* row of q is Q = p^m, support {p} */
Y = N - p;  Yp = Y;  while (Yp % q == 0) Yp /= q;
if (Yp == 1) { report_two_core(N,p,q); continue; }
z = primepower(Yp, &ez);         /* base of Yp if Yp is a prime power, else 0 */
if (!z || z == p || z == q || z >= N/3) continue;
Z = N - z;  om = 0;
while (Z % p == 0) { Z /= p; om++; }
while (Z % q == 0) { Z /= q; om++; }
if (Z != 1 || om < 2) continue;
if (p >= N/3 || q >= N/3) continue;
report_three_core(N, p, q, z);
/* E5 replaces the three-element test by a full closure:
   W = {p};  for each v in W: m = N-v; factor m; for each prime f | m:
       if N % f == 0 skip; if N-f is prime -> GOOD, abort;
       if f >= N/3 -> abort; else add f to W if new and f != q.
   If W exhausts with no GOOD vertex, {q} u W is a closed BAD set: N is a host.
   Factorisation: trial division by the sieved primes then Pollard rho with
   deterministic Miller-Rabin (7-base set). */

/* primepower(): trial division by odd primes < 512 (early exit on the first
   factor; if stripping it leaves 1 the number is a prime power, else reject);
   otherwise deterministic Miller-Rabin; otherwise test n = z^k for
   2 <= k <= log_512(n) by exact integer k-th roots. */

================================================================================
5.  HOSTILE CHECKS
================================================================================
```
