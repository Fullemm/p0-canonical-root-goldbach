---
id: P-THREE-CORE-SEARCH-R-20260908P
logical_id: P-THREE-CORE-SEARCH-R-20260908P
version_id: P-THREE-CORE-SEARCH-R-20260908P@P-R2
kind: canonical-result
run: P-R2
title: "E1-R.  COMPLETE THREE-CORE SEARCH"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION.  (Conclusion re-scoped; numbers unchanged.)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 640, line_end: 719}
metadata: {"stable_id": "P-THREE-CORE-SEARCH-R-20260908P", "version_id": "P-THREE-CORE-SEARCH-R-20260908P@P-R2", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 640, "line_end": 719}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["P-THREE-CORE-SEARCH-20260908P", "P-THREE-CORE-SEARCH-R-20260908P@P-R"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P-R2.txt", "line": 640, "line_end": 719}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
supersedes_runs: [P-R]
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P-R2.txt", line: 1089, style: ID-TABLE}
---

# E1-R.  COMPLETE THREE-CORE SEARCH

*Run P-R2 - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION.  (Conclusion re-scoped; numbers unchanged.)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
E1-R.  COMPLETE THREE-CORE SEARCH      ID: P-THREE-CORE-SEARCH-R-20260908P
       STATUS: VERIFIED COMPUTATION.  (Conclusion re-scoped; numbers unchanged.)
================================================================================
DOMAIN (stated as the enumeration box; the code has no N <= X filter).
   Q = p^m <= X with p an odd prime and m >= 2;  q an odd prime, q != p, with
   q^2 < Q + q  (equivalently q < sqrt N for N = Q + q).   Here X = 1e12.
   The box COVERS every even N <= X, because Q = N - q < N <= X; it also tests
   some N in (X, X + sqrt X], which is extra coverage, not a gap.  The prime
   list runs to sqrt(X) + 2, covering both the bases and the largest admissible
   partner (q^2 - q < X).
   By P3a this box is a COMPLETE decision of the THREE-ELEMENT CORE class over
   even N <= X, not a cutoff.
ALGORITHM.  For every odd prime p and m >= 2 with Q = p^m <= X, and every odd
prime q != p with q^2 < Q + q (i.e. q < sqrt N for N = Q + q):
   N = Q + q;  row of q is N - q = Q = p^m, support {p};
   Y = N - p;  strip all factors q from Y to get Y';
     if Y' = 1: {p,q} is a two-element closed BAD set (report);
     else Y' must be a prime power z^j with z prime, z not in {p,q}, z < N/3;
   then Z = N - z must satisfy: stripping p and q from Z leaves 1, with
   Omega(Z) >= 2 (this also rejects z GOOD).  Any survivor is a three-element
   closed BAD set with all labels below N/3.
RESULTS.
   X = 1e8   :        818 200 candidates;  0 three-element closed BAD sets;
                    2 two-element hits, both N = 2200
   X = 3e9   :     16 169 954 candidates;  0 three-element closed BAD sets;
                    2 two-element hits, both N = 2200
   X = 1e12  :  3 125 079 631 candidates;  0 three-element closed BAD sets;
                    2 two-element hits, both N = 2200
                    (the two orientations 3^7 + 13 and 13^3 + 3)
CONCLUSION (exact scope).  No even N <= 1e12 carries a three-element CORE.
The only two-element core in range is N = 2200, reproducing D7 on a smaller
domain by independent code.
WHAT THIS DOES NOT SAY.  (i) It does not exclude three-element closed BAD sets
that are not minimal: N = 2200 with S = {3,13,1471} is one, and it is invisible
to the box because 1471 > sqrt(2200).  (ii) It says nothing about N > 1e12;
all-N existence of a three-element core is OPEN.

================================================================================
E2.  CYCLE CENSUS                      (certificates for P5-R(b))  VERIFCOMP
================================================================================
Every even N in [100000, 100400); vertices = primes p < N/3 with p not dividing
N and N - p composite; edges p -> q iff q | N - p; all cycles of length 2, 3, 4
enumerated exactly.  Numbers as in P5-R(b).

================================================================================
E3-R.  CORE MATCHINGS AND CYCLE COVERS  (certificates for P5-R(c))  VERIFCOMP
       STATUS: RECOMPUTED with the correct quantifier.
================================================================================
All perfect matchings of the six cores enumerated by exact backtracking; each
decomposed into cycles.  Checkpoint P reported the MAXIMUM over covers of the
maximum cycle product; the meaningful quantity is the MINIMUM over covers.
   N      #matchings   min over covers of max cycle product   cycle lengths
   128        1        23023                        > N       [4,4]
   1718       6        40362411867383749            > N       [8,8,9,3]
   1862       6        48592489134145               > N       [4,7,5,5]
   1928       7        6359253161365                > N       [7,7]
   2200       1        39                          <= N       [2]
   6142       6        2983                        <= N       [2,2,2,2,2]
So at N = 2200 and N = 6142 there IS a cover all of whose cycle products are
below N, contradicting the claim made in checkpoint P.  At the other four every
cover has a cycle of product at least N, and this is NOT an artefact of the
enumeration: it is forced by the product criterion of P5-R(c), because
prod S >= N^{floor(s/2)} holds at exactly those four (4.106e8 >= 2.684e8;
4.607e51 >= 1.951e45; 3.987e39 >= 5.010e32; 1.240e23 >= 9.903e22) and fails at
exactly the two involutive ones.  The enumeration and the criterion agree
everywhere.
Two-cycles present in each core (each obeying D6, pq < N):
   128: {3,5};  1718: {3,5},{7,59};  1862: {3,11};  1928: {3,5},{3,11},{7,17};
   2200: {3,13};  6142: {3,7},{3,877},{5,17},{7,409},{13,227},{19,157}.

================================================================================
E4.  SMALL/LARGE VERIFICATION          (certificates for P1, P2-R)  VERIFCOMP
================================================================================
Table reproduced in P2-R.  All four clauses hold on all six cores.  The
hypothesis max S < N/3 was checked separately for each core (41 < 42.67,
571 < 572.67, 619 < 620.67, 641 < 642.67, 13 < 733.33, 877 < 2047.33) and the
counterexample of R1 was verified to be a genuine closed BAD set.

================================================================================
E5-R.  PURE-ROW HOST CENSUS (all core sizes)
```
