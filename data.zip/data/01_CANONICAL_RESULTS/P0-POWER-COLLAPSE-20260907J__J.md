---
id: P0-POWER-COLLAPSE-20260907J
logical_id: P0-POWER-COLLAPSE-20260907J
version_id: P0-POWER-COLLAPSE-20260907J@J
kind: canonical-result
run: J
title: "8.2"
status: EMPIRICAL
status_raw: "HEURISTIC (counts are exact)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 921, line_end: 933}
metadata: {"stable_id": "P0-POWER-COLLAPSE-20260907J", "version_id": "P0-POWER-COLLAPSE-20260907J@J", "status": "EMPIRICAL", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 921, "line_end": 933}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 921, "line_end": 933}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1102, style: ID-TABLE}
---

# 8.2

*Run J - status `EMPIRICAL` (raw: `HEURISTIC (counts are exact)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
8.2  P0-POWER-COLLAPSE-20260907J          STATUS: HEURISTIC (counts are exact)
On the three genuine trials the composite-mirror failure rates at that host are
0.692, 0.564, 0.346 (all ranks) and 0.600, 0.500, 0.300 (size-matched, top-10
mirrors).  The null hypothesis "rank 0 is an ordinary rank" therefore predicts
        P[p_0 survives all three] = 0.088   (per-host rates)
                                  = 0.140   (size-matched rates)
                                  = 0.214   (pooled rank-1..30 rate 0.402).
Fisher exact test of rank 0 (0 failures / 3 trials) against rank 1
(2 failures / 5 trials): P = 0.357.
NONE of these rejects the null at any conventional level.  The corpus's EXP8
line "root FAILURES: p_0 = 0, p_1 = 2 over 99 976 values of N" is not a
categorical separation; it is 0-of-3 against 2-of-5.
```
