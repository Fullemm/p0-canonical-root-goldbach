---
id: POINTWISE-CORE-LABEL-GROWTH-20260905
logical_id: POINTWISE-CORE-LABEL-GROWTH-20260905
version_id: POINTWISE-CORE-LABEL-GROWTH-20260905@research
kind: canonical-result
run: research
title: "Pointwise core label growth"
status: PROVED
status_raw: "PROVED (asymptotic consequence, no assertion of novelty)."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 501, line_end: 543}
metadata: {"stable_id": "POINTWISE-CORE-LABEL-GROWTH-20260905", "version_id": "POINTWISE-CORE-LABEL-GROWTH-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 501, "line_end": 543}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 501, "line_end": 543}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Pointwise core label growth

*Run research - status `PROVED` (raw: `PROVED (asymptotic consequence, no assertion of novelty).`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: POINTWISE-CORE-LABEL-GROWTH-20260905
STATUS: PROVED (asymptotic consequence, no assertion of novelty).
EXACT STATEMENT:
Uniformly along any sequence N->infinity possessing a nonempty closed
active BAD set C, its largest prime label M obeys
  M >= (1-o(1)) *
       (log log N)(log log log N)/(log log log log N).       (LG)
The iterated logarithms are used only beyond their positivity thresholds.

PROOF:
The effective theorem first implies M->infinity along such a sequence.
The prime number theorem gives s_y=(1+o(1))y/log y. Therefore
  log A_y
  <= s_y*(log 30+log log y)+O(log y)
  <= (1+o(1))*y log log y/log y.
Since D_y=A_y+log(2y), the same main upper bound holds for log D_y,
and also for log(2 D_y log(2 D_y)), the extra term log log D_y being
lower order. Apply N<F(M), take log twice, and conclude
  log log N <= (1+o(1))*M log log M/log M.
The function g(u)=u log log u/log u is increasing for sufficiently large u.
Its asymptotic inverse is v log v/log log v, since direct substitution
shows g(v log v/log log v)~v. This proves (LG).

IMPLICATION / SCOPE FOR THE THREE HEIGHT RESULTS:
These constrain every genuine closed BAD set, including one arising from
rooted failure in an otherwise Goldbach-successful N. A full failed rooted
world has a terminal SCC; all its vertices are factors of composite odd
rows and hence <N/3. Apply the same results to this terminal core, so the
bound need not be vacuously satisfied just by the large starting root.
The existence of a terminal SCC follows from finite graph closure; it has
at least two vertices by activity. No classification of such SCCs is used.
RELATION TO GOLDBACH:
Global Goldbach failure forces a closed BAD component, but its labels can
satisfy (LG). The result is a necessary condition, not a contradiction.
RELATION TO p0 EXCEPTIONALITY:
Shared by all failed traversals. No canonical asymmetry is proved.
WHAT REMAINS OPEN:
An upper restriction incompatible with this lower growth, or a direct
arithmetic escape theorem for the moving support. We have neither.
NOVELTY: NOT YET AUDITED. Classical logarithmic-form methods are the source;
the advance over the supplied lemma is the removal of its branching hypothesis
and an explicit common-envelope threshold with correct scope.
```
