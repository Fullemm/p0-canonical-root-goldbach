---
id: PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907
logical_id: PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907
version_id: PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907@research
kind: canonical-result
run: research
title: "Prime lift and low gap exhaustive audit"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5396, line_end: 5473}
metadata: {"stable_id": "PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907", "version_id": "PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5396, "line_end": 5473}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5396, "line_end": 5473}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Prime lift and low gap exhaustive audit

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: PRIME-LIFT-AND-LOW-GAP-EXHAUSTIVE-AUDIT-20260907
STATUS: VERIFIED COMPUTATION.
DOMAIN / METHOD:
Exact smallest-prime-factor sieve; FIFO queue; ascending distinct factors;
duplicates suppressed on enqueue; no work or depth cutoff for full BFS.
For every even N from 4 through 1,000,000 (499,999 inputs), run BFS from 2.
For every prime divisor d|N with m=N/d-1>=2 and R=N-m prime, compare the
full queue, depths, verdict and number of composite rows in the two starts
d and R, including the separate direct-complement case. This is exhaustive
in that domain, not a random sample or a scan of selected paths.
COUNTS:
41,536 admissible h=1 inputs, of which 36,971 have composite P-2.
265,847 admissible prime-divisor lifts: 200,602 composite-complement lifts
and 65,245 direct-complement lifts. All claimed conjugacies and direct-case
corrections passed. Exactly one lift failed: (N,d,R)=(1862,7,1597), the
complete certificate recorded above. No h=1 input failed in this range.
The ONLY root-2 failures in this finite range are
 N=2^a+2, 2<=a<=19, each W=1,
and N=128 (W=9), N=1718 (W=29).
The power-of-two family is rigorously a self-loop: N-2=2^a. For a=1,
N=4 succeeds directly; thus that endpoint is deliberately excluded.
The statement that the list is exhaustive beyond the scanned range is NOT
claimed. In particular a finite list of known active cores was not assumed
complete by the scan. At N=6142, root 2 actually succeeds along
 2 ->307 ->389 ->11, with final complement 6131 prime:
 6142-2=2^2*5*307, 6142-307=3*5*389,
 6142-389=11*523. Inclusive BFS work W=12.
Thus the mere existence of a known closed BAD component at the SAME N does
not imply failure from 2 or from any other specified root.

SECOND DOMAIN / METRIC:
Every even 4<=N<=200000 and each admissible upper rank k=0,...,6;
retain exactly composite m=N-p_k with h=p_k-N/2<min PF(m).
If no GOOD vertex occurs at depths 0,1,2, expand ALL these rows and count
the distinct nonroot labels discovered at depths 1,2,3, without expanding
depth-3 rows for the count. Early exit when a GOOD vertex at <=2 is found
is permitted only for deciding that the input is outside the BAD2 class.
Counts (rank: eligible low-gap inputs, complete BAD through depth 2):
 0: 38715, 7135
 1: 22044, 4503
 2: 14356, 3136
 3: 11229, 2495
 4: 9285, 2096
 5: 7915, 1808
 6: 6790, 1516
Every input passed the proved lower bound of three distinct nonroot labels.
The observed minimum was FIVE labels, first at (N,R,k)=(4422,2213,0).
This stronger minimum is EMPIRICAL ONLY. Exact complete first rows:
 4422-2213=47^2;
 4422-47=5^4*7;
 4422-5=7*631;
 4422-7=5*883.
Hence depths are {47}:1, {5,7}:2, {631,883}:3. The last vertex 883 is
GOOD (4422-883=3539 prime); 631 is BAD (3791=17*223).
Thus this is complete BADness THROUGH depth 2, not through depth 3.
Full BFS succeeds at depth 3 after W=6 tests.

INDEPENDENT HOSTILE CHECK:
Trial division independently verified the N=4422 complete rows and ranks,
the two nontrivial root-2 failure reachable sets, the N=6142 successful
path, and the N=1862 lift closure certificate. This is an independent
certificate audit, not a second exhaustive million-input scan.
The three-label theorem is not made stronger by the observed five-label
minimum. The existing master already treats three-vertex closed cores as
an open coupled prime-power/support system; empirical absence is not a
classification theorem. No Scott--Bozek uniqueness claim is used.
REPRODUCTION:
The retained C++ source audit_prime_lifts_20260907.cpp uses an SPF array
through 1,001,000, enough for all roots and rows in the stated ranges.
Its raw result is audit_prime_lifts_20260907.out. All counts, domains,
exceptions and the direction-changing witnesses are preserved here so
this checkpoint remains usable without those scratch diagnostics.
RELATION TO p0 / GOLDBACH:
Confirms exact finite behaviour and the theorem's breadth across nearby
roots; proves neither universal canonical success nor binary Goldbach.
NOVELTY: NOT YET AUDITED.
```
