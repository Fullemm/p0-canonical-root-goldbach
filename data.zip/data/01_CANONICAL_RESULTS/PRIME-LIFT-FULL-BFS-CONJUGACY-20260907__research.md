---
id: PRIME-LIFT-FULL-BFS-CONJUGACY-20260907
logical_id: PRIME-LIFT-FULL-BFS-CONJUGACY-20260907
version_id: PRIME-LIFT-FULL-BFS-CONJUGACY-20260907@research
kind: canonical-result
run: research
title: "Prime lift full bfs conjugacy"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5179, line_end: 5256}
metadata: {"stable_id": "PRIME-LIFT-FULL-BFS-CONJUGACY-20260907", "version_id": "PRIME-LIFT-FULL-BFS-CONJUGACY-20260907@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5179, "line_end": 5256}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["PRIME-LIFT-FULL-BFS-CONJUGACY"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5179, "line_end": 5256}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Prime lift full bfs conjugacy

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: PRIME-LIFT-FULL-BFS-CONJUGACY-20260907
STATUS: PROVED.
EXACT STATEMENT:
Let N>=4 be even, d a prime divisor of N, x=N/d, and m=x-1>=2.
Suppose R=N-m=(d-1)x+1 is prime. Use full factor BFS from any admissible
prime, including the inactive start d; remove duplicate visits, use FIFO
and enqueue all distinct prime factors in increasing order.
Then R>N/2, R<=N-2, and:
(A) If m is prime, R succeeds immediately with (depth,W)=(0,1), while
    d succeeds via d ->m with (depth,W)=(1,2).
(B) If m is composite, the two searches have identical verdicts. If they
    succeed, their first-success depths and inclusive work counts agree.
    In fact their entire ordered test transcripts agree after replacing
    the initial d by R. All complete stopped frontiers after the initial
    root are the same. On failure the reachable sets differ only by
    replacing d with R.
At graph level in (B), deletion of the harmless self-loop d->d and
renaming that root gives the same complete reachable stopped graph.

PROOF:
Since d>=2, R=N-N/d+1>=N/2+1. The assumption m>=2 gives R<=N-2.
Also R-d=(d-1)(x-1)=(d-1)m>0. If d|m, then d|N-m=R, contradicting
primality of R>d. Hence d does not divide m.
If a prime q divides both m=x-1 and N=dx, it must divide d, since
q cannot divide x and x-1. This would mean q=d, already excluded.
Therefore every prime factor of m is active, i.e. coprime to N.
We have the EXACT row relation
 N-d=d*m,             N-R=m,
so PF(N-d)={d} disjoint-union PF(m).
The self-loop at d is ignored by duplicate suppression. Thus, after
processing the first BAD row, both queues contain exactly the same
ordered set PF(m), each at distance 1.
Activity is preserved: if p is an active prime and q|N-p also divides
N, then q|p, so q=p, contradicting p not dividing N. Consequently no
later vertex can equal the inactive prime d.
Nor can a later prime parent p have an edge to R in the composite-m
case. Since R>N/2, a positive N-p<N divisible by R must equal R;
this would give p=N-R=m, which is composite. Thus the root R is never
encountered again from any prime vertex, including any terminal row.
The two discovered sets therefore differ only in their initial root;
this difference cannot affect any later duplicate test. Inductively,
FIFO removes the same next prime at the same distance, tests the same
row, and enqueues the same new factors. This proves (B), including
complete-frontier equality and the graph statement. No assumption of
success is used in the induction.
If m is prime, the R-root test is immediately successful. The d-root
row has factors d and m, with m!=d as established above. After ignoring
d's self-loop, m is tested at depth 1 and is GOOD because N-m=R is
prime. This proves (A).

HOSTILE CHECK:
The initial d is INACTIVE. The active-root theorem cannot be invoked
at that initial vertex; the proof explicitly separates its self-loop
and proves that all other children are active. The conjugacy is for
composite m; applying its depth equality to prime m would be false.
The absence of an incoming edge to R is proved, rather than inferred
from a selected BAD path. Entire BFS queues are compared, not one path.
The theorem does not assert that either search succeeds.
DEPENDENCIES: Elementary divisibility, primality and finite full BFS only.
RELATION TO GOLDBACH:
An exact equivalence of two algorithmic reachability questions, not
an independent source of a Goldbach representation.
RELATION TO p0:
Taking d=2 gives x=P-1, N=2(P-1), R=P. If P>=5 is prime, P is the
canonical root. Therefore every non-direct canonical h=1 traversal
is, for ALL generations, exactly the traversal from prime 2 after the
stated initial-root replacement. An invariant of the resulting stopped
transition graph which ignores that replacement and its self-loop
cannot distinguish these two starts.
This is a restricted h=1 theorem; root 2 is not a nearby upper root.
It does not claim equivalence between p0 and pk for k>=1.
WHAT REMAINS OPEN:
Whether the prime-lift condition with d=2 excludes eventual failure.
The same question for all prime divisors d is FALSE, as the following
exact example shows. Thus lift primality alone is not a general closer.
NOVELTY: NOT YET AUDITED. Targeted corpus search found the h=1
least-factor/shift-2 lemmas but no prior full-BFS conjugacy entry.
```
