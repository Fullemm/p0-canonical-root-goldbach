---
id: PRIME-LIFT-FULL-BFS-CONJUGACY@research
logical_id: PRIME-LIFT-FULL-BFS-CONJUGACY
version_id: PRIME-LIFT-FULL-BFS-CONJUGACY@research
kind: historical-version
run: research
title: "Prime lift full bfs conjugacy"
status: SUPERSEDED
status_raw: "for N=d*x and prime lift"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5879, line_end: 5884}
metadata: {"stable_id": "PRIME-LIFT-FULL-BFS-CONJUGACY", "version_id": "PRIME-LIFT-FULL-BFS-CONJUGACY@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5879, "line_end": 5884}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "PRIME-LIFT-FULL-BFS-CONJUGACY-20260907", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5879, "line_end": 5884}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: PRIME-LIFT-FULL-BFS-CONJUGACY-20260907
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Prime lift full bfs conjugacy

*Run research - status `SUPERSEDED` (raw: `for N=d*x and prime lift`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `PRIME-LIFT-FULL-BFS-CONJUGACY-20260907` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
2. PRIME-LIFT-FULL-BFS-CONJUGACY: for N=d*x and prime lift
   R=(d-1)*x+1 with composite x-1, the full BFS from inactive d and
   from R are identical after renaming their initial root. At d=2
   this is an exact all-generation equivalence for canonical h=1.
   The tempting general success consequence is FALSE at
   (N,d,R)=(1862,7,1597), with a complete 22-vertex closure certificate.
```
