---
id: PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907
logical_id: PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907
version_id: PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907@research
kind: canonical-result
run: research
title: "FAIL-"
status: KILLED
status_raw: "KILLED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5257, line_end: 5314}
metadata: {"stable_id": "PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907", "version_id": "PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907@research", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5257, "line_end": 5314}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5257, "line_end": 5314}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `KILLED` (raw: `KILLED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: PRIME-LIFT-PRIMALITY-FORCES-SUCCESS-20260907
STATUS: KILLED.
CLAIM / ROUTE:
If the affine lift R=(d-1)N/d+1 of a prime divisor d|N is prime, then
full factor search from d (equivalently its lift R) must succeed.
WHY IT LOOKED PROMISING:
Lift primality automatically removes inactive factors from PF(N/d-1),
and for d=2 gives exactly the canonical h=1 initial condition.
EXACT COUNTEREXAMPLE:
N=1862, d=7, x=266, m=265=5*53, R=1597 prime.
Both complete BFS runs fail, each after W=22 tests. Their common active
nonroot reachable set U has the 21 labels listed by the rows below.
For every p in U, N-p is composite and has all factors in U. The root
1597 also has all its factors in U. This is a COMPLETE closure
certificate, independent of any claim about terminal-SCC classification.
 1862-3 = 1859 = 11 * 13^2
 1862-5 = 1857 = 3 * 619
 1862-11 = 1851 = 3 * 617
 1862-13 = 1849 = 43^2
 1862-17 = 1845 = 3^2 * 5 * 41
 1862-41 = 1821 = 3 * 607
 1862-43 = 1819 = 17 * 107
 1862-47 = 1815 = 3 * 5 * 11^2
 1862-53 = 1809 = 3^3 * 67
 1862-67 = 1795 = 5 * 359
 1862-83 = 1779 = 3 * 593
 1862-107 = 1755 = 3^3 * 5 * 13
 1862-113 = 1749 = 3 * 11 * 53
 1862-167 = 1695 = 3 * 5 * 113
 1862-179 = 1683 = 3^2 * 11 * 17
 1862-251 = 1611 = 3^2 * 179
 1862-359 = 1503 = 3^2 * 167
 1862-593 = 1269 = 3^3 * 47
 1862-607 = 1255 = 5 * 251
 1862-617 = 1245 = 3 * 5 * 83
 1862-619 = 1243 = 11 * 113
 1862-1597 = 265 = 5 * 53

The inactive root has 1862-7=1855=7*5*53, so only its own duplicate
self-loop is added. Primality and all rows were independently checked
by trial division. The prime-divisor/lift enumeration was exhaustive
only over divisors of the six known hosts, not over all N: this was the
only admissible prime lift in that small diagnostic.
For the SAME N, p0=937 succeeds along 937 ->37 ->73, since
1862-937=5^2*37, 1862-37=5^2*73, and 1862-73=1789 prime.
Thus a successful canonical search can have a separate branch into U;
reaching a BAD closed component does not imply full rooted failure.
WHAT SURVIVES:
The exact conjugacy and the special d=2 question. The counterexample
has d=7 and does not contradict canonical h=1 success.
DO NOT REPEAT:
Do not infer success merely from a prime affine lift or the absence of
additional inactive factors. Those conditions hold in this example.
POSSIBLE REPLACEMENT:
A restriction using d=2 essentially, or a pointwise theorem controlling
access from PF(N/2-1) to moving closed active support.
```
