---
id: PUREPOWER-HOST-SEARCH-20260907J
logical_id: PUREPOWER-HOST-SEARCH-20260907J
version_id: PUREPOWER-HOST-SEARCH-20260907J@J
kind: canonical-result
run: J
title: "Purepower host search"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 583, line_end: 740}
metadata: {"stable_id": "PUREPOWER-HOST-SEARCH-20260907J", "version_id": "PUREPOWER-HOST-SEARCH-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 583, "line_end": 740}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 583, "line_end": 740}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Purepower host search

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X7.  PUREPOWER-HOST-SEARCH-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
QUESTION (sharp, driven by T6/T7): every two-element core and every
three-element core contains a row that is a pure prime power q^e with e >= 2
(T6, T7).  Search that shape directly at large N, far beyond any census range.
ALGORITHM: for every prime power Q = q^e <= X (q <= Y odd prime, e >= 2) and
every odd prime r <= Z with r != q, put N = Q + r.  Then N - r = Q, so
PF(N-r) = {q} and r in B_N <=> q in B_N; test the latter by BFS of the forward
closure of q with early abort on the first GOOD vertex (closure cap 400).
Every hit is an EAC host.  Exact integer arithmetic (sympy factorint/isprime).
DOMAIN RUN 1: X = 10^11,  Y = 1000, Z =  500 ->  50 187 candidates tested.
DOMAIN RUN 2: X = 10^17,  Y = 3000, Z = 1500 -> 466 644 candidates tested.
RESULT: run 1 produced 13 hits, run 2 produced 23 hits.  EVERY hit is one of the
six known hosts, reached through a different pure-power representation:
   128  = 3^3+101 = 3^4+47 = 5^2+103 = 5^3+3 = 7^2+79 = 11^2+7
   1718 = 29^2+877 = 31^2+757 = 37^2+349 = 41^2+37
   1862 = 41^2+181 = 43^2+13
   1928 = 43^2+79
   2200 = 3^7+13 = 13^3+3
   6142 = 17^3+1229
NO NEW HOST at any scale up to 10^17.  This is the first probe of the host set
far beyond census range, and it is negative.
SCOPE: this finds every host possessing an element r <= Z whose row is a pure
power of a prime q <= Y, with that power <= X.  It does not exclude hosts
without a pure-power row (the cores of N = 1928 and N = 6142 have none, and are
found here only through non-core elements of B_N).

--------------------------------------------------------------------------------
4.7  REPRODUCIBLE CODE
--------------------------------------------------------------------------------
(Exact sources; all are self-contained.)

--- basin and core (Python 3 + sympy) ---
from sympy import primerange, isprime, factorint, nextprime
def basin(N):
    lim=(N-1)//3
    ps=[p for p in primerange(3,lim+1) if N%p]
    fac={p:factorint(N-p) for p in ps}
    alive={p:(not isprime(N-p)) and N-p>1 for p in ps}
    ch=True
    while ch:
        ch=False
        for p in ps:
            if alive[p]:
                for q in fac[p]:
                    if not alive.get(q,False): alive[p]=False; ch=True; break
    return sorted(p for p in ps if alive[p])
def core(N,B):
    Bs=set(B); adj={p:[q for q in factorint(N-p) if q in Bs] for p in B}
    def fwd(p):
        seen={p}; st=[p]
        while st:
            v=st.pop()
            for w in adj[v]:
                if w not in seen: seen.add(w); st.append(w)
        return seen
    for p in B:
        F=fwd(p)
        if all(fwd(q)==F for q in F): return sorted(F)
def upper_roots(N):
    p = N//2 if isprime(N//2) else nextprime(N//2); out=[]
    while p<N: out.append(p); p=nextprime(p)
    return out
# r fails  <=>  m=N-r composite >1 and set(factorint(m)) <= set(basin(N))
# (diagonal 2r=N and prime m are successes at depth 0)

--- X3, complete two-core search (Python 3 + numpy + sympy) ---
import numpy as np
from math import isqrt
def sieve(n):
    b=np.ones(n+1,dtype=bool); b[:2]=False
    for i in range(2,isqrt(n)+1):
        if b[i]: b[i*i::i]=False
    return np.nonzero(b)[0]
X=10**24; cube=round(X**(1/3))+2
vals={}
for q in sieve(cube):
    q=int(q)
    if q==2: continue
    qe=q**3; e=3
    while qe<=X:
        vals.setdefault(qe-q,[]).append((q,e)); qe*=q; e+=1
sols=[]
for V,lst in vals.items():
    for i in range(len(lst)):
        for j in range(i+1,len(lst)):
            if lst[i][0]!=lst[j][0]: sols.append((V,lst[i],lst[j]))
    d=1+4*V; s=isqrt(d)
    if s*s==d and (1+s)%2==0:
        r=(1+s)//2
        if r>2 and isprime(r):
            for (q,e) in lst:
                if q!=r: sols.append((V,(q,e),(r,2)))
# result: sols == [(2184,(3,7),(13,3))]  -> N = 2200

--- X1, exact host census (C) ---
/* alive[p] for odd primes p<=(N-1)/3 with p!|N and N-p composite;
   worklist of dead q; dead q kills every p = N (mod q), p <= (N-1)/3. */
for(long N=lo; N<=hi; N+=2){
  long third=(N-1)/3, sp=0, nalive=0;
  for(long p=3;p<=third;p+=2){
    if(!isprime[p]||N%p==0){ alive[p]=0; continue; }
    if(isprime[N-p]){ alive[p]=0; stack[sp++]=p; } else { alive[p]=1; nalive++; }
  }
  while(sp>0 && nalive>0){
    long q=stack[--sp], r=N%q; if(!r) continue;
    long p=r; if(p<3) p+=((3-p+q-1)/q)*q; if(!(p&1)) p+=q;
    for(; p<=third; p+=2*q) if(alive[p]){ alive[p]=0; nalive--; stack[sp++]=p; }
  }
  if(nalive>0) report(N);
}

--- X7, pure-power host search (Python 3 + sympy) ---
from sympy import isprime, factorint, primerange
for q in primerange(3,Y+1):
    Q=q*q; e=2
    while Q<=X:
        for r in primerange(3,Z+1):
            if r==q: continue
            N=Q+r
            if isprime(N-q): continue            # q GOOD -> dead
            seen={q}; stack=[q]; good=False; nv=0
            while stack and not good:
                v=stack.pop(); nv+=1
                if nv>400: good=True; break
                for f in factorint(N-v):
                    if N%f==0: continue
                    if isprime(N-f): good=True; break
                    if f not in seen: seen.add(f); stack.append(f)
            if not good: report_host(N,q,e,r,sorted(seen))
        Q*=q; e+=1

--- X2, seeded deep search (C), inner loop ---
/* spf[] = smallest prime factor of odd n; pr[] = primality byte array */
for(long s=3;s<=SEEDMAX && s<=third;s+=2){
  if(!pr[s]||N%s==0||pr[N-s]) continue;
  head=tail=nt=good=0; q[tail++]=s; inq[s]=1; touched[nt++]=s;
  while(head<tail && !good){
    long v=q[head++], m=N-v;
    while(m>1){ long f=spf[m>>1]; while(m%f==0) m/=f;
      if(pr[N-f]){ good=1; break; }
      if(!inq[f]){ inq[f]=1; touched[nt++]=f; q[tail++]=f; } }
  }
  for(long i=0;i<nt;i++) inq[touched[i]]=0;
  if(!good) report_host(N,s,tail);
}

================================================================================
5.  HOSTILE CHECKS
================================================================================

HC1.  Did I re-verify what I depend on?
Yes for D2/D3 (reproved as T3, and machine-checked on 891 pairs), D4 (X1), D5
(X5).  D6 (the 10^7 canonical scan) was NOT re-run; the argument in section 8
does not need it to be true -- if it were false the p_0 hypothesis would be dead
outright.

HC2.  Is the height/Matveev layer capable of deciding anything about real
```
