---
id: Q-CYCLE-COVER-ARITHMETIC-01
logical_id: Q-CYCLE-COVER-ARITHMETIC-01
version_id: Q-CYCLE-COVER-ARITHMETIC-01@Q
kind: canonical-result
run: Q
title: "Q cycle cover arithmetic"
status: PROVED
status_raw: "PROVED / OLD LOCK COMBINED WITH COVERS"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 169, line_end: 219}
metadata: {"stable_id": "Q-CYCLE-COVER-ARITHMETIC-01", "version_id": "Q-CYCLE-COVER-ARITHMETIC-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["A simple BAD directed cycle of active odd primes", "For cover-level formulas, a cover of S exists"], "statement": "a_i=(N-p_i)/p_next, K_C=prod(a_i), K_C=epsilon mod N; prod(C)<N^(ell-1).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 169, "line_end": 219}, "depends_on": [], "consequences": [], "does_not_imply": ["Does not establish cycle-cover existence", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 169, "line_end": 219}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q cycle cover arithmetic

*Run Q - status `PROVED` (raw: `PROVED / OLD LOCK COMBINED WITH COVERS`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

a_i=(N-p_i)/p_next, K_C=prod(a_i), K_C=epsilon mod N; prod(C)<N^(ell-1).

**Assumptions:** A simple BAD directed cycle of active odd primes; For cover-level formulas, a cover of S exists.

**Does not imply:** Does not establish cycle-cover existence; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-CYCLE-COVER-ARITHMETIC-01 -- PROVED / OLD LOCK COMBINED WITH COVERS
P-R2 correctly kills product(C)<N for arbitrary long directed cycles.
It must not be read as saying that long cycles have no arithmetic height
bound. The old Global Cycle Product Lock (Biblia lines 1484-1530) survives.
Here is its exact consequence for covers, including non-involutive covers.

Let C be a directed cycle of length ell, q_i -> q_(i+1), with active odd
labels below N/3, and put a_i=(N-q_i)/q_(i+1). Each a_i is an odd integer
>=3: its row is composite. Put
  K_C=product(a_i)=product_(q in C)(N-q)/product_(q in C)q.
Modulo N, q_i=-a_i*q_(i+1); multiplying and cancelling the invertible prime
labels gives
  K_C = (-1)^ell (mod N).
Since K_C>1,
  K_C >= N-1 for odd ell,
  K_C >= N+1 for even ell.
For ell=2 the old even coefficient t gives the sharper exact identity
  K_C = 1+t*N >= 2N+1.

In EVERY case,
  product_(q in C)q < N^(ell-1),
and for ell=2, product(C)<N/2.
For odd ell, where the denominator N-1 is slightly below N, the strict
inequality still follows: one label is >=3, so
  product(N-q) <= (N-3)*N^(ell-1),
and division by K_C>=N-1 gives the result. The even case is immediate.

Thus for ANY cycle cover f of a core S, write c_2 for its 2-cycle count,
e for its even-cycle count of lengths >=4, o for its odd-cycle count, and
c=c_2+e+o. The SAME cover-independent integer
  T_S=product_(q in S)(N-q)/product_(q in S)q
satisfies
  T_S >= (2N+1)^c_2 * (N+1)^e * (N-1)^o,
  product(S) < N^(s-c)/2^c_2.
All factors here come from DISJOINT cycles, so no valuation mass is counted
twice. This is stronger than using only the single congruence for T_S when
the cover has several cycles. It is valid uniformly for long cycles too.

Scope and strategic significance:
The old lock was never false, only insufficient by itself. Matching now
supplies a partition on which its costs multiply. This recovers an arithmetic
consumer for non-involutive covers that the P frontier did not exploit.
It saves one power of N per cycle, NOT per two vertices of a long cycle.
To obtain a contradiction one still needs an independent upper budget for
T_S, or sufficiently many short disjoint cycles plus an incompatible label
lower bound. The next result shows that the support constraints alone do
not supply the needed growth in the number of cycles.

SAVE POINT Q2: general reciprocal defect and a valid arithmetic replacement
for the killed long-cycle bound are proved. No Goldbach implication closes.
```
