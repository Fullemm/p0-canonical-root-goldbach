---
id: Q-MINIMUM-CYCLE-DESCENT-01
logical_id: Q-MINIMUM-CYCLE-DESCENT-01
version_id: Q-MINIMUM-CYCLE-DESCENT-01@Q
kind: canonical-result
run: Q
title: "Q minimum cycle descent"
status: PROVED
status_raw: "PROVED, FULL CLOSURE ESSENTIAL"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 339, line_end: 384}
metadata: {"stable_id": "Q-MINIMUM-CYCLE-DESCENT-01", "version_id": "Q-MINIMUM-CYCLE-DESCENT-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Active fully closed BAD set S", "An existing directed cycle cover f", "Saturated odd cycle C: K_C=N-1"], "statement": "Full cofactor a_p=(N-p)/f(p) divides p-1. At min C, factors of a_p lead to cover components with smaller minima; descent ends at an even or nonsaturated odd component.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 339, "line_end": 384}, "depends_on": ["Q-PARITY-CYCLE-LOCK-01"], "consequences": [], "does_not_imply": ["No bound on many-to-one absorption", "No proper closed-subcore descent", "Divisibility is not for arbitrary cycles", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 339, "line_end": 384}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure", "minimum-cycle-descent", "absorption"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q minimum cycle descent

*Run Q - status `PROVED` (raw: `PROVED, FULL CLOSURE ESSENTIAL`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Full cofactor a_p=(N-p)/f(p) divides p-1. At min C, factors of a_p lead to cover components with smaller minima; descent ends at an even or nonsaturated odd component.

**Assumptions:** Active fully closed BAD set S; An existing directed cycle cover f; Saturated odd cycle C: K_C=N-1.

**Does not imply:** No bound on many-to-one absorption; No proper closed-subcore descent; Divisibility is not for arbitrary cycles; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-MINIMUM-CYCLE-DESCENT-01 -- PROVED, FULL CLOSURE ESSENTIAL
Let S be a closed BAD set with a cycle cover f. An odd cycle C is called
saturated HERE precisely when K_C=N-1 (equivalently g_C=1).
For each p in such a cycle, write a_p=(N-p)/f(p). Then
  a_p divides p-1.
Hence EVERY prime factor of a_p is strictly below p. These are actual
unselected factors of the complete row, not hypothetical graph edges.

Proof, including the sign. Since a_p divides K_C and N-p,
  K_C-epsilon=g_C*N (mod a_p)
gives
  a_p divides g_C*p+epsilon.
For an odd cycle epsilon=-1; if g_C=1 this is a_p | p-1. The cofactor a_p
is >=3, so it has a prime factor. This derivation uses the positive quotient
K_C-epsilon and the PLUS sign in g_C*p+epsilon.

Choose p=min(C). Every prime factor q of a_p then satisfies q<p. Full closure
puts q in S, while q is outside C. Let D be the cycle of the cover containing
q. Then min(D)<=q<min(C). Choose one such actual cofactor factor at the
minimum of each saturated odd cycle and draw C->D. The cycle minima strictly
decrease along these arrows. Repeated arrows therefore end at a cycle that
is NOT saturated odd: either an even cycle (g>=2) or an odd cycle with g>=3.
This is a genuine terminating descent on cover components. It does not
delete a prime from a core, and it does not claim a smaller closed core.

In particular the cycle containing min(S) cannot be saturated odd. If that
cycle is odd, K_C>=3N-1. If a cover consists entirely of O odd cycles, then
  T_S >= (3N-1)*(N-1)^(O-1).                      (Q-ALL-ODD-COVER-BOUND)

Relation to the old corpus: Biblia thm:atak5-g3, around lines 5437-5460,
already excludes g=1 for a terminal odd Hamilton cycle. The argument here
extends the conclusion to the cycle containing the global minimum in ANY
cover, and retains an actual edge to a smaller cycle for every other
saturated odd cycle. This combines the old reconstruction/terminality idea
with the current matching language; it is not a new proof of the old special
case under a new name.

Limit of the descent: one non-saturated component can receive many arrows.
No uniform bound on this multiplicity has been proved. The ordered-parent
lemma permits a small prime to have many larger parents. Thus termination
of this descent does NOT prove that S cannot exist. The outstanding bridge
is an upper budget for the actual absorption at its terminal components.

SAVE POINT Q4: parity for all cycle lengths and the full-row minimum-cycle
descent saved, with their exact scope and the remaining absorption problem.
```
