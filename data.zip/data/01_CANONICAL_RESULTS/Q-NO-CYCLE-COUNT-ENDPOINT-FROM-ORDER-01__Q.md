---
id: Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01
logical_id: Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01
version_id: Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01@Q
kind: canonical-result
run: Q
title: "Q no cycle count endpoint from order"
status: PROVED
status_raw: "PROVED NEGATIVE, EXACT SCOPE"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 220, line_end: 273}
metadata: {"stable_id": "Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01", "version_id": "Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Abstract ordered support graphs", "s>=5"], "statement": "There is a strongly connected pure-free family satisfying ordered parents, K and P7 with exactly two covers [s] and [2,s-2].", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 220, "line_end": 273}, "depends_on": [], "consequences": [], "does_not_imply": ["Not a prime realization", "Does not assert every complete-row forbidden block holds", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 220, "line_end": 273}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q no cycle count endpoint from order

*Run Q - status `PROVED` (raw: `PROVED NEGATIVE, EXACT SCOPE`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

There is a strongly connected pure-free family satisfying ordered parents, K and P7 with exactly two covers [s] and [2,s-2].

**Assumptions:** Abstract ordered support graphs; s>=5.

**Does not imply:** Not a prime realization; Does not assert every complete-row forbidden block holds; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-NO-CYCLE-COUNT-ENDPOINT-FROM-ORDER-01 -- PROVED NEGATIVE, EXACT SCOPE
For every integer s>=5 there is an abstract ordered directed graph on
{1,...,s} with ALL of the following properties:
  strongly connected, hence no nonempty proper closed subset;
  no loops; every row has exactly two distinct children (pure-free);
  each child has at most one smaller parent;
  the K triangular sparse-row and P7 localisation properties;
  exactly TWO perfect matchings/cycle covers, with cycle lengths
       [s] and [2,s-2], respectively.
In particular every cover has a cycle of length at least s-2 and the maximum
number of cycles is always 2, even as s tends to infinity.

Construction (labels are INDICES, not primes):
  R_1={2,4}, R_2={1,3}, R_3={2,5}, R_4={1,2},
  R_i={1,i+1} for 5<=i<s,
  R_s={1,2}.
At s=5 the middle range is empty. Every row has size 2. Smaller parents are
1 for child 2, 2 for child 3, 1 for child 4, 3 for child 5, and j-1 for
child j>=6, so the ordered-parent condition holds. Vertex 1 reaches 2,4 and
the entire chain 2->3->5->...->s; every vertex returns to 1, so it is strong.

In any perfect matching, columns 4 and 3 force 1->4 and 2->3, respectively.
Columns 5,...,s force 3->5->6->...->s along the entire chain. The only two
unassigned rows are 4 and s, and the only unassigned columns are 1 and 2.
Both choices are allowed:
  4->1,s->2 gives the 2-cycle (1,4) and one (s-2)-cycle;
  4->2,s->1 gives a single Hamilton cycle.
This proves the count and cycle lengths for every s, without enumeration.
The universal sparse-row inequality follows directly from the ordered
condition (minimum support 2, 3<=s-1). P7 also follows from that condition;
explicitly, for k=floor(s/2)+1, either row 2 (k=3) or row 1 (k>=4) is
contained in the first k indices.

What this KILLS:
  deriving a cycle count tending to infinity with s, or a uniform bound on
  the longest cycle, from ordered parents + strong closure as a graph +
  no pure rows + existence of a perfect matching + K/P7 alone.
What this DOES NOT kill:
  a theorem using common N, prime labels and COMPLETE row factorisations.
These are abstract graphs, not arithmetic cores. They need not satisfy L/N
arithmetic forbidden blocks, and no prime realisation is asserted. P's
sqrt(N) support constraints cannot repair this graph-only obstruction:
at the level of those constraints one may mark every vertex as small.
Such a marking is not a construction of primes or N.

This identifies a concrete surviving parameter: a compulsory long cycle
of length s-2. The new cover budget is not a uniform closure merely because
it is expressed as a product over cycles. The old moving-parameter wall
reappears here in a form that can be proved, not merely suspected.

SAVE POINT Q3: the proposed combinatorial source of a scalable cycle count
is refuted by an infinite pure-free family. Arithmetic realisation remains
the load-bearing missing ingredient.
```
