---
id: Q-PARITY-CYCLE-LOCK-01
logical_id: Q-PARITY-CYCLE-LOCK-01
version_id: Q-PARITY-CYCLE-LOCK-01@Q
kind: canonical-result
run: Q
title: "Q parity cycle lock"
status: PROVED
status_raw: "PROVED, ALL N / ALL CYCLE LENGTHS"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 304, line_end: 338}
metadata: {"stable_id": "Q-PARITY-CYCLE-LOCK-01", "version_id": "Q-PARITY-CYCLE-LOCK-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["A simple BAD directed cycle of active odd primes"], "statement": "K_C=1 mod 2N for even length, N-1 mod 2N for odd length; respective lower bounds 2N+1 and N-1.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 304, "line_end": 338}, "depends_on": [], "consequences": [], "does_not_imply": ["No uniform count of cover cycles", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 304, "line_end": 338}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q parity cycle lock

*Run Q - status `PROVED` (raw: `PROVED, ALL N / ALL CYCLE LENGTHS`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

K_C=1 mod 2N for even length, N-1 mod 2N for odd length; respective lower bounds 2N+1 and N-1.

**Assumptions:** A simple BAD directed cycle of active odd primes.

**Does not imply:** No uniform count of cover cycles; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-PARITY-CYCLE-LOCK-01 -- PROVED, ALL N / ALL CYCLE LENGTHS
This strengthens the earlier Q-CYCLE-COVER-ARITHMETIC bound. It is also a
direct parity consequence of the older reconstruction formula; the elementary
modulus proof below avoids needing any external reconstruction theorem.

For a BAD directed cycle C, let ell=|C|, epsilon=(-1)^ell and
  K_C=product(N-q)/product(q),  g_C=(K_C-epsilon)/N.
Then g_C is a positive integer and
  g_C is EVEN for even ell, and ODD for odd ell.
Equivalently,
  K_C = 1 (mod 2N)      if ell is even,
  K_C = N-1 (mod 2N)    if ell is odd.
Consequently EVERY even cycle, however long, costs K_C>=2N+1.

Proof. Every q is coprime to 2N. Its inverse modulo 2N is odd, so
  (N-q)*q^(-1) = N-1 (mod 2N).
The ratio defining K_C is an integer, so it may be evaluated in this unit
group. Multiply over C. Since N is even, (N-1)^2=1 (mod 2N), yielding the
two residues. The lower bounds use K_C>1. For odd ell, K_C+1 is an odd
multiple of N; for even ell, K_C-1 is an even multiple of N.

Thus for EVERY cover f, with E even cycles, O odd cycles and c=E+O,
  T_S >= (2N+1)^E*(N-1)^O,
  product(S) < N^(s-c)/2^E.                         (Q-FINAL-COVER-BOUND)
For an even cycle, divide product(N-q)<N^ell by K_C>=2N+1 to get
product(C)<N^(ell-1)/2. The odd-cycle strict bound was proved earlier.
Multiplication over disjoint cycles finishes the proof.

The modulus statement also holds for the whole T_S of ANY source-free
closed BAD set, even without a matching: closure and source-freeness make
T_S an integer, while the same unit-group multiplication proves
  T_S=(N-1)^s (mod 2N).
Thus an even-size such set has T_S>=2N+1. This is a global parity refinement,
not a requirement of involutivity.
```
