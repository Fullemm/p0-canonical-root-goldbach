---
id: Q-RECIPROCAL-DEFECT-01
logical_id: Q-RECIPROCAL-DEFECT-01
version_id: Q-RECIPROCAL-DEFECT-01@Q
kind: canonical-result
run: Q
title: "Q reciprocal defect"
status: PROVED
status_raw: "PROVED, ALL N / ALL SIZES"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 123, line_end: 143}
metadata: {"stable_id": "Q-RECIPROCAL-DEFECT-01", "version_id": "Q-RECIPROCAL-DEFECT-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Domain of reciprocal forest", "An arbitrary existing directed cycle cover when counting long-cycle vertices"], "statement": "Every cover has at least delta=|V|-2*nu(F) vertices in cycles of length>=3; delta=0 iff an involutive cover exists.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 123, "line_end": 143}, "depends_on": ["Q-RECIPROCAL-FOREST-01"], "consequences": [], "does_not_imply": ["delta need not be attained by the long-cycle count", "delta=0 does not make every cover involutive", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 123, "line_end": 143}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q reciprocal defect

*Run Q - status `PROVED` (raw: `PROVED, ALL N / ALL SIZES`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Every cover has at least delta=|V|-2*nu(F) vertices in cycles of length>=3; delta=0 iff an involutive cover exists.

**Assumptions:** Domain of reciprocal forest; An arbitrary existing directed cycle cover when counting long-cycle vertices.

**Does not imply:** delta need not be attained by the long-cycle count; delta=0 does not make every cover involutive; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-RECIPROCAL-DEFECT-01 -- PROVED, ALL N / ALL SIZES
Let nu(F) be the maximum number of disjoint reciprocal edges and put
  delta(F) = |V| - 2*nu(F).
Every directed cycle cover contains at least delta(F) vertices in cycles of
length >=3. Involutivity is equivalent to delta(F)=0, and then the cover is
the unique involution of Q-UNIQUE-INVOLUTION-01.
Proof: the 2-cycles of any cover form a matching of F, with at most nu(F)
edges. Thus they cover at most 2*nu(F) vertices. The remaining vertices belong
to longer cycles. The converse at delta=0 is the forest perfect matching.
This is a cardinality bound, not a claim that a particular set of delta
vertices is excluded from 2-cycles in every cover.

Maximum matching is found by the same leaf procedure, with isolated vertices
discarded and counted. Proof of maximal cardinality: for a leaf p with sole
neighbour q, there is a maximum matching using p--q. If a maximum matching
leaves both unmatched, add the edge; if it matches q to r, replace q--r by
p--q without changing size; if it already contains p--q, nothing is needed.
Removal and induction prove optimality. The number of discarded isolated
vertices is delta, independent of the leaf choices (the matching itself
need not be unique when delta>0).
```
