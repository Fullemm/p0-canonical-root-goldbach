---
id: Q-RECIPROCAL-FOREST-01
logical_id: Q-RECIPROCAL-FOREST-01
version_id: Q-RECIPROCAL-FOREST-01@Q
kind: canonical-result
run: Q
title: "Q reciprocal forest"
status: PROVED
status_raw: "PROVED, ALL N / ALL SIZES"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 93, line_end: 106}
metadata: {"stable_id": "Q-RECIPROCAL-FOREST-01", "version_id": "Q-RECIPROCAL-FOREST-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Distinct active odd primes below N/3"], "statement": "Mutual-edge graph is a forest; labels increase away from each component minimum.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 93, "line_end": 106}, "depends_on": [], "consequences": [], "does_not_imply": ["No bound on width or number of components", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 93, "line_end": 106}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q reciprocal forest

*Run Q - status `PROVED` (raw: `PROVED, ALL N / ALL SIZES`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Mutual-edge graph is a forest; labels increase away from each component minimum.

**Assumptions:** Distinct active odd primes below N/3.

**Does not imply:** No bound on width or number of components; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-RECIPROCAL-FOREST-01 -- PROVED, ALL N / ALL SIZES
Let V be any finite set of distinct active odd primes below N/3. Put an
UNDIRECTED edge p--q precisely when q divides N-p and p divides N-q.
Neither closure nor minimality is required. This reciprocal graph F is a
forest. Each nontrivial component is rooted at its unique smallest label,
and labels strictly increase on every path away from that root.

Proof. Each vertex has at most one smaller neighbour, by the ordered-parent
fact. An undirected cycle would have a largest vertex with two smaller
neighbours. Thus F is a forest. In a component with v vertices, orient each
edge from small to large. There are v-1 edges and every indegree is at most
one, so exactly one vertex has indegree zero. It is the minimum. Every other
vertex has its unique smaller predecessor, proving the rooted statement.
```
