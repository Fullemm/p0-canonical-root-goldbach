---
id: Q-RECIPROCAL-PATH-GROWTH-01
logical_id: Q-RECIPROCAL-PATH-GROWTH-01
version_id: Q-RECIPROCAL-PATH-GROWTH-01@Q
kind: canonical-result
run: Q
title: "Q reciprocal path growth"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 144, line_end: 155}
metadata: {"stable_id": "Q-RECIPROCAL-PATH-GROWTH-01", "version_id": "Q-RECIPROCAL-PATH-GROWTH-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Root-to-leaf path p0<...<ph in reciprocal forest", "h>=1 for endpoint formula"], "statement": "p_(i+1)>=2*p_i+p_(i-1); A0=3,A1=5,A_(i+1)=2*A_i+A_(i-1); N>2*A_(h-1)*A_h.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 144, "line_end": 155}, "depends_on": [], "consequences": [], "does_not_imply": ["Depth cost does not bound breadth", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 144, "line_end": 155}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q reciprocal path growth

*Run Q - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

p_(i+1)>=2*p_i+p_(i-1); A0=3,A1=5,A_(i+1)=2*A_i+A_(i-1); N>2*A_(h-1)*A_h.

**Assumptions:** Root-to-leaf path p0<...<ph in reciprocal forest; h>=1 for endpoint formula.

**Does not imply:** Depth cost does not bound breadth; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-RECIPROCAL-PATH-GROWTH-01 -- PROVED
On a root-to-leaf path p_0<p_1<...<p_h in F,
  p_(i+1)-p_(i-1) is a positive multiple of 2*p_i,
  p_(i+1) >= 2*p_i+p_(i-1).
Both neighbours divide rows whose common factor is p_i, so p_i divides
their difference; oddness supplies the factor 2. Hence with A_0=3,A_1=5,
A_(i+1)=2*A_i+A_(i-1), one has p_i>=A_i. On the final reciprocal edge,
  N >= p_(h-1)+p_h+2*p_(h-1)*p_h > 2*A_(h-1)*A_h.
This is genuine exponential cost in tree depth, uniform in the total core
size. It does NOT bound breadth, the number of isolated reciprocal vertices,
or the number of reciprocal components uniformly in N.
```
