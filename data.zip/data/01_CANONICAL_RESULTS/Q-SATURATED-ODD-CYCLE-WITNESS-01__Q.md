---
id: Q-SATURATED-ODD-CYCLE-WITNESS-01
logical_id: Q-SATURATED-ODD-CYCLE-WITNESS-01
version_id: Q-SATURATED-ODD-CYCLE-WITNESS-01@Q
kind: canonical-result
run: Q
title: "Q saturated odd cycle witness"
status: VERIFIED EXACT CERTIFICATE
status_raw: "VERIFIED EXACT CERTIFICATE"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 385, line_end: 469}
metadata: {"stable_id": "Q-SATURATED-ODD-CYCLE-WITNESS-01", "version_id": "Q-SATURATED-ODD-CYCLE-WITNESS-01@Q", "status": "VERIFIED EXACT CERTIFICATE", "scope": "Exactly the domains in assumptions", "assumptions": ["N=100224", "Ambient BAD cycle, NOT closed"], "statement": "1613->3181->1831->1613 with full rows 31*3181,53*1831,61*1613; K=100223=N-1; escape 1613->31 with N-31 prime.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 385, "line_end": 469}, "depends_on": [], "consequences": [], "does_not_imply": ["Not a closed obstruction", "Does not refute the minimum-containing cycle theorem", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 385, "line_end": 469}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q saturated odd cycle witness

*Run Q - status `VERIFIED EXACT CERTIFICATE` (raw: `VERIFIED EXACT CERTIFICATE`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

1613->3181->1831->1613 with full rows 31*3181,53*1831,61*1613; K=100223=N-1; escape 1613->31 with N-31 prime.

**Assumptions:** N=100224; Ambient BAD cycle, NOT closed.

**Does not imply:** Not a closed obstruction; Does not refute the minimum-containing cycle theorem; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-SATURATED-ODD-CYCLE-WITNESS-01 -- VERIFIED EXACT CERTIFICATE
The lower bound K_C=N-1 CAN be attained by a genuine ambient BAD cycle:
  N=100224, 1613 -> 3181 -> 1831 -> 1613,
  100224-1613=31*3181,
  100224-3181=53*1831,
  100224-1831=61*1613,
  31*53*61=100223=N-1.
All six factors in these rows are primes. All three cycle labels are active,
above sqrt(N) and below N/3. Their product is 9,394,774,943, against
N^2=10,044,850,176. Thus the exponent ell-1 bound is already close to its
scale on this small concrete example; no asymptotic sharpness is asserted.
The cofactor primes divide the corresponding p-1, as the descent predicts.

This cycle is NOT closed. It has the actual short GOOD escape
  1613 -> 31,    N-31=100193 prime.
Consequently N=31+100193 is a Goldbach representation. The example separates
cycle arithmetic from complete closure exactly. It rules out upgrading
K>=N-1 to K>=3N-1 for ALL ambient odd BAD cycles, while leaving the closed
Hamilton and minimum-containing-cycle statements untouched.
Primality and every complete row were checked by integer trial division;
the certificate is reproduced by the Q audit script.

FURTHER DIAGNOSTIC: exhaustive searches for K=N-1 cycles INSIDE each of the
six actual cores find none, including cycles not belonging to any cover.
Search completeness is only for these six finite graphs: edge cofactors are
>=3, so a partial product exceeding N-1 cannot complete to equality.
All simple cycles are represented once by starting at their least label.
Pruned DFS states: 18,65,48,30,3,18, respectively. This does NOT prove that
every odd cycle inside every core has K>=3N-1; that stronger claim is OPEN.

HOSTILE CHECKS AND CORRECTIONS DURING Q
1. P-R2's version and input hashes were read before choosing the attack;
   its beta=2 result supersedes the unfinished older O script.
2. The bibliography comparison located the exact earlier ordered-parent and
   square-root results, preventing false novelty claims.
3. The reciprocal maximum-matching defect is only a lower bound on long
   vertices; enumeration shows that it is not always attained by a cover.
4. The universal long-cycle bound is N^(ell-1), never N. The 2N+1 improvement
   comes from parity, not from treating long cycles as 2-cycles.
5. A draft diagnostic assertion initially used g*p-epsilon instead of
   g*p+epsilon. Exact host testing rejected it. It was corrected by the
   displayed modular derivation and all checks then passed. No theorem with
   the wrong sign was promoted in this checkpoint.
6. The infinite support family proves only a graph-level obstruction. It is
   never used as a prime-realised BAD core or a Goldbach counterexample.
7. The saturated odd witness explicitly has a GOOD escape. Closure cannot be
   inferred from its three selected cycle edges.

FINAL STRATEGIC VERDICT / RELATION TO GOLDBACH
The user's concern about repeated local casework is justified for the
beta/size ladders without a uniform endpoint. Several claimed new structural
ingredients already occur in the historical corpus, sometimes more strongly.
L/N's complete-row exclusions and O's fixed-beta moving-label finiteness are
real arithmetic advances within narrower classes. P does not by itself
remove the older closure or capacity obstruction.

This run obtains an exact arbitrary-size reciprocal forest/defect, transfers
and sharpens the old cycle budget to EVERY cover, and extracts a valid
full-row descent between cover cycles. It also proves why ordered support
constraints cannot force the number of cycles needed to make that budget
grow with s. This is information about the proposed route, not a claim that
all core methods are impossible.

The next meaningful target is not another beta or size. It is a theorem
bounding the actual cofactor mass that can be absorbed at the terminal
components of the minimum-cycle descent, or a complete-row obstruction that
forces additional disjoint cycles in arithmetic cores. Both require common
N, actual prime factors and their row identities. No such capacity theorem
is currently proved. If neither becomes tractable, work should consume the
extra all-root information of a hypothetical Goldbach failure, rather than
only classify a core which can also exist when Goldbach holds.

Nothing in Q distinguishes p0 from p_k. The earlier p0 empirical limitation
therefore persists. Binary Goldbach remains OPEN. Master and historical
inputs have not been rewritten.

FINAL REPRODUCIBILITY / INTEGRITY CHECK
The final version of reciprocal_cycle_audit_20260908Q_code.txt was rerun
successfully after the parity/descent additions. Every assertion passed.
Results were regenerated in reciprocal_cycle_audit_20260908Q_results.txt.
The three input SHA256 values were rechecked at the end and match the
values recorded at the start. New files from Q are exactly the checkpoint,
the TXT script and its TXT results. No subagents, TeX or PDF were created.
END OF CHECKPOINT 2026-09-08Q.
```
