---
id: Q-SIX-HOST-AUDIT-01
logical_id: Q-SIX-HOST-AUDIT-01
version_id: Q-SIX-HOST-AUDIT-01@Q
kind: canonical-result
run: Q
title: "Q six host audit"
status: FINITE CENSUS
status_raw: "VERIFIED COMPUTATION"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 274, line_end: 303}
metadata: {"stable_id": "Q-SIX-HOST-AUDIT-01", "version_id": "Q-SIX-HOST-AUDIT-01@Q", "status": "FINITE CENSUS", "scope": "Exactly the domains in assumptions", "assumptions": ["N in {128,1718,1862,1928,2200,6142}", "Full reconstructed cores and exhaustive cover enumeration"], "statement": "Exact six-host forest/defect/cover audit; first four hosts have no 2-cycle in any cover; last two have unique involutions.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 274, "line_end": 303}, "depends_on": [], "consequences": [], "does_not_imply": ["No all-N matching or classification theorem", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 274, "line_end": 303}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q six host audit

*Run Q - status `FINITE CENSUS` (raw: `VERIFIED COMPUTATION`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Exact six-host forest/defect/cover audit; first four hosts have no 2-cycle in any cover; last two have unique involutions.

**Assumptions:** N in {128,1718,1862,1928,2200,6142}; Full reconstructed cores and exhaustive cover enumeration.

**Does not imply:** No all-N matching or classification theorem; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-SIX-HOST-AUDIT-01 -- VERIFIED COMPUTATION
Independent reconstruction from complete prime factorizations at each of
the six known N; no pasted core list used. Primality is exact via a sieve.
All source SCC/core, reciprocal forest, coupling parity, path spacing,
cofactor congruence and cover inequalities were checked on every cover.

  N     s  edges(F)  nu(F)  delta  covers  min long vertices  max cycles
  128    8     1       1      6      1          8                 2
  1718  28     2       2     24      6         28                 4
  1862  21     1       1     19      6         21                 4
  1928  14     3       2     10      7         14                 2
  2200   2     1       1      0      1          0                 1
  6142  10     6       5      0      6          0                 5

Not only are the first four cores non-involutive: NONE of their covers
contains even one 2-cycle. This stronger statement is a complete finite
enumeration for these four specific cores, not an all-core theorem.
It also shows that nu(F) can overestimate how many 2-cycles can be used in
a directed cover: the remaining rows and columns must still be matched.
The unique involution at 6142 is independently recovered, consistent with
the repaired P result. The abstract family was additionally checked for
s=5,...,40 (exactly two covers each); the all-s proof above is independent
of this finite diagnostic.

Reproducible artifacts:
  reciprocal_cycle_audit_20260908Q_code.txt
  reciprocal_cycle_audit_20260908Q_results.txt
The results file contains all complete core rows, all reciprocal edges,
maximum forest matchings, all cover signatures and integer cycle costs.
```
