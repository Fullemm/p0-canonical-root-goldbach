---
id: Q-STRATEGIC-AUDIT-01
logical_id: Q-STRATEGIC-AUDIT-01
version_id: Q-STRATEGIC-AUDIT-01@Q
kind: canonical-result
run: Q
title: "Q strategic audit"
status: AUDITED ASSESSMENT
status_raw: "SCOPE-CORRECTED / STRATEGIC ASSESSMENT"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 32, line_end: 92}
metadata: {"stable_id": "Q-STRATEGIC-AUDIT-01", "version_id": "Q-STRATEGIC-AUDIT-01@Q", "status": "AUDITED ASSESSMENT", "scope": "Exactly the domains in assumptions", "assumptions": ["Focused source comparison, not a corpus-wide proof audit"], "statement": "Square-root attractor is in Biblia I10; ordered-parent divisibility in I18; L-O complete-row exclusions are different consumers.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 32, "line_end": 92}, "depends_on": [], "consequences": [], "does_not_imply": ["No blanket novelty verdict over the entire archive", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 32, "line_end": 92}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q strategic audit

*Run Q - status `AUDITED ASSESSMENT` (raw: `SCOPE-CORRECTED / STRATEGIC ASSESSMENT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Square-root attractor is in Biblia I10; ordered-parent divisibility in I18; L-O complete-row exclusions are different consumers.

**Assumptions:** Focused source comparison, not a corpus-wide proof audit.

**Does not imply:** No blanket novelty verdict over the entire archive; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-STRATEGIC-AUDIT-01 -- SCOPE-CORRECTED / STRATEGIC ASSESSMENT
Focused comparison, not a claim to have audited every theorem in the corpus.

1. The small/large decomposition is substantially an old mechanism.
Biblia chapter 'Iteracja 10: pierwiastkowy atraktor SCC', lines 6207 onward,
already proves: the least-factor map sends a terminal BAD SCC below sqrt(N);
there is a directed small-label cycle; each row has at most one large factor,
with exponent 1; large cycles have length at least 3; exact Schur elimination
preserves determinant and integer resonances after retaining cycle ports.
Thus P1's second-label consequence and most of P2 are not a new uniform route.
P1 is explicitly scoped to every closed BAD set, but the same old elementary
least-factor proof extends to that domain. P2's N/3 row window must retain its
source-free/core hypothesis. No first-discovery claim is made here.

2. Ordered parents are also in the old corpus.
Biblia Iteration 18, lines 10177-10268, states exactly that a prime child has
at most one smaller parent, and the stronger spacing 2(k-1)G <= parent span.
K's increasing-edge forest and triangular sparse-row bound package useful
consequences; the divisibility mechanism itself is not new. P7 is a new useful
localisation consequence relative to the passages checked, not a contraction.
It finds ONE internally supported row, not a proper closed subset. In a core
there is NO nonempty proper closed subset, by definition. Repeated halving
cannot be justified by applying P7 to its prefix. The old failure log already
kills closed-subcore descent (Biblia final review, around line 49363).

3. There is a real strengthening in L--O, but its quantifiers matter.
L's four-core matching and the L/N forbidden COMPLETE-row blocks are all-N
arithmetic exclusions, not just support enumeration. O proves finiteness of
the entire moving-prime family at each fixed beta: this improves on fixing
the whole prime alphabet. It still leaves beta free. v1.5 already incorporates
the repaired beta=2 audit; the stale O source assertion is not rerun here.
No next-beta ladder is started. Completing one five-core branch would still
leave other Hall types and arbitrary core sizes; a matching theorem alone
would not eliminate the actual six cores, all of which already have matchings.

4. Involutions are a useful narrower object, not a replacement Goldbach target.
The old exact two-cycle identity is N=p+q+t*p*q, t positive EVEN (Biblia
thm:gfg-two-cycle, around line 1601). P's product test is a consequence.
Every core being involutive is already false. Moreover upgrading matching to
involution for ALL sizes <=4 includes ruling out every 3-core, since an odd
set has no fixed-point-free involution. This is not merely a small graph task.
The current finite census does not settle that all-N Diophantine question.

5. Strategic wall.
The current local restrictions do not become contradictory merely as s grows:
sparse-row allowance grows like sqrt(s), the localised prefix like s/2, and
the small alphabet is unbounded. Older collision/valuation accounting already
identified the same missing global control, while also retaining information
lost by a support-only view. P has not repaired the lost closure/realisation
needed to iterate the old Schur or collision reductions. No old dead route
has yet been shown viable just by combining P with the older results.
This is an assessment of these mechanisms, NOT an impossibility theorem for
all future core methods. A Goldbach failure implies a BAD core; the converse
is false at all six known hosts. Host elimination is a stronger sufficient
route and must not be silently called an equivalent Goldbach reduction.

CHOSEN ATTACK
Use the old ordered-parent fact on the full reciprocal-edge graph, for all N
and all sizes. Seek an exact invariant distinguishing the involutive and
non-involutive parts, rather than additional small-core classifications.
```
