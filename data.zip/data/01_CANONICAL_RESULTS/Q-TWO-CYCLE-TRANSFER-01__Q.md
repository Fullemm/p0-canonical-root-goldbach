---
id: Q-TWO-CYCLE-TRANSFER-01
logical_id: Q-TWO-CYCLE-TRANSFER-01
version_id: Q-TWO-CYCLE-TRANSFER-01@Q
kind: canonical-result
run: Q
title: "Q two cycle transfer"
status: PROVED
status_raw: "PROVED / OLD RESULT REUSED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 156, line_end: 168}
metadata: {"stable_id": "Q-TWO-CYCLE-TRANSFER-01", "version_id": "Q-TWO-CYCLE-TRANSFER-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["BAD reciprocal pair of active odd labels", "Involutive cover only for whole-set conclusions"], "statement": "N=p+q+t*p*q, t positive even; pq<N/2. An involutive s-vertex cover gives prod(S)<(N/2)^(s/2).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 156, "line_end": 168}, "depends_on": [], "consequences": [], "does_not_imply": ["No pq<N analogue for arbitrary long-cycle label products", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 156, "line_end": 168}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q two cycle transfer

*Run Q - status `PROVED` (raw: `PROVED / OLD RESULT REUSED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

N=p+q+t*p*q, t positive even; pq<N/2. An involutive s-vertex cover gives prod(S)<(N/2)^(s/2).

**Assumptions:** BAD reciprocal pair of active odd labels; Involutive cover only for whole-set conclusions.

**Does not imply:** No pq<N analogue for arbitrary long-cycle label products; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-TWO-CYCLE-TRANSFER-01 -- PROVED / OLD RESULT REUSED
For reciprocal p,q below N/3,
  N=p+q+t*p*q,  t positive EVEN, so 2*p*q<N.
The divisibility is the old two-cycle identity; positivity follows from
p+q<2N/3 and evenness from N even and p,q odd. In particular an involutive
core of size s satisfies the sharper inherited bound
  product(S) < (N/2)^(s/2),
and
  product_(q in S)(2q+1) <= (2N+1)^(s/2).
For each pair (2p+1)(2q+1)<=2N+1; multiply over its unique involution.
These inequalities do not constitute a converse test for cores. No
counterexample or proof of the converse for actual cores is claimed.
```
