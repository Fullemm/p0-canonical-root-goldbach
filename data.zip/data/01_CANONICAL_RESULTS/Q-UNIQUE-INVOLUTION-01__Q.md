---
id: Q-UNIQUE-INVOLUTION-01
logical_id: Q-UNIQUE-INVOLUTION-01
version_id: Q-UNIQUE-INVOLUTION-01@Q
kind: canonical-result
run: Q
title: "Q unique involution"
status: PROVED
status_raw: "PROVED, ALL N / ALL SIZES"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08Q.txt", line: 107, line_end: 122}
metadata: {"stable_id": "Q-UNIQUE-INVOLUTION-01", "version_id": "Q-UNIQUE-INVOLUTION-01@Q", "status": "PROVED", "scope": "Exactly the domains in assumptions", "assumptions": ["Domain of reciprocal forest"], "statement": "An involutive cover is a perfect matching of the reciprocal forest; if it exists it is unique.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 107, "line_end": 122}, "depends_on": ["Q-RECIPROCAL-FOREST-01"], "consequences": [], "does_not_imply": ["Does not assert existence of an involution or of any cover", "No Goldbach proof"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08Q.txt", "line": 107, "line_end": 122}, "proof_provenance": [], "computation": ["reciprocal_cycle_audit_20260908Q"], "concepts": ["reciprocal-forest", "cycle-cover", "cycle-product-lock", "closure"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# Q unique involution

*Run Q - status `PROVED` (raw: `PROVED, ALL N / ALL SIZES`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

An involutive cover is a perfect matching of the reciprocal forest; if it exists it is unique.

**Assumptions:** Domain of reciprocal forest.

**Does not imply:** Does not assert existence of an involution or of any cover; No Goldbach proof.

## Source transcript (historical wording; apply current metadata)

```
Q-UNIQUE-INVOLUTION-01 -- PROVED, ALL N / ALL SIZES
An involutive cover of V is exactly a perfect matching of F. It is unique if
it exists. It can be decided by repeatedly matching a leaf to its only
neighbour and deleting both; an isolated vertex certifies failure. Reaching
the empty graph certifies existence and returns the unique involution.
Proof: a leaf edge is forced in every perfect matching. Removal preserves
equivalence. An isolated vertex is impossible to match. Every nonempty forest
without isolated vertices has a leaf, so the procedure terminates. This also
proves uniqueness without invoking an external matching theorem.
These are new deductions for this run, elementary consequences of the old
ordered-parent lemma; no external novelty or priority claim is made.

SAVE POINT Q1: strategic comparison and two arbitrary-size theorems saved.
Next: quantify the reciprocal defect, verify it on actual full-factor cores,
and test whether its arithmetic cost offers any uniform endpoint.
```
