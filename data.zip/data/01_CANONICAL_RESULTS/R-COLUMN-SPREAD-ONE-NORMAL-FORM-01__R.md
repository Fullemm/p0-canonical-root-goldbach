---
id: R-COLUMN-SPREAD-ONE-NORMAL-FORM-01
logical_id: R-COLUMN-SPREAD-ONE-NORMAL-FORM-01
version_id: R-COLUMN-SPREAD-ONE-NORMAL-FORM-01@R
kind: canonical-result
run: R
title: "R column spread one normal form"
status: PROVED
status_raw: "PROVED, NECESSARY ONLY"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 134, line_end: 160}
metadata: {"stable_id": "R-COLUMN-SPREAD-ONE-NORMAL-FORM-01", "version_id": "R-COLUMN-SPREAD-ONE-NORMAL-FORM-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "If max E-min E<=1, then d>=2, N-r=P^d, every q<P has E_q=d+1 and every p!=r has Omega(N-p)=d+1.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 134, "line_end": 160}, "depends_on": ["R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 134, "line_end": 160}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R column spread one normal form

*Run R - status `PROVED` (raw: `PROVED, NECESSARY ONLY`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

If max E-min E<=1, then d>=2, N-r=P^d, every q<P has E_q=d+1 and every p!=r has Omega(N-p)=d+1.

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-COLUMN-SPREAD-ONE-NORMAL-FORM-01 -- PROVED, NECESSARY ONLY
Suppose the range of the column totals is at most 1:
  max(E_q)-min(E_q)<=1.
Then necessarily all of the following hold:
  d=E_P>=2;
  N-r=P^d (pure top row);
  E_q=d+1 for EVERY q<P;
  Omega(N-p)=d+1 for EVERY p!=r;
  Omega(N-r)=d.
Thus range zero is impossible, and range one has one and only one deficient
column, namely the largest prime, paired with one and only one lower-degree
row, its pure parent. This is a necessary normal form, NOT an existence claim.

Proof. The nonpure case forces some E_q>=d+2, incompatible with range <=1.
The pure case forces some E_q>=d+1; since E_P=d, all other E_q<=d+1.
There are s-1 other columns, whose surplus is >=s-1 by the preceding theorem.
Each contributes at most 1, so every one contributes exactly 1. Equality in
the total-count inequality then forces every other row degree to equal d+1.

This excludes an entire moving-exponent profile class at every size and gives
an exact description of the immediate residual class. No enumeration of
successive d or s is undertaken.

SAVE POINT R2: an integer surplus of at least s-1 is forced on smaller primes;
range-one column profiles have an exact necessary form. These are stronger
than the weighted comparison and do not require a perfect matching.
```
