---
id: R-HOSTILE-COUNTEREXAMPLES-01
logical_id: R-HOSTILE-COUNTEREXAMPLES-01
version_id: R-HOSTILE-COUNTEREXAMPLES-01@R
kind: canonical-result
run: R
title: "R hostile counterexamples"
status: VERIFIED EXACT CERTIFICATE
status_raw: "VERIFIED EXACT CERTIFICATES / KILLED EXTENSIONS"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 161, line_end: 268}
metadata: {"stable_id": "R-HOSTILE-COUNTEREXAMPLES-01", "version_id": "R-HOSTILE-COUNTEREXAMPLES-01@R", "status": "VERIFIED EXACT CERTIFICATE", "scope": "Specified exact finite witnesses", "assumptions": ["Use each stated set separately; the no-closure witness is NOT a core"], "statement": "N=2200 kills pressure at an arbitrary one-parent prime. N=128 kills arbitrary pure-base minimum-row claims; S={5,7,11} kills the no-closure extension.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 161, "line_end": 268}, "depends_on": [], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 161, "line_end": 268}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R hostile counterexamples

*Run R - status `VERIFIED EXACT CERTIFICATE` (raw: `VERIFIED EXACT CERTIFICATES / KILLED EXTENSIONS`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

N=2200 kills pressure at an arbitrary one-parent prime. N=128 kills arbitrary pure-base minimum-row claims; S={5,7,11} kills the no-closure extension.

**Assumptions:** Use each stated set separately; the no-closure witness is NOT a core.

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-HOSTILE-COUNTEREXAMPLES-01 -- VERIFIED EXACT CERTIFICATES / KILLED EXTENSIONS
1. The maximum-prime hypothesis cannot be replaced by 'has a unique parent'.
At N=2200 the core is S={3,13}, with
  N-3=13^3, N-13=3^7.
Both primes have one parent. E_13=3 and E_3=7. R1 holds with P=13,d=3,
but applying it again with base 3 and d=7 would demand
  3^7*13^3 > (3*13)^7,
which is false. Likewise the other row has Omega=3, not >=8. Therefore
iterating the theorem by moving to the newly found higher-exponent prime
is KILLED by an actual minimal core. The order geometry is essential.

2. An arbitrary pure row need not be the minimum-Omega row.
The actual core at N=128 contains N-3=5^3 and N-5=3*41. The former has
Omega=3, the latter Omega=2. The pure base 5 is not the largest core label.
Thus the stronger conclusion is specifically about a pure row at the
largest BASE, not at the largest parent, nor at any pure row.

3. Full closure cannot be omitted from the row-degree theorem.
Take N=128 and S={5,7,11}. These are active prime labels with composite rows;
P=11 has the unique parent 7 and N-7=11^2. But N-5=3*41 has only two factors,
contrary to the would-be >=3 conclusion. The factor 41 leaves S. This is
not a core, and demonstrates exactly why the Q^d comparison needs closure.

VERIFIED COMPUTATION
Reconstructed each of the six known cores by trial division, maximal BAD-set
pruning and minimal forward closures. This is independent of the sieve used
in Q. Verified complete factorizations, strong connectivity, unique top
parent, every R inequality, equality conditions and the counterexamples.

  N     s    P   parent d   k   min Omega  sum E  sum(E-d)  max E
  128    8    41    5   1   3       2       20      12        7
  1718  28   571    5   1   3       2       74      46       20
  1862  21   619    5   1   3       2       61      40       25
  1928  14   641    5   1   3       2       45      31       12
  2200   2    13    3   3   1       3       10       4        7
  6142  10   877    3   1   7       2       40      30       13

The pure-top equality min Omega=d is exercised at N=2200; the other five
exercise the nonpure case. No known core has column spread <=1, so the
range-one normal form is supported by its proof, not by a positive example.
An additional integer-only regression checked the gap inequalities for
1,253,175 bounded tuples of odd P,Q,r,d,k. This finite grid is only a code
check; the all-N/all-d proof is the explicit difference-of-powers estimate.

Artifacts:
  valuation_pressure_audit_20260908R_code.txt
  valuation_pressure_audit_20260908R_results.txt
Both are plain text. The latter includes full rows, column totals, row
degrees, exact rational weighted ratios and the scope counterexamples.

RELATION TO THE ARCHIVES AND LIMITS
The exact column product A=product(q^E_q) is old (Biblia's global SCC lock;
the Flow Factor Theory conservation identities). This run does not claim it
as new. The added argument combines the unique parent of the largest prime
with the gap P^d-Q^d to compare EVERY other complete row against Q^d. That
produces a pointwise row-degree bound and then a linear integer surplus;
it is not obtained by renaming the old product identity.
Focused searches did not locate this exact general row-degree comparison or
column-spread-one normal form in the supplied corpus. This is not a claim
of mathematical priority, and it is not an exhaustive audit of every archive.

The post-CRD warning about transferring rooted absorption is respected:
the N=2200 core has no branching row at all, and R's theorem holds there.
It forces total exponents, not multiple distinct factors in every row.
In particular Omega>=d+1 does NOT imply omega>=d+1 or even omega>=2;
a pure power of a smaller prime can supply the full degree, as 3^7 does.
Replacing multiplicity by branching would erase precisely the surviving
case and invalidate the argument.

WHAT HAS AND HAS NOT MOVED
PROVED for every size: uniform column totals are impossible; the largest
prime's total exponent forces a strict degree gap in every other row; at
least s-1 units of surplus must occur on smaller primes; range-one columns
are confined to the displayed exact normal form. No matching is assumed.

The effect is strongest when d>=2. For five of the known six cores d=1,
and the basic surplus is largely a restatement of compositeness. It would
be misleading to present R as a uniform elimination of all cores or as an
asymptotic Goldbach result. Even the d>=2 class is not eliminated: N=2200
is a standing witness.

The missing upper bound is now explicit. If h_q=max_p v_q(N-p), then the
old actual-valuation decomposition writes
  sum_q(E_q-d)
    = sum_q(E_q-h_q) + sum_q(h_q-d).
The first sum records repeat use across actual rows; the second can grow
through pure prime powers of smaller primes. R supplies a lower bound for
their sum but no uniform upper bound. Either resource may be large, and
the N=2200 example places all the surplus in pure powers, without collisions.
An argument charging every surplus unit to a collision would therefore fail.

GOLDBACH STATUS / NEXT FRONTIER
Goldbach failure implies existence of a BAD core, but actual cores coexist
with Goldbach representations. R gives necessary restrictions on such cores;
it does not produce the final contradiction or distinguish p0 from p_k.
Binary Goldbach, universal root success and host finiteness remain OPEN.

The next useful question must bound both actual repeat valuations and high
pure powers while preserving their row identities, or use information about
ALL prime roots that a genuine Goldbach failure supplies. Simply reapplying
R at the higher-exponent smaller prime is explicitly refuted above. No
successive size, exponent or column-spread census is recommended without
an independent uniform endpoint.

SAVE POINT R3: proofs, exact audits and the failed recursive extension are
recorded. All new artifacts are TXT; the supplied master and archives are
preserved. No proof of Goldbach is claimed.
```
