---
id: R-LINEAR-VALUATION-SURPLUS-01
logical_id: R-LINEAR-VALUATION-SURPLUS-01
version_id: R-LINEAR-VALUATION-SURPLUS-01@R
kind: canonical-result
run: R
title: "R linear valuation surplus"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 114, line_end: 133}
metadata: {"stable_id": "R-LINEAR-VALUATION-SURPLUS-01", "version_id": "R-LINEAR-VALUATION-SURPLUS-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "sum(E_q-d)>=s-1 if k=1, >=s otherwise. max_{q<P}E_q>=d+1 (pure), >=d+2 (nonpure).", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 114, "line_end": 133}, "depends_on": ["R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 114, "line_end": 133}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R linear valuation surplus

*Run R - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

sum(E_q-d)>=s-1 if k=1, >=s otherwise. max_{q<P}E_q>=d+1 (pure), >=d+2 (nonpure).

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-LINEAR-VALUATION-SURPLUS-01 -- PROVED
Full factorisation conserves the total number of prime factors:
  sum_(q in S)E_q = sum_(p in S)Omega(N-p).
Consequently
  sum_(q in S)(E_q-d) >= s-1            if k=1,
  sum_(q in S)(E_q-d) >= s              if k>=3.
Since the term at P is zero, the same inequalities sum only over q<P.
In particular
  max_(q<P) E_q >= d+1                 if k=1,
  max_(q<P) E_q >= d+2                 if k>=3.
For the last line, if all other totals were <=d+1 then their surplus would
be <=s-1, less than the required s. These are integer constraints, not
asymptotic estimates or numerical conjectures.

For d>=2 this is an all-size excess over the generic compositeness bound
sum Omega>=2s: total mass is at least s(d+1)-1, or s(d+1) in the nonpure case.
The force increases with s at fixed d, but the AVAILABLE exponent mass is
also unbounded. This alone is not a contradiction. For d=1, k=1 is forbidden
by BADness and the basic total bound is just the old sum Omega>=2s.
```
