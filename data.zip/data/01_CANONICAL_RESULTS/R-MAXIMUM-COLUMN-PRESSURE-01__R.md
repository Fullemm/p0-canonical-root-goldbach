---
id: R-MAXIMUM-COLUMN-PRESSURE-01
logical_id: R-MAXIMUM-COLUMN-PRESSURE-01
version_id: R-MAXIMUM-COLUMN-PRESSURE-01@R
kind: canonical-result
run: R
title: "R maximum column pressure"
status: PROVED
status_raw: "PROVED, ALL N / ALL SIZES"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 39, line_end: 72}
metadata: {"stable_id": "R-MAXIMUM-COLUMN-PRESSURE-01", "version_id": "R-MAXIMUM-COLUMN-PRESSURE-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "A=prod(N-p)>R^d, R=prod(q), d=E_P. Therefore some q<P has E_q>d.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 39, "line_end": 72}, "depends_on": ["TOP-DIVIDES-ONE-ROW-20260907J"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 39, "line_end": 72}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R maximum column pressure

*Run R - status `PROVED` (raw: `PROVED, ALL N / ALL SIZES`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

A=prod(N-p)>R^d, R=prod(q), d=E_P. Therefore some q<P has E_q>d.

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-MAXIMUM-COLUMN-PRESSURE-01 -- PROVED, ALL N / ALL SIZES
Assume the largest prime P has an internal parent (automatic if S is a core).
Put d=E_P. Then
  A > R^d,
equivalently
  sum_(q in S)(E_q-d)*log(q) > 0.
In particular some q<P has E_q>d. The exponent total at the largest prime
is strictly below the logarithmically weighted average of all column totals.

Proof.
P can divide at most one row: if P divided N-r and N-t, it would divide
0<|r-t|<P. Let r be that unique parent. It is distinct from P by activity.
Write the COMPLETE row as
  N-r=k*P^d,  k odd positive, P not dividing k.
Here d is the WHOLE column total because P has just one parent.

If k>=3, then for every p in S,
  N-p = k*P^d+r-p >=3*P^d+r-P >2*P^d >=2*p^d,
since P^d>=P. Multiplication gives the stronger A>2^s*R^d.

If k=1, BADness gives d>=2. Put Q=max(S without P); s>=2 since a singleton
closed active set is impossible. We have N=P^d+r. Cancel the exact row P^d
from A and the factor P^d from R^d. Each remaining row satisfies
  N-p >= P^d+r-P > Q^d.
Indeed P-Q>=2, and
  P^d-Q^d=(P-Q)*(P^(d-1)+...+Q^(d-1)) >=2*P^(d-1)>=2P.
Every remaining base is <=Q, so its d-th power is <=Q^d. There are s-1
remaining rows and s-1 remaining bases. Their product comparison is strict,
so A/R^d>1. QED.

The proof consumes a full row, the largest-prime parent rigidity and exact
prime-exponent conservation. It does not follow from the support graph alone.
No numerical cutoff, minimality, cycle cover or external theorem is used.
```
