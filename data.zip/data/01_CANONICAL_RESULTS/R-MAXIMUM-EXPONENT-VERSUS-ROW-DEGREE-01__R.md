---
id: R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01
logical_id: R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01
version_id: R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01@R
kind: canonical-result
run: R
title: "R maximum exponent versus row degree"
status: PROVED
status_raw: "PROVED, ALL N / ALL SIZES"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 96, line_end: 113}
metadata: {"stable_id": "R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01", "version_id": "R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "For p!=r, Omega(N-p)>=d+1. E_P<=min Omega, equality iff k=1; then row r is the unique minimum and Omega(N-r)=d.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 96, "line_end": 113}, "depends_on": ["TOP-DIVIDES-ONE-ROW-20260907J"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 96, "line_end": 113}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R maximum exponent versus row degree

*Run R - status `PROVED` (raw: `PROVED, ALL N / ALL SIZES`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

For p!=r, Omega(N-p)>=d+1. E_P<=min Omega, equality iff k=1; then row r is the unique minimum and Omega(N-r)=d.

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01 -- PROVED, ALL N / ALL SIZES
The same top-row argument gives a stronger COUNTING statement, before logs.
Retain P, its unique parent r, d=E_P and N-r=k*P^d. Then
  Omega(N-p)>=d+1 for EVERY p in S other than r.
If k>=3 this also holds for p=r. If k=1, the row at r has Omega=d and is
the UNIQUE row of minimum total prime-factor count.
Here Omega counts prime factors WITH multiplicity; it is not omega/support.

Proof. No row at p!=r contains P. Its factors all lie at most at the second
largest label Q. As proved in R1, N-p>Q^d in both k=1 and k>=3 cases.
If it had at most d prime factors, its value would be <=Q^d, a contradiction.
The parent row has Omega=d+Omega(k); Omega(k)=0 iff k=1, and otherwise >=1.
Thus
  E_P <= min_(p in S) Omega(N-p),
with equality EXACTLY when the parent row is pure, and then the minimum
occurs at that row alone. This does not assert that every pure row is such
a minimum: its base must be the largest prime of the entire closed set.
```
