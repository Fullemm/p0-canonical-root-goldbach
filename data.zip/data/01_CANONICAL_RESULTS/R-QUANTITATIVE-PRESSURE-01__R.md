---
id: R-QUANTITATIVE-PRESSURE-01
logical_id: R-QUANTITATIVE-PRESSURE-01
version_id: R-QUANTITATIVE-PRESSURE-01@R
kind: canonical-result
run: R
title: "R quantitative pressure"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 81, line_end: 95}
metadata: {"stable_id": "R-QUANTITATIVE-PRESSURE-01", "version_id": "R-QUANTITATIVE-PRESSURE-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "For N-r=k*P^d, k>=3 implies A>2^s*R^d. For k=1, A/R^d >= ((P^d+r-P)/Q^d)^(s-1)>1, Q second largest.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 81, "line_end": 95}, "depends_on": ["R-MAXIMUM-COLUMN-PRESSURE-01"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 81, "line_end": 95}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R quantitative pressure

*Run R - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

For N-r=k*P^d, k>=3 implies A>2^s*R^d. For k=1, A/R^d >= ((P^d+r-P)/Q^d)^(s-1)>1, Q second largest.

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-QUANTITATIVE-PRESSURE-01 -- PROVED
If the unique parent row of P is not pure (k>=3), then
  sum_(q in S)(E_q-d)*log(q) > s*log(2).
If it is pure, N=P^d+r and Q is the second largest prime, then
  A/R^d >= ((P^d+r-P)/Q^d)^(s-1) > 1.
The first lower bound grows linearly in s on the logarithmic scale. It has
not been paired with a uniform upper bound. When d=1 it is essentially the
familiar row-height bound T_S>2^s, so it must not be advertised as new
information in that common case. Its extra content concerns d>=2 and the
pure top row, where comparison is with R^d rather than merely R.

SAVE POINT R1: the all-size maximum-column comparison and the uniform-profile
exclusion are proved. Next: test stronger plausible formulations, and inspect
whether the valuation imbalance can be converted into an iterated argument.
```
