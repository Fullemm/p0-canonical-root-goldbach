---
id: R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01
logical_id: R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01
version_id: R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01@R
kind: canonical-result
run: R
title: "R uniform column profile exclusion"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08R.txt", line: 73, line_end: 80}
metadata: {"stable_id": "R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01", "version_id": "R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01@R", "status": "PROVED", "scope": "All N and arbitrary finite size under stated hypotheses", "assumptions": ["N even", "S finite, nonempty, odd active primes", "N-p composite for all p in S", "ALL prime factors of every N-p belong to S", "P=max S has an internal parent (source-free is sufficient, not necessary)"], "statement": "The totals E_q cannot all be equal; E_P is not a maximum column total.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 73, "line_end": 80}, "depends_on": ["R-MAXIMUM-COLUMN-PRESSURE-01"], "consequences": [], "does_not_imply": ["No Goldbach proof", "No p0-specific guarantee", "No uniform upper capacity bound", "No iteration at a smaller prime", "Omega is multiplicity, not support", "Spread-one form is necessary, not an existence theorem"], "killed_stronger_forms": [], "counterexamples": ["N=2200, S={3,13}; E3=7, E13=3", "N=128, N-3=5^3, N-5=3*41", "N=128 nonclosed S={5,7,11}"], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08R.txt", "line": 73, "line_end": 80}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "old top-parent input, not the R surplus theorem"}, {"file": "ai_master_1_6.tex", "line": 8312, "relation": "comparison snapshot Q-R3"}], "computation": ["valuation_pressure_audit_20260908R"], "concepts": ["unique-top-parent", "column-total", "row-degree", "closure", "collision"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
---

# R uniform column profile exclusion

*Run R - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

The totals E_q cannot all be equal; E_P is not a maximum column total.

**Assumptions:** N even; S finite, nonempty, odd active primes; N-p composite for all p in S; ALL prime factors of every N-p belong to S; P=max S has an internal parent (source-free is sufficient, not necessary).

**Does not imply:** No Goldbach proof; No p0-specific guarantee; No uniform upper capacity bound; No iteration at a smaller prime; Omega is multiplicity, not support; Spread-one form is necessary, not an existence theorem.

## Source transcript (historical wording; apply current metadata)

```
R-UNIFORM-COLUMN-PROFILE-EXCLUSION-01 -- PROVED
No source-free active closed BAD set can have E_q equal to one constant d
for every q in S. More generally E_P cannot be the largest column total.
This follows immediately from R-MAXIMUM-COLUMN-PRESSURE-01. It excludes
all sizes and all possible positive constants d simultaneously.
This is a conclusion about TOTAL valuations across rows, not equal row
lengths, equal support degrees, or equal exponents on the edges of one cycle.
```
