---
id: RANK-MIRROR-SURJECTIVITY-20260907G
logical_id: RANK-MIRROR-SURJECTIVITY-20260907G
version_id: RANK-MIRROR-SURJECTIVITY-20260907G@research
kind: canonical-result
run: research
title: "AUDIT-"
status: PROVED WITH REPAIR
status_raw: "PROOF ACCEPTED, with one small domain correction and scope limits."
audit: SOURCE-PROOF-REPAIR-LOCATED; ASYMPTOTIC-DEPENDENCY-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6568, line_end: 6590}
metadata: {"stable_id": "RANK-MIRROR-SURJECTIVITY-20260907G", "version_id": "RANK-MIRROR-SURJECTIVITY-20260907G@research", "status": "PROVED WITH REPAIR", "scope": "Fixed rank and individual complement values", "assumptions": ["Odd m>=3", "k>=0", "Standard PNT and Bertrand as stated in source"], "statement": "Each odd m>=3 occurs as a complement at every fixed rank. Unit m=1 occurs at k>=1, never p0. Include the N=4 diagonal complement 2 when that convention is used.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6568, "line_end": 6590}, "depends_on": [], "consequences": [], "does_not_imply": ["Same range is not same distribution", "No eventual BFS success theorem"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6568, "line_end": 6590}, "proof_provenance": [], "computation": [], "concepts": ["p0-exceptionality", "rank-formula"], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-PROOF-REPAIR-LOCATED; ASYMPTOTIC-DEPENDENCY-NOT-RECHECKED", "metadata_completeness": "CURATED"}
---

# AUDIT-

*Run research - status `PROVED WITH REPAIR` (raw: `PROOF ACCEPTED, with one small domain correction and scope limits.`) - audit `SOURCE-PROOF-REPAIR-LOCATED; ASYMPTOTIC-DEPENDENCY-NOT-RECHECKED`*

> Verification: **SOURCE-PROOF-REPAIR-LOCATED; ASYMPTOTIC-DEPENDENCY-NOT-RECHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Each odd m>=3 occurs as a complement at every fixed rank. Unit m=1 occurs at k>=1, never p0. Include the N=4 diagonal complement 2 when that convention is used.

**Assumptions:** Odd m>=3; k>=0; Standard PNT and Bertrand as stated in source.

**Does not imply:** Same range is not same distribution; No eventual BFS success theorem.

## Source transcript (historical wording; apply current metadata)

```
AUDIT-ID: RANK-MIRROR-SURJECTIVITY-20260907G
STATUS: PROOF ACCEPTED, with one small domain correction and scope limits.
For every odd integer m>=3 and k>=0, some odd prime P>m has
 #{prime q : (P+m)/2 <= q < P}=k.
Equivalently, at N=P+m, the root p_k has complement exactly m.
Proof checked: along consecutive primes above m, this count starts at
zero and its upward jumps are at most one. PNT gives count tending to
infinity, so every nonnegative integer is attained. The asymptotic input
pi(t)~t/log(t) is stated at https://dlmf.nist.gov/27.2#E3.
For m=1 the count starts at one at P=3, and every k>=1 is attained.
Bertrand excludes k=0. Thus every noncanonical fixed rank has a unit row.
SMALL CORRECTION:
If N=4 and roots p>=N/2 are included, p0=2 has complement 2.
Hence the full C_0 in 07F is {2} union {odd m>=3}, not just the odd set.
The displayed odd-only formula is correct after restricting to odd roots
or N>=6. Composite-complement conclusions are unaffected.
SCOPE CORRECTION:
This rules out an excluded class of individual odd first-row integers
as a universal explanation of a rank. It does NOT rule out a law about
rank and eventual success, properties involving N jointly with m, or
different frequencies of first-row patterns at different ranks.
All fixed ranks having the same range is not distributional equivalence.
```
