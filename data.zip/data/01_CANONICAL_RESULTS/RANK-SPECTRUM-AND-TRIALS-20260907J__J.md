---
id: RANK-SPECTRUM-AND-TRIALS-20260907J
logical_id: RANK-SPECTRUM-AND-TRIALS-20260907J
version_id: RANK-SPECTRUM-AND-TRIALS-20260907J@J
kind: canonical-result
run: J
title: "Rank spectrum and trials"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 502, line_end: 563}
metadata: {"stable_id": "RANK-SPECTRUM-AND-TRIALS-20260907J", "version_id": "RANK-SPECTRUM-AND-TRIALS-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 502, "line_end": 563}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 502, "line_end": 563}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1097, style: ID-TABLE}
---

# Rank spectrum and trials

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X5.  RANK-SPECTRUM-AND-TRIALS-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
DOMAIN: every upper root p_k (all primes in [N/2, N)) of every host, using the
reference implementation semantics exactly, including the diagonal rule.
AUDIT: 891 (N, root) pairs; the stopped traversal verdict and the criterion
"PF(m) subseteq B_N" agree in every case (0 mismatches).  Total failures 301,
distributed 8 / 68 / 63 / 57 / 4 / 101 -- identical to EXP3.

(a) Which hosts actually test p_0:
   N=128 : p_0 = 67,   m_0 = 61 PRIME          -> p_0 is itself a Goldbach
                                                  witness, depth 0, |R| = 0
   N=1718: p_0 = 859 = N/2 PRIME (DIAGONAL)    -> success at depth 0, |R| = 0
   N=1862: p_0 = 937,  m_0 = 925 = 5^2 * 37    -> TESTED; success depth 2,
                                                  |R| = 23, escapes = 1: (37,73)
   N=1928: p_0 = 967,  m_0 = 961 = 31^2        -> TESTED; success depth 2,
                                                  |R| = 16, escapes = 1: (31,271)
   N=2200: p_0 = 1103, m_0 = 1097 PRIME        -> depth 0, |R| = 0
   N=6142: p_0 = 3079, m_0 = 3063 = 3 * 1021   -> TESTED; success depth 2,
                                                  |R| = 12, escapes = 1: (1021,569)
   ==> the traversal from p_0 is exercised at exactly THREE values of N in the
       whole range, and in ALL THREE the world hangs on exactly ONE escape edge.
       (Consistent with EXP4: 1862, 1928 and 6142 all appear in the corpus's own
       G_esc = 1 list.)

(b) First failing rank and the gap to m_0:
   N=128 : first failure rank 2, mirror 55  (m_0 = 61,  gap 6)
   N=1718: first failure rank 2, mirror 841 (m_0 = 859, gap 18)
   N=1862: first failure rank 1, mirror 921 (m_0 = 925, gap 4)
   N=1928: first failure rank 1, mirror 957 (m_0 = 961, gap 4)
   N=2200: first failure rank 48, mirror 729 (m_0 = 1097, gap 368)
   N=6142: first failure rank 2, mirror 3053 (m_0 = 3063, gap 10)
   ==> on FIVE of the six hosts failure begins at rank 1 or 2, with the largest
       failing mirror within 4 to 18 of m_0.  The sole exception is N = 2200,
       whose basin has only two elements.

(c) Per-rank trial table (a rank is TESTED at a host iff its mirror is composite;
    otherwise the root is itself a Goldbach witness):
        rank  tested  failed   rate
           0       3       0   0.00
           1       5       2   0.40
           2       6       4   0.67
           3       6       5   0.83
           4       4       3   0.75
           5       5       2   0.40
           6       3       1   0.33
           7       6       1   0.17
           8       6       5   0.83
           9       4       1   0.25
          10       3       0   0.00
          11       6       3   0.50
    ranks 1..30 pooled: 127 tested, 51 failed, rate 0.402.

(d) The corpus's own survivor set {0,10,14,26,28,30,62,63,71,74} with the number
    of times each rank was actually tested:
        rank :   0  10  14  26  28  30  62  63  71  74
        tests:   3   3   2   5   4   2   4   2   5   3
    ==> rank 0 has the SAME record as rank 10 and a STRICTLY WEAKER record than
        ranks 26 and 71 (0 failures in 5 trials each).  The master explicitly
        warns "Do not promote the survivor ranks" for 10,14,26,...; by its own
        data that warning applies a fortiori to rank 0.

--------------------------------------------------------------------------------
```
