---
id: RANK0-NOT-DISTINGUISHED-20260907J
logical_id: RANK0-NOT-DISTINGUISHED-20260907J
version_id: RANK0-NOT-DISTINGUISHED-20260907J@J
kind: canonical-result
run: J
title: "8.3"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 934, line_end: 1082}
metadata: {"stable_id": "RANK0-NOT-DISTINGUISHED-20260907J", "version_id": "RANK0-NOT-DISTINGUISHED-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 934, "line_end": 1082}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 934, "line_end": 1082}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1103, style: ID-TABLE}
---

# 8.3

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
8.3  RANK0-NOT-DISTINGUISHED-20260907J          STATUS: VERIFIED COMPUTATION
Rank 0 was tested 3 times with 0 failures.  So was rank 10.  Ranks 26 and 71
were each tested 5 times with 0 failures -- a strictly better record.  The
master's own warning box says of {10,14,26,28,30,62,63,71,74}: "Neither the
4035 transplant exhaustion nor the 22130 bounded-mirror census proves universal
composite-success of any noncanonical rank."  By the corpus's own data, that
warning applies to rank 0 with MORE force, not less.  This is an internal
inconsistency in the corpus and it is load-bearing: X1/H-p_0 is called "the
central hypothesis of the whole project".

8.4  The margin.  On all three genuine trials the complete canonical world has
EXACTLY ONE escape edge:
   N = 1862: |R| = 23, escape (37 -> 73), i.e. 1862-73 = 1789 prime;
   N = 1928: |R| = 16, escape (31 -> 271), i.e. 1928-271 = 1657 prime;
   N = 6142: |R| = 12, escape (1021 -> 569), i.e. 6142-569 = 5573 prime.
Delete one edge in each and X1 is false.  A "structural protection" that always
wins by exactly one edge, three times, is not a structure.

8.5  How close the failures come.  On FIVE of the six hosts the FIRST failing
rank is 1 or 2, and the largest failing mirror is within 4 to 18 of m_0
(N = 1862: 921 vs 925;  N = 1928: 957 vs 961;  N = 6142: 3053 vs 3063).  Any
putative canonical mechanism must therefore switch off between consecutive
primes, at the same N -- precisely the discrimination the master's
cor:postDH-fixedprojection proves impossible for any fixed finite prime-label
projection, and which its EXP8 shows to be invisible to depth, world size,
margin, Omega, retention and normalised largest factor.

8.6  What survives about p_0.  Everything CATEGORICAL in Chapter "The Canonical
p_0 Programme" survives untouched: the gap equivalence r = p_0 <=> [x,r) has no
prime, the reflection gate, kappa_gen(p_k) = k, reflection-completeness,
boundary filtration, the phase trichotomy, and the fact that p_0 is the unique
fixed rank with no unit-row input.  These are theorems about the POSITION of
p_0.  What does not survive is the inference from them to DYNAMICAL reliability:
the reliability data consist of three trials.

8.7  Consequence for the frontier.  If H is finite -- which all evidence and
the heuristic of section 9.3 support -- then X1 is TRUE, but true for the
uninteresting reason that B_N = empty for all N > 6142, plus a three-case
verification.  Its proof is then exactly a proof of (SSR), which implies
Goldbach.  There is no intermediate p_0-specific theorem to find.

================================================================================
9.  EXACT NEW FRONTIER
================================================================================

9.1  The object.  H = { N even : N has a self-smooth representation }, i.e.
there is a finite set S of primes coprime to N with max S < N/3 and N - S
contained in Gamma_S.  Equivalently (T2) H = { N : Gamma_N has a terminal SCC
inside Bad_N }.  Established here:
   H ^ [6, 2.6*10^6]                              = the six  (X1, exhaustive)
   H ^ [6, 6*10^7] with min(basin) <= 200         = the six  (X2)
   H with a two-element core, N <= 10^24          = {2200}   (X3, complete)
   H with a pure-power row q^e <= 10^17, q <= 3000,
       partner <= 1500                            = the six  (X7)
Cores have sizes 2, 8, 10, 14, 21, 28 and maxima 13, 41, 571, 619, 641, 877.

9.2  The three questions that matter now.
  F1  (finiteness)  Is H finite?  Equivalent to (SSR) for large N, hence
      Goldbach-hard.  Not to be attacked head-on.
  F2  (rarity)      Is #{N <= X : N in H} = o(X)?  This is weaker than F1 and
      is NOT obviously Goldbach-hard in the same way, since almost-all Goldbach
      is known.  It is nevertheless at least as hard as the current
      exceptional-set bounds, because Goldbach failure at N forces N in H
      (T10(a)).  A proof would be a genuine analytic advance.
  F3  (classification by core size)  For each fixed s, classify all N whose
      basin has a core of size s.  s = 2 is COMPLETE for N <= 10^24 (X3) and
      reduces to a Pillai equation (T6).  s = 3 is reduced to an explicit
      two-parameter family by T7.  s >= 4 is open; T5 gives one step of the
      induction and it does not obviously continue.

9.3  Why H is expected to be finite (HEURISTIC, with the counting).
Fix a candidate core S with |S| = s and let the q's be the primes of S.  The
number of S-smooth integers up to X is ~ (log X)^s / (s! prod log q), so the
density of Gamma_S near X is ~ (log X)^{s-1} / ((s-1)! X prod log q).  A host
requires ONE membership N - q_1 in Gamma_S (which selects N from a set of size
~ (log X)^s / (s! prod log q) up to X) and then s-1 further independent
memberships.  The expected number of N <= X working for a given S is therefore
  ~ [(log X)^s / (s! prod log q)] * [(log X)^{s-1} / ((s-1)! X prod log q)]^{s-1}.
For s = 2 this is ~ (log X)^3 / (2 X (log q_1 log q_2)^2); summing over pairs
q_1 < q_2 <= sqrt X gives O((log X)^{-3}), i.e. a convergent total.  For s >= 3
the exponent s-1 makes convergence faster.  The heuristic therefore predicts
finitely many hosts in total, consistent with six observed and with X3 finding
no second two-core below 10^24.  It also predicts that new hosts, if any, are
small -- which is why deep searches at large N are a poor investment (see 10).

9.4  The mechanism (X6, EMPIRICAL).  Basins survive exactly where the peeling
is weak, and the peeling is driven by the low Goldbach partners
G_low = {q < N/3 : N-q prime}.  All six hosts are below their local mean in
G_low/pi(N/3); four have a near-minimal singular series.  A quantitative version
of "small G_low => basin survives with probability ..." would be the natural
analytic entry point to F2.

9.5  What is now closed and should not be reopened.
  - selector-versus-basin theorems motivated by p_0 reliability (section 8);
  - fixed finite alphabet S machinery of any kind (HC2, HC3, FR1);
  - counting/pigeonhole squeezes on the exponent matrix (FR2, FR3);
  - cycle-rarity arguments (FR4);
  - any further transplant or bounded-mirror census (the master already
    exhausted these, and X5(d) shows what they can and cannot mean).

================================================================================
10.  RECOMMENDED NEXT ATTACK
================================================================================

NEXT-1 (highest value, cheap, purely Diophantine).  Complete the s = 3
classification.  A FIRST PASS WAS RUN IN THIS SESSION (X7) and was negative up
to 10^17 for pure-power bases q <= 3000 with partner <= 1500; what remains is
the complementary region (large base, or large partner r, or the case where the
pure-power row is the row of a LARGE element).  T7 reduces every three-element
core to
        N = q_1 + q_2^a   or   N = q_2 + q_1^b,   exponent >= 2, base <= N^{1/2},
with the third element q_3 recovered as N minus a {q_1,q_2}-smooth number in
(2N/3, N).  Enumerate prime powers Q = q^e <= X (e >= 2) and, for each, the
O(log^2 X) admissible partners; test each candidate N by the forward-closure
test of X2 (which is O(polylog) per candidate).  This should reach X = 10^{14}
or beyond and would either produce a NEW HOST -- immediately supplying a fourth
trial of the p_0 hypothesis, the single most informative datum available -- or
close the s = 3 class the way X3 closed s = 2.

NEXT-2.  Extend T5 to a genuine induction.  T5 says max S divides exactly one
row.  Ask: for which t does q_t divide at most one row of index < t (T4 gives
q_t > max S - min S as a sufficient condition, which only the top element
satisfies)?  A version usable for the top k elements would give an s = 4, 5
analogue of T7 and, iterated, a structure theorem for all cores.

NEXT-3.  Attack F2 (rarity) analytically via the X6 mechanism.  Concretely:
show that N in H forces an abnormal deficiency in
#{q < N/3 : q prime, N-q prime} relative to the singular series, and combine
with a Bombieri-Vinogradov / circle-method bound on the set of N with such a
deficiency.  This is the only route identified in this run that is plausibly
NOT Goldbach-hard, because it asks for a density statement, not an every-N one.

NEXT-4.  Two lines of bookkeeping for the master.
  (a) Record HC3: thm:postDH-supportsep is asymptotically true and finitely
      vacuous; move it out of the frontier chapter.
  (b) Record T1's scope correction to def:graph.

NOT RECOMMENDED.  Undirected deep host searches at very large N.  The seeded
search (X2) is cheap and can be pushed further -- note its cost is dominated by
random access into the smallest-prime-factor table, so beyond ~10^8 it becomes
memory- rather than CPU-bound -- but 9.3 predicts hosts are small and sparse and
X7 confirms this at 10^17 for the searchable shapes; the marginal return per
CPU-hour is far below NEXT-1 and NEXT-3.  Also not
recommended: any further work on P1BR, L1, E1, W1, K1, X1 as stated -- by
section 8 they are targets defined by a three-trial observation.

================================================================================
STABLE IDS INTRODUCED IN THIS RUN
================================================================================
```
