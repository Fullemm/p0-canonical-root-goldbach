---
id: S-ARITY-GCD-PURE-TOP-PRESSURE-01
logical_id: S-ARITY-GCD-PURE-TOP-PRESSURE-01
version_id: S-ARITY-GCD-PURE-TOP-PRESSURE-01@S
kind: canonical-result
run: S
title: "Arity gcd amplifies pure-top column pressure"
status: PROVED
status_raw: "AUDITED HISTORICAL IMPORT"
audit: ASTRA-PROOF-CHECKED
source_audit: ASTRA-CHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "research_S/residue_matching_checkpoint_20260909S.txt", line: 137, line_end: 170}
metadata: {"stable_id": "S-ARITY-GCD-PURE-TOP-PRESSURE-01", "version_id": "S-ARITY-GCD-PURE-TOP-PRESSURE-01@S", "status": "PROVED", "scope": "All instances under the explicitly stated hypotheses; no existence assertion", "assumptions": ["N even", "S finite nonempty source-free active closed BAD set", "P=max S has unique parent r with N-r=P^d", "g_S is gcd of Omega(N-p)-1 over all rows of S"], "statement": "For p!=r, Omega(N-p)>=d+g_S; sum_(q<P)(E_q-d)>=(|S|-1)g_S and column spread>=g_S. Thus a spread-one core has arity gcd one; if it lies in a load-one failed world, all corresponding residue quotient indices equal one.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 137, "line_end": 170}, "depends_on": ["R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01", "R-COLUMN-SPREAD-ONE-NORMAL-FORM-01", "S-RESIDUE-QUOTIENT-ARITY-01"], "consequences": [], "does_not_imply": ["No contradictory upper capacity bound", "The strengthened surplus requires a pure maximal-label row", "N=2200 remains a valid core and satisfies Goldbach", "Goldbach and universal p0 success remain OPEN"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 137, "line_end": 170}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/research_S/source_chat_max_selected_20260909.txt", "relation": "source discussion; claims independently scoped in checkpoint S"}], "computation": ["research_audit_20260909S"], "concepts": ["row-degree", "column-total", "pure-row", "unique-top-parent"], "historical_aliases": [], "search_aliases": ["arity gcd pure top pressure", "quotient modulus spread one bridge"], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED", "external_dependencies": [], "verification_note": "Run S: written argument checked in main process; external Nagura statement checked in primary paper. Finite controls do not establish universal claims."}
---

# Arity gcd amplifies pure-top column pressure

*Run S - status `PROVED` (raw: `AUDITED HISTORICAL IMPORT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

For p!=r, Omega(N-p)>=d+g_S; sum_(q<P)(E_q-d)>=(|S|-1)g_S and column spread>=g_S. Thus a spread-one core has arity gcd one; if it lies in a load-one failed world, all corresponding residue quotient indices equal one.

**Assumptions:** N even; S finite nonempty source-free active closed BAD set; P=max S has unique parent r with N-r=P^d; g_S is gcd of Omega(N-p)-1 over all rows of S.

**Does not imply:** No contradictory upper capacity bound; The strengthened surplus requires a pure maximal-label row; N=2200 remains a valid core and satisfies Goldbach; Goldbach and universal p0 success remain OPEN.

## Source transcript (historical wording; apply current metadata)

```
S-ARITY-GCD-PURE-TOP-PRESSURE-01 -- PROVED
Statement. Let S be a finite nonempty source-free active closed BAD set.
Let P=max S have unique parent r with N-r=P^d. Define
  g_S=gcd over p in S of [Omega(N-p)-1].
Then
  g_S divides d-1,
  Omega(N-p)>=d+g_S for every p!=r,
  sum over q<P of (E_q-d)>=(|S|-1)g_S,
  max E-min E>=g_S.
Thus any such spread-one set has g_S=1. Any spread-one core contained in a
load-one failed world forces ALL of that world's residue quotient indices t_q
to be 1. Conversely a nontrivial t_q excludes spread-one cores in that world.

Proof. The pure top row has Omega(N-r)=d, so g_S divides d-1.
The audited R-MAXIMUM-EXPONENT-VERSUS-ROW-DEGREE-01 gives Omega(N-p)>=d+1
for every p!=r, preserving complete closure and the maximal label P.
All row degrees are 1 modulo g_S, and so is d. The next allowed degree above
d is therefore d+g_S. Summing row degrees and using exact column equality gives
  sum_q E_q >= d+(|S|-1)(d+g_S).
Subtract |S|d and use E_P=d. Among |S|-1 lower columns at least one then has
E_q>=d+g_S, while min E<=E_P=d. This proves the range bound.
If a core K lies in R minus {r_root}, RAL makes each t_q divide every row arity
minus one of K, hence t_q divides g_K. A spread-one core has a pure top by the
R normal form and the just-proved bound forces g_K=1. QED.

Concrete check: N=2200, S={3,13}, P=13, r=3, d=3. The two row degrees are
3 and 7, so g_S=gcd(2,6)=2. The bound gives E_3-3>=2; actually E_3-3=4.
This survives a real core and correctly gives no Goldbach contradiction.

Research gain and limit. This couples the new RAL invariant to the existing R
pressure theorem and the range-one Hall branch. The multiplicity modulus
increases the pure-top surplus floor; no upper capacity bound is supplied.
The nonprimitive canonical branch and full-generation residue branch survive.
END RESULT
```
