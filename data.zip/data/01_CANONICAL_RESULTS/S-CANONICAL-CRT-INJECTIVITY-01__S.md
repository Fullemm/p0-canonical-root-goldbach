---
id: S-CANONICAL-CRT-INJECTIVITY-01
logical_id: S-CANONICAL-CRT-INJECTIVITY-01
version_id: S-CANONICAL-CRT-INJECTIVITY-01@S
kind: canonical-result
run: S
title: "Canonical global CRT states are injective"
status: PROVED-EXTERNAL
status_raw: "AUDITED HISTORICAL IMPORT"
audit: ASTRA-PROOF-CHECKED
source_audit: ASTRA-CHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "research_S/residue_matching_checkpoint_20260909S.txt", line: 31, line_end: 64}
metadata: {"stable_id": "S-CANONICAL-CRT-INJECTIVITY-01", "version_id": "S-CANONICAL-CRT-INJECTIVITY-01@S", "status": "PROVED-EXTERNAL", "scope": "All instances under the explicitly stated hypotheses; no existence assertion", "assumptions": ["N even and N>=50", "p0 is the least prime at least N/2 and its complete traversal fails", "R is the finite reachable active closed BAD world", "For the subgroup product corollary only: m squarefree and each first-front prime has the root as unique parent"], "statement": "Reduction modulo m=N-p0 is injective on R minus {p0}; multiplying by N inverse preserves it. Thus |A_m|=|R'| exactly. On the primitive branch |R'|<=product_q |G_q intersect (1-G_q)|.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 31, "line_end": 64}, "depends_on": ["S-RESIDUE-QUOTIENT-ARITY-01"], "consequences": [], "does_not_imply": ["No bound comparing |R'| with |Q|", "No forced small subgroup", "No noncanonical-root injection claim", "Prime diagonal is GOOD and has no normalization inverse", "Goldbach and universal p0 success remain OPEN"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 31, "line_end": 64}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/research_S/source_chat_max_selected_20260909.txt", "relation": "source discussion; claims independently scoped in checkpoint S"}], "computation": ["research_audit_20260909S"], "concepts": ["p0-exceptionality", "collision", "failure-criterion", "closure"], "historical_aliases": [], "search_aliases": ["global CRT residue entropy", "canonical modulus collision multiplicity", "iniekcja reszt modulo m"], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED", "external_dependencies": ["Nagura prime interval theorem (1952); N=50 checked separately"], "verification_note": "Run S: written argument checked in main process; external Nagura statement checked in primary paper. Finite controls do not establish universal claims."}
---

# Canonical global CRT states are injective

*Run S - status `PROVED-EXTERNAL` (raw: `AUDITED HISTORICAL IMPORT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

Reduction modulo m=N-p0 is injective on R minus {p0}; multiplying by N inverse preserves it. Thus |A_m|=|R'| exactly. On the primitive branch |R'|<=product_q |G_q intersect (1-G_q)|.

**Assumptions:** N even and N>=50; p0 is the least prime at least N/2 and its complete traversal fails; R is the finite reachable active closed BAD world; For the subgroup product corollary only: m squarefree and each first-front prime has the root as unique parent.

**Does not imply:** No bound comparing |R'| with |Q|; No forced small subgroup; No noncanonical-root injection claim; Prime diagonal is GOOD and has no normalization inverse; Goldbach and universal p0 success remain OPEN.

## Source transcript (historical wording; apply current metadata)

```
S-CANONICAL-CRT-INJECTIVITY-01 -- PROVED-EXTERNAL
Statement. Let N>=50 and let R be a failed world rooted at canonical p0.
Then reduction modulo m=N-p0 is injective on R minus {p0}. Consequently, with
sigma_u=N^(-1)u mod m and A_m={sigma_u:u in R'}, one has EXACTLY |A_m|=|R'|.
This injection does not require primitive load-one or squarefreeness.

Proof. For x>25, Nagura proves a prime between x and 6x/5. With x=N/2 and
canonical minimality, p0<3N/5 and m>2N/5. At N=50 the same bound follows directly
from p0=29. Every u in R minus {p0} is <N/3<m. Thus two distinct such integers
cannot be congruent modulo m. Also gcd(N,m)=gcd(N,p0)=1 because p0 is an active
upper prime, so multiplying by N^(-1) preserves distinctness. QED.

Primitive corollary. For each q in Q define H_q and G_q as in the next result.
Each u in R' is prime and different from every divisor q of m, hence coprime
to m. Load-one also makes N-u coprime to m. Under the CRT identification,
sigma_u belongs to product_q [G_q intersect (1-G_q)]. Therefore
  |R'| = |A_m| <= product over q in Q of |G_q intersect (1-G_q)|.
The bound is now a bound on the actual number of residual labels, without a
collision-multiplicity loss. It gives no contradiction unless its right side
is proved smaller than the necessary population.

Provenance. Nagura, On The Interval Containing At Least One Prime Number,
Proc. Japan Acad. 28(4), 177-181 (1952), DOI 10.3792/pja/1195570997.
Primary source: https://www.jstage.jst.go.jp/article/pjab1945/28/4/28_4_177/_pdf
Project antecedents: raw/root/master_ai.tex lines 4905-4911 (Nagura window),
and 2880-2886 (non-root endpoint bound). Related old two-sheet product-collision
argument at 2889-2906 concerns path products, not this exact state map.

Target correction. The chat proposed worlds with arbitrarily many actual rows
collapsing onto few GLOBAL classes modulo m. They cannot exist in this canonical
domain. Repeated residues at ONE prime q, repeated paths, and repeated appearances
of the SAME label are different questions and are not excluded by this theorem.
This says nothing about a general noncanonical upper root with very small m.
END RESULT
```
