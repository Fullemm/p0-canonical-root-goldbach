---
id: S-RANGE-ONE-MATCHING-01
logical_id: S-RANGE-ONE-MATCHING-01
version_id: S-RANGE-ONE-MATCHING-01@S
kind: canonical-result
run: S
title: "Column spread one forces a cycle cover and edge extension"
status: PROVED
status_raw: "AUDITED HISTORICAL IMPORT"
audit: ASTRA-PROOF-CHECKED
source_audit: ASTRA-CHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "research_S/residue_matching_checkpoint_20260909S.txt", line: 105, line_end: 135}
metadata: {"stable_id": "S-RANGE-ONE-MATCHING-01", "version_id": "S-RANGE-ONE-MATCHING-01@S", "status": "PROVED", "scope": "All instances under the explicitly stated hypotheses; no existence assertion", "assumptions": ["N even", "S finite nonempty source-free closed BAD set of active odd primes", "Complete valuation column range is at most one"], "statement": "The support has a perfect matching and directed cycle cover. Removing the pure parent row and maximal-label column gives a (d+1)-regular matrix decomposable into d+1 permutation matrices. Every support edge extends to a cover. Minimality is unnecessary.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 105, "line_end": 135}, "depends_on": ["R-COLUMN-SPREAD-ONE-NORMAL-FORM-01"], "consequences": [], "does_not_imply": ["Does not construct or exclude an arithmetic spread-one set", "Does not prove arbitrary-size Hall outside this branch", "Does not force an involution or reciprocal cycles", "Goldbach and universal p0 success remain OPEN"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/research_S/residue_matching_checkpoint_20260909S.txt", "line": 105, "line_end": 135}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/research_S/source_chat_max_selected_20260909.txt", "relation": "source discussion; claims independently scoped in checkpoint S"}], "computation": ["research_audit_20260909S"], "concepts": ["cycle-cover", "column-total", "row-degree", "unique-top-parent"], "historical_aliases": [], "search_aliases": ["range one matching bridge", "spread one Hall regular valuation multigraph", "regular matrix decomposition"], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED", "external_dependencies": [], "verification_note": "Run S: written argument checked in main process; external Nagura statement checked in primary paper. Finite controls do not establish universal claims."}
---

# Column spread one forces a cycle cover and edge extension

*Run S - status `PROVED` (raw: `AUDITED HISTORICAL IMPORT`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

The support has a perfect matching and directed cycle cover. Removing the pure parent row and maximal-label column gives a (d+1)-regular matrix decomposable into d+1 permutation matrices. Every support edge extends to a cover. Minimality is unnecessary.

**Assumptions:** N even; S finite nonempty source-free closed BAD set of active odd primes; Complete valuation column range is at most one.

**Does not imply:** Does not construct or exclude an arithmetic spread-one set; Does not prove arbitrary-size Hall outside this branch; Does not force an involution or reciprocal cycles; Goldbach and universal p0 success remain OPEN.

## Source transcript (historical wording; apply current metadata)

```
S-RANGE-ONE-MATCHING-01 -- PROVED
Statement. Let S be a finite nonempty source-free closed BAD set of active odd
primes. Let M[p,q]=v_q(N-p), E_q=sum_p M[p,q], P=max S. If max E-min E<=1,
then its support admits a perfect matching, hence a directed cycle cover.
Minimality of S is unnecessary. More strongly, every support edge belongs to
some cover. The reduced valuation matrix is a sum of d+1 permutation matrices.

Proof. The already audited R-COLUMN-SPREAD-ONE-NORMAL-FORM-01 gives a unique
parent r of P, d=E_P>=2, N-r=P^d, E_q=d+1 for q!=P, and row totals d+1 for
p!=r. Remove row r and column P from M. The remaining square nonnegative
integer matrix B has every row and column sum d+1: removed row r had no other
factor and removed column P had no other parent.
For any collection X of remaining rows, its (d+1)|X| units enter columns with
capacity at most (d+1)|neighbors(X)|. Thus Hall's condition holds. A matching
of all remaining rows, together with r->P, is a full cover of S.
Subtract the matching permutation matrix from B and repeat while the common
degree is positive. This decomposes B into d+1 permutation matrices. Every
positive entry occurs in at least one of these matchings. Adjoining r->P to
each proves the support-edge extension assertion. For the full matrix this is
M plus ONE extra unit at (r,P), not M itself, decomposed into d+1 covers.
There are no loops because p divides N-p would imply p divides N, forbidden
by activity. QED.

Scope. This closes Hall only in the spread-one branch. It neither constructs
an arithmetic spread-one set nor eliminates one. It does not force reciprocal
cycles or an involution. An abstract graph counterexample to a strengthening
is not automatically an arithmetic counterexample.
Provenance: chat turn 1f5cd26c-a0cd-46c3-8e07-3d67cc112a9e and its review
ffc093c9-b509-4e09-966f-9f01a5ef64e0; archived R normal form at
raw/nowe/goldbach_checkpoint_2026-09-08R.txt lines 134-160.
END RESULT
```
