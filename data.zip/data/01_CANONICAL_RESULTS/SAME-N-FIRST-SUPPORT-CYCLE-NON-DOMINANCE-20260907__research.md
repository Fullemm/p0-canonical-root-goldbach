---
id: SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907
logical_id: SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907
version_id: SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907@research
kind: canonical-result
run: research
title: "Same n first support cycle non dominance"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION with exact hand-checkable certificates."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5590, line_end: 5633}
metadata: {"stable_id": "SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907", "version_id": "SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5590, "line_end": 5633}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5590, "line_end": 5633}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n first support cycle non dominance

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION with exact hand-checkable certificates.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-FIRST-SUPPORT-CYCLE-NON-DOMINANCE-20260907
STATUS: VERIFIED COMPUTATION with exact hand-checkable certificates.
EXACT STATEMENT:
Whether the first-support induced factorization subgraph is acyclic can
favor p0 or p1 at the SAME N. It is not a universal separator of the roots.
EXAMPLE A (p0 acyclic, p1 cyclic):
 N=344, p0=173 (h=1), p1=179 (h=7).
 S0=PF(171)={3,19}; its induced graph has no edges:
 344-3=11*31, 344-19=5^2*13.
 S1=PF(165)={3,5,11}; its induced edges are
 3->11, 5->3, 11->3, because
 344-3=11*31, 344-5=3*113, 344-11=3^2*37.
 Thus 3<->11 is a BAD cycle inside S1. As already recorded above,
 BOTH full searches succeed at depth 2 with W=5. The cycle does not
 force even a larger work count here.
EXAMPLE B (p0 cyclic, p1 acyclic):
 N=1268, p0=641 (h=7), p1=643 (h=9).
 The integers 634,...,640 are composite, and 641 and 643 are primes;
 hence the ranks are exact. The first complements are
 1268-641=627=3*11*19; 1268-643=625=5^4.
 In S0={3,11,19}, the BAD vertices 3 and 11 form a two-cycle:
 1268-3=1265=5*11*23; 1268-11=1257=3*419.
 The remaining child 19 is GOOD, since 1268-19=1249 prime. Therefore
 the COMPLETE stopped induced subgraph on S0 has exactly edges
 3->11 and 11->3. The p0 search succeeds at depth 1, W=4, via 19.
 In S1={5}, there is no internal edge: 1268-5=1263=3*421.
 Thus p1's first-support induced graph is acyclic while p0's is cyclic.

HOSTILE CHECK:
All roots, prime factors, prime endpoints and root ranks were verified
by trial division. The induced graph uses all internal edges; GOOD
vertices contribute no outgoing edges in the stopped graph. In B the
cycle labels are BAD even though another first child is GOOD. This is
precisely why a prescribed BAD cycle must not be confused with complete
first-front BADness or full BFS failure. These are exact examples,
not an exhaustive claim about first occurrences.
DEPENDENCIES: Elementary arithmetic and the fixed graph definition.
RELATION TO p0 / GOLDBACH:
Same-N non-dominance of this structural diagnostic. Neither example is
a failed canonical search or a Goldbach counterexample. The earlier
performance non-dominance examples N=2024 and N=2180 remain separate.
NOVELTY: NOT YET AUDITED.
```
