---
id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B
logical_id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B
version_id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B@research
kind: canonical-result
run: research
title: "Same n growing depth dual product barrier"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4562, line_end: 4637}
metadata: {"stable_id": "SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B", "version_id": "SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4562, "line_end": 4637}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4562, "line_end": 4637}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n growing depth dual product barrier

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B
STATUS: PROVED.
EXACT STATEMENT:
Fix epsilon in (0,1), c in (0,1), and kappa>=0 with c+kappa<1. Put
 L=log X, l=loglog X,
 D=floor(c*l/log l),       K=floor(L^kappa).
For all but o(X/L) primes P in [X,2X], let N=2(P-1). Then every
SAME-N root p_k(N), 0<=k<=K, is BAD, and every simple successful
stopped path from any one of those roots, of length 1<=d<=D, satisfies
 BOTH
  product_(j=1..d) q_j > X^(1-epsilon),
  product_(j=1..d) [(N-q_(j-1))/q_j] > X^(1-epsilon).        (DUAL)
The exceptional proportion among primes P is at most
 L^(-(1-c-kappa)/2+o(1)).
Here q_0 is the selected root, and the products exclude q_0 as a label
but include the cofactor of its first edge. The result is simultaneous
over the entire root prefix and over every eligible simple path.

PROOF:
The canonical union of the two small-product exceptions and direct
success has size <=X*L^(-2+c+o(1)). For later roots, the union of the
two pair exceptions just proved has size <=H*X*L^(-3+c+o(1)), uniformly
for 3<=H<=L^2. These are counts of all possible later-root pairs, so
there will be no extra factor K when using them for a root prefix.
Take H to be an integer within 1 of
 L^((3-c+kappa)/2).
The inequality c+kappa<1 guarantees H<L^2 for large X. The same
consecutive-gap summation proved in SAME-N-GROWING-ROOTS-COMPLETE-
RADIUS-TWO gives at most O(KX/H) starts with p_K-P>H-1. The use of PNT
to place all p_K below 3X remains valid because K is a fixed power of
log X. Outside these long-gap starts, every later prefix root has
h<=H, so all its exceptions are counted by the pair union.
Divide the total exceptional count by pi(2X)-pi(X) asymptotic to X/L.
It is bounded by
 L^(-1+c+o(1)) + O(K*L/H) + H*L^(-2+c+o(1))
 <= L^(-(1-c-kappa)/2+o(1)).
The exponent is negative. Every root and every successful simple path
outside this exceptional set has (DUAL), proving the assertion.

HOSTILE CHECK:
1. This is a restriction on successful paths, not complete BADness
   through the growing depth D. Large products remain possible.
2. Both products are for the ACTUAL same path. Their simultaneous
   lower bounds are obtained by removing the union of the two failure
   sets; no independence is assumed.
3. The depth-prefix tradeoff c+kappa<1 is explicit. It is not legitimate
   to let both parameters approach 1 with this proof.
4. The cofactor proof had to handle the changing gcd of a moving
   product; the label proof had to retain the extra prime P. Neither
   is an automatic h=1-to-h>1 substitution.
5. A shortest successful path is simple, so the theorem supplies a
   necessary condition for success by D. A closed BAD core has no
   successful path and therefore satisfies the conclusion vacuously.
6. The proof does not claim that the scalar data C_j or A_j distinguish
   p0. The SAME-N conclusion proves the asymptotic obstruction is shared.
DEPENDENCIES: Both product pair bounds; PNT; prime-gap double count.
RELATION TO GOLDBACH: Constrains increasingly long routes but supplies
no contradiction to arbitrary closed support or to large-product success.
RELATION TO p0: A multigeneration property previously available only
for p0 is now shared by a growing SAME-N nearby prefix, with a second,
complementary arithmetic product constraint added.
WHAT REMAINS OPEN: The middle range where both products are large,
complete radius three, and eventual escape from a closed BAD set.
NOVELTY: NOT YET AUDITED.

COROLLARY / EXACT RESIDUAL WINDOW:
At any successful path the identity
 (product q_j)*(product a_j)=product_(j=1..d)(N-q_(j-1))
is exact. Since N<4X, (DUAL) implies, on the same typical starts,
 X^(1-epsilon)<product q_j<4^d*X^(d-1+epsilon),
and the same upper and lower bounds for product a_j. At depth three,
the unexcluded label-product range is therefore between approximately
X^(1-epsilon) and X^(2+epsilon). It still includes the region with
all three labels of size X^0.4. Nothing here resolves the existing
FAIL-ID AUTOMATIC-THIRD-GENERATION-SIEVE-SWITCH-20260906.
```
