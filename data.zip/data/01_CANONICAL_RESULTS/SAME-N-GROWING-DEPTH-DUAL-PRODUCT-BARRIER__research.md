---
id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER@research
logical_id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER
version_id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER@research
kind: historical-version
run: research
title: "Same n growing depth dual product barrier"
status: SUPERSEDED
status_raw: "for fixed c+kappa<1,"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5053, line_end: 5058}
metadata: {"stable_id": "SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER", "version_id": "SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5053, "line_end": 5058}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5053, "line_end": 5058}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Same n growing depth dual product barrier

*Run research - status `SUPERSEDED` (raw: `for fixed c+kappa<1,`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER-20260906B` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
1. SAME-N-GROWING-DEPTH-DUAL-PRODUCT-BARRIER: for fixed c+kappa<1,
   almost every prime P in [X,2X] has, simultaneously for the same-N
   roots k<=floor((log X)^kappa), no successful simple path of length
   <=floor(c*loglog X/logloglog X) whose LABEL product or COFACTOR
   product is <=X^(1-epsilon). The new cofactor argument uses an exact
   moving modulus, growing-form sieve, and an ordered-simplex bound.
```
