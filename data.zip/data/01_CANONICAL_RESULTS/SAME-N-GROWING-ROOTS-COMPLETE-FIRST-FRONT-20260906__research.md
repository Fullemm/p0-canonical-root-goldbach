---
id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906
logical_id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906
version_id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906@research
kind: canonical-result
run: research
title: "Same n growing roots complete first front"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2173, line_end: 2293}
metadata: {"stable_id": "SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906", "version_id": "SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2173, "line_end": 2293}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2173, "line_end": 2293}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n growing roots complete first front

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906
STATUS: PROVED.
EXACT STATEMENT:
Let P run over primes in [X,2X], let N=2(P-1), and let p_k(N) be the
(k+1)-st prime at or above N/2; in particular p_0=P. Let K=K(X)>=1 be
integer-valued with
 K=o(log X/(loglog X)^3).
For all but o(X/log X) such primes P, EVERY root p_k, 0<=k<=K, is BAD
and EVERY prime divisor q of N-p_k is also BAD. Thus none of these
roots has a GOOD vertex at distance <=1 in its complete stopped graph.
This compares all the roots for the SAME N, and includes all their
large as well as small first-front factors.
For 1<=K<=log X/(loglog X)^3, a quantitative bound for the exceptional
proportion (relative to X/log X) is
 O((loglog X)^2/log X + sqrt(K*(loglog X)^3/log X)).             (R1)
For example K=floor(log X/(loglog X)^5) gives proportion O(1/loglog X).
These are asymptotic statements; they do not assert this proportion at
currently accessible numerical sizes.

PROOF:
Write L=log X and l=loglog X. First isolate p_0: the preceding theorem
counts its exceptional P by O(X*l^2/L^2).
For any later prime Q=p_k, put h=Q-P+1. Then h is an odd integer >=3,
 P=Q-h+1,       N=2(Q-h),       m=N-Q=Q-2h.
We first count all such pairs (P,Q) with 3<=h<=H, without imposing any
rank condition on Q. Assume 2<=H<=sqrt(X)/10, P in [X,2X], Q prime.
Then Q<=3X for large X. For EACH h the number of these pairs with a
GOOD root or a GOOD first-front child is
 O(X*l^3/L^3), uniformly in h.                                (R2)
We prove (R2) carefully.
If m is prime, the three forms in Q are
 Q,                    Q-h+1,                    Q-2h.
They are primitive, distinct since h>1, with nonzero shift differences
h-1, 2h, h+1. Their Delta is polynomially bounded in X and nu(ell)>=1.
The three-form consumer bounds the count by O(X*l^2/L^3).
Otherwise m is odd composite. For a GOOD child q write m=a*q, a>=3 odd.
The quantities
 Q=a*q+2h,
 P=a*q+h+1,
 g=N-q=(2a-1)*q+2h
are prime. Split into q<=sqrt X and q>sqrt X.
For small prime q, sieve in a<=3X/q the THREE forms
 q*a+2h,             q*a+h+1,              2q*a+2h-q.
If q divides h or h+1, one of Q,P would be divisible by q while larger
than q, so this tuple contributes nothing. For every remaining q these
three forms are primitive, including the last since its constant is
odd and coprime to q. Their pair determinants are
 q*(1-h),           -q*(q+2h),            -q*(q+2),
all nonzero. Delta is bounded by X to an absolute constant power.
Except possibly at ell=q there is a root modulo every prime. Hence
the uniform three-form count is O(X*l^2/(q*L^3)). Summing 1/q over
prime q<=sqrt X gives O(l), and this range contributes O(X*l^3/L^3).
For large q>sqrt X, fix a<=3sqrt X and sieve in q<=3X/a the FOUR forms
 q,       a*q+2h,       a*q+h+1,       (2a-1)*q+2h.
If any of the last three forms is not primitive, every value is a
multiple of a fixed integer d>1 with d<=2h+1<X. But its actual prime
value (Q, P, or g) is >=X for large X. Hence that a has no solutions.
For the remaining a all forms are primitive. The determinants between
the first form and the others are 2h, h+1, 2h. The other three are
 a*(1-h),           2h*(1-a),            h+1-2a.
The first two do not vanish. If the last vanished, then h+1=2a and
gcd(a,h+1)=a>1, a case just excluded. Thus there is no hidden
coincidence of two prime forms. Delta is polynomially bounded in X,
and nu(ell)>=1 because the first form is the variable q. The four-form
bound is O(X*l^3/(a*L^4)). Summing 1/a up to 3sqrt X costs O(L),
giving O(X*l^3/L^3). All relevant prime values exceed four. Both
sieve-variable upper limits are >=sqrt X, so the uniform constants
are absolute, independently of h<=H. This proves (R2).
Summing (R2) over h<=H bounds the number of exceptional P with ANY
such nearby Q by O(H*X*l^3/L^3). No extra factor K is required: every
relevant pair (P,Q) is already in this count.
It remains to show that the first K successors usually lie within
Q-P<=H-1. For the indicated range of K, PNT ensures that p_K<=3X for
every P in [X,2X] and sufficiently large X. Write each p_K-P as the
sum of its K consecutive prime gaps. Summing over starting primes P
in [X,2X], every gap is used at most K times and all gaps lie between
primes in [X,3X]. Their total length is <=2X. Therefore
 sum_(P in [X,2X] prime)(p_K-P)<=2KX,
so at most 2KX/(H-1) of these P have p_K-P>H-1.
Combining all three exceptional sets and dividing by X/L yields
 O(l^2/L + K*L/(H-1) + H*l^3/L^2).
Take H to be an integer within O(1) of sqrt(K*L^3/l^3). Uniformly in
1<=K<=L/l^3, H tends to infinity and is <sqrt X/10 for large X.
This proves (R1). If K=o(L/l^3), both terms in (R1) tend to zero.
For every remaining P, all roots have positive odd complements; their
proper prime factors are active by gcd(N,Q)=1 and q<Q. Indeed Q>P
is close to P, Q>N/2 and Q<N, so it cannot divide the even number N
(the only possible quotient would be 1). A root is BAD after excluding
the prime case, and each child complement exceeds 1 and is composite
after excluding all the counted GOOD children. This completes the
full stopped-graph conclusion.

HOSTILE CHECK:
1. The rank condition was used only in the unweighted prime-gap sum.
   No claim about typical polylogarithmic gaps for uniformly sampled
   even N is required. Sampling is over prime P, not over gap-weighted x.
2. The extra primality P=Q-h+1 is essential. Without it the sieve loses
   one logarithm and summing over h in the required range does not give
   this result. For h=1 these forms coincide; p_0 was handled separately
   by the two-/three-form theorem, not by a false four-prime count.
3. The potentially vanishing determinant h+1-2a forces an imprimitive
   form and has no actual prime solutions in the stated large-X range.
4. The conclusion is FULL radius-one BAD, not a selected path, not a
   statement that only many children are BAD, and not failure of BFS.
5. The property is explicitly SHARED by nearby roots at the same N.
   It is not evidence of an advantage peculiar to p_0. It rules out
   shallow-success explanations only in the precise asymptotic family
   and prefix stated here, leaving all deeper behavior open.
6. The count remains true if the algorithm has arbitrary child order:
   it is a graph-theoretic distance assertion, not a runtime statistic.

DEPENDENCIES: Uniform FKL sieve consumer, elementary harmonic sums,
PNT for the prime-sample density and availability of K primes below 3X.
RELATION TO GOLDBACH: No representation is ruled out outside the tested
one-step factor neighborhoods. Many steps or other roots may succeed.
RELATION TO p0: A rigorous SAME-N asymptotic no-go for distinguishing
p_0 from a growing nearby prefix by existence of a depth-0/1 GOOD node.
WHAT REMAINS OPEN: Control the complete second frontier; prove or refute
unbounded shortest GOOD distance in the h=1 family.
NOVELTY: NOT YET AUDITED.
```
