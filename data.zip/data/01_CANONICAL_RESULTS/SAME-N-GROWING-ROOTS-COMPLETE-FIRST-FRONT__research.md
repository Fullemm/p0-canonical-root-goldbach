---
id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT@research
logical_id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT
version_id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT@research
kind: historical-version
run: research
title: "Same n growing roots complete first front"
status: SUPERSEDED
status_raw: "for almost all such P,"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3324, line_end: 3326}
metadata: {"stable_id": "SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT", "version_id": "SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3324, "line_end": 3326}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3324, "line_end": 3326}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Same n growing roots complete first front

*Run research - status `SUPERSEDED` (raw: `for almost all such P,`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT-20260906` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
2. SAME-N-GROWING-ROOTS-COMPLETE-FIRST-FRONT: for almost all such P,
   every root of rank <=K=o(log X/(loglog X)^3) has its entire first
   front BAD. This is a same-N comparison, not a selected CRT tree.
```
