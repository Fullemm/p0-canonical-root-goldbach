---
id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B
logical_id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B
version_id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B@research
kind: canonical-result
run: research
title: "Same n growing roots complete radius two"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3672, line_end: 3763}
metadata: {"stable_id": "SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B", "version_id": "SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3672, "line_end": 3763}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3672, "line_end": 3763}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n growing roots complete radius two

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B
STATUS: PROVED.
EXACT STATEMENT:
Write L=log X and l=loglog X. Let K=K(X) be a positive integer with
 K=o(L^(1/6)/l^(3/2)).
For all but o(X/L) primes P in [X,2X], set N=2(P-1) and let Q_k be the
(k+1)-st prime at or above N/2. Then EVERY root Q_k, 0<=k<=K, has a
COMPLETE stopped radius-two neighborhood consisting of BAD vertices.
An upper bound for the exceptional proportion among primes P is
 O((l^3/L)^(1/5) + sqrt(K*l^(3/2)/L^(1/6))).                 (PREFIX2)
All implied constants are absolute, for X sufficiently large along
any K satisfying the displayed hypothesis. A concrete admissible
choice is K=floor((log X)^(1/8)).

HYPOTHESES / SCOPE:
The sample is primes P, with N=2(P-1); it is not all even N. BADness is
asserted for every vertex reachable within at most TWO edges, including
the root itself, with expansion stopped at GOOD vertices. The growing
prefix is for the SAME N. There is no assertion of eventual failure,
closedness, or a p0-specific invariant.

PROOF:
For large P the integer P-1 is composite and there is no integer between
P-1 and P, so Q_0=P. The previous audited canonical radius-two theorem
bounds starts with a GOOD vertex within two edges from Q_0 by
 O((X/L)*(l^3/L)^(1/5)).                                   (C0)

We use an elementary aggregate gap bound. List primes as s_i. For each
P=s_i in [X,2X], Q_K=s_(i+K). The prime number theorem, together with
K=o(L^(1/6)/l^(3/2)), ensures s_(i+K)<=3X for every such i when X is
large, since pi(3X)-pi(2X)>>X/L>K. Expand
 Q_K-P=sum_(j=i)^(i+K-1)(s_(j+1)-s_j).
After summing over the eligible i, each consecutive prime gap occurs
at most K times. All participating gaps lie in [X,3X], up to endpoints
already lying inside that interval; their total length is at most 2X.
Consequently
 sum_(P prime in [X,2X])(Q_K-P)<=2KX.
For H>=3, the number of starts with Q_K-P>H-1 is therefore at most
 2KX/(H-1)=O(KX/H).                                       (GAP)
No assertion about a uniform short interval containing K primes has
been made; the long-gap starts have been counted explicitly.

For every remaining start, all 1<=k<=K satisfy
 Q_k>P,       Q_k-P+1<=H.
If any such root has success within two edges, the pair (P,Q_k) is
included in SAME-N-RADIUS-TWO-PAIR-COUNT. Counting all pairs only
increases the number of exceptional starts. Thus (PAIR2*) gives
 O(H*X*l^(3/2)/L^(13/6))                                  (LATER)
provided H<=L^2. There is NO further factor K in (LATER), since that
pair count already includes every prime Q at the allowed offset.

Take H to be an integer within 1 of
 H_* = sqrt(K)*L^(13/12)/l^(3/4).
Then H_* tends to infinity, and the bound on K gives
 H_* = o(L^(7/6)/l^(3/2)) < L^2,
so the pair theorem applies. Divide (C0), (GAP), and (LATER) by
pi(2X)-pi(X) asymptotic to X/L. The last two resulting bounds are
 O(K*L/H + H*l^(3/2)/L^(7/6))
 =O(sqrt(K*l^(3/2)/L^(1/6))).
This proves (PREFIX2), which tends to zero under the stated condition.
For K=floor(L^(1/8)), the required ratio is at most
 l^(3/2)/L^(1/24), and tends to zero. The proof is complete.

HOSTILE CHECK:
1. This does not carry the earlier, larger radius-one prefix
   K=o(L/l^3) to radius two. The new sufficient range is shorter.
2. The extra primality condition P=N/2+1 in the pair count is retained;
   that count is not being applied to a generic root at a generic N.
3. Both a root being directly GOOD and success at the first frontier
   are included in the exceptional set. Therefore outside it the whole
   radius-two BFS, rather than selected BAD paths, is BAD.
4. The gap bound is a double count of actual consecutive prime gaps;
   it does not replace a mean gap by a pointwise gap estimate.
5. H is chosen only after the uniform pair estimate has been proved
   for the full range 3<=H<=L^2. Hence no hidden dependence of a
   sieve constant on an arbitrarily growing H is introduced.
6. The theorem compares shallow BADness only. It gives no coupling of
   later BFS generations and no equality of eventual success rates.
DEPENDENCIES: SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B; audited
COMPLETE-H1-RADIUS-TWO-RARE-SUCCESS; PNT and elementary gap summation.
IMPLICATION: A deeper SAME-N negative result for explanations based on
universally shallow success of p0: asymptotically almost every member
of this family has complete radius-two BADness simultaneously at p0
and a growing nearby prefix.
RELATION TO GOLDBACH: This is compatible with Goldbach being true for
all the starts. It is not a lower-bound argument for prime pairs.
RELATION TO p0: A property previously established at radius two only
for p0 is now proved to be shared by nearby roots at the SAME N.
WHAT REMAINS OPEN: Radius three, large-product successful paths,
eventual reachability, and any pointwise p0-specific distinction.
NOVELTY: NOT YET AUDITED.
```
