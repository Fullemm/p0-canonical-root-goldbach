---
id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO@research
logical_id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO
version_id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO@research
kind: historical-version
run: research
title: "Same n growing roots complete radius two"
status: SUPERSEDED
status_raw: "almost every such P has"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5059, line_end: 5118}
metadata: {"stable_id": "SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO", "version_id": "SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5059, "line_end": 5118}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5059, "line_end": 5118}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Same n growing roots complete radius two

*Run research - status `SUPERSEDED` (raw: `almost every such P has`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO-20260906B` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
2. SAME-N-GROWING-ROOTS-COMPLETE-RADIUS-TWO: almost every such P has
   COMPLETE radius-two BADness simultaneously for all same-N roots
   k<=K=o((log X)^(1/6)/(loglog X)^(3/2)). This extends the previous
   canonical radius-two theorem to nearby roots, with all gcd cases.
3. Exact same-N non-dominance: at N=2180 p0 is BAD through radius two
   while p1 is directly GOOD; at N=2024 p0 succeeds at depth two while
   p1 has complete radius-two BADness. This refutes either universal
   inclusion of the two shallow BADness events, not eventual success.
All novelty claims remain NOT YET AUDITED.

=========================
CURRENT FRONTIER
=========================
No proof of binary Goldbach, no universal p0 success theorem, and no
exclusion of moving closed BAD support. Complete radius three remains
uncontrolled. The new count removes another class of large-label paths,
namely those with small cofactor product, but the region where BOTH
products are large remains. The successful-path barriers have no
closed-core consumer: inside a BAD closed core their hypotheses never
occur. The two-smallest-row height restriction remains a compatible
lower bound, with no contradictory upper bound. The Scott--Bozek
classification issue was not used or advanced in this continuation.

=========================
p0 STATUS
=========================
A stronger SAME-N no-go was obtained: complete radius-two BADness and
the growing-depth dual product restriction are shared by nearby roots.
No nontrivial property holding for every p0 and failing at a nearby
same-N root with an eventual-reachability consequence was proved.
Finite shallow success can favor either p0 or p1. The empirical
exceptionality of eventual p0 traversal remains unexplained.

=========================
EXACT NEXT QUESTION
=========================
Is the number of primes P in [X,2X] admitting the following system
o(X/log X)?
 P=a*q+2,
 b*r=(2a-1)*q+2,
 c*s=2*a*q+2-r,
 g=2*a*q+2-s prime,
where q,r,s are distinct odd primes, a,b,c are odd integers >=3,
and BOTH q*r*s>X^(9/10) and a*b*c>X^(9/10).
Count distinct starts P, not paths with multiplicity. This is the
explicit remaining region for canonical stopped success at depth three.
Together with the proved small-product barriers and the existing
radius-two estimate, an affirmative answer would establish complete
canonical radius-three BADness for almost all h=1 starts. It would
still be an asymptotic traversal theorem, not a Goldbach proof.


======================================================================
CONTINUATION 2026-09-07: RETURN FROM ARTICLE PREPARATION TO RESEARCH
======================================================================
The 2026-09-06B frontier above remains the starting point. No recent
asymptotic result is being used critically in the following exact arguments.
Research resumes in this same raw TXT file. The article is a separate,
completed deliverable and is not the research checkpoint.
```
