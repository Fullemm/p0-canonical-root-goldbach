---
id: SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906
logical_id: SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906
version_id: SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906@research
kind: canonical-result
run: research
title: "Same n nearby root first front sieve"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2294, line_end: 2364}
metadata: {"stable_id": "SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906", "version_id": "SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2294, "line_end": 2364}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2294, "line_end": 2364}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n nearby root first front sieve

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-NEARBY-ROOT-FIRST-FRONT-SIEVE-20260906
STATUS: PROVED.
EXACT STATEMENT:
Let X be sufficiently large and 3<=H<=sqrt(X)/10. Count pairs of odd
primes P,Q with X<=P<=2X, P<Q<=3X, and h=Q-P+1<=H. Set N=2(P-1).
The number of these pairs for which the stopped traversal from Q has
a GOOD vertex at distance 0 or 1 is
 O(H*X*(loglog X)^3/(log X)^3),
with an absolute implied constant. No consecutiveness assumption on
P,Q is needed. All first-front prime factors are covered.

PROOF:
Fix h. Since P,Q are odd and Q>P, h is odd and h>=3. The identities are
 P=Q-h+1,   N=2Q-2h,   m=N-Q=Q-2h.
Because h<=sqrt X/10 and Q>=X, m>1, and all relevant rows below have
size bounded below by a constant times X. A GOOD root Q requires the
THREE forms Q, Q-h+1, Q-2h to be prime. Their nonzero pair differences
are h-1, 2h, h+1. Leading coefficients are 1, so they are primitive
and nu(ell)>=1. Uniform three-form sieving in Q<=3X bounds the count
by O(X*(loglog X)^2/(log X)^3).
Otherwise m is odd composite. Write m=a*q, with a>=3 odd and q an odd
prime. A GOOD child q requires primality of
 Q=a*q+2h,       P=a*q+h+1,       g=N-q=(2a-1)*q+2h.              (S)
For q<=sqrt X fix q and sieve in a<=3X/q the three forms
 q*a+2h,        q*a+h+1,         2q*a+2h-q.
If q divides 2h, Q would be a multiple of q smaller than Q, impossible.
If q divides h+1, the same holds for P. Thus parameters violating
these coprimality conditions contribute no actual pair. In the remaining
case all three forms are primitive (their odd constant in the third
form also excludes a common factor 2). Their pair determinants are
 q*(1-h),       -q*(q+2h),       -q*(q+2),
all nonzero. Delta is polynomially bounded in X, uniformly in h<=H.
For ell!=q, the first form has a root modulo ell; only the one odd
prime q may have nu(q)=0. The improved r=3 sieve bound gives
 O(X*(loglog X)^2/(q*(log X)^3)).
The sum over prime q<=sqrt X is therefore
 O(X*(loglog X)^3/(log X)^3).
For q>sqrt X, fix a<=3sqrt X and sieve in q<=3X/a using FOUR forms:
 q,             a*q+2h,        a*q+h+1,        (2a-1)*q+2h.
If gcd(a,2h)>1 or gcd(a,h+1)>1 or gcd(2a-1,2h)>1, one of Q,P,g
has a fixed divisor between 2 and 2h, whereas the relevant prime value
is >=cX>2h. Hence there are no actual pairs for that parameter.
For the remaining parameters the four forms are primitive. Determinants
involving the first form are 2h,h+1,2h. The other three are
 a*(1-h),       2h*(1-a),       h+1-2a.
The first two are nonzero because h>=3 and a>=3. If h+1-2a=0, then
P=a*(q+2) is composite; equivalently gcd(a,h+1)=a>1 already excluded
this case. Thus no zero-determinant case is being passed to the sieve.
The first form ensures nu(ell)>=1 at every prime. Delta remains bounded
by a fixed power of X. The r=4 bound is
 O(X*(loglog X)^3/(a*(log X)^4)).
Summing a<=3sqrt X costs O(log X). This proves the same bound as in the
small-q range, for each fixed h. All actual prime values exceed 4 in
this range, and both sieve variable limits are >=sqrt X. Adding the
root-GOOD bound and summing over h<=H proves the statement.

HOSTILE CHECK:
The extra prime P=N/2+1 is essential for the extra sieve dimension.
Ignoring its primality would lose one log X and would not prove the
nearby-root prefix result below. It is available because all roots are
being compared for the SAME N in the h=1 family. For h=1, P and Q
coincide and this dimension gain disappears; that case is handled by
COMPLETE-H1-FIRST-FRONT-RARE-SUCCESS instead. The other possible
proportional pair at h+1=2a is not ignored: it has no prime solutions.
No typical prime-gap estimate is assumed in this counting lemma.
DEPENDENCIES: Uniform few-form sieve consumer, elementary identities.
RELATION TO GOLDBACH: Counts successful radius-one traversals only.
RELATION TO p0: Enables an actual same-N comparison with nearby roots.
WHAT REMAINS OPEN: Extend complete-front estimates to deeper generations.
NOVELTY: NOT YET AUDITED.
```
