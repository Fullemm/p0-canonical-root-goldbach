---
id: SAME-N-PREFIX-VALUATION-REALIZATION-20260907H
logical_id: SAME-N-PREFIX-VALUATION-REALIZATION-20260907H
version_id: SAME-N-PREFIX-VALUATION-REALIZATION-20260907H@research
kind: canonical-result
run: research
title: "Same n prefix valuation realization"
status: PROVED-EXTERNAL
status_raw: "PROVED, using an external theorem on consecutive congruent primes."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 7392, line_end: 7462}
metadata: {"stable_id": "SAME-N-PREFIX-VALUATION-REALIZATION-20260907H", "version_id": "SAME-N-PREFIX-VALUATION-REALIZATION-20260907H@research", "status": "PROVED-EXTERNAL", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7392, "line_end": 7462}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 7392, "line_end": 7462}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n prefix valuation realization

*Run research - status `PROVED-EXTERNAL` (raw: `PROVED, using an external theorem on consecutive congruent primes.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-PREFIX-VALUATION-REALIZATION-20260907H
STATUS: PROVED, using an external theorem on consecutive congruent primes.
This is a new application within this checkpoint, not a claim that the
underlying theorem on primes is new.

Statement. Fix K>=0, a finite set T of odd primes, and arbitrary prescribed
nonnegative integers e_l for l in T. There are infinitely many even N
such that, writing p_j for the j-th prime at or above N/2, ZERO-based,
  p_0=N/2+1,
  v_l(N-p_j)=e_l for every l in T and every 0<=j<=K.
All K+1 complements can additionally be required to be composite.
Moreover, along an infinite subfamily there are FIXED integers
  0=d_0<d_1<...<d_K
such that p_j=p_0+d_j and h_j=p_j-N/2=1+d_j throughout that subfamily.
The d_j are supplied existentially; this does not allow arbitrary chosen
prime-gap patterns such as a prescribed twin-prime constellation.

External input, checked in the primary paper:
Tristan Freiberg, A note on the theorem of Maynard and Tao,
arXiv:1311.5319, Theorem 1.2, https://arxiv.org/pdf/1311.5319
For a reduced residue a modulo q, with q>=4, and any fixed length L>=3,
infinitely many strings of L consecutive primes are all a modulo q
and have diameter bounded by a constant depending only on q,a,L.
Consecutive means in the sequence of ALL primes. The bounded diameter
strengthens Shiu's earlier result. This particular paper has ONE author,
Tristan Freiberg; it is not the separate Banks--Freiberg--Turnage-Butterbaugh
paper. We use only the stated existence and bounded-diameter conclusion.

Proof of the application.
For l in T impose on a the congruence
  a=2+l^e_l modulo l^(e_l+1), if e_l>=1;
  a=1 modulo l, if e_l=0.
These residues are units modulo l and force v_l(a-2)=e_l in the
congruence sense. Add a=1 modulo 4. CRT gives a reduced class a modulo
  M=4*product_(l in T) l^(e_l+1).
If no positive exponent was prescribed, add one new odd prime outside T
with prescribed exponent 1. This guarantees eventual compositeness
without changing any of the requested valuations.
Apply Freiberg with L=max(3,K+1), and retain the first K+1 primes
P_0<...<P_K in each string. Set N=2(P_0-1). Since P_0-1 is an even
integer greater than 2, P_0 is exactly p_0(N), and the consecutive
P_j are exactly p_j(N). If B bounds the string diameter, then
  m_j=N-P_j=P_0-2-(P_j-P_0)>=P_0-2-B,
so every m_j is positive and tends to infinity as P_0 tends to infinity.
Since P_j=P_0=a modulo M, we have m_j=a-2 modulo M. This proves all
specified valuations simultaneously at the SAME N. An imposed positive
exponent supplies a proper prime factor once m_j exceeds that prime,
which proves the compositeness assertion. Finally there are only
finitely many increasing integer offset vectors with diameter <=B.
One vector occurs infinitely often, proving the fixed-offset assertion.

A slightly more general form, used in the proof, is useful to retain:
for every even M>=4, every reduced class a modulo M and fixed K,
infinitely many such N have
  N=2a-2 modulo M,
  N-p_j=a-2 modulo M,
  h_j=1 modulo M,
for all j<=K, and have fixed offsets on an infinite subfamily.

Exact scope. These are prescribed valuations at a FIXED FINITE list of
prime labels, not full factorizations. The uncontrolled cofactors are
positive and unbounded. Neither full factor closure, a common FIFO
transcript, identical GOOD/BAD verdicts below the root, nor eventual
success of p_0 or any other rank follows. The construction shows that
finite valuation data alone cannot distinguish p_0 from every p_j at
the same N, even with all these initial complements composite. It does
not say such matching is typical, or exclude criteria using h_j as an
integer, growing prime-label sets, or full N-dependent factorization.

SAVE POINT H1: theorem and proof recorded before further computation.
```
