---
id: SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B
logical_id: SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B
version_id: SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B@research
kind: canonical-result
run: research
title: "Same n radius two adversarial scan"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION; finite evidence, not an asymptotic test."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3780, line_end: 4259}
metadata: {"stable_id": "SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B", "version_id": "SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3780, "line_end": 4259}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3780, "line_end": 4259}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n radius two adversarial scan

*Run research - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION; finite evidence, not an asymptotic test.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-RADIUS-TWO-ADVERSARIAL-SCAN-20260906B
STATUS: VERIFIED COMPUTATION; finite evidence, not an asymptotic test.
EXACT DOMAIN:
All primes P in [1000,2000), [10000,20000), [100000,200000), and
[500000,1000000): respectively 135, 1033, 8392, 36960 starts. For each
start set N=2(P-1), and examine the SAME-N roots of ranks 0,1,2,5.
No starts excluded. All distinct prime factors of every expanded row
are included. The stopped search checks success at distances 0,1,2.
Category 3 means no success by distance 2, not success at distance 3.
Exact smallest-prime-factor sieve through 4,000,100 suffices for every
integer factored or tested. Arithmetic tests below concern successful
length-two paths from ranks 1,2,5 only, after excluding roots with ANY
success at distance 0 or 1. Thus they are actual shortest paths.

MAIN DIAGNOSTICS:
70,836 shortest successful length-two paths were reconstructed from
the reduced five-form parametrization. Every affine identity and every
compatibility d|h held; gcd(q,b)=1 held for all of them. Of these,
15,761 had d=gcd(b,2a-1)>1. There were 12,256 paths with r|(2a-1),
and in all such cases r|h, as required. At the illustrative split
eta=0.1, 1,180 paths with d>1 were in the CC size regime, and 2,996
r|(2a-1) paths were in the CL size regime. This finite eta is for
case diagnostics only; these small X need not meet the theorem's
asymptotic eta bounds.
For 16,752 reconstructions all five actual prime values exceeded
their positive leading coefficients; in every such reconstruction
all five forms were primitive and all ten determinants nonzero.
The remaining reconstructions were NOT declared counterexamples:
the size hypothesis of the degeneracy filter was not being imposed
outside the large-factor regime.

REAL NONCOPRIME WITNESS:
P=1423, N=2844, p1=Q=1427, h=5, q=109, r=547,
a=13, b=5, g=2297. The path Q -> 109 -> 547 succeeds at depth two.
Here d=gcd(5,25)=5, not 1. The reduced variable t=108 gives
 q=t+1, r=5t+7, Q=13t+23, P=13t+19, g=21t+29.
This certifies why reusing the canonical gcd=1 proof would miss an
actual nearby-root configuration. The compatible-gcd averaging lemma
has a necessary arithmetic consumer.

REAL DEGENERATE-CONGRUENCE WITNESS:
P=1277, N=2552, p5=Q=1297, h=21, q=251, r=3,
a=5, b=767, g=2549. Then 2a-1=9 is divisible by r=3 and h=21
is divisible by r. The congruence for q modulo r does not specify a
unique class. The separate CL-exception sieve includes this case.

SAME-N POINTWISE NON-DOMINANCE AT RADIUS TWO:
At N=2180, the previously verified p0=1091 certificate has its complete
radius-two neighborhood BAD; p1=1093 is directly GOOD since 1087 is
prime. In the other direction, N=2024 has p0=1013 with a successful
length-two path 1013 -> 337 -> 7 (2024-7=2017 prime), while p1=1019
has complete radius-two BADness. Its full certificate is:
 2024-1019=3*5*67;
 2024-3=43*47, 2024-5=3*673, 2024-67=19*103;
 2024-43=7*283, 2024-47=3*659, 2024-673=7*193,
 2024-19=5*401, 2024-103=17*113.
Every displayed factor is prime, and every radius<=2 row is composite.
Thus neither radius-two BADness event includes the other pointwise for
p0 and p1. This is stronger evidence of a precise scope limit than
simply comparing average percentages. No eventual-reachability claim
is made for either example.

At the largest interval, category counts [depth0,depth1,depth2,BAD<=2]
were p0=[3604,14500,11540,7316], p1=[6406,11779,11426,7349],
p2=[6242,11976,11366,7376], p5=[6297,12160,11217,7286].
722 starts had complete radius-two BADness at all four selected roots.
The finite proportions are far from the asymptotic density-one limit;
no numerical convergence rate or eventual advantage is inferred.
The complete diagnostic source and output follow, preserving all
metrics and first witnesses without a second report artifact.

BEGIN DIAGNOSTIC SOURCE audit_same_n_radius2_20260906b.py
import numpy as np
from math import isqrt, gcd
from collections import Counter
from itertools import combinations
import json
LIMIT=4000100
spf=np.zeros(LIMIT+1,dtype=np.int32)
for p in range(2,isqrt(LIMIT)+1):
    if spf[p]==0:
        v=spf[p*p::p]
        v[v==0]=p
primes=np.flatnonzero(spf[2:]==0)+2
isprime=np.zeros(LIMIT+1,dtype=np.bool_)
isprime[primes]=True

def pf(n):
    out=[]
    while n>1:
        p=int(spf[n]) or n
        out.append(p)
        while n%p==0:n//=p
    return out

def depth2(N,Q):
    m=N-Q
    assert m>1 and N%Q
    if isprime[m]:return 0,[],[]
    qs=pf(m)
    if any(isprime[N-q] for q in qs):return 1,qs,[]
    paths=[]
    for q in qs:
        for r in pf(N-q):
            if isprime[N-r]:paths.append((q,r))
    return (2 if paths else 3),qs,paths

out={'domain':'Exhaustive primes P in each stated half-open dyadic interval; N=2(P-1); same-N roots k=0,1,2,5. Category 3 means no GOOD within distance 2, not actual success at distance 3. All prime factors included, no size cutoffs. Exact SPF sieve through 4,000,100.', 'intervals':{},'audit':{}}
audit=Counter();witness={}
ks=[0,1,2,5]
for X in [1000,10000,100000,500000]:
    inds=np.flatnonzero((primes>=X)&(primes<2*X))
    hist=Counter(); firstexamples={}
    for idx in inds:
        P=int(primes[idx]);N=2*(P-1);cats=[]
        for k in ks:
            Q=int(primes[idx+k]);h=Q-P+1
            depth,qs,paths=depth2(N,Q);cats.append(depth)
            if k==0:continue
            for q,r in paths:
                a=(N-Q)//q;b=(N-q)//r;c=2*a-1;d=gcd(b,c);g=N-r
                audit['shortest_success_length2_paths']+=1
                assert Q==a*q+2*h and P==a*q+h+1
                assert b*r==c*q+2*h and g==2*a*q+2*h-r
                assert gcd(q,b)==1 and h%d==0
                assert len({q,r,P,Q,g})==5
                audit['identities_activity_compatibility_checked']+=1
                bp=b//d;cp=c//d;hp=h//d
                A=((-2*hp)*pow(cp,-1,bp))%bp if bp>1 else 0
                if A==0:A=bp
                R=(cp*A+2*hp)//bp
                assert (cp*A+2*hp)%bp==0
                assert (q-A)%bp==0
                t=(q-A)//bp
                forms=[(bp,A),(cp,R),(a*bp,a*A+2*h),(a*bp,a*A+h+1),(2*a*bp-cp,2*a*A+2*h-R)]
                vals=[u*t+v for u,v in forms]
                assert vals==[q,r,Q,P,g]
                assert all(u>0 for u,v in forms)
                audit['reduced_five_form_reconstruction_checked']+=1
                if all(value>u for value,(u,v) in zip(vals,forms)):
                    assert all(gcd(u,v)==1 for u,v in forms)
                    assert all(u*y-w*v!=0 for (u,v),(w,y) in combinations(forms,2))
                    audit['full_filter_hypotheses_and_conclusion_checked']+=1
                rec={'X':X,'P':P,'N':N,'k':k,'Q':Q,'h':h,'q':q,'r':r,'a':a,'b':b,'g':g,'d':d,'reduced_forms':forms,'t':t}
                if d>1:
                    audit['d_greater_than_one']+=1
                    witness.setdefault('noncoprime_CC_equation',rec)
                    if q>X**0.6 and r>isqrt(X):
                        audit['noncoprime_CC_regime_eta_point1']+=1
                        witness.setdefault('noncoprime_CC_regime_eta_point1',rec)
                if c%r==0:
                    assert h%r==0
                    audit['degenerate_r_divides_2a_minus1']+=1
                    witness.setdefault('CL_exception_equation',rec)
                    if q>X**0.6 and r<=isqrt(X):
                        audit['CL_exception_regime_eta_point1']+=1
                        witness.setdefault('CL_exception_regime_eta_point1',rec)
        key=tuple(cats);hist[key]+=1;firstexamples.setdefault(key,P)
    out['intervals'][str(X)]={
        'prime_count':len(inds),
        'root_categories_0_1_2_bad_radius2':{str(k):[sum(n for v,n in hist.items() if v[j]==d) for d in range(4)] for j,k in enumerate(ks)},
        'all_four_radius2_BAD':sum(n for v,n in hist.items() if min(v)==3),
        'first_P_all_four_radius2_BAD':firstexamples.get((3,3,3,3)),
        'p0_bad_radius2_p1_success_within2':sum(n for v,n in hist.items() if v[0]==3 and v[1]<3),
        'p1_bad_radius2_p0_success_within2':sum(n for v,n in hist.items() if v[1]==3 and v[0]<3)
    }
out['audit']=dict(audit);out['witnesses']=witness
print(json.dumps(out,indent=2))
END DIAGNOSTIC SOURCE
BEGIN DIAGNOSTIC OUTPUT
{
  "domain": "Exhaustive primes P in each stated half-open dyadic interval; N=2(P-1); same-N roots k=0,1,2,5. Category 3 means no GOOD within distance 2, not actual success at distance 3. All prime factors included, no size cutoffs. Exact SPF sieve through 4,000,100.",
  "intervals": {
    "1000": {
      "prime_count": 135,
      "root_categories_0_1_2_bad_radius2": {
        "0": [
          26,
          68,
          26,
          15
        ],
        "1": [
          46,
          44,
          34,
          11
        ],
        "2": [
          37,
          56,
          29,
          13
        ],
        "5": [
          34,
          57,
          31,
          13
        ]
      },
      "all_four_radius2_BAD": 1,
      "first_P_all_four_radius2_BAD": 1217,
      "p0_bad_radius2_p1_success_within2": 13,
      "p1_bad_radius2_p0_success_within2": 9
    },
    "10000": {
      "prime_count": 1033,
      "root_categories_0_1_2_bad_radius2": {
        "0": [
          137,
          469,
          278,
          149
        ],
        "1": [
          235,
          362,
          305,
          131
        ],
        "2": [
          227,
          383,
          281,
          142
        ],
        "5": [
          236,
          360,
          272,
          165
        ]
      },
      "all_four_radius2_BAD": 11,
      "first_P_all_four_radius2_BAD": 10559,
      "p0_bad_radius2_p1_success_within2": 105,
      "p1_bad_radius2_p0_success_within2": 87
    },
    "100000": {
      "prime_count": 8392,
      "root_categories_0_1_2_bad_radius2": {
        "0": [
          936,
          3481,
          2543,
          1432
        ],
        "1": [
          1656,
          2802,
          2436,
          1498
        ],
        "2": [
          1611,
          2820,
          2455,
          1506
        ],
        "5": [
          1661,
          2851,
          2419,
          1461
        ]
      },
      "all_four_radius2_BAD": 129,
      "first_P_all_four_radius2_BAD": 100931,
      "p0_bad_radius2_p1_success_within2": 898,
      "p1_bad_radius2_p0_success_within2": 964
    },
    "500000": {
      "prime_count": 36960,
      "root_categories_0_1_2_bad_radius2": {
        "0": [
          3604,
          14500,
          11540,
          7316
        ],
        "1": [
          6406,
          11779,
          11426,
          7349
        ],
        "2": [
          6242,
          11976,
          11366,
          7376
        ],
        "5": [
          6297,
          12160,
          11217,
          7286
        ]
      },
      "all_four_radius2_BAD": 722,
      "first_P_all_four_radius2_BAD": 501617,
      "p0_bad_radius2_p1_success_within2": 4538,
      "p1_bad_radius2_p0_success_within2": 4571
    }
  },
  "audit": {
    "shortest_success_length2_paths": 70836,
    "identities_activity_compatibility_checked": 70836,
    "reduced_five_form_reconstruction_checked": 70836,
    "full_filter_hypotheses_and_conclusion_checked": 16752,
    "d_greater_than_one": 15761,
    "degenerate_r_divides_2a_minus1": 12256,
    "CL_exception_regime_eta_point1": 2996,
    "noncoprime_CC_regime_eta_point1": 1180
  },
  "witnesses": {
    "noncoprime_CC_equation": {
      "X": 1000,
      "P": 1013,
      "N": 2024,
      "k": 2,
      "Q": 1021,
      "h": 9,
      "q": 17,
      "r": 223,
      "a": 59,
      "b": 9,
      "g": 1801,
      "d": 9,
      "reduced_forms": [
        [
          1,
          1
        ],
        [
          13,
          15
        ],
        [
          59,
          77
        ],
        [
          59,
          69
        ],
        [
          105,
          121
        ]
      ],
      "t": 16
    },
    "CL_exception_equation": {
      "X": 1000,
      "P": 1049,
      "N": 2096,
      "k": 2,
      "Q": 1061,
      "h": 13,
      "q": 3,
      "r": 13,
      "a": 345,
      "b": 161,
      "g": 2083,
      "d": 1,
      "reduced_forms": [
        [
          161,
          3
        ],
        [
          689,
          13
        ],
        [
          55545,
          1061
        ],
        [
          55545,
          1049
        ],
        [
          110401,
          2083
        ]
      ],
      "t": 0
    },
    "CL_exception_regime_eta_point1": {
      "X": 1000,
      "P": 1277,
      "N": 2552,
      "k": 5,
      "Q": 1297,
      "h": 21,
      "q": 251,
      "r": 3,
      "a": 5,
      "b": 767,
      "g": 2549,
      "d": 1,
      "reduced_forms": [
        [
          767,
          251
        ],
        [
          9,
          3
        ],
        [
          3835,
          1297
        ],
        [
          3835,
          1277
        ],
        [
          7661,
          2549
        ]
      ],
      "t": 0
    },
    "noncoprime_CC_regime_eta_point1": {
      "X": 1000,
      "P": 1423,
      "N": 2844,
      "k": 1,
      "Q": 1427,
      "h": 5,
      "q": 109,
      "r": 547,
      "a": 13,
      "b": 5,
      "g": 2297,
      "d": 5,
      "reduced_forms": [
        [
          1,
          1
        ],
        [
          5,
          7
        ],
        [
          13,
          23
        ],
        [
          13,
          19
        ],
        [
          21,
          29
        ]
      ],
      "t": 108
    }
  }
}
END DIAGNOSTIC OUTPUT

HISTORICAL CHECK 2026-09-06B:
The original post-CRD failure log was searched for common-divisor,
local-offset, and support-height routes. Its Tail Hard-Edge Universality
entry and All-root collision identity do not imply the present theorem:
they establish identities without a BFS consumer. Here the compatibility
weight is consumed by a uniform prime-form count, and complete success
is bounded by a union over ALL possible first two edges. No assertion
that a gcd collision forces new support is used. The log's h=1
root-factor descent still has its stated scope; the present proof does
not presume that descent persists after an offset or support change.
```
