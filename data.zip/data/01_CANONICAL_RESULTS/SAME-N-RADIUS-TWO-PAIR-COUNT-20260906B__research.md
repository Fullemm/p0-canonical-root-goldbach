---
id: SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B
logical_id: SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B
version_id: SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B@research
kind: canonical-result
run: research
title: "Same n radius two pair count"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3484, line_end: 3671}
metadata: {"stable_id": "SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B", "version_id": "SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3484, "line_end": 3671}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3484, "line_end": 3671}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n radius two pair count

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-RADIUS-TWO-PAIR-COUNT-20260906B
STATUS: PROVED.
EXACT STATEMENT:
Let L=log X and l=loglog X. Assume X sufficiently large,
 3<=H<=L^2,       L^(-1/4)<=eta<=1/8.
Let T_2(X,H) be the number of pairs of primes (P,Q) with
 X<=P<=2X,       P<Q,       h=Q-P+1<=H,
such that in the graph for N=2(P-1), the stopped traversal rooted at Q
has a GOOD vertex at distance <=2. Then, with an absolute constant,
 T_2(X,H) << H*X*[l*(eta+1/L)/L^2 + l^4/(eta^5*L^3)].       (PAIR2)
In particular, taking eta=l^(1/2)/L^(1/6),
 T_2(X,H) << H*X*l^(3/2)/L^(13/6).                         (PAIR2*)
These count pairs (P,Q), not paths with multiplicity. No rank restriction
or consecutiveness assumption on Q is imposed.

PROOF:
All offsets h in the count are odd and >=3. Also Q<=2X+H<=3X. The
known same-N first-front pair sieve counts success at distances 0 or 1
by O(H*X*l^3/L^3), which is absorbed by (PAIR2). Hence consider a
shortest successful path Q -> q -> r with Q and q BAD and r GOOD.
Write
 m=N-Q=Q-2h=a*q,
 N-q=b*r,
 g=N-r.
Then a,b are odd integers >=3, and
 Q=a*q+2h,        P=a*q+h+1,
 b*r=(2a-1)*q+2h,          g=2a*q+2h-r.                    (E)
The prime values q,r,P,Q,g are pairwise distinct: q!=r by activity,
q,r<N/3; P=(N+2)/2; Q=P+h-1=P+o(X); and g>2N/3>Q for large X.
Thus g>Q>P>max(q,r), apart from the already separately ordered q,r.
In particular every tuple of variable prime forms below really must
have distinct values.

BAND REMOVAL:
For each h remove any pair whose root complement has a prime divisor
 q in [X^(1/2-eta),X^(1/2+eta)].
For fixed q, the two forms q*a+2h and q*a+h+1 must be prime.
Here q>2H for large X, so both forms are primitive. Their determinant
q*(1-h) is nonzero. Except at ell=q there is a root modulo every prime;
the two-form singular series is O(l). Sieving a<=3X/q, whose logarithm
is at least 3L/8, gives O(X*l/(q*L^2)). By partial summation from the
Chebyshev bound pi(t)<<t/log t, the reciprocal sum over this band is
O(eta+1/L). Sum h<=H to bound the removed PAIRS by
 O(H*X*l*(eta+1/L)/L^2).                                   (B2)
Removing all such pairs only enlarges the exceptional set; the divisor
need not actually belong to the successful path being counted.

For a remaining pair choose any shortest successful length-two path.
Its q is either below X^(1/2-eta) or above X^(1/2+eta). Split also at
r=sqrt X. Use the following four counts to bound the existence of such
a path. Parameters outside the indicated arithmetic compatibility
conditions have no actual solutions.

CASE LL: q<X^(1/2-eta), r<=sqrt X. Fix h and distinct odd primes q,r.
The edge conditions give
 Q=2h modulo q,       2Q=2h+q modulo r.
They specify one class A modulo q*r. Choose 1<=A<=q*r and write
 Q=A+q*r*t,        P=Q-h+1,        g=2Q-2h-r.
Here t>=1 and t<=3X/(q*r), since q*r<X and Q>=X. These are THREE
integer prime forms with positive leading coefficients q*r,q*r,2q*r.
All coefficients are o(X), uniformly for eta>=L^(-1/4), and smaller
than their corresponding actual prime values. By the degeneracy filter,
nonprimitive forms or zero pair determinants imply no actual solution
and are discarded. (Directly the determinants are proportional to
h-1, 2h+r, and r+2, all nonzero.) Every prime outside {q,r} has an
invertible leading coefficient; at 2, q*r is odd. Thus S=O(l^2).
The uniform three-form bound is
 O(X*l^2/(q*r*(eta*L)^3)).
Summing reciprocals of the two prime parameters costs O(l^2), giving
 O(X*l^4/(eta^3*L^3)) for each h.

CASE LC: q<X^(1/2-eta), r>sqrt X. Fix h, prime q, and odd
b=(N-q)/r<=4sqrt X. The congruences are
 Q=2h modulo q,       2Q=2h+q modulo b.
They require gcd(q,b)=1. Indeed q|b would imply q|2h by (E), and
then q|Q=a*q+2h, impossible since Q is prime and q<Q.
Thus there is a unique class A modulo q*b. Write
 Q=A+q*b*t,   P=Q-h+1,
 r=(2A-2h-q)/b+2q*t,   g=2Q-2h-r.
The FOUR positive leading coefficients are q*b,q*b,2q,2q*(b-1).
We have q*b<=4X^(1-eta), and 2q<sqrt X<r for large X. Thus every
coefficient is smaller than its actual prime value. The degeneracy
filter removes all nonprimitive or coincident forms without losing a
possible solution. The coefficient 2q of r is invertible at every
odd prime except q, while Q has odd leading coefficient at 2.
Consequently S=O(l^3). The variable satisfies
 1<=t<=3X/(q*b),       log(3X/(q*b))>=eta*L-O(1).
The four-form count is O(X*l^3/(q*b*(eta*L)^4)). Sum the prime q
reciprocals and integer b reciprocals to obtain
 O(X*l^4/(eta^4*L^3)) for each h.

CASE CL: q>X^(1/2+eta), r<=sqrt X. Fix h, odd
 a=(Q-2h)/q<=3X^(1/2-eta),
and the prime r. If gcd(r,2a-1)=1, the equation (E) gives one class
q=A+r*t, 1<=A<=r, with t>=1 and t<=3X/(a*r). Sieve the FOUR forms
 q,       Q=a*q+2h,       P=a*q+h+1,       g=2a*q+2h-r.
Their t-coefficients are r,a*r,a*r,2a*r, smaller than the actual prime
values because a*r<=3X^(1-eta) and q>sqrt X>=r. The degeneracy filter
again applies. Outside ell=r the first form has an invertible leading
coefficient, giving S=O(l^3). Summing the bound
 O(X*l^3/(a*r*(eta*L)^4))
over integer a and prime r gives O(X*l^4/(eta^4*L^3)) for each h.

CL EXCEPTION (must not be omitted): If r|2a-1, compatibility forces
r|2h and hence r|h. The progression condition on q then degenerates.
For these pairs it suffices to DROP q,a and count the necessary prime
conditions directly: P, Q=P+h-1, and g=2P-2-r are all prime for some
odd prime r|h. These three forms are primitive and their determinants
are nonzero (h-1, -(r+2), -(2h+r)). At every prime there is a root of
the form P, so S=O(l^2). Since P<=2X, the count for each h,r is
O(X*l^2/L^3). Sum over h<=H and r|h:
 sum_(h<=H)omega(h)<=sum_(r<=H prime)floor(H/r)<<H*loglog(3H).
Hence this exceptional branch contributes
 O(H*X*l^2*loglog(3H)/L^3)=O(H*X*l^3/L^3).
This branch counts PAIRS directly, not all paths with multiplicity.
That is sufficient for the stated union/existence problem.

CASE CC: q>X^(1/2+eta), r>sqrt X. Fix h, odd
 a<=3X^(1/2-eta),       b<=4sqrt X.
Put c=2a-1 and d=gcd(b,c). By (E), d|2h, hence d|h because d is odd.
No assumption d=1 is made. Set b'=b/d, c'=c/d, h'=h/d, so
 gcd(b',c')=1,       b'*r=c'*q+2h'.
There is exactly one class q=A+b'*t, with 1<=A<=b'. Put
 R=(c'*A+2h')/b', an integer. Then the FIVE prime forms in t are
 q=A+b'*t,
 r=R+c'*t,
 Q=a*A+2h+a*b'*t,
 P=a*A+h+1+a*b'*t,
 g=2a*A+2h-R+(2a*b'-c')*t.
The last leading coefficient is positive since b>=3 and
2a*b'-c'=[2a*(b-1)+1]/d>0. Moreover q>b>=b' and r>c>=c' for
large X; the Q,P,g coefficients are O(a*b)=O(X^(1-eta)) and are
smaller than their actual prime values. Thus the degeneracy filter
rigorously excludes every imprimitive or proportional case. For all
remaining parameter choices Delta is nonzero and polynomially bounded
in X. The coprime coefficients b',c' guarantee nu(ell)>=1 at every
prime. Therefore S=O(l^4).
Here t>=1 and
 t<=3X/(a*b')=3dX/(a*b),
whose logarithm is >=eta*L-O(1). The five-form bound for fixed h,a,b is
 O(d*X*l^4/(a*b*(eta*L)^5)).
Crucially, the d in this count is retained. Summing all compatible a,b
using WEIGHTED-COMPATIBLE-GCD-AVERAGE gives at most
 O(X*l^4*sigma_{-1}(h)/(eta^5*L^3))
for this h, because the two logarithmic harmonic sums are O(L^2).
Sum h<=H. The identity
 sum_(h<=H)sigma_{-1}(h)<=zeta(2)*H
makes the TOTAL CC bound
 O(H*X*l^4/(eta^5*L^3)),
with no growing extra divisor-count factor.

In every case the representatives, positive leading coefficients and
constant terms have absolute values bounded by fixed powers of X.
After nondegenerate primitive filtering, Delta has the same property.
The variable logarithms are >=c*eta*L, while B_FKL=O(l)=o(eta*L),
uniformly in the stipulated eta interval. Actual prime values in the
sieve exceed the number of forms (fixed q,r are not sieved as variables).
Thus all FKL applications are uniform, including k=5. Add LL, LC, CL,
the CL exception, CC, BAND, and earlier-depth successes. Since eta<=1,
the resulting total is (PAIR2).
For eta=l^(1/2)/L^(1/6), the hypotheses hold for sufficiently large X,
and both main terms in the brackets are O(l^(3/2)/L^(13/6)). The
1/L part of BAND is smaller. This proves (PAIR2*).

HOSTILE CHECK:
1. gcd(q,b)=1 in LC follows from ROOT primality; it is not an independent
   CRT-programming assumption. The different gcd in CC can be >1 and
   is handled by reducing the modulus and then averaging its full cost.
2. The CL zero-coefficient congruence branch r|h is treated separately.
   Simply writing an inverse of 2a-1 modulo r would omit real cases.
3. Primitive/proportional filtering uses actual distinct prime values
   and coefficient-size bounds, verified above in all four cases. A
   generic promise that forms are 'different' would not suffice.
4. The count concerns existence of SOME shortest successful path and
   therefore controls the COMPLETE radius-two frontier. It does not
   prescribe a path or claim the neighborhoods themselves are identical.
5. The prime P=N/2+1 is an additional sieve condition for the later root
   Q. Without it every case loses a logarithm; this proof cannot be
   exported unchanged to the uniform-even-N sample.
6. This is an explicit repair of the changing-offset/gcd obstruction
   mentioned in the prior radius-two theorem, not its automatic reuse.
DEPENDENCIES: FKL Lemma 5.1, k<=5; compatible-gcd harmonic average;
Chebyshev prime upper bound; the audited radius-one pair count.
RELATION TO GOLDBACH: Upper bound on shallow successful traversal pairs.
RELATION TO p0: Supplies a deeper SAME-N comparison with nearby roots.
WHAT REMAINS OPEN: Radius three and eventual rooted reachability.
NOVELTY: NOT YET AUDITED.
```
