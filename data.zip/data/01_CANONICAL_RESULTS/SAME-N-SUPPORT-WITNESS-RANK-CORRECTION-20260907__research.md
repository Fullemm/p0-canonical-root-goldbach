---
id: SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907
logical_id: SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907
version_id: SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907@research
kind: canonical-result
run: research
title: "Same n support witness rank correction"
status: VERIFIED COMPUTATION
status_raw: "SCOPE-CORRECTED / VERIFIED COMPUTATION."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 5119, line_end: 5149}
metadata: {"stable_id": "SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907", "version_id": "SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907@research", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5119, "line_end": 5149}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 5119, "line_end": 5149}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Same n support witness rank correction

*Run research - status `VERIFIED COMPUTATION` (raw: `SCOPE-CORRECTED / VERIFIED COMPUTATION.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SAME-N-SUPPORT-WITNESS-RANK-CORRECTION-20260907
STATUS: SCOPE-CORRECTED / VERIFIED COMPUTATION.
EXACT STATEMENT:
For N=212, the primes at or above N/2 begin 107,109,113. Consequently
113 is p2, not p1. A temporary p1 label during article preparation was
incorrect. The support comparison at N=212 is valid as p0 versus p2:
 PF(212-107)={3,5,7}, PF(212-113)={3,11}, PF(212-3)={11,19}.
A genuine same-N p0 versus p1 replacement is N=344:
 p0=173, p1=179,
 344-173=171=3^2*19,
 344-179=165=3*5*11,
 344-3=341=11*31.
Thus the least first factor 3 has a second row disjoint from the p0
factor set {3,19}, but meeting the p1 factor set {3,5,11} at 11.
Both searches have first-success depth 2 and inclusive work W=5.
The common successful tail is 3 ->31, with 344-31=313 prime.
For p0 the FIFO test order is 173,3,19,11,31; for p1 it is
179,3,5,11,31. All indicated primalities and all root ranks were checked
by exact trial division, including the absence of intervening primes.
DEPENDENCIES / PROVENANCE:
The underlying least-factor escape is already PCRD-H1-1 in the master,
not a newly discovered general theorem. The new point is the exact
same-N witness and correction of the previously mislabelled index.
HOSTILE CHECK:
This distinguishes initial-support retention, not eventual success.
Both roots here even have the SAME first-success depth and work.
Neither this witness nor the minimum-factor lemma implies universal p0
success. The same-N radius-two witnesses N=2024 and N=2180 retain their
previously stated p0/p1 ranks after explicit enumeration.
NOVELTY: NOT YET AUDITED.
```
