---
id: SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G
logical_id: SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G
version_id: SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G@research
kind: canonical-result
run: research
title: "AUDIT-"
status: REQUIRES HUMAN REVIEW
status_raw: "DEPENDENCY NOT ACCEPTED AS A COMPLETE GLOBAL CLASSIFICATION."
audit: DOCUMENTED-UNRESOLVED-DEPENDENCY; NO NEW EXTERNAL THEOREM AUDIT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6778, line_end: 7144}
metadata: {"stable_id": "SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G", "version_id": "SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G@research", "status": "REQUIRES HUMAN REVIEW", "scope": "Claimed global two-core classification dependency", "assumptions": ["Parity-specific Scott statement must be reconciled with the proposed application"], "statement": "Existing proof dependency leaves the cross-parity branch unresolved; no global two-core uniqueness is accepted.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6778, "line_end": 7144}, "depends_on": [], "consequences": [], "does_not_imply": ["Not a counterexample to uniqueness", "Does not invalidate independent finite census"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6778, "line_end": 7144}, "proof_provenance": [], "computation": [], "concepts": ["pillai-equation"], "historical_aliases": [], "search_aliases": [], "verification": "DOCUMENTED-UNRESOLVED-DEPENDENCY; NO NEW EXTERNAL THEOREM AUDIT", "metadata_completeness": "CURATED"}
---

# AUDIT-

*Run research - status `REQUIRES HUMAN REVIEW` (raw: `DEPENDENCY NOT ACCEPTED AS A COMPLETE GLOBAL CLASSIFICATION.`) - audit `DOCUMENTED-UNRESOLVED-DEPENDENCY; NO NEW EXTERNAL THEOREM AUDIT`*

> Verification: **DOCUMENTED-UNRESOLVED-DEPENDENCY; NO NEW EXTERNAL THEOREM AUDIT**. Metadata coverage: CURATED.

## Current scoped statement

Existing proof dependency leaves the cross-parity branch unresolved; no global two-core uniqueness is accepted.

**Assumptions:** Parity-specific Scott statement must be reconciled with the proposed application.

**Does not imply:** Not a counterexample to uniqueness; Does not invalidate independent finite census.

## Source transcript (historical wording; apply current metadata)

```
AUDIT-ID: SCOTT-BOZEK-PARITY-GAP-REAPPEARS-IN-SOL-CONVERSATION-20260907G
STATUS: DEPENDENCY NOT ACCEPTED AS A COMPLETE GLOBAL CLASSIFICATION.
The older conversation uses uniqueness of the two-vertex EAC to exclude
all canonical two-vertex terminal cores and to remove the 'all children
above q' hypothesis from an h=1 singleton FOUR lemma. This relies on
Bozek's Theorem 3.7. Its displayed proof paraphrases Scott as giving at
most one solution to a^x-b^y=c, with five exceptions, without the parity
qualification. Scott's original publisher abstract instead bounds
solutions with y ODD (five exceptions) and y EVEN separately.
Source https://www.sciencedirect.com/science/article/pii/S0022314X83710413
DOI https://doi.org/10.1006/jnth.1993.1041.
The trivial solution (x,y)=(1,1) and a proposed solution with even y
belong to different parity classes. Those two separate uniqueness
statements do not themselves exclude their coexistence.
Thus the quoted reduction leaves a branch, precisely the one already
quarantined in the older project checkpoint. This is an identified gap
in the supplied proof dependency, not a counterexample to the claimed
two-vertex classification. No complete repair has been proved here.
Neither the rank/mirror finite-fibre theorem nor any of the exact
finite computations above uses that classification. They remain valid.
The previously proved upward FOUR lemma and its q=3,h=1 corollary also
do not depend on it. The unconditional all-q singleton strengthening
from the Sol conversation is not promoted to PROVED in this checkpoint.


CERTIFICATE-BLOCK: SIX-HOST-EXACT-ARITHMETIC-20260907G
STATUS: exact certificates from the independent audit, plain TXT.

N=128; B_N=[3, 5, 7, 11, 13, 17, 23, 29, 37, 41]
Genuine failed upper-root ranks: [2, 3, 4, 5, 7, 8, 9, 11]
Complete rows of every vertex in B_N:
 128-3=125=5^3
 128-5=123=3*41
 128-7=121=11^2
 128-11=117=3^2*13
 128-13=115=5*23
 128-17=111=3*37
 128-23=105=3*5*7
 128-29=99=3^2*11
 128-37=91=7*13
 128-41=87=3*29
Rank 0 and rank 10:
 k=0, r=67, m=61=61, factors outside B_N=[61], success depth=0, W=1
 k=10, r=109, m=19=19, factors outside B_N=[19], success depth=0, W=1

N=1718; B_N=[3, 5, 7, 11, 13, 17, 29, 31, 37, 41, 43, 47, 53, 59, 67, 73, 79, 89, 101, 127, 137, 149, 163, 167, 181, 191, 197, 199, 211, 233, 239, 241, 251, 281, 283, 311, 313, 349, 353, 383, 389, 409, 431, 443, 449, 463, 479, 491, 503, 509, 523, 557, 563, 569, 571]
Genuine failed upper-root ranks: [2, 3, 4, 8, 11, 13, 17, 21, 22, 23, 25, 29, 31, 34, 36, 37, 39, 41, 43, 46, 47, 48, 49, 50, 51, 52, 54, 55, 56, 57, 59, 60, 65, 69, 70, 73, 75, 77, 79, 81, 82, 83, 85, 86, 87, 89, 90, 92, 93, 94, 95, 96, 97, 99, 101, 102, 103, 104, 106, 107, 109, 110, 112, 113, 114, 115, 116, 118]
Complete rows of every vertex in B_N:
 1718-3=1715=5*7^3
 1718-5=1713=3*571
 1718-7=1711=29*59
 1718-11=1707=3*569
 1718-13=1705=5*11*31
 1718-17=1701=3^5*7
 1718-29=1689=3*563
 1718-31=1687=7*241
 1718-37=1681=41^2
 1718-41=1677=3*13*43
 1718-43=1675=5^2*67
 1718-47=1671=3*557
 1718-53=1665=3^2*5*37
 1718-59=1659=3*7*79
 1718-67=1651=13*127
 1718-73=1645=5*7*47
 1718-79=1639=11*149
 1718-89=1629=3^2*181
 1718-101=1617=3*7^2*11
 1718-127=1591=37*43
 1718-137=1581=3*17*31
 1718-149=1569=3*523
 1718-163=1555=5*311
 1718-167=1551=3*11*47
 1718-181=1537=29*53
 1718-191=1527=3*509
 1718-197=1521=3^2*13^2
 1718-199=1519=7^2*31
 1718-211=1507=11*137
 1718-233=1485=3^3*5*11
 1718-239=1479=3*17*29
 1718-241=1477=7*211
 1718-251=1467=3^2*163
 1718-281=1437=3*479
 1718-283=1435=5*7*41
 1718-311=1407=3*7*67
 1718-313=1405=5*281
 1718-349=1369=37^2
 1718-353=1365=3*5*7*13
 1718-383=1335=3*5*89
 1718-389=1329=3*443
 1718-409=1309=7*11*17
 1718-431=1287=3^2*11*13
 1718-443=1275=3*5^2*17
 1718-449=1269=3^3*47
 1718-463=1255=5*251
 1718-479=1239=3*7*59
 1718-491=1227=3*409
 1718-503=1215=3^5*5
 1718-509=1209=3*13*31
 1718-523=1195=5*239
 1718-557=1161=3^3*43
 1718-563=1155=3*5*7*11
 1718-569=1149=3*383
 1718-571=1147=31*37
Rank 0 and rank 10:
 k=0, r=859, m=859=859, factors outside B_N=[859], success depth=0, W=1
 k=10, r=937, m=781=11*71, factors outside B_N=[71], success depth=2, W=6

N=1862; B_N=[3, 5, 11, 13, 17, 29, 41, 43, 47, 53, 59, 67, 83, 97, 101, 107, 113, 127, 131, 151, 167, 179, 181, 191, 211, 233, 251, 257, 263, 269, 307, 311, 347, 353, 359, 383, 401, 421, 431, 443, 487, 499, 503, 509, 547, 557, 569, 577, 587, 593, 599, 601, 607, 617, 619]
Genuine failed upper-root ranks: [1, 3, 4, 5, 6, 8, 13, 20, 23, 25, 27, 33, 36, 39, 40, 42, 44, 46, 47, 48, 50, 52, 53, 54, 56, 58, 59, 60, 64, 66, 68, 69, 70, 75, 77, 79, 80, 81, 82, 84, 87, 88, 89, 92, 93, 94, 96, 97, 99, 100, 101, 103, 105, 106, 108, 109, 111, 112, 116, 118, 121, 122, 124]
Complete rows of every vertex in B_N:
 1862-3=1859=11*13^2
 1862-5=1857=3*619
 1862-11=1851=3*617
 1862-13=1849=43^2
 1862-17=1845=3^2*5*41
 1862-29=1833=3*13*47
 1862-41=1821=3*607
 1862-43=1819=17*107
 1862-47=1815=3*5*11^2
 1862-53=1809=3^3*67
 1862-59=1803=3*601
 1862-67=1795=5*359
 1862-83=1779=3*593
 1862-97=1765=5*353
 1862-101=1761=3*587
 1862-107=1755=3^3*5*13
 1862-113=1749=3*11*53
 1862-127=1735=5*347
 1862-131=1731=3*577
 1862-151=1711=29*59
 1862-167=1695=3*5*113
 1862-179=1683=3^2*11*17
 1862-181=1681=41^2
 1862-191=1671=3*557
 1862-211=1651=13*127
 1862-233=1629=3^2*181
 1862-251=1611=3^2*179
 1862-257=1605=3*5*107
 1862-263=1599=3*13*41
 1862-269=1593=3^3*59
 1862-307=1555=5*311
 1862-311=1551=3*11*47
 1862-347=1515=3*5*101
 1862-353=1509=3*503
 1862-359=1503=3^2*167
 1862-383=1479=3*17*29
 1862-401=1461=3*487
 1862-421=1441=11*131
 1862-431=1431=3^3*53
 1862-443=1419=3*11*43
 1862-487=1375=5^3*11
 1862-499=1363=29*47
 1862-503=1359=3^2*151
 1862-509=1353=3*11*41
 1862-547=1315=5*263
 1862-557=1305=3^2*5*29
 1862-569=1293=3*431
 1862-577=1285=5*257
 1862-587=1275=3*5^2*17
 1862-593=1269=3^3*47
 1862-599=1263=3*421
 1862-601=1261=13*97
 1862-607=1255=5*251
 1862-617=1245=3*5*83
 1862-619=1243=11*113
Rank 0 and rank 10:
 k=0, r=937, m=925=5^2*37, factors outside B_N=[37], success depth=2, W=6
 k=10, r=1009, m=853=853, factors outside B_N=[853], success depth=0, W=1

N=1928; B_N=[3, 5, 7, 11, 13, 17, 29, 43, 53, 71, 73, 79, 101, 103, 113, 131, 163, 173, 179, 211, 227, 233, 239, 251, 269, 311, 317, 353, 373, 383, 401, 443, 449, 461, 467, 487, 509, 563, 599, 619, 641]
Genuine failed upper-root ranks: [1, 2, 3, 8, 11, 15, 16, 18, 22, 23, 29, 33, 35, 36, 38, 45, 46, 47, 50, 52, 55, 56, 60, 61, 64, 65, 67, 73, 75, 76, 78, 80, 82, 85, 91, 92, 93, 95, 98, 99, 102, 104, 107, 108, 110, 111, 113, 117, 118, 120, 124, 125, 126, 127, 128, 129, 130]
Complete rows of every vertex in B_N:
 1928-3=1925=5^2*7*11
 1928-5=1923=3*641
 1928-7=1921=17*113
 1928-11=1917=3^3*71
 1928-13=1915=5*383
 1928-17=1911=3*7^2*13
 1928-29=1899=3^2*211
 1928-43=1885=5*13*29
 1928-53=1875=3*5^4
 1928-71=1857=3*619
 1928-73=1855=5*7*53
 1928-79=1849=43^2
 1928-101=1827=3^2*7*29
 1928-103=1825=5^2*73
 1928-113=1815=3*5*11^2
 1928-131=1797=3*599
 1928-163=1765=5*353
 1928-173=1755=3^3*5*13
 1928-179=1749=3*11*53
 1928-211=1717=17*101
 1928-227=1701=3^5*7
 1928-233=1695=3*5*113
 1928-239=1689=3*563
 1928-251=1677=3*13*43
 1928-269=1659=3*7*79
 1928-311=1617=3*7^2*11
 1928-317=1611=3^2*179
 1928-353=1575=3^2*5^2*7
 1928-373=1555=5*311
 1928-383=1545=3*5*103
 1928-401=1527=3*509
 1928-443=1485=3^3*5*11
 1928-449=1479=3*17*29
 1928-461=1467=3^2*163
 1928-467=1461=3*487
 1928-487=1441=11*131
 1928-509=1419=3*11*43
 1928-563=1365=3*5*7*13
 1928-599=1329=3*443
 1928-619=1309=7*11*17
 1928-641=1287=3^2*11*13
Rank 0 and rank 10:
 k=0, r=967, m=961=31^2, factors outside B_N=[31], success depth=2, W=4
 k=10, r=1031, m=897=3*13*23, factors outside B_N=[23], success depth=2, W=9

N=2200; B_N=[3, 13]
Genuine failed upper-root ranks: [48, 79, 129, 141]
Complete rows of every vertex in B_N:
 2200-3=2197=13^3
 2200-13=2187=3^7
Rank 0 and rank 10:
 k=0, r=1103, m=1097=1097, factors outside B_N=[1097], success depth=0, W=1
 k=10, r=1187, m=1013=1013, factors outside B_N=[1013], success depth=0, W=1

N=6142; B_N=[3, 5, 7, 13, 17, 19, 31, 43, 67, 71, 73, 97, 107, 109, 157, 199, 227, 229, 233, 283, 311, 317, 337, 353, 409, 467, 541, 557, 613, 617, 647, 673, 727, 769, 787, 811, 827, 877, 947, 997, 1039, 1063, 1087, 1117, 1129, 1229, 1237, 1249, 1297, 1303, 1327, 1399, 1483, 1487, 1543, 1553, 1579, 1613, 1627, 1669, 1693, 1777, 1787, 1823, 1867, 2011]
Genuine failed upper-root ranks: [2, 3, 8, 12, 15, 19, 21, 24, 25, 31, 32, 36, 41, 46, 50, 51, 53, 56, 64, 68, 70, 72, 75, 78, 84, 88, 93, 95, 98, 103, 104, 125, 127, 131, 135, 140, 149, 152, 155, 163, 166, 170, 171, 173, 174, 178, 179, 183, 184, 185, 189, 198, 200, 205, 219, 230, 237, 238, 244, 246, 248, 250, 252, 253, 262, 264, 265, 271, 273, 274, 280, 283, 284, 287, 293, 305, 308, 311, 313, 314, 316, 320, 322, 324, 325, 329, 330, 333, 336, 338, 339, 341, 343, 344, 347, 349, 351, 353, 355, 358, 360]
Complete rows of every vertex in B_N:
 6142-3=6139=7*877
 6142-5=6137=17*19^2
 6142-7=6135=3*5*409
 6142-13=6129=3^3*227
 6142-17=6125=5^3*7^2
 6142-19=6123=3*13*157
 6142-31=6111=3^2*7*97
 6142-43=6099=3*19*107
 6142-67=6075=3^5*5^2
 6142-71=6071=13*467
 6142-73=6069=3*7*17^2
 6142-97=6045=3*5*13*31
 6142-107=6035=5*17*71
 6142-109=6033=3*2011
 6142-157=5985=3^2*5*7*19
 6142-199=5943=3*7*283
 6142-227=5915=5*7*13^2
 6142-229=5913=3^4*73
 6142-233=5909=19*311
 6142-283=5859=3^3*7*31
 6142-311=5831=7^3*17
 6142-317=5825=5^2*233
 6142-337=5805=3^3*5*43
 6142-353=5789=7*827
 6142-409=5733=3^2*7^2*13
 6142-467=5675=5^2*227
 6142-541=5601=3*1867
 6142-557=5585=5*1117
 6142-613=5529=3*19*97
 6142-617=5525=5^2*13*17
 6142-647=5495=5*7*157
 6142-673=5469=3*1823
 6142-727=5415=3*5*19^2
 6142-769=5373=3^3*199
 6142-787=5355=3^2*5*7*17
 6142-811=5331=3*1777
 6142-827=5315=5*1063
 6142-877=5265=3^4*5*13
 6142-947=5195=5*1039
 6142-997=5145=3*5*7^3
 6142-1039=5103=3^6*7
 6142-1063=5079=3*1693
 6142-1087=5055=3*5*337
 6142-1117=5025=3*5^2*67
 6142-1129=5013=3^2*557
 6142-1229=4913=17^3
 6142-1237=4905=3^2*5*109
 6142-1249=4893=3*7*233
 6142-1297=4845=3*5*17*19
 6142-1303=4839=3*1613
 6142-1327=4815=3^2*5*107
 6142-1399=4743=3^2*17*31
 6142-1483=4659=3*1553
 6142-1487=4655=5*7^2*19
 6142-1543=4599=3^2*7*73
 6142-1553=4589=13*353
 6142-1579=4563=3^3*13^2
 6142-1613=4529=7*647
 6142-1627=4515=3*5*7*43
 6142-1669=4473=3^2*7*71
 6142-1693=4449=3*1483
 6142-1777=4365=3^2*5*97
 6142-1787=4355=5*13*67
 6142-1823=4319=7*617
 6142-1867=4275=3^2*5^2*19
 6142-2011=4131=3^5*17
Rank 0 and rank 10:
 k=0, r=3079, m=3063=3*1021, factors outside B_N=[1021], success depth=2, W=6
 k=10, r=3181, m=2961=3^2*7*47, factors outside B_N=[47], success depth=2, W=9

Opposite verdicts at exactly the same rank and mirror:
N=116, r=89=p_7, m=27, success=True, depth=1, W=2
 depth 0: 116-89=27=3^3
 depth 1: 116-3=113=113
N=128, r=101=p_7, m=27, success=False, depth=None, W=9
 depth 0: 128-101=27=3^3
 depth 1: 128-3=125=5^3
 depth 2: 128-5=123=3*41
 depth 3: 128-41=87=3*29
 depth 4: 128-29=99=3^2*11
 depth 5: 128-11=117=3^2*13
 depth 6: 128-13=115=5*23
 depth 7: 128-23=105=3*5*7
 depth 8: 128-7=121=11^2
N=1862, r=1063=p_20, m=799, success=False, depth=None, W=22
 depth 0: 1862-1063=799=17*47
 depth 1: 1862-17=1845=3^2*5*41
 depth 1: 1862-47=1815=3*5*11^2
 depth 2: 1862-3=1859=11*13^2
 depth 2: 1862-5=1857=3*619
 depth 2: 1862-41=1821=3*607
 depth 2: 1862-11=1851=3*617
 depth 3: 1862-13=1849=43^2
 depth 3: 1862-619=1243=11*113
 depth 3: 1862-607=1255=5*251
 depth 3: 1862-617=1245=3*5*83
 depth 4: 1862-43=1819=17*107
 depth 4: 1862-113=1749=3*11*53
 depth 4: 1862-251=1611=3^2*179
 depth 4: 1862-83=1779=3*593
 depth 5: 1862-107=1755=3^3*5*13
 depth 5: 1862-53=1809=3^3*67
 depth 5: 1862-179=1683=3^2*11*17
 depth 5: 1862-593=1269=3^3*47
 depth 6: 1862-67=1795=5*359
 depth 7: 1862-359=1503=3^2*167
 depth 8: 1862-167=1695=3*5*113
N=1886, r=1087=p_20, m=799, success=True, depth=2, W=5
 depth 0: 1886-1087=799=17*47
 depth 1: 1886-17=1869=3*7*89
 depth 1: 1886-47=1839=3*613
 depth 2: 1886-3=1883=7*269
 depth 2: 1886-7=1879=1879
N=2200, r=1471=p_48, m=729, success=False, depth=None, W=3
 depth 0: 2200-1471=729=3^6
 depth 1: 2200-3=2197=13^3
 depth 2: 2200-13=2187=3^7
N=2180, r=1451=p_48, m=729, success=True, depth=4, W=10
 depth 0: 2180-1451=729=3^6
 depth 1: 2180-3=2177=7*311
 depth 2: 2180-7=2173=41*53
 depth 2: 2180-311=1869=3*7*89
 depth 3: 2180-41=2139=3*23*31
 depth 3: 2180-53=2127=3*709
 depth 3: 2180-89=2091=3*17*41
 depth 4: 2180-23=2157=3*719
 depth 4: 2180-31=2149=7*307
 depth 4: 2180-709=1471=1471
N=2210, r=1481=p_48, m=729, success=True, depth=1, W=2
 depth 0: 2210-1481=729=3^6
 depth 1: 2210-3=2207=2207

Fixed dangerous-mirror set (all 214 exact integers):
[9, 15, 21, 25, 27, 39, 45, 49, 51, 55, 63, 75, 81, 85, 91, 95, 99, 105, 111, 117, 121, 129, 135, 141, 145, 147, 153, 155, 159, 165, 169, 175, 187, 189, 195, 205, 215, 219, 225, 231, 235, 237, 243, 245, 249, 255, 259, 261, 265, 267, 273, 279, 285, 289, 291, 295, 301, 303, 309, 315, 319, 321, 335, 339, 351, 357, 363, 369, 375, 381, 385, 399, 405, 411, 415, 423, 425, 429, 435, 441, 453, 459, 469, 477, 481, 485, 489, 495, 501, 505, 507, 517, 519, 525, 531, 535, 543, 555, 559, 561, 565, 567, 573, 583, 585, 595, 603, 609, 615, 625, 633, 637, 639, 645, 649, 657, 663, 665, 675, 685, 697, 699, 705, 711, 715, 729, 735, 749, 753, 765, 771, 777, 799, 819, 825, 833, 835, 837, 841, 845, 865, 867, 871, 885, 891, 895, 909, 921, 933, 945, 951, 957, 963, 975, 995, 1029, 1065, 1083, 1139, 1209, 1349, 1391, 1413, 1491, 1505, 1521, 1539, 1575, 1581, 1623, 1625, 1635, 1649, 1685, 1701, 1785, 1805, 1853, 1911, 1941, 1989, 2015, 2043, 2219, 2223, 2261, 2289, 2295, 2345, 2375, 2433, 2451, 2471, 2499, 2511, 2535, 2601, 2613, 2625, 2631, 2675, 2709, 2769, 2795, 2799, 2835, 2841, 2883, 2889, 2925, 2951, 2975, 3033, 3053]

END EXACT CERTIFICATE BLOCK.
```
