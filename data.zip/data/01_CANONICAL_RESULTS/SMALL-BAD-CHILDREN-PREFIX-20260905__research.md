---
id: SMALL-BAD-CHILDREN-PREFIX-20260905
logical_id: SMALL-BAD-CHILDREN-PREFIX-20260905
version_id: SMALL-BAD-CHILDREN-PREFIX-20260905@research
kind: canonical-result
run: research
title: "Small bad children prefix"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 275, line_end: 421}
metadata: {"stable_id": "SMALL-BAD-CHILDREN-PREFIX-20260905", "version_id": "SMALL-BAD-CHILDREN-PREFIX-20260905@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 275, "line_end": 421}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["SMALL-BAD-CHILDREN-PREFIX"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 275, "line_end": 421}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Small bad children prefix

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: SMALL-BAD-CHILDREN-PREFIX-20260905
STATUS: PROVED.
EXACT STATEMENT:
Fix 0<alpha<1/2 and 0<epsilon<1/2. Put z=(log X)^alpha,
s=#{odd primes q<=z}, mu=sum_(3<=q<=z, q prime) 1/q.
Let K=K(X)>=0 be an integer with K+1=o(mu), equivalently it suffices to
assume K+1=o(log log log X). For all but o(X) integers 4<=x<=X,
every upper root p_k(2x), 0<=k<=K, is BAD and has at least
(1-epsilon)mu distinct active BAD children q<=z.
In particular the lower bound is at least
(1-2epsilon)log log log X for all sufficiently large X when 0<epsilon<1/2.
This concerns actual vertices on the COMPLETE first frontier, not merely
an arbitrarily prescribed partial tree. It does NOT say that all children
are BAD or that shortest GOOD depth tends to infinity.

HYPOTHESES / CONVENTIONS:
BAD here means a positive composite complement, excluding unit rows.
All quantifiers over k are simultaneous on one set of x of density 1.
Logs are natural and X tends to infinity; no useful small-X rate is claimed.

PROOF:
1. Uniform arithmetic progression counts.
Let H=X-3 and J be the number of source prime cells meeting [4,X], so
J=O(X/log X). For ANY k>=0 and ANY odd d>=1, as x runs across a source
cell, m_k(2x) is an arithmetic progression with difference 2. Therefore
  A_d(k):=#{4<=x<=X: d divides m_k(2x)} = H/d + O(J),
with absolute error at most J, uniform in d and k. Negative complements
can provisionally be counted here as integers; we remove them in step 4.
The final partial cell also has discrepancy at most 1.

2. Mean and variance on actual root complements.
Define f_k(x)=sum_(3<=q<=z, prime) 1_(q divides m_k(2x)). Then
  sum_x f_k = H mu + O(J s),
  sum_x f_k^2 = H(mu^2+mu-sum_q 1/q^2) + O(J s^2).
The latter follows by expanding the square and using A_(qr) for distinct
q,r. It follows, without assuming independence in x, that
  sum_x (f_k-mu)^2 <= H mu + O(J(s^2+mu s)).
Consequently
  #{x: f_k(x)<(1-epsilon)mu}
  <= H/(epsilon^2 mu)
     + O(J(s^2+mu s)/(epsilon^2 mu^2)).
All constants are independent of k. Taking a union over 0..K is allowed.
The elementary bound s<=z and mu<=sum_(n<=z)1/n=O(log z) shows that
the second error, divided by X and multiplied by K+1=o(mu), tends to 0:
J/X=O(1/log X) and z^2=(log X)^(2alpha) with 2alpha<1.
The first error tends to 0 because K+1=o(mu).

3. Every sufficiently small prime vertex is BAD on almost all inputs.
For each odd prime q<=z, the condition 2x-q prime holds for at most pi(2X)
values of x. Thus the number of x having ANY GOOD q<=z is at most
  s*pi(2X)=O(X*z/log X)=o(X).
This is an ordinary counting upper bound, not an independence heuristic.
For x>=sqrt X all N-q>1 and exceed q, so rows avoiding the prime case are
composite. Also all roots exceed z.

4. Positivity, activity and root status.
The prime number theorem gives at least c*x/log x primes in [x,2x) for all
sufficiently large x. Uniformly for sqrt X<=x<=X this number exceeds K+1,
since K+1=o(mu)=O(log z). Hence p_k(2x)<2x and m_k(2x)>0 for all k<=K
in this range. Removing x<sqrt X costs o(X).
Outside the exceptional set in step 2, f_k>1 eventually, so m_k is composite
and p_k is not diagonal. Because x<=p_k<2x, a nondiagonal prime p_k cannot
divide 2x. For q|m_k, q|2x would imply q|p_k and thus q=p_k, impossible
since m_k<p_k. All counted child primes are therefore active. Step 3 makes
their complete complements composite. This proves the assertion.

5. Growth of mu; no normal-order theorem is needed here.
The Euler product over primes <=z contains all reciprocals 1/n for n<=z,
so product_(q<=z)(1-1/q)^(-1) >= sum_(n<=z)1/n >= log z.
Taking logarithms and using sum_q sum_(a>=2)1/(a*q^a)=O(1) gives
sum_(q<=z)1/q >= log log z-O(1). Removing q=2 changes a constant.
Thus mu>=log log log X+log alpha-O(1), proving the asserted lower bound.
The standard sharper Mertens estimate is unnecessary for this lower bound.

HOSTILE CHECK:
The square expansion involves q*r, never prime powers q^2 for the diagonal
term. Divisibility discrepancy is counted by SOURCE cells, whose number is
independent of k; no unjustified prime-residue distribution is assumed.
Goodness is tested in N-q, not in the root complement. Step 3 is a union
bound over all small q, so no conditional-primality assumption is hidden.
The full frontier can still have a large GOOD child and succeed at depth 1.

DEPENDENCIES:
Exact source-cell geometry; elementary second moments and Euler product;
pi(t)=O(t/log t) and the prime number theorem pi(t)~t/log t. The latter is
used only for uniform positivity of the first slowly growing prefix.

ACTUAL TRAVERSAL CONSUMERS:
(a) In world/exhaustion mode, which expands all reachable BAD vertices and
stops only each GOOD branch, |R_N(p_k)|>=1+(1-epsilon)mu simultaneously.
Each small BAD child of a BAD root is necessarily in that world even when
some other child is GOOD.
(b) In the reference algorithm the root's children are tested in increasing
prime order. Before finding a GOOD child or exhausting the root row, it
must perform at least (1-epsilon)mu DISTINCT unsuccessful child-goodness
tests, because every child <=z precedes every possible GOOD child.
The same conclusion holds for a lazy FIFO BFS with children enqueued in
increasing order, counting tested vertices before first GOOD.
(c) This is NOT a lower bound of mu on expanded BAD rows before first escape
in an eager-child implementation: it may detect a large GOOD child while
still processing the root. The distinction is material.

RELATION TO GOLDBACH:
An algorithmic lower bound on a specific search, not a lack of prime pairs.
RELATION TO p0 EXCEPTIONALITY:
A nontrivial traversal statistic, but it is shared simultaneously by p0 and
a growing prefix of nearby roots. Slow early testing / a growing BAD first
front cannot by itself explain unique eventual success of p0.
WHAT REMAINS OPEN:
Control of LARGE child exits, complete BAD depth, and multigeneration
correlations. Nothing here forces either success or closed failure.
NOVELTY: NOT YET AUDITED.

SOURCE-CORRECTION ADDENDUM TO AUDIT-FBTU:
The older Biblia independently records the precise obstruction already:
iteration 108, immediately before theorem iteration108-support (around
lines 28288–28310 of upload/goldbach_biblia(1).tex), reports that CRT retained
up to eight prescribed BAD-path edges but additional prime factors let BFS
escape. It explicitly distinguishes retaining existing edges from preventing
new factors. Therefore the present audit repairs a later scope regression,
not the first discovery of cofactor leakage. The small N=92 certificate and
the complete-two-row finiteness bound provide additional exact witnesses.

HISTORICAL LEMMA RECOVERED FOR FURTHER IMPROVEMENT:
Biblia theorem iteration108-support (around lines 28317–28373) uses Matveev
to obtain a support-height bound, but assumes at least two nonbranching
rows, via |R|>=b+2. The text correctly notes this excludes highly branched
worlds. The current continuation is checking whether that restriction can
be removed by choosing two arbitrary distinct rows and using max C itself
as the row-gap bound. This is a genuine changed hypothesis/consumer, not
an attempt to reuse generic fixed-S finiteness as a full Goldbach proof.

EXTERNAL-INPUT: MATVEEV-IN-BMS-9.4
STATUS: EXACT STATEMENT AND DERIVATION CHECKED IN PRIMARY RESEARCH SOURCE.
Y. Bugeaud, M. Mignotte, S. Siksek, Classical and modular approaches to
exponential Diophantine equations I. Fibonacci and Lucas perfect powers,
Annals of Mathematics 163 (2006), 969–1018, Theorem 9.4, real-field clause.
Author's full text, printed pp.16–17:
https://samirsiksek.github.io/siksek.github.io/papers/fibannalsfinal.pdf
The source derives this product-minus-one form from Matveev's Corollary 2.3.
For positive rational alpha_1,...,alpha_t and integer b_i, B=max|b_i|>=1,
Lambda=product alpha_i^b_i-1 !=0, and
A_i>=max(h(alpha_i), |log alpha_i|, 0.16), its D=1 real case gives
log|Lambda| > -1.4*30^(t+3)*t^(9/2)*(1+log B)*product A_i.
Here h(a/b)=log max(|a|,|b|) for coprime integers a,b, b>0.
We use this verified form, not an unverified stronger interpretation.
```
