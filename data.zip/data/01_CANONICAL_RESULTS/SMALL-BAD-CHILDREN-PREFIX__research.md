---
id: SMALL-BAD-CHILDREN-PREFIX@research
logical_id: SMALL-BAD-CHILDREN-PREFIX
version_id: SMALL-BAD-CHILDREN-PREFIX@research
kind: historical-version
run: research
title: "Small bad children prefix"
status: SUPERSEDED
status_raw: "simultaneous actual first-front BAD growth for"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1912, line_end: 1969}
metadata: {"stable_id": "SMALL-BAD-CHILDREN-PREFIX", "version_id": "SMALL-BAD-CHILDREN-PREFIX@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1912, "line_end": 1969}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "SMALL-BAD-CHILDREN-PREFIX-20260905", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1912, "line_end": 1969}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: SMALL-BAD-CHILDREN-PREFIX-20260905
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Small bad children prefix

*Run research - status `SUPERSEDED` (raw: `simultaneous actual first-front BAD growth for`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `SMALL-BAD-CHILDREN-PREFIX-20260905` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
4. SMALL-BAD-CHILDREN-PREFIX: simultaneous actual first-front BAD growth for
   a slowly growing prefix of roots, with exact search-cost consumers and
   no inference about shortest GOOD depth. This is shared by nearby roots.
5. AUDIT-FBTU: corrects the later partial-tree/full-BFS scope regression;
   N=92 is a short exact certificate, and complete h=1 two-row finiteness
   disproves an infinite fixed-alphabet/full-row interpretation.
The original prefix-transfer estimate survived the audit; it is inherited
work, not counted as a new result of this continuation.

=========================
CURRENT FRONTIER
=========================
No proof of binary Goldbach. No unconditional Goldbach threshold N_0.
A globally failed N supplies a closed active BAD core. A failed canonical
traversal also supplies a reachable closed BAD core, but does not imply that
all other vertices of the graph are BAD. The new results constrain each such
core's height and support, and exclude a quantitatively specified small-label
regime. They do not rule out moving supports above that regime.
The h=1 expansion theorem ends at new prime labels, not at GOOD vertices.
No proved invariant controls their next complete rows strongly enough to
force another expansion, and no contradictory upper support bound was found.
A pointwise positive prime-pair count or a contradiction to full composite
closure remains missing. Existing density-one conclusions cannot remove
every exceptional N.

=========================
p0 STATUS
=========================
Found a genuine restricted h=1 arithmetic/reachability theorem with an
explicit size hypothesis. Did NOT find a property proved for every canonical
p0 whose corresponding claim fails at a nearby root for the same N.
The density-transfer and small-BAD-child results are shared by nearby roots.
The claimed broad finite-local no-go needs the scope correction above; partial
CRT programming is not a theorem about complete bounded-depth failure.
There is still no convincing mathematical explanation of universal canonical
traversal success, and that universal success remains unproved.

=========================
EXACT NEXT QUESTION
=========================
For every integer d>=1, does there exist a prime P>=5 with N=2(P-1),
P-2 composite, such that EVERY vertex at directed distance at most d from
canonical P in the factorization graph is BAD (positive composite complement)?
Equivalently, are the minimum distances from canonical h=1 roots to GOOD
vertices unbounded, allowing infinity for a failed traversal?
A proof must control the COMPLETE factor frontiers, including every residual
cofactor; programming a selected BAD path is not an answer. Resolving this
would settle the strongest presently unsupported bounded-depth no-go in the
corpus, or provide a uniform finite-depth success theorem on the h=1 family.

=========================
CONTINUATION 2026-09-06
=========================
Previous sections remain an archive of the 2026-09-05 run; later entries
below override any conflicting frontier statement. The present run starts
from the complete-support / moving-support obstruction. No assertion of a
Goldbach proof or of universal canonical traversal success is assumed.
```
