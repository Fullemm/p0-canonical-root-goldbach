---
id: SPACING-ONE-CLASS-20260907J
logical_id: SPACING-ONE-CLASS-20260907J
version_id: SPACING-ONE-CLASS-20260907J@J
kind: canonical-result
run: J
title: "Spacing one class"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 223, line_end: 234}
metadata: {"stable_id": "SPACING-ONE-CLASS-20260907J", "version_id": "SPACING-ONE-CLASS-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 223, "line_end": 234}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 223, "line_end": 234}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1086, style: ID-TABLE}
---

# Spacing one class

*Run J - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T4.  SPACING-ONE-CLASS-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S be closed and BAD and q in S.  Then
        {r in S : q | N-r}  is contained in a single residue class mod q
(namely N mod q), hence
        #{r in S : q | N-r}  <=  1 + floor( (max S - min S) / q ).
More generally #{r in S : q^v | N-r} <= 1 + floor((max S - min S)/q^v).

PROOF.  q | N-r <=> r = N (mod q).  Two elements of one class mod q^v differ by
a multiple of q^v; all elements lie in [min S, max S].  QED

--------------------------------------------------------------------------------
```
