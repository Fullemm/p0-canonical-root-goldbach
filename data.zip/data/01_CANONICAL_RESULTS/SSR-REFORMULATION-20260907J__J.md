---
id: SSR-REFORMULATION-20260907J
logical_id: SSR-REFORMULATION-20260907J
version_id: SSR-REFORMULATION-20260907J@J
kind: canonical-result
run: J
title: "Ssr reformulation"
status: PROVED
status_raw: "PROVED (7.2)"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1109, line_end: 1122}
metadata: {"stable_id": "SSR-REFORMULATION-20260907J", "version_id": "SSR-REFORMULATION-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 1109, "line_end": 1122}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 1109, "line_end": 1122}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Ssr reformulation

*Run J - status `PROVED` (raw: `PROVED (7.2)`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
SSR-REFORMULATION-20260907J              PROVED (7.2)

EXTERNAL REFERENCES USED
  E. M. Matveev, "An explicit lower bound for a homogeneous rational linear form
  in logarithms of algebraic numbers II", Izv. Math. 64 (2000), 1217-1269.
  Statement used in the form of J.-H. Evertse, Diophantine Approximation
  lecture notes (Leiden), Chapter 5, Theorem 5.4.  Verified in this run.
  No other external theorem is relied on.  Sondow's Ramanujan-prime bound,
  BHP, Freiberg and Bozek are cited by the master and are not used here.

================================================================================
END OF CHECKPOINT 2026-09-07J
================================================================================
```
