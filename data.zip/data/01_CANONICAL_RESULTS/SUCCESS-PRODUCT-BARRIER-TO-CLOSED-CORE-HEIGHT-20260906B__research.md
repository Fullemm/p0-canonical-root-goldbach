---
id: SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B
logical_id: SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B
version_id: SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B@research
kind: canonical-result
run: research
title: "FAIL-"
status: KILLED
status_raw: "KILLED AS AN INFERENCE; both input theorems survive."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 4638, line_end: 4669}
metadata: {"stable_id": "SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B", "version_id": "SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B@research", "status": "KILLED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4638, "line_end": 4669}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 4638, "line_end": 4669}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# FAIL-

*Run research - status `KILLED` (raw: `KILLED AS AN INFERENCE; both input theorems survive.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
FAIL-ID: SUCCESS-PRODUCT-BARRIER-TO-CLOSED-CORE-HEIGHT-20260906B
STATUS: KILLED AS AN INFERENCE; both input theorems survive.
CLAIM / ROUTE:
Combine the growing-depth product barriers with TWO-SMALLEST-ROWS-
HEIGHT to rule out a closed active BAD core reached from p0.
WHY IT LOOKED PROMISING:
One input controls products along moving paths; the other forces
complexity in a core's two least rows. Both refer to large arithmetic
objects, so it is tempting to regard their bounds as opposing capacities.
EXACT FAILURE:
The product barriers quantify over SUCCESSFUL paths, which a closed
BAD core has none of. Applying them inside such a core yields only a
vacuously true statement. The height theorem is a lower complexity
bound, not a conflicting upper bound. The new cofactor theorem does
not alter this logical domain mismatch.
In its sieve proof the final prime g=N-q_d is a crucial EXTRA prime
condition. Dropping it to count paths ending at BAD vertices loses a
factor log X: for canonical starts k changes from d+2 to d+1. The
resulting crude bound is of size (X/L)*L^(c+o(1)), not o(X/L). Thus
the written proof itself identifies the missing consumer, rather than
merely failing to state one.
WHAT SURVIVES:
Both complete radius-two density theorems, both path-product barriers,
and the pointwise two-smallest-row height restriction. None assumes a
fixed prime alphabet through the path.
DO NOT REPEAT:
Do not apply a successful-endpoint sieve to a failed closed core;
do not treat two lower bounds as a lower-versus-upper contradiction.
POSSIBLE REPLACEMENT:
A bound for BAD path endpoints or moving support that supplies an
independent upper restriction in a genuinely closed failed world.
```
