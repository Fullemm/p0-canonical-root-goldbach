---
id: THREE-CORE-PUREPOWER-20260907J
logical_id: THREE-CORE-PUREPOWER-20260907J
version_id: THREE-CORE-PUREPOWER-20260907J@J
kind: canonical-result
run: J
title: "Three core purepower"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 309, line_end: 330}
metadata: {"stable_id": "THREE-CORE-PUREPOWER-20260907J", "version_id": "THREE-CORE-PUREPOWER-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 309, "line_end": 330}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 309, "line_end": 330}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1089, style: ID-TABLE}
---

# Three core purepower

*Run J - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T7.  THREE-CORE-PUREPOWER-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S = {q_1 < q_2 < q_3} be a closed BAD set with |S| = 3 which is
source-free (e.g. a core).  Then one of the two rows N-q_1, N-q_2 is a pure
prime power:
        either N - q_1 = q_2^a (a >= 2)   or   N - q_2 = q_1^b (b >= 2).
Consequently every three-element core lies in an explicitly parametrised
family: N = q_1 + q_2^a or N = q_2 + q_1^b with the exponent at least 2, and
in both cases the base is <= N^{1/2}.

PROOF.  By T5, q_3 divides exactly one of N-q_1, N-q_2 (it cannot divide N-q_3).
Let j be the index (1 or 2) with q_3 | N-q_j, and let k be the other one.  Then
PF(N-q_k) subseteq {q_1,q_2,q_3} \ {q_k, q_3} = {q_1,q_2} \ {q_k}, a singleton;
N-q_k > 1, so N-q_k is a power of that single prime, and it is composite so the
exponent is >= 2.  The size bound follows since the power exceeds 2N/3.  QED

REMARK.  T7 makes the |S| = 3 class searchable in the same way as |S| = 2; see
section 10, NEXT-1.  It does not extend verbatim to |S| >= 4 (the argument
consumes one high prime per step but the remaining rows may still carry two
labels).

--------------------------------------------------------------------------------
```
