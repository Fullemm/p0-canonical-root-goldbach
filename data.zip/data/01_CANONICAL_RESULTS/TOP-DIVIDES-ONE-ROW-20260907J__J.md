---
id: TOP-DIVIDES-ONE-ROW-20260907J
logical_id: TOP-DIVIDES-ONE-ROW-20260907J
version_id: TOP-DIVIDES-ONE-ROW-20260907J@J
kind: canonical-result
run: J
title: "Top divides one row"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 235, line_end: 249}
metadata: {"stable_id": "TOP-DIVIDES-ONE-ROW-20260907J", "version_id": "TOP-DIVIDES-ONE-ROW-20260907J@J", "status": "PROVED", "scope": "All finite active sets; existence of parent separately required", "assumptions": ["P=max S", "S finite active primes", "Source-free/core only needed for at least one parent"], "statement": "P divides at most one row because otherwise P divides a positive difference <P; with a parent it divides exactly one. In BAD source-free sets P<N/3.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 235, "line_end": 249}, "depends_on": [], "consequences": [], "does_not_imply": ["Not unique-parent dynamics of I151", "Not recursive at smaller primes"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 235, "line_end": 249}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 13240, "relation": "SAME RESULT / OLDER ORIGIN"}], "computation": [], "concepts": ["unique-top-parent", "ordered-parents"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1087, style: ID-TABLE}
---

# Top divides one row

*Run J - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

P divides at most one row because otherwise P divides a positive difference <P; with a parent it divides exactly one. In BAD source-free sets P<N/3.

**Assumptions:** P=max S; S finite active primes; Source-free/core only needed for at least one parent.

**Does not imply:** Not unique-parent dynamics of I151; Not recursive at smaller primes.

## Source transcript (historical wording; apply current metadata)

```
T5.  TOP-DIVIDES-ONE-ROW-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S be closed and BAD with P = max S.  Then P divides AT MOST ONE
row N-r, r in S.  If S is a core, P divides EXACTLY ONE row.

PROOF.  By T4 with q = P, any two such r differ by a multiple of P; but all
r in S lie in [min S, P] so differ by less than P; hence at most one.  Also
P !| N-P by T1 (self-exclusion).  If S is a core it is source-free (T2 (iii)),
so P has an in-edge, i.e. at least one row is divisible by P.  QED

VERIFIED on the six cores: the unique row divisible by max(core) is N-3 for
N = 2200, 6142 and N-5 for N = 128, 1718, 1862, 1928.  So the largest core
element is always produced as a cofactor of the row of 3 or of 5.

--------------------------------------------------------------------------------
```
