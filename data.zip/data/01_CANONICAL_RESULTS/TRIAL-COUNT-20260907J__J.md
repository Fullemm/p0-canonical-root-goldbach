---
id: TRIAL-COUNT-20260907J
logical_id: TRIAL-COUNT-20260907J
version_id: TRIAL-COUNT-20260907J@J
kind: canonical-result
run: J
title: "8.1"
status: VERIFIED COMPUTATION
status_raw: "PROVED (T3, T10) + VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 906, line_end: 920}
metadata: {"stable_id": "TRIAL-COUNT-20260907J", "version_id": "TRIAL-COUNT-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 906, "line_end": 920}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 906, "line_end": 920}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1101, style: ID-TABLE}
---

# 8.1

*Run J - status `VERIFIED COMPUTATION` (raw: `PROVED (T3, T10) + VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
8.1  TRIAL-COUNT-20260907J          STATUS: PROVED (T3, T10) + VERIFIED COMPUTATION
Canonical failure is possible only at N in H (T3(b) with k = 0).  For every
N not in H, EVERY upper root with composite mirror succeeds, and the reason
does not mention the selector.  Hence:

   the exhaustive canonical scan over any range R contributes exactly
        # { N in R ^ H : m_0(N) is composite }
   Bernoulli trials of the hypothesis "rank 0 is protected", and no more.

For R = [6, 6*10^4] (and, by X1/X2, for the extended ranges) that number is
        THREE:  N = 1862, 1928, 6142.
On the other three hosts p_0 is itself a Goldbach witness (m_0 = 61, 1097 prime;
N = 1718 is the diagonal case p_0 = N/2 = 859 prime), so the traversal returns
SUCCESS at depth 0 with an EMPTY world and no dynamics whatever.
```
