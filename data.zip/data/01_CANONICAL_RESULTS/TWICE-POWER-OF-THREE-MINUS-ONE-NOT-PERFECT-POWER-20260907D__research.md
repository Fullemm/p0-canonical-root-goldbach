---
id: TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D
logical_id: TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D
version_id: TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D@research
kind: canonical-result
run: research
title: "Twice power of three minus one not perfect power"
status: PROVED
status_raw: "PROVED by an elementary factorization argument."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 6430, line_end: 6454}
metadata: {"stable_id": "TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D", "version_id": "TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6430, "line_end": 6454}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 6430, "line_end": 6454}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Twice power of three minus one not perfect power

*Run research - status `PROVED` (raw: `PROVED by an elementary factorization argument.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: TWICE-POWER-OF-THREE-MINUS-ONE-NOT-PERFECT-POWER-20260907D
STATUS: PROVED by an elementary factorization argument.
EXACT STATEMENT:
For every integer u>=1, 2*3^u-1 is not a proper integer power A^k,
with integers A>=2 and k>=2. A need not be prime.
PROOF:
Suppose 2*3^u-1=A^k. The number is odd and is 2 modulo 3, so A is
odd, A=2 (mod 3), and k is odd. Choose an odd prime ell dividing k
and put B=A^(k/ell). Then B>=3 is odd, B=-1 (mod 3), and
 (B+1)*(B^(ell-1)-B^(ell-2)+...-B+1)=2*3^u.
The second factor F is odd and greater than one; hence F is a
positive power of 3. Modulo 3 each of its ell terms is 1, so
F=ell (mod 3), forcing ell=3. Thus
 B^2-B+1 is a positive power of 3.
Writing B=3t-1 gives B^2-B+1=3*(3t(t-1)+1), with exactly one
factor of 3. Therefore B^2-B+1=3, implying B=2 or B=-1.
Both contradict B odd and B>=3. This proves the statement.
HOSTILE CHECK:
This excludes every proper power, not just a prime power. It does
not say the number is composite: u=1,2,3 give 5,17,53, all prime.
No primality of 3^u+2 is used. The result was derived by the one
subagent and independently checked by the root agent.
NOVELTY: elementary lemma/application, not a literature priority claim.
```
