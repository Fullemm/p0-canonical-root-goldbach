---
id: TWO-CORE-EXHAUSTED-1E24-20260907J
logical_id: TWO-CORE-EXHAUSTED-1E24-20260907J
version_id: TWO-CORE-EXHAUSTED-1E24-20260907J@J
kind: canonical-result
run: J
title: "Two core exhausted 1e24"
status: VERIFIED COMPUTATION
status_raw: "VERIFIED COMPUTATION"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 469, line_end: 486}
metadata: {"stable_id": "TWO-CORE-EXHAUSTED-1E24-20260907J", "version_id": "TWO-CORE-EXHAUSTED-1E24-20260907J@J", "status": "VERIFIED COMPUTATION", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 469, "line_end": 486}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 469, "line_end": 486}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1095, style: ID-TABLE}
---

# Two core exhausted 1e24

*Run J - status `VERIFIED COMPUTATION` (raw: `VERIFIED COMPUTATION`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
X3.  TWO-CORE-EXHAUSTED-1E24-20260907J          STATUS: VERIFIED COMPUTATION
--------------------------------------------------------------------------------
QUESTION (sharp): find ALL even N admitting a two-element closed BAD set.
By T6 this is exactly the solution set of q_1^a - q_1 = q_2^b - q_2 in distinct
odd primes with a,b >= 2, and by T6(i) at least one exponent is >= 3.
DOMAIN: all (q,e) with e >= 3 and q^e <= 10^24 (q <= 10^8: 5 761 455 primes,
5 848 394 prime powers).  For each value V = q^e - q, (A) collisions inside the
table, and (B) the exponent-2 partner obtained by solving r^2 - r = V exactly
(r = (1 + isqrt(1+4V))/2, integrality and primality checked exactly).
Since both q_1^a = N-q_2 < N and q_2^b = N-q_1 < N, this is COMPLETE for every
even N <= 10^24.
RESULT:  exactly one solution,
        3^7 - 3 = 13^3 - 13 = 2184,        N = 2200.
No two-element closed BAD set exists for any other even N <= 10^24.
RUNTIME: 38 s.  Compare T9/HC2: the Matveev bound for the same class
(s = 2, S = {3,13}) is 1.15 * 10^9 times weaker than this direct result.

--------------------------------------------------------------------------------
```
