---
id: TWO-CORE-PILLAI-20260907J
logical_id: TWO-CORE-PILLAI-20260907J
version_id: TWO-CORE-PILLAI-20260907J@J
kind: canonical-result
run: J
title: "Two core pillai"
status: PROVED
status_raw: "PROVED"
audit: ASTRA-PROOF-CHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 250, line_end: 308}
metadata: {"stable_id": "TWO-CORE-PILLAI-20260907J", "version_id": "TWO-CORE-PILLAI-20260907J@J", "status": "PROVED", "scope": "All N, exact structural characterization", "assumptions": ["p<q distinct odd primes", "b,c integers>=2"], "statement": "{p,q} is a closed BAD core iff N=p+q^b=q+p^c; 2<=b<c. N=2200 is a witness.", "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 250, "line_end": 308}, "depends_on": [], "consequences": [], "does_not_imply": ["Not global uniqueness", "Finite census is separate"], "killed_stronger_forms": [], "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 250, "line_end": 308}, "proof_provenance": [{"file": "07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex", "line": 12787, "relation": "SAME RESULT / OLDER ORIGIN"}], "computation": [], "concepts": ["pillai-equation", "pure-row"], "historical_aliases": [], "search_aliases": [], "verification": "ASTRA-PROOF-CHECKED", "metadata_completeness": "CURATED"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1088, style: ID-TABLE}
---

# Two core pillai

*Run J - status `PROVED` (raw: `PROVED`) - audit `ASTRA-PROOF-CHECKED`*

> Verification: **ASTRA-PROOF-CHECKED**. Metadata coverage: CURATED.

## Current scoped statement

{p,q} is a closed BAD core iff N=p+q^b=q+p^c; 2<=b<c. N=2200 is a witness.

**Assumptions:** p<q distinct odd primes; b,c integers>=2.

**Does not imply:** Not global uniqueness; Finite census is separate.

## Source transcript (historical wording; apply current metadata)

```
T6.  TWO-CORE-PILLAI-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let S = {q_1 < q_2} be a closed BAD set with |S| = 2.  Then there
are integers a, b >= 2 with
        N - q_1 = q_2^b ,    N - q_2 = q_1^a ,
equivalently
        q_1^a - q_1 = q_2^b - q_2 = N - q_1 - q_2 .
Moreover
  (i)   (a,b) != (2,2);
  (ii)  ord_{q_1}(q_2) | b-1  and  ord_{q_2}(q_1) | a-1;
  (iii) q_1 q_2 | N - q_1 - q_2  and  q_1 q_2 < N;
  (iv)  q_1 < q_2 <= N^{1/2}, a > b >= 2, and max(a,b) = a >= 3.
Conversely, for any two distinct odd primes q_1, q_2 and integers a, b >= 2
with q_1^a - q_1 = q_2^b - q_2, the number N := q_1 + q_2^b is even, both q_i
are active, S = {q_1,q_2} is a closed BAD set, and therefore B_N != empty:
N is an EAC host.

PROOF.  Closedness gives PF(N-q_1) subseteq {q_1,q_2}, and q_1 !| N-q_1 by T1,
so PF(N-q_1) = {q_2} (nonempty since N-q_1 > 1), i.e. N-q_1 = q_2^b; BADness
makes N-q_1 composite so b >= 2.  Symmetrically N-q_2 = q_1^a, a >= 2.
Subtracting, q_1^a - q_1 = (N-q_2) - q_1 = (N-q_1) - q_2 = q_2^b - q_2.
(i) a = b = 2 gives q_1^2-q_1 = q_2^2-q_2, i.e. (q_1-q_2)(q_1+q_2-1) = 0,
impossible for distinct positive primes.
(ii) q_1 | q_1^a - q_1 = q_2(q_2^{b-1}-1) and q_1 != q_2, so q_1 | q_2^{b-1}-1.
(iii) N-q_1-q_2 = q_2^b - q_2 = q_2(q_2^{b-1}-1) is divisible by q_2 and, by
(ii), by q_1; it is positive because q_1, q_2 < N/3.  Hence q_1q_2 <=
N-q_1-q_2 < N.
(iv) q_2^b = N-q_1 < N with b >= 2, so q_2 <= N^{1/2}.  Since q_1^a and q_2^b
differ by less than q_2 < N^{1/2} while both exceed 2N/3, a log q_1 = b log q_2
+ O(N^{-1/2}), and q_1 < q_2 forces a > b; with (i) this gives a >= 3.
Converse: N = q_1 + q_2^b is odd+odd = even; q_1 | N would force q_1 | q_2^b,
false; likewise q_2 | N would force q_2 | q_1^a (using N = q_2 + q_1^a), false;
q_2^b > 2N/3 gives q_2 <= N^{1/2} < N/3 for N >= 9, and q_1 < q_2; both rows are
composite prime powers whose prime supports lie in S.  QED

REMARK (abc).  STATUS: CONJECTURE-CONDITIONAL.  Write the solution as the
coprime abc triple  q_1^a + (q_2 - q_1) = q_2^b  (coprimality: q_1 | q_2-q_1
would force q_1 | q_2, and q_2 | q_2-q_1 would force q_2 | q_1).  Its radical is
q_1 * rad(q_2-q_1) * q_2 <= q_1 q_2^2 <= N^{1/a + 2/b}, while its largest term is
q_2^b > 2N/3.  So the abc conjecture forces 1/a + 2/b >= 1 - o(1).  With
a > b >= 2 (T6(iv)) this leaves ONLY b = 2:  b=3 needs a<=3, b=4 needs a<=2,
b>=5 is impossible.  Hence under abc, all but finitely many two-element cores
satisfy N - q_1 = q_2^2 with q_1 < q_2 ~ N^{1/2} and N - q_2 = q_1^a, a >= 3.
The one known solution has (a,b) = (7,3) with 1/7 + 2/3 = 0.81 < 1, i.e. it is
exactly one of the finitely many abc-exceptional cases -- consistent with its
unusually high abc quality 1.29.  X3 found no b = 2 solution below 10^24 either.

REMARK (the reduction).  The equation q_1^a - q_1 = q_2^b - q_2 with a,b >= 2 is
a Pillai / Bennett-type exponential Diophantine equation with MOVING bases.  It
is not known to have finitely many solutions unconditionally.  Under abc it does
whenever 1/a + 1/b + 1/min(a,b) < 1.  The single known solution
3^7 - 3 = 13^3 - 13 = 2184 is an abc triple of quality
log 2197 / log rad(3^7 * 13^3 * 10) = log 2197 / log 390 = 1.29.
The corpus already flagged this as "the 2-core wall" (rem:2200); T6 supplies
the exact statement, both directions, and the corollary that ANY solution
manufactures a new EAC host.  X3 below settles the equation computationally for
all N <= 10^24.

--------------------------------------------------------------------------------
```
