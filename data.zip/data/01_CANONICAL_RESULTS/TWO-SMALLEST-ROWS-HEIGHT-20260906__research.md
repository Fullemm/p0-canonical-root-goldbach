---
id: TWO-SMALLEST-ROWS-HEIGHT-20260906
logical_id: TWO-SMALLEST-ROWS-HEIGHT-20260906
version_id: TWO-SMALLEST-ROWS-HEIGHT-20260906@research
kind: canonical-result
run: research
title: "Two smallest rows height"
status: PROVED
status_raw: "PROVED; refinement of UNRESTRICTED-CLOSED-SUPPORT-HEIGHT."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1970, line_end: 2050}
metadata: {"stable_id": "TWO-SMALLEST-ROWS-HEIGHT-20260906", "version_id": "TWO-SMALLEST-ROWS-HEIGHT-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1970, "line_end": 2050}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["TWO-SMALLEST-ROWS-HEIGHT"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1970, "line_end": 2050}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Two smallest rows height

*Run research - status `PROVED` (raw: `PROVED; refinement of UNRESTRICTED-CLOSED-SUPPORT-HEIGHT.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: TWO-SMALLEST-ROWS-HEIGHT-20260906
STATUS: PROVED; refinement of UNRESTRICTED-CLOSED-SUPPORT-HEIGHT.
EXACT STATEMENT:
Let N>=8 be even, and C a nonempty finite set of primes p<N with p not
 dividing N, N-p composite, and PF(N-p) subset C. Write a<b for the two
smallest labels in C, U=N-a, V=N-b, S=PF(UV), t=|S|, and
 A(S)=1.4*30^(t+3)*t^(9/2)*product_(q in S) log q.
Then:
 (i) a<b<sqrt(N), and gcd(U,V)=1;
 (ii) log((N-b)/(b-a))
       < A(S)*(1+log(log N/log 3));
 (iii) log(sqrt(N)-1)
       < A(S)*(1+log(log N/log 3)).
In particular the full support of just these two rows, even inside an
arbitrarily branching core with large other labels, must satisfy
 product_(q in S) log q >
 log(sqrt(N)-1) /
 [1.4*30^(t+3)*t^(9/2)*(1+log(log N/log 3))].

PROOF:
A singleton C={a} would give N-a=a^e, hence a|N, contradicting activity.
All labels are odd. The least prime divisor r of the odd composite U is
at most sqrt(U)<sqrt(N). Closure gives r in C, and activity gives r!=a,
because a|(N-a) would imply a|N. Hence b<=r<sqrt(N), proving (i)'s
size assertion, without any assumption about pure-power rows.
If a prime ell divided U and V, then ell belongs to C and divides b-a.
It cannot equal a, by activity of a, and every other element of C is at
least b>b-a. Thus no such ell exists and gcd(U,V)=1.
Now U/V-1=(b-a)/(N-b)>0. Its prime bases are exactly S, with nonzero
signed exponents e_q=v_q(U)-v_q(V) and |e_q|<=log N/log 3. Apply the
rational real-field product-minus-one Matveev bound recorded above, with
A_q=log q, to obtain (ii). Finally b-a<b<sqrt(N) and
N-b>N-sqrt(N), whence (N-b)/(b-a)>sqrt(N)-1. This gives (iii).

HOSTILE CHECK:
The fragile elementary step is excluding a as a factor of its own row;
that requires activity, not merely compositeness. If inactive vertices
were allowed, singleton examples N=a+a^2 invalidate the claim. The bound
uses the actual union of two row supports, not necessarily all of C.
Nothing requires that either row be a prime power. The older result that
a terminal BAD SCC has a cycle below sqrt(N) is already stated in the
Biblia (late synthesis, near line 49182 in the supplied copy); the small
cycle itself is not claimed as new. Here the consumer is the quantitative
height comparison of the two least rows. This improves the previous
M/(N-M) comparison, but remains only a necessary condition on a failed
world. It does not put an upper bound on the moving support.

DEPENDENCIES:
Full factor closure; activity; Matveev-in-BMS-9.4. The external input is
being rechecked in the author's PDF in this run. No Scott classification.
RELATION TO GOLDBACH: Applies to any closed failed core, whether supplied
by global failure or by one failed traversal. Does not exclude all cores.
RELATION TO p0: Shared by all roots whose traversals fail. No asymmetry.
WHAT REMAINS OPEN: A contradictory upper support bound or another genuine
consumer of the close pair of coprime rows.
NOVELTY: NOT YET AUDITED.

SOURCE-AUDIT 2026-09-06:
The Matveev input was rechecked in Bugeaud--Mignotte--Siksek, Theorem 9.4,
author PDF printed pp.16--17. It is indeed the product-minus-one bound,
with real-field coefficient 1.4*30^(n+3)*n^4.5*(1+log B) for D=1.
The preceding two-smallest-row refinement uses exactly that statement.

EXTERNAL-INPUT: FKL-2010-LEMMA-5.1
STATUS: EXACT STATEMENT CHECKED in primary research, including uniformity.
Kevin Ford, Sergei V. Konyagin, Florian Luca, Prime chains and Pratt trees,
Geom. Funct. Anal. 20 (2010), 1231--1258, Lemma 5.1, printed pp.12--13.
https://arxiv.org/pdf/0904.0473
For k primitive integer linear forms a_i n+b_i, a_i>0, let nu(ell) count
their roots modulo ell, B=sum_ell (k-nu(ell))*log(ell)/ell, and
 S=product_ell (1-nu(ell)/ell)*(1-1/ell)^(-k).
There is an absolute delta>0 such that, if x>10,
k<=delta*log(x)/loglog(x), B<=delta*log(x), the number of positive n<=x
for which all forms are prime and exceed k is at most
 2^k*k!*x*S/(log x)^k *
 exp(O((k*B+k^2*loglog x)/log x)).
The displayed O constant is absolute. We only use k=2,3,4. All pairwise
determinants are checked nonzero below; nonprimitive forms and prime
values <=k are removed before application. This is an upper-bound sieve,
not a prime-tuples lower bound.
```
