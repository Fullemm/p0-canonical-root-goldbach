---
id: TWO-SMALLEST-ROWS-HEIGHT@research
logical_id: TWO-SMALLEST-ROWS-HEIGHT
version_id: TWO-SMALLEST-ROWS-HEIGHT@research
kind: historical-version
run: research
title: "Two smallest rows height"
status: SUPERSEDED
status_raw: "every active closed BAD set has two least"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3330, line_end: 3375}
metadata: {"stable_id": "TWO-SMALLEST-ROWS-HEIGHT", "version_id": "TWO-SMALLEST-ROWS-HEIGHT@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3330, "line_end": 3375}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "TWO-SMALLEST-ROWS-HEIGHT-20260906", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3330, "line_end": 3375}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: TWO-SMALLEST-ROWS-HEIGHT-20260906
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Two smallest rows height

*Run research - status `SUPERSEDED` (raw: `every active closed BAD set has two least`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `TWO-SMALLEST-ROWS-HEIGHT-20260906` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
4. TWO-SMALLEST-ROWS-HEIGHT: every active closed BAD set has two least
   labels below sqrt N with coprime rows, yielding a height constraint
   on their actual joint support without a pure-row assumption.
The first three statements coexist with ordinary Goldbach truth for
relative density one of the h=1 prime starts, by a known exceptional-set
bound. That external Goldbach bound has not been improved here.

=========================
CURRENT FRONTIER
=========================
No proof of binary Goldbach, no pointwise Goldbach threshold, and no
proof of universal canonical traversal success. The new analytic results
settle full shallow BADness through radius two in the h=1 family in a
relative-density-one sense. They do not yet settle every fixed radius.
The radius-three large-product parameter region is not controlled by
the current one-variable sieve switching. Closed BAD reachable sets
with moving large support remain unexcluded. No upper support bound
contradicts the new or inherited necessary height bounds.

=========================
p0 STATUS
=========================
No nontrivial property proved for every p0 with a demonstrated same-N
failure at p1. A substantial SAME-N negative theorem was proved: complete
first-front BADness is shared by p0 and a growing nearby prefix in the
h=1 family. Complete radius-two BADness was proved asymptotically for
p0 there, but no conclusion comparing the radius-two laws of p0 and p1
is justified yet. The empirical eventual-traversal exceptionality of
p0 remains unexplained.

=========================
EXACT NEXT QUESTION
=========================
Is the number of primes P in [X,2X] for which the canonical root of
N=2(P-1) reaches a GOOD vertex within THREE edges o(X/log X)?
A proof must control the complete third frontier, especially successful
paths with large product of labels for which all naive choices of
fixed labels or cofactors leave too short a sieve variable.

=========================
CONTINUATION 2026-09-06B
=========================
The previous run's end sections are archival. This continuation audits
its radius-two theorem and investigates a deeper SAME-N comparison.
No pointwise Goldbach or eventual p0-reachability theorem is assumed.
```
