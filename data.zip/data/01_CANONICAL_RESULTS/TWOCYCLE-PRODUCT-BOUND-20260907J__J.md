---
id: TWOCYCLE-PRODUCT-BOUND-20260907J
logical_id: TWOCYCLE-PRODUCT-BOUND-20260907J
version_id: TWOCYCLE-PRODUCT-BOUND-20260907J@J
kind: canonical-result
run: J
title: "Twocycle product bound"
status: PROVED
status_raw: "PROVED"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 331, line_end: 344}
metadata: {"stable_id": "TWOCYCLE-PRODUCT-BOUND-20260907J", "version_id": "TWOCYCLE-PRODUCT-BOUND-20260907J@J", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 331, "line_end": 344}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-07J.txt", "line": 331, "line_end": 344}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
also_at:
  - {file: "nowe/goldbach_checkpoint_2026-09-07J.txt", line: 1090, style: ID-TABLE}
---

# Twocycle product bound

*Run J - status `PROVED` (raw: `PROVED`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
T8.  TWOCYCLE-PRODUCT-BOUND-20260907J          STATUS: PROVED
--------------------------------------------------------------------------------
STATEMENT.  Let p != q be active primes with q | N-p and p | N-q (a 2-cycle in
Gamma_N).  Then p q | N - p - q.  If moreover p, q < N/3, then
        p q <= N - p - q < N .
More generally, for a cycle p_1 -> p_2 -> ... -> p_L -> p_1 the congruences
N = p_i (mod p_{i+1}) determine N modulo prod p_i; so either prod p_i <= N or
N is exactly the least positive CRT solution of that system.

PROOF.  N = p (mod q) and N = q (mod p); p+q satisfies both congruences, and
gcd(p,q) = 1, so N = p+q (mod pq).  Since p,q < N/3 we have N-p-q > N/3 > 0,
hence pq divides a positive integer < N.  The cycle statement is CRT.  QED

--------------------------------------------------------------------------------
```
