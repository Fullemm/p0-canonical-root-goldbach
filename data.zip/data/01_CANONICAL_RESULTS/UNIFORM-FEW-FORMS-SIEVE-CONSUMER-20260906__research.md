---
id: UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906
logical_id: UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906
version_id: UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906@research
kind: canonical-result
run: research
title: "Uniform few forms sieve consumer"
status: PROVED
status_raw: "PROVED from FKL-2010-LEMMA-5.1."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 2051, line_end: 2104}
metadata: {"stable_id": "UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906", "version_id": "UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2051, "line_end": 2104}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 2051, "line_end": 2104}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Uniform few forms sieve consumer

*Run research - status `PROVED` (raw: `PROVED from FKL-2010-LEMMA-5.1.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: UNIFORM-FEW-FORMS-SIEVE-CONSUMER-20260906
STATUS: PROVED from FKL-2010-LEMMA-5.1.
EXACT STATEMENT:
Fix r in {2,3,4}, epsilon>0, C>0. Let primitive linear forms
 L_i(n)=a_i*n+b_i, a_i>0, have nonzero pairwise determinants and
 1<=Delta=abs(product_i a_i * product_(i<j)(a_i*b_j-a_j*b_i))<=X^C.
Suppose X^epsilon<=z<=X^C. Uniformly in these forms, the number of
positive n<=z with every L_i(n) prime and >r is
 O_(epsilon,C)(z*(loglog X)^r/(log z)^r).
If nu(ell)>=1 for every prime ell, improve the exponent r on loglog X
to r-1. The same improvement holds when the only possible exception is
one odd prime q>=3; its extra local factor is bounded by (3/2)^r.
All assertions are for sufficiently large X; changing constants covers
bounded X in any use where the logarithms are replaced by positive logs.

PROOF:
For ell not dividing Delta, nu(ell)=r, since all leading coefficients are
invertible and the r roots are distinct. Always 0<=nu(ell)<=r. Thus
 B<=r*sum_(ell|Delta) log(ell)/ell = O_C(loglog X).
Here is an elementary justification of the uniform bound: put
T=max(3,log(3*Delta)). For ell<=T the sum is O(log T), by partial
summation from theta(t)=sum_(ell<=t)log ell=O(t). For ell>T it is at most
(log Delta)/T<=1. Chebyshev's theta bound is sufficient (and also follows
from the PNT already used in the checkpoint).
Similarly
 product_(ell|Delta)(1-1/ell)^(-1)=O(loglog(3*Delta)).
For completeness, the factors ell>T have bounded product because their
logarithms are O(sum_(ell|Delta,ell>T)1/ell)=O(1). For ell<=T, put
sigma=1+1/log T. Comparing Euler factors at 1 and sigma costs O(1) in
logarithm: the first-power difference is at most
(sigma-1)*sum_(ell<=T)log(ell)/ell=O(1), and higher powers have a
bounded sum. The product at sigma is <=zeta(sigma)<=1+1/(sigma-1),
by the integral comparison for sum n^(-sigma). Thus the product is O(log T).
For ell not dividing Delta, the local singular-series factor is <=1,
by 1-r/ell<=(1-1/ell)^r; primes ell<=r outside Delta cannot occur
unless local admissibility fails. At exceptional primes use the bound
(1-1/ell)^(-r). If nu(ell)>=1, use the sharper exponent -(r-1).
This proves S=O_C((loglog X)^r), or the stated improvement. If S=0,
a prime ell<=r divides at least one form for every n, so no tuple of
prime values >r occurs. Finally B=O_C(loglog X) and log z>=epsilon log X
verify both FKL size hypotheses for large X; its exponential factor is
bounded. This proves the claimed uniform bounds.

HOSTILE CHECK:
A fixed-coefficient asymptotic sieve result would be insufficient here;
FKL supplies the needed uniform B condition. Common leading primes may
have nu=0 even for primitive forms, so the exponent r-1 is NOT used
without the explicitly stated local check. A zero pair determinant
would destroy the r-dimensional sieve gain; such cases are checked
separately in each consumer. This lemma is an application, not a new
claim about the underlying sieve theorem.
DEPENDENCIES: FKL Lemma 5.1; elementary Euler products and Chebyshev bound.
NOVELTY: NOT YET AUDITED.
```
