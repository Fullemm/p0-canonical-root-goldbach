---
id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905
logical_id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905
version_id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905@research
kind: canonical-result
run: research
title: "Unrestricted closed support height"
status: PROVED WITH REPAIR
status_raw: "PROVED WITH REPAIR / GENERALIZATION of Biblia iteration108-support."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 422, line_end: 463}
metadata: {"stable_id": "UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905", "version_id": "UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905@research", "status": "PROVED WITH REPAIR", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 422, "line_end": 463}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": ["UNRESTRICTED-CLOSED-SUPPORT-HEIGHT"], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 422, "line_end": 463}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Unrestricted closed support height

*Run research - status `PROVED WITH REPAIR` (raw: `PROVED WITH REPAIR / GENERALIZATION of Biblia iteration108-support.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905
STATUS: PROVED WITH REPAIR / GENERALIZATION of Biblia iteration108-support.
EXACT STATEMENT:
Let N>=8 be even and let C be a nonempty set of active prime labels <N,
with every N-p composite and PF(N-p) subset C for every p in C.
Put s=|C|, M=max C, and
  A(C)=1.4*30^(s+3)*s^(9/2)*product_(q in C) log q.
Then s>=2, all q in C are odd, and
  log((N-M)/M)
  < A(C) * (1+log(log N/log 3)).                    (H)
No assumption on the number of nonbranching rows, SCC minimality,
canonicity, or global Goldbach failure is made.

PROOF:
Activity excludes 2 because N is even. The singleton case is excluded as
in CLOSED-ALPHABET-COUNT. Choose any a<b in C; one may choose the two smallest.
Write U=N-a and V=N-b. Closure implies U,V are C-smooth and U>V>0.
Let e_q=v_q(U)-v_q(V). Since U,V<N and q>=3,
  |e_q|<=log N/log q<=log N/log 3.
Omit zero coefficients if necessary. At least one remains, because U!=V.
For Lambda=U/V-1=(b-a)/(N-b)>0, use the preceding Matveev form with
alpha_i=q_i, A_i=log q_i (h(q_i)=log q_i>0.16), D=1.
All logarithms of odd primes exceed 1. Thus adding back omitted primes
only enlarges the product; the factor 1.4*30^(t+3)*t^(9/2) increases with t.
The result is
  log Lambda > -A(C)*(1+log(log N/log 3)).
On the other hand b-a<M and N-b>=N-M, so
  Lambda < M/(N-M).
Compare and negate to obtain (H).

HOSTILE CHECK:
Lambda is PRODUCT-minus-one, precisely the verified external theorem's form.
No confusion with the logarithmic form is needed. The inequality remains
valid if M>N/2, but its left side then gives no information. This is an
explicit limitation, not an omitted hypothesis. No coprimality of U,V is
needed here, and no assumption about two small pure-power rows is used.
For M<=sqrt N, (H) immediately yields the familiar positive order-log N
lower bound on A(C), without any branching restriction.

DEPENDENCIES: Exact full factor closure; the verified real rational Matveev
bound. No Scott classification, prime-gap bound, RH, or abc assumption.
```
