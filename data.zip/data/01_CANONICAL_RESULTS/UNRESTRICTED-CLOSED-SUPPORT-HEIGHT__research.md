---
id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT@research
logical_id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT
version_id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT@research
kind: historical-version
run: research
title: "Unrestricted closed support height"
status: SUPERSEDED
status_raw: "removes the historical two-pure-row"
audit: HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 1900, line_end: 1904}
metadata: {"stable_id": "UNRESTRICTED-CLOSED-SUPPORT-HEIGHT", "version_id": "UNRESTRICTED-CLOSED-SUPPORT-HEIGHT@research", "status": "SUPERSEDED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1900, "line_end": 1904}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": "UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905", "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 1900, "line_end": 1904}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT", "metadata_completeness": "SOURCE-POINTER-ONLY"}
superseded_by_id: UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905
supersession_reason: "Short historical name/summary reference; resolve the maintained canonical identity."
---

# Unrestricted closed support height

*Run research - status `SUPERSEDED` (raw: `removes the historical two-pure-row`) - audit `HISTORICAL-VERSION-DO-NOT-CITE-AS-CURRENT`*

> **SUPERSEDED** -- do not cite as current. Kept for historical recovery.
>
> Replaced by `UNRESTRICTED-CLOSED-SUPPORT-HEIGHT-20260905` (run `?`).
>
> **Defect:** Short historical name/summary reference; resolve the maintained canonical identity.

## Source transcript (historical wording; apply current metadata)

```
1. UNRESTRICTED-CLOSED-SUPPORT-HEIGHT: removes the historical two-pure-row
   assumption. EFFECTIVE-BOUNDED-CORE-THRESHOLD gives a completely explicit
   F(y) excluding every closed active BAD core supported below y once
   N>=F(y). POINTWISE-CORE-LABEL-GROWTH gives the resulting iterated-log
   lower bound on the largest core prime, uniformly over arbitrary branching.
```
