---
id: V81-C2-RESIDUAL
logical_id: V81-C2-RESIDUAL
version_id: V81-C2-RESIDUAL@P
kind: canonical-result
run: P
title: "Is P1 really new, or a restatement of"
status: REQUIRES HUMAN REVIEW
status_raw: "?"
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_checkpoint_2026-09-08P.txt", line: 579, line_end: 631}
metadata: {"stable_id": "V81-C2-RESIDUAL", "version_id": "V81-C2-RESIDUAL@P", "status": "REQUIRES HUMAN REVIEW", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 579, "line_end": 631}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_checkpoint_2026-09-08P.txt", "line": 579, "line_end": 631}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Is P1 really new, or a restatement of

*Run P - status `REQUIRES HUMAN REVIEW` (raw: `?`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
HC1.  Is P1 really new, or a restatement of V81-C2-RESIDUAL?
They are different statements.  V81-C2 bounds min R' for one specific derived
world in the v4.81 chain.  P1 bounds q_2, the SECOND smallest label, of an
arbitrary closed BAD set, and the second-smallest bound is exactly what makes
P3a a finite search (the smallest-label bound alone does not).  P1's proof is
two lines and is certainly not new as a technique; only its use is.

HC2.  Is the E1 search really complete, or does it silently assume something?
It assumes exactly D4 (top-label rigidity, PROVED), D5 (three-core pure row,
PROVED), D3 (auto-activity, PROVED) and P1.  Chain: D4 => P3 (exact dichotomy)
=> the pure row's partner is q_1 or q_2 => P1 gives partner < sqrt N => the
enumeration over (prime power, small partner) is exhaustive.  Two independent
sanity checks: the code reproduces N = 2200 in both orientations, and it reports
no false positives on the six known hosts (whose cores have sizes 2, 8, 10, 14,
21, 28, so only the size-2 one is expected and only that one is found).

HC3.  Does E1 depend on the ordering conventions?
No.  The loop ranges over ALL ordered pairs (base p, partner q) with q < sqrt N,
so both case (A) (p = q_1 < q = q_2) and case (B) (q = q_1 < p = q_2) are
covered, and the two orientations of the N = 2200 solution are both found,
confirming this.

HC4.  Does P5 overclaim?
No.  P5(a) is a proof only of why the L = 2 mechanism does not extend; it is not
a proof that no other cycle invariant exists.  P5(b) and (c) are exact finite
computations.  The conclusion drawn is precisely: the ONLY known arithmetic
consequence of a cycle -- its size bound -- fails for L >= 3 and fails
spectacularly on every real core.  It is not claimed that no unknown invariant
could exist; it is claimed that the exit route as currently stated is empty and
that nothing is presently known to replace it.

HC5.  Does P6 claim the K--O theorems are wrong?
No.  They are correct.  P6 records that their regime (s = 4, 5) contains no
known host and, for s = 3, provably contains none up to 1e12.  This is a
priority argument, not a refutation.

HC6.  Quantifier discipline.
P1, P2, P3, P4, P5(a) are for-all statements about arbitrary closed BAD sets or
cores, with no fixed alphabet, no fixed N and no density language.  P3a is a
for-all-N reduction to a finite enumeration; E1 is that enumeration on an
explicitly stated finite domain.  P2's corollaries are exact counting
inequalities, not averages.  E2--E4 are finite computations with stated domains.
Nothing here is promoted from computation to theorem.

HC7.  What P1 does NOT give.
P1 bounds q_2 but says nothing about q_3, ..., q_s; the real cores have
|L| up to 18 labels above sqrt N.  P1 therefore does not by itself make the
s >= 4 classes finite, and section 6 records precisely why.

================================================================================
6.  FAILED ROUTES DISCOVERED IN THIS RUN
================================================================================
```
