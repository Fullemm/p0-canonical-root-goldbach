---
id: WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B
logical_id: WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B
version_id: WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B@research
kind: canonical-result
run: research
title: "Weighted compatible gcd average"
status: PROVED
status_raw: "PROVED."
audit: SOURCE-REPORTED-NOT-RECHECKED
source_audit: SOURCE-REPORTED-NOT-RECHECKED
layer: 1
generated: true
generator: 09_TOOLS/build_canonical.py
sources:
  - {file: "nowe/goldbach_research_checkpoint_2026-09-07.txt", line: 3396, line_end: 3448}
metadata: {"stable_id": "WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B", "version_id": "WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B@research", "status": "PROVED", "scope": null, "assumptions": null, "statement": null, "proof_location": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3396, "line_end": 3448}, "depends_on": null, "consequences": null, "does_not_imply": null, "killed_stronger_forms": null, "counterexamples": [], "supersedes": [], "superseded_by": null, "original_source": {"file": "07_HISTORICAL_CORPUS/raw/nowe/goldbach_research_checkpoint_2026-09-07.txt", "line": 3396, "line_end": 3448}, "proof_provenance": [], "computation": [], "concepts": [], "historical_aliases": [], "search_aliases": [], "verification": "SOURCE-REPORTED-NOT-RECHECKED", "metadata_completeness": "SOURCE-POINTER-ONLY"}
---

# Weighted compatible gcd average

*Run research - status `PROVED` (raw: `PROVED.`) - audit `SOURCE-REPORTED-NOT-RECHECKED`*

> Verification: **SOURCE-REPORTED-NOT-RECHECKED**. Metadata coverage: SOURCE-POINTER-ONLY.

> Scope has not yet been structurally curated. Read the full original before using this result as a premise. Null fields mean unknown, not unrestricted.

## Source transcript (historical wording; apply current metadata)

```
RESULT-ID: WEIGHTED-COMPATIBLE-GCD-AVERAGE-20260906B
STATUS: PROVED.
EXACT STATEMENT:
For A,B>=2 and an odd positive integer h, define
 W_h(A,B)=sum_(1<=a<=A,1<=b<=B; gcd(b,2a-1)|h)
                    gcd(b,2a-1)/(a*b).
Then, with an absolute constant C,
 W_h(A,B)<=C*log(2A)*log(2B)*sigma_{-1}(h),
where sigma_{-1}(h)=sum_(e|h)1/e. Consequently, for H>=1,
 sum_(1<=h<=H,h odd) W_h(A,B)
 <=C*zeta(2)*H*log(2A)*log(2B).
Restricting a,b to odd integers >=3 preserves these upper bounds.
Also, for any odd prime r,
 sum_(1<=a<=A; 2a=1 mod r)1/a <=C*log(2A)/r,
and
 sum_(h<=H)sum_(r|h, r prime)1/r <=H*sum_r 1/r^2 <=H*zeta(2).

PROOF:
For d=gcd(b,2a-1), the elementary identity d=sum_(e|d)phi(e) holds.
If d|h, all divisors e of d divide h. Dropping the condition d|h after
expanding gives
 W_h <=sum_(e|h)phi(e)
            [sum_(b<=B,e|b)1/b]
            [sum_(a<=A,2a=1 mod e)1/a].
All e here are odd. The first bracket is <=(1+log B)/e. For e>=3,
the least positive solution of 2a=1 mod e is (e+1)/2. The subsequent
solutions are spaced e apart. Hence its reciprocal sum is at most
2/e+(1/e)*log(2A), by comparison with the integral of 1/(e*t+(e+1)/2).
For e=1 the ordinary harmonic bound gives the same assertion with an
absolute constant. Thus the second bracket is <=C*log(2A)/e.
Since phi(e)<=e, this proves the first bound. Finally
 sum_(h<=H)sigma_{-1}(h)
 =sum_(e<=H)(1/e)*floor(H/e)<=H*sum_(e>=1)1/e^2=H*zeta(2).
The prime-r variants follow from the same progression estimate and
by summing floor(H/r)/r. All quantities are nonnegative, so the
additional parity and lower-end restrictions can be dropped safely.

HOSTILE CHECK:
The hypothesis gcd(b,2a-1)|h is essential to the stated per-h estimate;
there is no claimed uniform O(log A log B) bound for the unrestricted
gcd sum. The proof does not replace a moving divisor by a fixed one.
It sums every compatible divisor and retains its exact multiplicative
weight before averaging h. No prime distribution or Goldbach premise
is used in this lemma.
DEPENDENCIES: gcd=sum phi, elementary harmonic estimates.
IMPLICATION: Compensates for the d-fold increase in progression length
when b*r=(2a-1)*q+2h has gcd(b,2a-1)=d>1. This is a real consumer
of the compatibility relation d|h, not a collision-to-new-support claim.
RELATION TO GOLDBACH: Counting tool only, not a positivity theorem.
RELATION TO p0: Makes deeper same-N nearby-root comparisons possible.
WHAT REMAINS OPEN: Verify every accompanying prime-form and exceptional
progression case in that comparison. NOVELTY: NOT YET AUDITED.
```
