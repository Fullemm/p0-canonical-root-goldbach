---
id: BIBLIA-L00652-AKTYWNY-GRAF-FAKTORYZACYJNY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 652
line_end: 666
env: definition
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Aktywny graf faktoryzacyjny

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:652-666`
- Original label: ``
- Section: Model grafowy i pełny BFS > Aktywne liczby pierwsze i orientacja
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Aktywny graf faktoryzacyjny] Dla ustalonego parzystego (N) aktywną liczbą pierwszą nazywamy pierwszą (p N). W orientacji algorytmicznej piszemy [ p q q (N-p), q N. ] Etykietą krawędzi jest nieparzysty iloraz

## Exact source transcript

```tex
\begin{definition}[Aktywny graf faktoryzacyjny]
Dla ustalonego parzystego \(N\) aktywną liczbą pierwszą nazywamy pierwszą
\(p\nmid N\). W orientacji algorytmicznej piszemy
\[
  p\longrightarrow q
  \quad\Longleftrightarrow\quad
  q\mid (N-p),\qquad q\nmid N.
\]
Etykietą krawędzi jest nieparzysty iloraz
\[
  k(p,q)=\frac{N-p}{q}.
\]
Wierzchołek \(p\) jest \emph{dobry}, jeżeli \(N-p\) jest pierwsza; wtedy
\(N=p+(N-p)\) jest reprezentacją Goldbacha.
\end{definition}
```
