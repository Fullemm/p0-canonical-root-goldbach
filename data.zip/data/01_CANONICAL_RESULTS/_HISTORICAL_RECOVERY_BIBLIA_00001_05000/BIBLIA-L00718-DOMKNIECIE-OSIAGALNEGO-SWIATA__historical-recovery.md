---
id: BIBLIA-L00718-DOMKNIECIE-OSIAGALNEGO-SWIATA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 718
line_end: 730
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Domknięcie osiągalnego świata

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:718-730`
- Original label: `lem:reach-closed`
- Section: Model grafowy i pełny BFS > Skończony certyfikat porażki
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Domknięcie osiągalnego świata] Jeżeli BFS z aktywnego startu nie trafia w dobry wierzchołek, to zbiór (R= (p_0)) jest skończony, zły i domknięty na wszystkie aktywne dzieci. Każde osiągalne dziecko (q) jest dodatnim dzielnikiem liczby (N-p<N),

## Exact source transcript

```tex
\begin{lemma}[Domknięcie osiągalnego świata]
\label{lem:reach-closed}
Jeżeli BFS z aktywnego startu nie trafia w dobry wierzchołek, to zbiór
\(R=\Reach(p_0)\) jest skończony, zły i domknięty na wszystkie aktywne
dzieci.
\end{lemma}

\begin{proof}
Każde osiągalne dziecko \(q\) jest dodatnim dzielnikiem liczby \(N-p<N\),
więc \(q<N\). Istnieje zatem tylko skończenie wiele możliwych wierzchołków.
Pełny BFS dodaje każde aktywne dziecko. Brak sukcesu oznacza, że dla żadnego
\(p\in R\) liczba \(N-p\) nie jest pierwsza.
\end{proof}
```
