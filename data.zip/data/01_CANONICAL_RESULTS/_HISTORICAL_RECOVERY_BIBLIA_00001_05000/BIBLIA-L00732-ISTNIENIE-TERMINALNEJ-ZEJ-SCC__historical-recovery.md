---
id: BIBLIA-L00732-ISTNIENIE-TERMINALNEJ-ZEJ-SCC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 732
line_end: 742
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Istnienie terminalnej złej SCC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:732-742`
- Original label: `cor:terminal-scc`
- Section: Model grafowy i pełny BFS > Skończony certyfikat porażki
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Istnienie terminalnej złej SCC] Przy porażce podgraf indukowany przez (R) ma co najmniej jedną terminalną złą silnie spójną składową. Po odwróceniu orientacji odpowiada ona EAC. Kondensacja skończonego grafu skierowanego jest skończonym DAG-iem, a każdy skończony DAG ma ujście. Domknięcie z lem:reach-closed mówi, że

## Exact source transcript

```tex
\begin{corollary}[Istnienie terminalnej złej SCC]
\label{cor:terminal-scc}
Przy porażce podgraf indukowany przez \(R\) ma co najmniej jedną terminalną
złą silnie spójną składową. Po odwróceniu orientacji odpowiada ona EAC.
\end{corollary}

\begin{proof}
Kondensacja skończonego grafu skierowanego jest skończonym DAG-iem, a każdy
skończony DAG ma ujście. Domknięcie z \cref{lem:reach-closed} mówi, że
ujściowa SCC nie ma aktywnej krawędzi na zewnątrz.
\end{proof}
```
