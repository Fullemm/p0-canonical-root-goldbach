---
id: BIBLIA-L00764-PIERWSZY-FRONT-JEST-MAY-I-AKTYWNY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 764
line_end: 783
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Pierwszy front jest mały i aktywny

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:764-783`
- Original label: `lem:q-small-active`
- Section: Geometria minimalnego startu > Normalna postać (x,h,m_0, ,Q)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Pierwszy front jest mały i aktywny] W przypadku porażki (m_0) jest nieparzyste i złożone, a dla (q Q) [ q m_03< N6. ] Ponadto ( (m_0,N)=1), więc każdy (q Q) jest aktywny.

## Exact source transcript

```tex
\begin{lemma}[Pierwszy front jest mały i aktywny]
\label{lem:q-small-active}
W przypadku porażki \(m_0\) jest nieparzyste i złożone, a dla \(q\in Q\)
\[
  q\le \frac{m_0}{3}<\frac{N}{6}.
\]
Ponadto \(\gcd(m_0,N)=1\), więc każdy \(q\in Q\) jest aktywny.
\end{lemma}

\begin{proof}
Dla \(N>4\) liczba \(p_0\) jest nieparzysta, zatem \(m_0=N-p_0\) jest
nieparzyste. Jeżeli \(q\mid m_0\) i \(m_0\) jest złożone, iloraz \(m_0/q\)
jest nieparzystą liczbą co najmniej \(3\), co daje pierwszą nierówność.
Ponieważ \(m_0<N/2\), druga jest ścisła.

Mamy
\(\gcd(m_0,N)=\gcd(N-p_0,N)=\gcd(p_0,N)\). Gdyby pierwsza \(p_0\) dzieliła
\(N\), z \(p_0\ge N/2\) wynikałoby \(N=2p_0\), czyli \(p_0=x\), a to jest
przypadek natychmiastowego sukcesu.
\end{proof}
```
