---
id: BIBLIA-L00785-NAPRAWA-DROBNEJ-NIEROWNOSCI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 785
line_end: 790
env: remark
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Naprawa drobnej nierówności

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:785-790`
- Original label: `lem:gcd-hm`
- Section: Geometria minimalnego startu > Normalna postać (x,h,m_0, ,Q)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Naprawa drobnej nierówności] W części notatek pojawiał się zapis (q<m_0/3). Poprawna nierówność to (q m_0/3); równość zachodzi na przykład dla (N=32), (p_0=17), (m_0=15), (q=5). Wniosek (q<N/6) pozostaje ścisły. [Rozłączność luki i pierwszego frontu]

## Exact source transcript

```tex
\begin{remark}[Naprawa drobnej nierówności]
\CORRECTED\ W części notatek pojawiał się zapis \(q<m_0/3\). Poprawna
nierówność to \(q\le m_0/3\); równość zachodzi na przykład dla
\(N=32\), \(p_0=17\), \(m_0=15\), \(q=5\). Wniosek \(q<N/6\) pozostaje
ścisły.
\end{remark}
```
