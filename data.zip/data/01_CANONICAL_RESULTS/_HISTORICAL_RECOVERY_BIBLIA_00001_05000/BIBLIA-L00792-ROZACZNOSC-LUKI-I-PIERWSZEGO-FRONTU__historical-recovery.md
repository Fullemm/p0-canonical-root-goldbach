---
id: BIBLIA-L00792-ROZACZNOSC-LUKI-I-PIERWSZEGO-FRONTU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 792
line_end: 806
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Rozłączność luki i pierwszego frontu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:792-806`
- Original label: `lem:gcd-hm`
- Section: Geometria minimalnego startu > Normalna postać (x,h,m_0, ,Q)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Rozłączność luki i pierwszego frontu] Zachodzi [ (h,m_0)=1, (h) Q= . ]

## Exact source transcript

```tex
\begin{lemma}[Rozłączność luki i pierwszego frontu]
\label{lem:gcd-hm}
Zachodzi
\[
  \gcd(h,m_0)=1,
  \qquad
  \PF(h)\cap Q=\varnothing.
\]
\end{lemma}

\begin{proof}
Jeżeli \(d\mid h\) i \(d\mid m_0=x-h\), to \(d\mid x\), a zatem
\(d\mid x+h=p_0\). Ponieważ \(0<d\le h<p_0\) i \(p_0\) jest pierwsza,
\(d=1\). Drugie zdanie jest równoważnym zapisem pierwszego.
\end{proof}
```
