---
id: BIBLIA-L00808-NORMALNA-POSTAC-MODULO-POTEG-PIERWSZYCH
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 808
line_end: 821
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Normalna postać modulo potęg pierwszych

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:808-821`
- Original label: `lem:p0-normal`
- Section: Geometria minimalnego startu > Normalna postać (x,h,m_0, ,Q)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Normalna postać modulo potęg pierwszych] Jeżeli (q^e m_0), to [ x h q^e, p_0 2h= q^e. ]

## Exact source transcript

```tex
\begin{lemma}[Normalna postać modulo potęg pierwszych]
\label{lem:p0-normal}
Jeżeli \(q^e\Vert m_0\), to
\[
  x\equiv h\pmod{q^e},
  \qquad
  p_0\equiv 2h=\delta\pmod{q^e}.
\]
\end{lemma}

\begin{proof}
Pierwsza kongruencja wynika z \(m_0=x-h\). Po dodaniu \(h\) otrzymujemy
\(p_0=x+h\equiv2h\pmod{q^e}\).
\end{proof}
```
