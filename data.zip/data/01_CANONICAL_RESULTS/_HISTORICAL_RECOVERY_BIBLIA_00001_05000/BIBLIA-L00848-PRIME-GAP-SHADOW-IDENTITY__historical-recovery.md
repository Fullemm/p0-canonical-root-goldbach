---
id: BIBLIA-L00848-PRIME-GAP-SHADOW-IDENTITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 848
line_end: 862
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Prime-Gap Shadow Identity

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:848-862`
- Original label: `thm:shadow`
- Section: Geometria shadow i retencja pierwszego frontu > Shadow Identity
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Prime-Gap Shadow Identity] Dla (r Q) i dowolnej liczby pierwszej (p) [ r (N-p) r ( -p). ] Jeżeli (r^e m_0), ta sama równoważność zachodzi modulo (r^e).

## Exact source transcript

```tex
\begin{theorem}[Prime-Gap Shadow Identity]
\label{thm:shadow}
Dla \(r\in Q\) i dowolnej liczby pierwszej \(p\)
\[
  r\mid(N-p)
  \quad\Longleftrightarrow\quad
  r\mid(\delta-p).
\]
Jeżeli \(r^e\mid m_0\), ta sama równoważność zachodzi modulo \(r^e\).
\end{theorem}

\begin{proof}
Z \(N-p=2m_0+\delta-p\) wynika
\(N-p\equiv\delta-p\pmod{r^e}\) dla każdej potęgi \(r^e\mid m_0\).
\end{proof}
```
