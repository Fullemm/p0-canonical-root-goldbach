---
id: BIBLIA-L00870-THM-RETENTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 870
line_end: 875
env: definition
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# thm:retention

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:870-875`
- Original label: `thm:retention`
- Section: Geometria shadow i retencja pierwszego frontu > Retention--Escape
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

Dla (q Q) definiujemy współczynnik retencji [ d_q= (m_0, -q ). ] [Retention--Escape Lemma]

## Exact source transcript

```tex
\begin{definition}
Dla \(q\in Q\) definiujemy współczynnik retencji
\[
  d_q=\gcd\bigl(m_0,\abs{\delta-q}\bigr).
\]
\end{definition}
```
