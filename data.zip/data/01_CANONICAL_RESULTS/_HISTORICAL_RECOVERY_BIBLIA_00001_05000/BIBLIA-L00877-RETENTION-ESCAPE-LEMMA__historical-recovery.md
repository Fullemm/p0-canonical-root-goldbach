---
id: BIBLIA-L00877-RETENTION-ESCAPE-LEMMA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 877
line_end: 897
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Retention--Escape Lemma

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:877-897`
- Original label: `thm:retention`
- Section: Geometria shadow i retencja pierwszego frontu > Retention--Escape
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Retention--Escape Lemma] Dla każdego (q Q) [ (N-q) Q= (d_q). ] W szczególności (d_q=1) oznacza, że wszystkie aktywne dzieci wiersza (N-q) są nowe względem (Q).

## Exact source transcript

```tex
\begin{theorem}[Retention--Escape Lemma]
\label{thm:retention}
Dla każdego \(q\in Q\)
\[
  \PF(N-q)\cap Q=\PF(d_q).
\]
W szczególności \(d_q=1\) oznacza, że wszystkie aktywne dzieci wiersza
\(N-q\) są nowe względem \(Q\).
\end{theorem}

\begin{proof}
Dla \(r\in Q\), na mocy \cref{thm:shadow},
\[
 r\mid N-q
 \Longleftrightarrow
 r\mid\delta-q
 \Longleftrightarrow
 r\mid\gcd(m_0,\abs{\delta-q}).
\]
Zebranie wszystkich różnych pierwszych \(r\) daje tezę.
\end{proof}
```
