---
id: BIBLIA-L00899-UCIECZKA-Z-NAJMNIEJSZEGO-CZYNNIKA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 899
line_end: 911
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Ucieczka z najmniejszego czynnika

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:899-911`
- Original label: `cor:min-factor-escape`
- Section: Geometria shadow i retencja pierwszego frontu > Retention--Escape
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Ucieczka z najmniejszego czynnika] Niech (a=P^-(m_0)) będzie najmniejszym dzielnikiem pierwszym (m_0). Jeżeli (a>h), to (d_a=1). Każdy dzielnik pierwszy (d_a) należy do (Q), więc jest co najmniej (a). Tymczasem (a>h) daje (0< 2h-a<a); równość (2h=a) jest

## Exact source transcript

```tex
\begin{corollary}[Ucieczka z najmniejszego czynnika]
\label{cor:min-factor-escape}
Niech \(a=P^-(m_0)\) będzie najmniejszym dzielnikiem pierwszym \(m_0\).
Jeżeli \(a>h\), to \(d_a=1\).
\end{corollary}

\begin{proof}
Każdy dzielnik pierwszy \(d_a\) należy do \(Q\), więc jest co najmniej \(a\).
Tymczasem \(a>h\) daje \(0<\abs{2h-a}<a\); równość \(2h=a\) jest
niemożliwa, bo lewa strona jest parzysta, a \(a\) jest nieparzyste.
Żadna pierwsza co najmniej \(a\) nie może dzielić niezerowej liczby
mniejszej od \(a\).
\end{proof}
```
