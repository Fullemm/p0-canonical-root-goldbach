---
id: BIBLIA-L00927-LOKALIZACJA-CYKLU-Q
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 927
line_end: 947
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Lokalizacja cyklu (Q)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:927-947`
- Original label: `lem:qcycle-below-delta`
- Section: Geometria shadow i retencja pierwszego frontu > Cykle w grafie shadow
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Lokalizacja cyklu (Q)] Każdy skierowany cykl w (Q) leży w przedziale ((0, )). Jeżeli cykl prosty ma długość co najmniej (3), to każdy jego wierzchołek jest mniejszy niż ( /3=2h/3). Niech (q) będzie największym wierzchołkiem cyklu i (p q)

## Exact source transcript

```tex
\begin{lemma}[Lokalizacja cyklu \(Q\)]
\label{lem:qcycle-below-delta}
Każdy skierowany cykl w \(Q\) leży w przedziale \((0,\delta)\).
Jeżeli cykl prosty ma długość co najmniej \(3\), to każdy jego wierzchołek
jest mniejszy niż \(\delta/3=2h/3\).
\end{lemma}

\begin{proof}
Niech \(q\) będzie największym wierzchołkiem cyklu i \(p\rightsquigarrow q\)
jego poprzednikiem. Gdyby \(q\ge\delta\), to
\(\abs{\delta-p}<q\), ponieważ \(p\le q\) i \(p\ne q\). Nie może więc
zachodzić \(q\mid\delta-p\). Stąd \(q<\delta\), a więc wszystkie wierzchołki
są poniżej \(\delta\).

Na krawędzi cyklu piszemy
\(\delta-q_i=\lambda_i q_{i+1}\), gdzie \(\lambda_i\) jest dodatnie i
nieparzyste. Gdyby \(\lambda_i=1\), mielibyśmy
\(\delta-q_{i+1}=q_i\); z \(q_{i+1}\) nie wychodziłaby zatem krawędź
\(Q\) do trzeciej różnej pierwszej. W cyklu prostym długości co najmniej
\(3\) każde \(\lambda_i\ge3\), skąd \(q_{i+1}<\delta/3\).
\end{proof}
```
