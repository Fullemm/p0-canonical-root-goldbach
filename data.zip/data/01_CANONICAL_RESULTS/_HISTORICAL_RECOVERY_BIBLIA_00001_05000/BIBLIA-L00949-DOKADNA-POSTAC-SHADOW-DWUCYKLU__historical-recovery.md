---
id: BIBLIA-L00949-DOKADNA-POSTAC-SHADOW-DWUCYKLU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 949
line_end: 972
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Dokładna postać shadow dwucyklu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:949-972`
- Original label: `lem:shadow-two-cycle`
- Section: Geometria shadow i retencja pierwszego frontu > Cykle w grafie shadow
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Dokładna postać shadow dwucyklu] Dla różnych (q,r Q), które tworzą dwucykl, istnieje parzyste (t 0) takie, że [ =q+r+tqr. ] Jeżeli dwucykl leży w terminalnym (C Q) o ( C>2), to (t 2).

## Exact source transcript

```tex
\begin{lemma}[Dokładna postać shadow dwucyklu]
\label{lem:shadow-two-cycle}
Dla różnych \(q,r\in Q\), które tworzą dwucykl, istnieje parzyste
\(t\ge0\) takie, że
\[
  \delta=q+r+tqr.
\]
Jeżeli dwucykl leży w terminalnym \(C\subseteq Q\) o \(\abs C>2\), to
\(t\ge2\).
\end{lemma}

\begin{proof}
Piszemy \(\delta-q=ar\) i \(\delta-r=bq\), gdzie \(a,b\) są dodatnie
i nieparzyste. Odejmując równania, otrzymujemy
\((b-1)q=(a-1)r\). Pierwszość i różność \(q,r\) dają
\(a=1+tq\), \(b=1+tr\). Ponieważ \(a,b,q,r\) są nieparzyste, \(t\) jest
parzyste.

Jeżeli \(t=0\), to \(\delta-q=r\) i \(\delta-r=q\). Z
\cref{thm:retention} oraz terminalności wynika, że aktywne supporty
wierszy \(N-q,N-r\) to odpowiednio tylko \(\{r\}\) i \(\{q\}\). Para
tworzy więc zamkniętą właściwą SCC, sprzecznie z silną spójnością
większego \(C\). Zatem w większym rdzeniu \(t\ge2\).
\end{proof}
```
