---
id: BIBLIA-L00974-NAPRAWIONA-KOMPRESJA-TERMINALNEGO-Q-CORE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 974
line_end: 988
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Naprawiona kompresja terminalnego (Q)-core

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:974-988`
- Original label: `cor:qcore-compression`
- Section: Geometria shadow i retencja pierwszego frontu > Cykle w grafie shadow
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Naprawiona kompresja terminalnego (Q)-core] Jeżeli terminalna SCC (C Q) ma co najmniej (3) wierzchołki, to [ C (0, /3)=(0,2h/3). ]

## Exact source transcript

```tex
\begin{corollary}[Naprawiona kompresja terminalnego \(Q\)-core]
\label{cor:qcore-compression}
Jeżeli terminalna SCC \(C\subseteq Q\) ma co najmniej \(3\) wierzchołki,
to
\[
  C\subset(0,\delta/3)=(0,2h/3).
\]
\end{corollary}

\begin{proof}
Każdy wierzchołek silnie spójnego grafu leży na prostym cyklu. Cykl
długości co najmniej \(3\) obsługuje \cref{lem:qcycle-below-delta}.
Dwucykl w większym terminalnym rdzeniu ma \(t\ge2\), a wtedy
\(\delta=q+r+tqr>3q\) i analogicznie \(\delta>3r\).
\end{proof}
```
