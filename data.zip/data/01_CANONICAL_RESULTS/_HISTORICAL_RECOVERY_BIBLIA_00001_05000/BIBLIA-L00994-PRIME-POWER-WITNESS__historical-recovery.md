---
id: BIBLIA-L00994-PRIME-POWER-WITNESS
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 994
line_end: 1013
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Prime-Power Witness

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:994-1013`
- Original label: `thm:witness`
- Section: Geometria shadow i retencja pierwszego frontu > Prime-Power Witness
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Prime-Power Witness] Niech (q Q) i załóżmy ( (N-q) Q). Istnieje wtedy (r Q) takie, że [ v_r(m_0)=v_r( -q)=a_r>0. ]

## Exact source transcript

```tex
\begin{theorem}[Prime-Power Witness]
\label{thm:witness}
Niech \(q\in Q\) i załóżmy \(\PF(N-q)\subseteq Q\). Istnieje wtedy
\(r\in Q\) takie, że
\[
  v_r(m_0)=v_r(\delta-q)=a_r>0.
\]
\end{theorem}

\begin{proof}
Oznaczmy \(s=\delta-q\), zatem \(N-q=2m_0+s\). Załóżmy przeciwnie, że dla
każdego \(r\mid N-q\) wartości \(v_r(m_0)\) i \(v_r(s)\) są różne.
Dla nieparzystego \(r\) zachodzi wtedy
\[
  v_r(N-q)=\min\{v_r(m_0),v_r(s)\}\le v_r(s).
\]
Wszystkie czynniki pierwsze \(N-q\) należą z założenia do \(Q\), więc
otrzymalibyśmy \(N-q\mid\abs{s}\). Jest to niemożliwe, bo
\(N-q>\abs{\delta-q}\). Musi zatem wystąpić równość dodatnich valuacji.
\end{proof}
```
