---
id: BIBLIA-L01015-CYKL-MAPY-SWIADKOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1015
line_end: 1031
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Cykl mapy świadków

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1015-1031`
- Original label: `cor:witness-cycle`
- Section: Geometria shadow i retencja pierwszego frontu > Prime-Power Witness
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Cykl mapy świadków] Jeżeli terminalne (C Q), to wybór świadka (w(q) C) dla każdego (q C) zawiera cykl funkcjonalny [ -q_i=k_i q_i+1^a_i+1, k_i 1 nieparzyste, ] a dla każdego wierzchołka tego cyklu (q_i^a_i< ).

## Exact source transcript

```tex
\begin{corollary}[Cykl mapy świadków]
\label{cor:witness-cycle}
Jeżeli terminalne \(C\subseteq Q\), to wybór świadka \(w(q)\in C\) dla
każdego \(q\in C\) zawiera cykl funkcjonalny
\[
  \delta-q_i=k_i q_{i+1}^{a_{i+1}},
  \qquad k_i\ge1\ \text{nieparzyste},
\]
a dla każdego wierzchołka tego cyklu \(q_i^{a_i}<\delta\).
\end{corollary}

\begin{proof}
Terminalność daje \(\PF(N-q)\subseteq C\), więc świadek z
\cref{thm:witness} należy do \(C\). Każda funkcja na zbiorze skończonym ma
cykl. Równość valuacji pozwala wyłączyć dokładną potęgę
\(q_{i+1}^{a_{i+1}}\) z dodatniej liczby \(\delta-q_i<\delta\).
\end{proof}
```
