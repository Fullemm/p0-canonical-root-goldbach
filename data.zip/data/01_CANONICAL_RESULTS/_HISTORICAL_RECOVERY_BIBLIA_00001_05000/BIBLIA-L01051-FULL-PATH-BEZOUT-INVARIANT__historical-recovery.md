---
id: BIBLIA-L01051-FULL-PATH-BEZOUT-INVARIANT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1051
line_end: 1077
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Full Path Bézout Invariant

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1051-1077`
- Original label: `thm:bezout-path`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Pełny inwariant Bézouta
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Full Path Bézout Invariant] Dla każdego (t 0) [ K_t p_t-C_t x=(-1)^t h. PBI ] Ponadto [

## Exact source transcript

```tex
\begin{theorem}[Full Path Bézout Invariant]
\label{thm:bezout-path}
Dla każdego \(t\ge0\)
\[
  K_t p_t-C_t x=(-1)^t h.
  \tag{PBI}
\]
Ponadto
\[
  \gcd(K_t,C_t)=\gcd(K_t,h).
\]
\end{theorem}

\begin{proof}
Dla \(t=0\) lewa strona wynosi \(p_0-x=h\). Jeżeli teza zachodzi dla
\(t\), to z \(p_t=2x-k_t p_{t+1}\) otrzymujemy
\[
  K_tk_t p_{t+1}-(2K_t-C_t)x=(-1)^{t+1}h,
\]
co jest dokładnie krokiem indukcyjnym.

Każdy czynnik \(k_i\) dzieli \(N-p_i\), które jest względnie pierwsze z
\(N\), bo \(p_i\) jest aktywne. Stąd \(\gcd(K_t,x)=1\). Oznaczmy
\(d=\gcd(K_t,C_t)\). Z (PBI) wynika \(d\mid h\), więc
\(d\mid\gcd(K_t,h)\). Odwrotnie, jeżeli \(e\mid K_t,h\), to (PBI) daje
\(e\mid C_tx\), a \(\gcd(e,x)=1\), zatem \(e\mid C_t\).
\end{proof}
```
