---
id: BIBLIA-L01079-NIESKRACALNA-NORMALNA-POSTAC-WINDING
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1079
line_end: 1128
env: theorem
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Nieskracalna normalna postać winding

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1079-1128`
- Original label: `thm:winding-normal-form`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Pełny inwariant Bézouta
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Nieskracalna normalna postać winding] Połóżmy [ W_t= C_t-(-1)^t2. ] Wtedy (W_t ) i dla każdej ścieżki [ K_tp_t=W_tN+(-1)^tp_0,

## Exact source transcript

```tex
\begin{theorem}[Nieskracalna normalna postać winding]
\label{thm:winding-normal-form}
Połóżmy
\[
  W_t=\frac{C_t-(-1)^t}{2}.
\]
Wtedy \(W_t\in\Z\) i dla każdej ścieżki
\[
  K_tp_t=W_tN+(-1)^tp_0,
  \qquad
  \gcd(W_t,K_t)=1.
  \tag{WN}
\]
Ponadto
\[
  W_0=0,\qquad W_{t+1}=K_t-W_t.
\]
Jeżeli pierwsze \(t\) wierszy ścieżki są złe, to dla \(t\ge1\)
\(W_t>0\), liczba \(W_t\) ma tę samą parzystość co \(t\), a
\[
  t\ge2\quad\Longrightarrow\quad K_tp_t>2N.
\]
\end{theorem}

\begin{proof}
Współczynniki \(C_t\) są nieparzyste, ponieważ \(C_0=1\) i
\(C_{t+1}=2K_t-C_t\). Definicja \(W_t\) ma więc sens. Po użyciu
\(p_0=x+h\) i \(N=2x\), równanie (PBI) przyjmuje dokładnie postać (WN).
Rekurencja wynika z
\[
  W_{t+1}
  =\frac{2K_t-C_t+(-1)^t}{2}=K_t-W_t.
\]

Jeżeli \(d\mid W_t,K_t\), to (WN) daje \(d\mid p_0\). Każdy cofaktor
\(k_i=(N-p_i)/p_{i+1}\) jest mniejszy niż \(N/3<p_0\), więc pierwsza
\(p_0\) nie dzieli \(K_t\). Stąd \(d=1\).

Na złej ścieżce wszystkie \(k_i\ge3\). Z \(W_1=1<K_1\) i rekurencji
wynika indukcyjnie \(0<W_t<K_t\). Parzystość zmienia się na każdym
kroku, bo \(K_t\) jest nieparzyste. Zatem dla parzystego \(t\ge2\)
mamy \(W_t\ge2\). Dla nieparzystego \(t\ge3\) równość \(W_t=1\)
dawałaby
\[
  K_tp_t=N-p_0=m_0=k_0p_1,
\]
czyli \(k_1\cdots k_{t-1}p_t=p_1\), co jest niemożliwe, ponieważ lewa
strona jest złożona, a \(p_1\) pierwsza. Zatem \(W_t\ge3\). Podstawienie
tych dolnych granic do (WN), wraz z \(p_0<N\), daje \(K_tp_t>2N\).
\end{proof}
```
