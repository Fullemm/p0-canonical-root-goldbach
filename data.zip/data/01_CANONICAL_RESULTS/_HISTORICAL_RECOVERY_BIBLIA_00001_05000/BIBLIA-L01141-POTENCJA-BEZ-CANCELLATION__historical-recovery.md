---
id: BIBLIA-L01141-POTENCJA-BEZ-CANCELLATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1141
line_end: 1158
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Potencjał bez cancellation

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1141-1158`
- Original label: `cor:cancellation-free-potential`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Pełny inwariant Bézouta
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Potencjał bez cancellation] Dla każdego zredukowanego stanu na ścieżce [ B_tH_t= K_th. ] Jeżeli następna krawędź ma cofaktor (k_t), to niezależnie od wielkości redukcji przez ( (k_t,H_t)), [

## Exact source transcript

```tex
\begin{corollary}[Potencjał bez cancellation]
\label{cor:cancellation-free-potential}
Dla każdego zredukowanego stanu na ścieżce
\[
  \frac{B_t}{H_t}=\frac{K_t}{h}.
\]
Jeżeli następna krawędź ma cofaktor \(k_t\), to niezależnie od wielkości
redukcji przez \(\gcd(k_t,H_t)\),
\[
  \frac{B_{t+1}}{H_{t+1}}
  =k_t\frac{B_t}{H_t}.
\]
\end{corollary}

\begin{proof}
Obie równości wynikają przez skrócenie wspólnego czynnika:
\(B_t=K_t/d_t\), \(H_t=h/d_t\) i \(K_{t+1}=k_tK_t\).
\end{proof}
```
