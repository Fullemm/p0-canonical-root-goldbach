---
id: BIBLIA-L01160-SKONCZONA-LICZBA-STANOW-W-WIERZCHOKU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1160
line_end: 1174
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Skończona liczba stanów w wierzchołku

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1160-1174`
- Original label: `cor:path-state-count`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Pełny inwariant Bézouta
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Skończona liczba stanów w wierzchołku] Dla ustalonego wierzchołka (p), wartości (H h), znaku i warunku (0<B<x), liczba (B) jest wyznaczona jednoznacznie modulo (x). W szczególności w jednym (p) występuje najwyżej (2 (h)) zredukowanych stanów z (B<x).

## Exact source transcript

```tex
\begin{corollary}[Skończona liczba stanów w wierzchołku]
\label{cor:path-state-count}
Dla ustalonego wierzchołka \(p\), wartości \(H\mid h\), znaku i warunku
\(0<B<x\), liczba \(B\) jest wyznaczona jednoznacznie modulo \(x\).
W szczególności w jednym \(p\) występuje najwyżej \(2\tau(h)\)
zredukowanych stanów z \(B<x\).
\end{corollary}

\begin{proof}
Redukcja równania modulo \(x\) daje \(Bp\equiv\pm H\pmod x\).
Ponieważ aktywna pierwsza \(p\) nie dzieli \(N=2x\),
\(\gcd(p,x)=1\). Dla każdego \(H\mid h\) i znaku istnieje więc najwyżej
jedna klasa \(B\pmod x\), a w przedziale \(0<B<x\) najwyżej jeden
reprezentant.
\end{proof}
```
