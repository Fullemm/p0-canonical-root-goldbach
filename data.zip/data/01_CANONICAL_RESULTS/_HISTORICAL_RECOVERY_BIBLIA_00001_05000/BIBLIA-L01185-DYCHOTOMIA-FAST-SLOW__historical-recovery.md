---
id: BIBLIA-L01185-DYCHOTOMIA-FAST-SLOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1185
line_end: 1198
env: lemma
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Dychotomia FAST/SLOW

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1185-1198`
- Original label: `lem:fast-slow`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Przejście FAST/SLOW
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Dychotomia FAST/SLOW] Przejście jest SLOW dokładnie wtedy, gdy (k H); wówczas (B'=B) i (H'=H/k). W przeciwnym razie jest FAST i [ B'B= kg 3. ]

## Exact source transcript

```tex
\begin{lemma}[Dychotomia FAST/SLOW]
\label{lem:fast-slow}
Przejście jest \emph{SLOW} dokładnie wtedy, gdy \(k\mid H\); wówczas
\(B'=B\) i \(H'=H/k\). W przeciwnym razie jest \emph{FAST} i
\[
  \frac{B'}{B}=\frac{k}{g}\ge3.
\]
\end{lemma}

\begin{proof}
Wszystkie ilorazy są nieparzyste. Mamy \(B'=B\) dokładnie wtedy, gdy
\(k/g=1\), czyli \(k\mid H\). W przeciwnym razie nieparzysta liczba
\(k/g>1\) jest co najmniej \(3\).
\end{proof}
```
