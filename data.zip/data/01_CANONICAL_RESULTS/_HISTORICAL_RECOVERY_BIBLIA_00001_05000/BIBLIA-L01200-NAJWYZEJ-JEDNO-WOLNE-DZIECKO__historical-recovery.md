---
id: BIBLIA-L01200-NAJWYZEJ-JEDNO-WOLNE-DZIECKO
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1200
line_end: 1216
env: lemma
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Najwyżej jedno wolne dziecko

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1200-1216`
- Original label: `lem:one-slow-child`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Przejście FAST/SLOW
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Najwyżej jedno wolne dziecko] W złym osiągalnym wierszu mającym co najmniej dwa różne czynniki pierwsze najwyżej jedno dziecko może być SLOW. Iloczyn wszystkich kolejnych cofaktorów SLOW na ścieżce dzieli początkowe (h). Dla różnych dzieci pierwszych (q,r n) cofaktory (n/q,n/r) mają

## Exact source transcript

```tex
\begin{lemma}[Najwyżej jedno wolne dziecko]
\label{lem:one-slow-child}
W złym osiągalnym wierszu mającym co najmniej dwa różne czynniki pierwsze
najwyżej jedno dziecko może być SLOW. Iloczyn wszystkich kolejnych
cofaktorów SLOW na ścieżce dzieli początkowe \(h\).
\end{lemma}

\begin{proof}
Dla różnych dzieci pierwszych \(q,r\mid n\) cofaktory \(n/q,n/r\) mają
najmniejszą wspólną wielokrotność równą \(n\). Gdyby oba dzieliły \(H\),
to \(n\mid H\). Każdy zły osiągalny wierzchołek po starcie jest właściwym
czynnikiem pierwszym nieparzystej liczby złożonej, więc jest mniejszy niż
\(N/3\); stąd \(n=N-p>2N/3>h\ge H\), sprzeczność.

Na kroku SLOW nowe \(H\) powstaje przez podzielenie przez cofaktor \(k\).
Indukcyjnie iloczyn wykorzystanych cofaktorów dzieli początkowe \(h\).
\end{proof}
```
