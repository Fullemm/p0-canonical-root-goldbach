---
id: BIBLIA-L01218-FAST-ALBO-POTEGA-PIERWSZEJ
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1218
line_end: 1230
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# FAST albo potęga pierwszej

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1218-1230`
- Original label: `cor:fast-or-power`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Przejście FAST/SLOW
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[FAST albo potęga pierwszej] Przy hipotetycznej porażce można w każdym wierszu o co najmniej dwóch różnych czynnikach wybrać dziecko FAST. Po (O( x)) takich wyborach albo napotka się wiersz będący potęgą jednej pierwszej, albo otrzyma się (B>x).

## Exact source transcript

```tex
\begin{corollary}[FAST albo potęga pierwszej]
\label{cor:fast-or-power}
Przy hipotetycznej porażce można w każdym wierszu o co najmniej dwóch
różnych czynnikach wybrać dziecko FAST. Po \(O(\log x)\) takich wyborach
albo napotka się wiersz będący potęgą jednej pierwszej, albo otrzyma się
\(B>x\).
\end{corollary}

\begin{proof}
Istnienie wyboru wynika z \cref{lem:one-slow-child}. Każdy krok FAST
mnoży \(B\) co najmniej przez \(3\), więc przed przekroczeniem \(x\) może
ich być najwyżej \(\floor{\log_3 x}+1\).
\end{proof}
```
