---
id: BIBLIA-L01232-FIRST-CROSSING-RECONSTRUCTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1232
line_end: 1246
env: proposition
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# First-Crossing Reconstruction

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1232-1246`
- Original label: `prop:first-crossing`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Przejście FAST/SLOW
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[First-Crossing Reconstruction] Jeżeli po raz pierwszy (B>x), to równanie [ Ax H B, (A,B)=1, ] wyznacza (x) jednoznacznie w przedziale (0<x<B). Równość (B=x) jest niemożliwa.

## Exact source transcript

```tex
\begin{proposition}[First-Crossing Reconstruction]
\label{prop:first-crossing}
Jeżeli po raz pierwszy \(B>x\), to równanie
\[
  Ax\equiv\mp H\pmod B,\qquad \gcd(A,B)=1,
\]
wyznacza \(x\) jednoznacznie w przedziale \(0<x<B\). Równość \(B=x\)
jest niemożliwa.
\end{proposition}

\begin{proof}
Odwracalność \(A\) modulo \(B\) daje jedną klasę \(x\pmod B\), a podany
przedział jednego reprezentanta. Gdyby \(B=x\), równanie zredukowane
dawałoby \(x\mid H\), choć \(0<H\le h<x\).
\end{proof}
```
