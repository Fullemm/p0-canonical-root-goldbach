---
id: BIBLIA-L01264-TRZYKRAWEDZIOWA-KOMPRESJA-P-0
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1264
line_end: 1314
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Trzykrawędziowa kompresja (p_0)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1264-1314`
- Original label: `thm:three-edge-compression`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Kanoniczna ścieżka najmniejszego czynnika
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Trzykrawędziowa kompresja (p_0)] Niech trzy kolejne wiersze na powyższej ścieżce będą złe i niech [ u_N=N- N. ] Jeżeli [ ( m_0u_N^2xh )^3>N^4,

## Exact source transcript

```tex
\begin{theorem}[Trzykrawędziowa kompresja \(p_0\)]
\label{thm:three-edge-compression}
Niech trzy kolejne wiersze na powyższej ścieżce będą złe i niech
\[
  u_N=N-\floor{\sqrt N}.
\]
Jeżeli
\[
  \left(\frac{m_0u_N^2}{xh}\right)^3>N^4,
  \qquad u_N>h,
  \qquad m_0u_N>x^2,
  \tag{LC}
\]
to \(B_3>x\). W szczególności, korzystając z
\(h\ll N^{0.525}\) Baker--Harman--Pintza, warunki (LC) zachodzą dla
wszystkich dostatecznie dużych \(N\) \cite{BHP2001}.
\end{theorem}

\begin{proof}
Załóżmy przeciwnie, że \(B_3<x\). Ponieważ
\(d_3=\gcd(K_3,h)\le h\), mamy \(K_3<xh\). Z definicji cofaktorów
\[
  K_3=
  \frac{m_0}{p_1}\frac{N-p_1}{p_2}\frac{N-p_2}{p_3},
\]
a \(p_i<\sqrt N\). Stąd
\[
  p_1p_2p_3>
  \frac{m_0(N-p_1)(N-p_2)}{xh}
  \ge\frac{m_0u_N^2}{xh}>N^{4/3}.
\]
Iloczyn dowolnych dwóch spośród \(p_1,p_2,p_3\) jest mniejszy niż
\(N\), więc każde \(p_i>N^{1/3}\). Gdyby któryś z trzech
faktoryzowanych wierszy miał co najmniej trzy czynniki pierwsze liczone z
krotnościami, byłby co najmniej \(p_i^3>N\). Każdy wiersz jest zatem
semipierwszy, a \(k_0,k_1,k_2\) są pierwsze.

Mamy \(\gcd(k_0,h)=1\), ponieważ \(k_0\mid m_0\). Dalej
\(k_1k_2\ge u_N>h\). Niezależnie od tego, czy \(k_1=k_2\),
\[
  d_3=\gcd(k_1k_2,h)\le\max(k_1,k_2).
\]
W konsekwencji
\[
  B_3\ge k_0\min(k_1,k_2)
  \ge\sqrt{m_0u_N}>x,
\]
co daje sprzeczność. Wykluczyliśmy \(B_3<x\), a równość \(B_3=x\) jest
niemożliwa na mocy \cref{prop:first-crossing}. Ostatnie zdanie twierdzenia wynika z
\(m_0\sim N/2\), \(u_N\sim N\) i wykładnika \(0.525<2/3\).
\end{proof}
```
