---
id: BIBLIA-L01316-WARUNEK-DOKADNEGO-PRZEKROCZENIA-W-KROKU-TRZECIM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1316
line_end: 1331
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Warunek dokładnego przekroczenia w kroku trzecim

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1316-1331`
- Original label: `cor:third-crossing-cancellation`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Kanoniczna ścieżka najmniejszego czynnika
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Warunek dokładnego przekroczenia w kroku trzecim] Jeżeli na tej ścieżce (B_2<x<B_3), to [ d_2= (k_1,h), A_2= 2k_0-1d_2<p_2. ]

## Exact source transcript

```tex
\begin{corollary}[Warunek dokładnego przekroczenia w kroku trzecim]
\label{cor:third-crossing-cancellation}
Jeżeli na tej ścieżce \(B_2<x<B_3\), to
\[
  d_2=\gcd(k_1,h),
  \qquad
  A_2=\frac{2k_0-1}{d_2}<p_2.
\]
\end{corollary}

\begin{proof}
Pierwszy cofaktor jest względnie pierwszy z \(h\), więc wzór na \(d_2\)
jest natychmiastowy. Z równania
\(B_2p_2-A_2x=H_2>0\) i \(B_2<x\) dostajemy
\(A_2x<B_2p_2<xp_2\).
\end{proof}
```
