---
id: BIBLIA-L01343-STRONG-BRANCHING-LCM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1343
line_end: 1369
env: lemma
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Strong Branching LCM

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1343-1369`
- Original label: `lem:strong-branching`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Strong Branching LCM] Dla wiersza (n=N-p), stanu z parametrem (H) i dwóch różnych dzieci (q_1,q_2 n) połóżmy [ _i= n/q_i (n/q_i,H). ] Wtedy [

## Exact source transcript

```tex
\begin{lemma}[Strong Branching LCM]
\label{lem:strong-branching}
Dla wiersza \(n=N-p\), stanu z parametrem \(H\) i dwóch różnych dzieci
 \(q_1,q_2\mid n\) połóżmy
\[
  \mu_i=\frac{n/q_i}{\gcd(n/q_i,H)}.
\]
Wtedy
\[
  \lcm(\mu_1,\mu_2)=\frac{n}{\gcd(n,H)}
\]
i w szczególności
\[
  \max(\mu_1,\mu_2)\ge
  \sqrt{\frac{n}{\gcd(n,H)}}\ge\sqrt{\frac{n}{h}}.
\]
\end{lemma}

\begin{proof}
Sprawdzamy wykładniki każdej pierwszej \(\ell\). Maksimum wykładników
\(\ell\) w \(n/q_1\) i \(n/q_2\) jest równe \(v_\ell(n)\): obniżenie
wykładnika dotyczy dwóch różnych baz. Po odjęciu części pochłoniętej przez
\(H\) pozostaje
\(\max(v_\ell(n)-v_\ell(H),0)\), czyli dokładnie wykładnik w
\(n/\gcd(n,H)\). Nierówność wynika z
\(\max(u,v)^2\ge uv\ge\lcm(u,v)\) dla dodatnich \(u,v\).
\end{proof}
```
