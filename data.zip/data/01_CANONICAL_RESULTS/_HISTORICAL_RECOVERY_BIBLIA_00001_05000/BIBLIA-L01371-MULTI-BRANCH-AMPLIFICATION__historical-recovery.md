---
id: BIBLIA-L01371-MULTI-BRANCH-AMPLIFICATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1371
line_end: 1402
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Multi-Branch Amplification

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1371-1402`
- Original label: `thm:multi-branch`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Multi-Branch Amplification] Niech różnymi dziećmi wiersza (n=N-p) będą (q_1, ,q_s), gdzie (s= (n)), i połóżmy [ _i= n/q_i (n/q_i,H), _H= n (n,H). ]

## Exact source transcript

```tex
\begin{theorem}[Multi-Branch Amplification]
\label{thm:multi-branch}
Niech różnymi dziećmi wiersza \(n=N-p\) będą
\(q_1,\ldots,q_s\), gdzie \(s=\omega(n)\), i połóżmy
\[
  \mu_i=\frac{n/q_i}{\gcd(n/q_i,H)},
  \qquad
  \rho_H=\frac{n}{\gcd(n,H)}.
\]
Wtedy \(\mu_i\mid\rho_H\), dla \(i\ne j\)
\[
  \lcm(\mu_i,\mu_j)=\rho_H,
\]
oraz
\[
  \prod_{i=1}^{s}\mu_i\ge\rho_H^{s-1},
  \qquad
  \max_i\mu_i\ge\rho_H^{1-1/s}.
\]
\end{theorem}

\begin{proof}
Ustalmy pierwszą \(r\) i oznaczmy
\(e=\max(v_r(n)-v_r(H),0)\). W każdym \(\mu_i\), poza co najwyżej
dzieckiem \(q_i=r\), wykładnik \(r\) jest równy \(e\); w wyjątkowym
dziecku może spaść najwyżej o jeden. Suma wykładników \(r\) w iloczynie
wszystkich \(\mu_i\) jest więc co najmniej \((s-1)e\). To po
przemnożeniu po \(r\) daje nierówność produktową. Ta sama obserwacja dla
dowolnej pary różnych dzieci daje dokładną równość NWW, a dzielność
\(\mu_i\mid\rho_H\) jest bezpośrednia. Ostatnia nierówność wynika z
porównania maksimum ze średnią geometryczną.
\end{proof}
```
