---
id: BIBLIA-L01404-ILE-BOGATYCH-WIERSZY-MIESCI-SIE-PRZED-CROSSINGIEM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1404
line_end: 1420
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Ile bogatych wierszy mieści się przed crossingiem

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1404-1420`
- Original label: `cor:four-rich-rows`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Ile bogatych wierszy mieści się przed crossingiem] Po pierwszej krawędzi ścieżki każdy zły wiersz spełnia (n>2N/3). Przy (h N^0.525), cztery wybory maksymalizujące ( _i) w wierszach z ( (n) 3) wymuszają (B>x) dla dostatecznie dużego (N). Zatem przed pierwszym crossingiem taka ścieżka może zawierać najwyżej trzy bogate wiersze.

## Exact source transcript

```tex
\begin{corollary}[Ile bogatych wierszy mieści się przed crossingiem]
\label{cor:four-rich-rows}
Po pierwszej krawędzi ścieżki każdy zły wiersz spełnia \(n>2N/3\).
Przy \(h\ll N^{0.525}\), cztery wybory maksymalizujące \(\mu_i\) w
wierszach z \(\omega(n)\ge3\) wymuszają \(B>x\) dla dostatecznie dużego
\(N\). Zatem przed pierwszym crossingiem taka ścieżka może zawierać
najwyżej trzy bogate wiersze.
\end{corollary}

\begin{proof}
Każdy z czterech wyborów mnoży \(B\) co najmniej przez
\[
  \left(\frac{2N}{3h}\right)^{2/3}.
\]
Ich łączny wkład jest więc co najmniej
\((2N/(3h))^{8/3}\gg N^{(1-0.525)8/3}>N\), a początkowo \(B\ge1\).
\end{proof}
```
