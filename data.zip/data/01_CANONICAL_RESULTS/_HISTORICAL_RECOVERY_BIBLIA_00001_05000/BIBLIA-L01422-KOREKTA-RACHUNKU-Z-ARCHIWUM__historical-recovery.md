---
id: BIBLIA-L01422-KOREKTA-RACHUNKU-Z-ARCHIWUM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1422
line_end: 1426
env: remark
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Korekta rachunku z archiwum

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1422-1426`
- Original label: `thm:vandermonde`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Korekta rachunku z archiwum] Trzy bogate wiersze dają z samego (B 1) wykładnik (3 (1-0.525) 2/3=0.95), więc nie wystarczają do przekroczenia (x). Poprawna liczba w tym sformułowaniu to cztery. [Vandermonde Shared-Mass Bound] Niech (P=p_1, ,p_s) będzie zbiorem różnych parentów i

## Exact source transcript

```tex
\begin{remark}[Korekta rachunku z archiwum]
\CORRECTED\ Trzy bogate wiersze dają z samego \(B\ge1\) wykładnik
\(3\cdot(1-0.525)\cdot2/3=0.95\), więc nie wystarczają do przekroczenia
\(x\). Poprawna liczba w tym sformułowaniu to cztery.
\end{remark}
```
