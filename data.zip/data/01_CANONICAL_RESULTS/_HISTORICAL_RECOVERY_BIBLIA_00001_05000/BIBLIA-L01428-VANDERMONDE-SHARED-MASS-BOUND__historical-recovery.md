---
id: BIBLIA-L01428-VANDERMONDE-SHARED-MASS-BOUND
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1428
line_end: 1453
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Vandermonde Shared-Mass Bound

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1428-1453`
- Original label: `thm:vandermonde`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Vandermonde Shared-Mass Bound] Niech (P=p_1, ,p_s) będzie zbiorem różnych parentów i (n_i=N-p_i). Dla każdej pierwszej (r) uporządkujmy valuacje malejąco: [ e_1,r e_2,r e_s,r, e_i,r=v_r(n_ _r(i)). ] Wtedy

## Exact source transcript

```tex
\begin{theorem}[Vandermonde Shared-Mass Bound]
\label{thm:vandermonde}
Niech \(P=\{p_1,\ldots,p_s\}\) będzie zbiorem różnych parentów i
\(n_i=N-p_i\). Dla każdej pierwszej \(r\) uporządkujmy valuacje malejąco:
\[
 e_{1,r}\ge e_{2,r}\ge\cdots\ge e_{s,r},
 \qquad e_{i,r}=v_r(n_{\pi_r(i)}).
\]
Wtedy
\[
 \prod_r r^{\sum_{j=2}^{s}(j-1)e_{j,r}}
 =\prod_{i<j}\gcd(n_i,n_j)
 \mid\prod_{i<j}\abs{p_i-p_j}.
\]
\end{theorem}

\begin{proof}
Dla ustalonego \(r\), w parze uporządkowanych malejąco valuacji minimum
jest valuacją o większym indeksie. Wartość \(e_{j,r}\) pojawia się jako
minimum w dokładnie \(j-1\) parach, co daje pierwszą równość po
przemnożeniu po \(r\). Ponadto
\[
  \gcd(n_i,n_j)\mid n_i-n_j=p_j-p_i.
\]
Mnożenie po parach kończy dowód.
\end{proof}
```
