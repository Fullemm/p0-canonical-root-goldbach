---
id: BIBLIA-L01455-EXCLUSIVE-MAX-MATCHING
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1455
line_end: 1482
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Exclusive-Max Matching

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1455-1482`
- Original label: `thm:exclusive-matching`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Strong Branching i wspólna masa
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Exclusive-Max Matching] Niech (P=p_1, ,p_s) ma średnicę ( = P- P>0). Niech [ L_i= (n_j:j i), d_i= (n_i,L_i), u_i= n_id_i. ]

## Exact source transcript

```tex
\begin{theorem}[Exclusive-Max Matching]
\label{thm:exclusive-matching}
Niech \(P=\{p_1,\ldots,p_s\}\) ma średnicę
\(\Delta=\max P-\min P>0\). Niech
\[
  L_i=\lcm(n_j:j\ne i),\qquad
  d_i=\gcd(n_i,L_i),\qquad
  u_i=\frac{n_i}{d_i}.
\]
Jeżeli
\[
  N-\max P>\Delta^{s-1},
\]
to każde \(u_i>1\). Każdy wiersz ma zatem bazę pierwszą, na której osiąga
ścisłe maksimum valuacji, a bazy wybrane dla różnych wierszy są różne.
\end{theorem}

\begin{proof}
Liczba \(d_i\) dzieli iloczyn
\(\prod_{j\ne i}\gcd(n_i,n_j)\), a każdy jego czynnik dzieli
\(\abs{p_i-p_j}\le\Delta\). Stąd \(d_i\le\Delta^{s-1}\). Z założenia
\(n_i\ge N-\max P>d_i\), więc \(u_i>1\).

Pierwsza \(r\) dzieli \(u_i\) dokładnie wtedy, gdy \(v_r(n_i)\) jest
większe niż maksimum valuacji w pozostałych wierszach. Jedna baza nie może
mieć ścisłego maksimum w dwóch różnych wierszach, więc supporty \(u_i\)
są parami rozłączne.
\end{proof}
```
