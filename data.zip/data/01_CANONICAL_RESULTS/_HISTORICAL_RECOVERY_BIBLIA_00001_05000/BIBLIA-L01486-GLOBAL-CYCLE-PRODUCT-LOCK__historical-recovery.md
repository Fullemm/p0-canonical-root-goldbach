---
id: BIBLIA-L01486-GLOBAL-CYCLE-PRODUCT-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1486
line_end: 1511
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Global Cycle Product Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1486-1511`
- Original label: `thm:global-cycle-lock`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Global Cycle Product Lock] Niech [ p_0 p_1 p_r-1 p_0 ] będzie złym cyklem, a (K= _i=0^r-1k_i) iloczynem etykiet. Wtedy [

## Exact source transcript

```tex
\begin{theorem}[Global Cycle Product Lock]
\label{thm:global-cycle-lock}
Niech
\[
 p_0\to p_1\to\cdots\to p_{r-1}\to p_0
\]
będzie złym cyklem, a \(K=\prod_{i=0}^{r-1}k_i\) iloczynem etykiet.
Wtedy
\[
  K\equiv(-1)^r\pmod N.
\]
Ponieważ \(K>1\), mamy \(K\ge N-1\), a dla parzystego \(r\):
\(K\ge N+1\).
\end{theorem}

\begin{proof}
Iterowanie relacji \(p_i=N-k_ip_{i+1}\) daje
\[
  p_0=WN+(-1)^rKp_0
\]
dla pewnego \(W\in\Z\). Ponieważ \(\gcd(p_0,N)=1\), liczba
\(1-(-1)^rK\) jest podzielna przez \(N\). W złym cyklu każdy wiersz jest
złożony, więc etykiety są nieparzyste i większe od \(1\); w szczególności
\(K>1\). Najmniejsze dodatnie reprezentanty odpowiednich klas dają
oszacowania.
\end{proof}
```
