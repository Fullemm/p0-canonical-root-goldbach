---
id: BIBLIA-L01513-GLOBALNA-KONCENTRACJA-CYKLU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1513
line_end: 1531
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Globalna koncentracja cyklu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1513-1531`
- Original label: `cor:global-cycle-concentration`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Globalna koncentracja cyklu] Dla złego cyklu długości (r) [ _i p_i N1+(N-1)^1/r. ]

## Exact source transcript

```tex
\begin{corollary}[Globalna koncentracja cyklu]
\label{cor:global-cycle-concentration}
Dla złego cyklu długości \(r\)
\[
  \min_i p_i\le
  \frac{N}{1+(N-1)^{1/r}}.
\]
\end{corollary}

\begin{proof}
Iloczyn teleskopowy po mianownikach daje
\[
  K=\prod_{i=0}^{r-1}\frac{N-p_i}{p_{i+1}}
   =\prod_{i=0}^{r-1}\frac{N-p_i}{p_i}.
\]
Gdyby wszystkie \(p_i\) przekraczały prawą stronę tezy, każdy czynnik
byłby mniejszy od \((N-1)^{1/r}\), a \(K<N-1\), sprzecznie z
\cref{thm:global-cycle-lock}.
\end{proof}
```
