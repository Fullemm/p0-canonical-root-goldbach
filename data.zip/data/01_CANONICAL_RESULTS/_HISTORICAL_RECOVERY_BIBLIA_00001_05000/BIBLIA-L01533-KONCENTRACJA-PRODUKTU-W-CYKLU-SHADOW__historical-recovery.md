---
id: BIBLIA-L01533-KONCENTRACJA-PRODUKTU-W-CYKLU-SHADOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1533
line_end: 1555
env: theorem
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Koncentracja produktu w cyklu shadow

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1533-1555`
- Original label: `thm:shadow-cycle-product`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Koncentracja produktu w cyklu shadow] Niech prosty cykl (Q) długości (t 3) spełnia ( -q_i= _iq_i+1). Wtedy [ T:= _i _i = _i -q_iq_i (-1)^t . ]

## Exact source transcript

```tex
\begin{theorem}[Koncentracja produktu w cyklu shadow]
\label{thm:shadow-cycle-product}
Niech prosty cykl \(Q\) długości \(t\ge3\) spełnia
\(\delta-q_i=\lambda_iq_{i+1}\). Wtedy
\[
  T:=\prod_i\lambda_i
   =\prod_i\frac{\delta-q_i}{q_i}
   \equiv(-1)^t\pmod\delta.
\]
Ponieważ \(T>1\), mamy \(T\ge\delta-1\), a dla parzystego \(t\):
\(T\ge\delta+1\). W konsekwencji
\[
  \min_iq_i\le
  \frac{\delta}{1+(\delta-1)^{1/t}}.
\]
\end{theorem}

\begin{proof}
Iteracja \(q_i=\delta-\lambda_iq_{i+1}\) wokół cyklu jest identyczna jak
w dowodzie \cref{thm:global-cycle-lock}, z \(\delta\) w miejsce \(N\).
Teleskopowanie iloczynu i argument progowy są identyczne jak w
\cref{cor:global-cycle-concentration}.
\end{proof}
```
