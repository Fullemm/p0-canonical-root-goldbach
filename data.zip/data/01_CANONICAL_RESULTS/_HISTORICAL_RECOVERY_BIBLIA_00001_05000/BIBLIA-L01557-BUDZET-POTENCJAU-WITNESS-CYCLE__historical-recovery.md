---
id: BIBLIA-L01557-BUDZET-POTENCJAU-WITNESS-CYCLE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1557
line_end: 1588
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Budżet potencjału witness-cycle

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1557-1588`
- Original label: `cor:witness-potential`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Budżet potencjału witness-cycle] Jeżeli witness-cycle długości (t 3) ma postać [ q_i+k_iq_i+1^a_i+1= , ] to dla [ T= ( _i k_i ) _iq_i^a_i-1

## Exact source transcript

```tex
\begin{corollary}[Budżet potencjału witness-cycle]
\label{cor:witness-potential}
Jeżeli witness-cycle długości \(t\ge3\) ma postać
\[
 q_i+k_iq_{i+1}^{a_{i+1}}=\delta,
\]
to dla
\[
 T=\left(\prod_i k_i\right)\prod_iq_i^{a_i-1}
   =\prod_i\frac{\delta-q_i}{q_i}
\]
zachodzi
\[
 T\equiv(-1)^t\pmod\delta,
 \qquad T\ge\delta-1.
\]
Po zdefiniowaniu
\[
 \Phi_\delta(q)=\log\frac{\delta-q}{q}
\]
otrzymujemy dokładny budżet
\[
 \sum_i\Phi_\delta(q_i)=\log T\ge\log(\delta-1).
\]
\end{corollary}

\begin{proof}
W \cref{thm:shadow-cycle-product} wystarczy położyć
\(\lambda_i=k_iq_{i+1}^{a_{i+1}-1}\). Równość produktów wynika z
przemnożenia wszystkich równań witness-cycle, a ostatnia nierówność z
zastosowania logarytmu do dodatnich stron.
\end{proof}
```
