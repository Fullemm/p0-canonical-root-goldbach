---
id: BIBLIA-L01590-REMARK-AT-LINE-1590
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1590
line_end: 1599
env: remark
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# remark at line 1590

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1590-1599`
- Original label: ``
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

Jeżeli permutacja z gałęzi (B) thm:core-mass rozpada się na (r) cykli długości co najmniej (3), to po zsumowaniu po cyklach [ _q C _ (q) r ( -1). ] Jest to dowiedziony budżet wejściowy do dalszego ataku, ale jeszcze nie sprzeczność z faktoryzacją (m_0). Dwucykle wymagają osobnego użycia lem:shadow-two-cycle.

## Exact source transcript

```tex
\begin{remark}
Jeżeli permutacja z gałęzi (B) \cref{thm:core-mass} rozpada się na \(r\)
cykli długości co najmniej \(3\), to po zsumowaniu po cyklach
\[
 \sum_{q\in C}\Phi_\delta(q)\ge r\log(\delta-1).
\]
Jest to dowiedziony budżet wejściowy do dalszego ataku, ale jeszcze nie
sprzeczność z faktoryzacją \(m_0\). Dwucykle wymagają osobnego użycia
\cref{lem:shadow-two-cycle}.
\end{remark}
```
