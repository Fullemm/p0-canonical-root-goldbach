---
id: BIBLIA-L01601-DOKADNY-DWUCYKL-PENEGO-GFG
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1601
line_end: 1624
env: theorem
visibility_class: PRESENT_OR_SUPERSEDED_CURRENTLY
recovery_priority: LOW
---

# Dokładny dwucykl pełnego GFG

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1601-1624`
- Original label: `thm:gfg-two-cycle`
- Section: Rachunek ścieżek, rozgałęzień i cykli > Produkty cykli
- Visibility classification from Audit 1/10: **PRESENT_OR_SUPERSEDED_CURRENTLY**
- Recovery priority: **LOW**

## Extracted historical synopsis

[Dokładny dwucykl pełnego GFG] Dla różnych aktywnych pierwszych (p,q) tworzących zły dwucykl istnieje dodatnia parzysta liczba (t) taka, że [ N=p+q+tpq, ] [ N-p=q(1+tp), N-q=p(1+tq),

## Exact source transcript

```tex
\begin{theorem}[Dokładny dwucykl pełnego GFG]
\label{thm:gfg-two-cycle}
Dla różnych aktywnych pierwszych \(p,q\) tworzących zły dwucykl istnieje
dodatnia parzysta liczba \(t\) taka, że
\[
  N=p+q+tpq,
\]
\[
  N-p=q(1+tp),\qquad N-q=p(1+tq),
\]
oraz
\[
  (1+tp)(1+tq)=1+tN.
\]
\end{theorem}

\begin{proof}
Niech \(N-p=kq\) i \(N-q=\ell p\). Odjęcie daje
\((\ell-1)p=(k-1)q\). Pierwszość i różność \(p,q\) wymuszają
\(k=1+tp\), \(\ell=1+tq\). Parzystość \(N\) i nieparzystość \(p,q\)
dają parzyste \(t\). W złym dwucyklu \(t\ne0\), bo przy \(t=0\)
\(N-p=q\) byłaby pierwsza. Ostatnia tożsamość otrzymujemy przez
bezpośrednie wymnożenie.
\end{proof}
```
