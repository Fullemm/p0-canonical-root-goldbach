---
id: BIBLIA-L01645-CANCELLATION-EXPOSURE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1645
line_end: 1663
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Cancellation Exposure

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1645-1663`
- Original label: `lem:cancellation-exposure`
- Section: Alfabet luki i teoria dwóch alfabetów > Cancellation ujawnia gałąź BFS
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Cancellation Exposure] Niech przejście (p q) ma cofaktor (k=(N-p)/q), a stan przed przejściem parametr (H). Jeżeli [ g= (k,H)>1, ] to każda pierwsza (r g) jest aktywnym dzieckiem wiersza (p) i należy do (R_h). Dziecko (r) jest alternatywne względem (q), chyba

## Exact source transcript

```tex
\begin{lemma}[Cancellation Exposure]
\label{lem:cancellation-exposure}
Niech przejście \(p\to q\) ma cofaktor \(k=(N-p)/q\), a stan przed
przejściem parametr \(H\). Jeżeli
\[
  g=\gcd(k,H)>1,
\]
to każda pierwsza \(r\mid g\) jest aktywnym dzieckiem wiersza \(p\) i
należy do \(R_h\). Dziecko \(r\) jest alternatywne względem \(q\), chyba
że \(r=q\) wskutek wielokrotności \(q^2\mid N-p\).
\end{lemma}

\begin{proof}
Mamy \(r\mid k\mid N-p\) oraz \(r\mid H\mid h\). Cofaktor jest
nieparzysty, więc \(r\ne2\). Gdyby \(r\mid N\), to z \(r\mid N-p\)
wynikałoby \(r\mid p\), a pierwszość wymuszałaby \(r=p\) i
\(p\mid N\), wbrew aktywności \(p\). Zatem \(r\) jest aktywnym
dzieckiem i należy do \(R_h\).
\end{proof}
```
