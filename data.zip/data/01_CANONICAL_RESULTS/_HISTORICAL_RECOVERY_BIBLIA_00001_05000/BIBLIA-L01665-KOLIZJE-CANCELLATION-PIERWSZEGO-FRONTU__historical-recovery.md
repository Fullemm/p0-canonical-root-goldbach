---
id: BIBLIA-L01665-KOLIZJE-CANCELLATION-PIERWSZEGO-FRONTU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1665
line_end: 1719
env: theorem
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Kolizje cancellation pierwszego frontu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1665-1719`
- Original label: `thm:first-front-cancellation`
- Section: Alfabet luki i teoria dwóch alfabetów > Cancellation ujawnia gałąź BFS
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Kolizje cancellation pierwszego frontu] Dla (q Q) połóżmy [ k_q= m_0q, c_q= (N-q,h) = (2k_q-1,h). ]

## Exact source transcript

```tex
\begin{theorem}[Kolizje cancellation pierwszego frontu]
\label{thm:first-front-cancellation}
Dla \(q\in Q\) połóżmy
\[
  k_q=\frac{m_0}{q},
  \qquad
  c_q=\gcd(N-q,h)
      =\gcd(2k_q-1,h).
\]
Wtedy
\[
  \PF(c_q)\subseteq \PF(N-q)\cap R_h.
\]
Dla różnych \(q,r\in Q\)
\[
  \gcd(c_q,c_r)\mid(q-r),
  \qquad
  c_qc_r\le h\abs{q-r}.
\]
Ogólniej, dla \(Q_0=\{q_1,\ldots,q_s\}\subseteq Q\),
\[
  \prod_{i=1}^{s}c_{q_i}
  \le h\prod_{i<j}\abs{q_i-q_j}.
  \tag{VC}
\]
\end{theorem}

\begin{proof}
Z \(N=2m_0+2h\) i \(m_0=qk_q\) mamy
\[
  N-q=q(2k_q-1)+2h.
\]
Ponieważ \(\gcd(q,h)=1\), daje to wzór na \(c_q\) i inkluzję
supportów.

Jeżeli \(d\mid c_q,c_r\), to modulo \(d\)
\[
  2m_0q^{-1}\equiv1\equiv2m_0r^{-1}.
\]
Liczba \(2m_0\) jest odwracalna modulo \(d\), więc \(q\equiv r\pmod d\).
Stąd pierwsza dzielność. Ponieważ \(c_q,c_r\mid h\),
\[
  c_qc_r=\lcm(c_q,c_r)\gcd(c_q,c_r)\le h\abs{q-r}.
\]

Dla dowolnych dodatnich \(a_1,\ldots,a_s\) zachodzi
\[
  \prod_i a_i\le
  \lcm(a_1,\ldots,a_s)\prod_{i<j}\gcd(a_i,a_j).
\]
Rzeczywiście, po uporządkowaniu wykładników ustalonej pierwszej, maksimum
oraz minima w parach z elementem maksymalnym pokrywają sumę wszystkich
wykładników. Stosujemy tę nierówność do \(a_i=c_{q_i}\), używamy
\(\lcm(c_{q_i})\mid h\) i dzielności parowych.
\end{proof}
```
