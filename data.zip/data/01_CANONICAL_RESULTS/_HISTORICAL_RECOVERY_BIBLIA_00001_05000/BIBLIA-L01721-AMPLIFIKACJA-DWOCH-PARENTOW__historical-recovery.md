---
id: BIBLIA-L01721-AMPLIFIKACJA-DWOCH-PARENTOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1721
line_end: 1742
env: corollary
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Amplifikacja dwóch parentów

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1721-1742`
- Original label: `cor:two-parent-amplification`
- Section: Alfabet luki i teoria dwóch alfabetów > Cancellation ujawnia gałąź BFS
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Amplifikacja dwóch parentów] Dla (q Q) wybierzmy (s=P^-(N-q)) i zapiszmy (N-q= _qs). Wtedy dla ścieżki (p_0 q s) [ B_2(q) m_0q N-qc_q. ] Dla każdych różnych (q,r Q) istnieje (u q,r) takie, że

## Exact source transcript

```tex
\begin{corollary}[Amplifikacja dwóch parentów]
\label{cor:two-parent-amplification}
Dla \(q\in Q\) wybierzmy \(s=P^-(N-q)\) i zapiszmy
\(N-q=\lambda_qs\). Wtedy dla ścieżki \(p_0\to q\to s\)
\[
  B_2(q)\ge
  \frac{m_0}{q}\frac{\sqrt{N-q}}{c_q}.
\]
Dla każdych różnych \(q,r\in Q\) istnieje \(u\in\{q,r\}\) takie, że
\[
  B_2(u)\ge
  \frac{m_0}{u}
  \sqrt{\frac{N-u}{h\abs{q-r}}}.
\]
\end{corollary}

\begin{proof}
Na pierwszym kroku \(B_1=m_0/q\) i \(H_1=h\). Ponieważ \(s\) jest
najmniejszym czynnikiem, \(\lambda_q\ge\sqrt{N-q}\), a
\(\gcd(\lambda_q,h)\le c_q\). Druga nierówność wynika z
\(\min(c_q,c_r)\le\sqrt{h\abs{q-r}}\).
\end{proof}
```
