---
id: BIBLIA-L01746-SYGNATURY-ENDPOINTU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1746
line_end: 1767
env: lemma
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Sygnatury endpointu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1746-1767`
- Original label: `lem:endpoint-signatures`
- Section: Alfabet luki i teoria dwóch alfabetów > Sygnatury endpointu i cień krawędzi luki
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Sygnatury endpointu] Niech ścieżka kończy się w (p_t). Wtedy: p_t=q Q & C_t (-1)^t+1 q, p_t=r R_h &

## Exact source transcript

```tex
\begin{lemma}[Sygnatury endpointu]
\label{lem:endpoint-signatures}
Niech ścieżka kończy się w \(p_t\). Wtedy:
\begin{align*}
  p_t=q\in Q
  &\quad\Longrightarrow\quad
  C_t\equiv(-1)^{t+1}\pmod q,\\
  p_t=r\in R_h
  &\quad\Longrightarrow\quad
  C_t\equiv0\pmod r.
\end{align*}
Jeżeli w drugim przypadku \(d_t=\gcd(K_t,h)\) nie jest podzielne przez
\(r\), to w stanie zredukowanym \(r\mid A_t\) i \(r\mid H_t\).
\end{lemma}

\begin{proof}
Dla \(q\mid m_0=x-h\) mamy \(x\equiv h\pmod q\). Redukcja (PBI)
modulo endpoint \(p_t=q\) daje pierwszą kongruencję. Dla \(r\mid h\),
redukcja modulo \(r=p_t\) daje \(C_tx\equiv0\pmod r\). Ponieważ
\(\gcd(x,h)=1\), liczba \(x\) jest odwracalna modulo \(r\). Ostatnie
zdanie wynika po podzieleniu \(C_t,h\) przez \(d_t\).
\end{proof}
```
