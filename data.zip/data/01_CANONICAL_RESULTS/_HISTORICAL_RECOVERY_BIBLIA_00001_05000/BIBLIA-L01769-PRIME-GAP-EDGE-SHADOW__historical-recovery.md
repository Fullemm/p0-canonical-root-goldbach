---
id: BIBLIA-L01769-PRIME-GAP-EDGE-SHADOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1769
line_end: 1794
env: proposition
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Prime-gap edge shadow

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1769-1794`
- Original label: `prop:gap-edge-shadow`
- Section: Alfabet luki i teoria dwóch alfabetów > Sygnatury endpointu i cień krawędzi luki
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Prime-gap edge shadow] Jeżeli (p,r R_h) i (p r), to liczba [ z(p,r)=p_0- p+r2 ] jest całkowita, spełnia [ x z(p,r)<p_0,

## Exact source transcript

```tex
\begin{proposition}[Prime-gap edge shadow]
\label{prop:gap-edge-shadow}
Jeżeli \(p,r\in R_h\) i \(p\to r\), to liczba
\[
  z(p,r)=p_0-\frac{p+r}{2}
\]
jest całkowita, spełnia
\[
  x\le z(p,r)<p_0,
  \qquad r\mid z(p,r),
\]
i jest złożona. Każda krawędź wewnątrz alfabetu luki wskazuje więc
konkretną liczbę złożoną w rzeczywistym przedziale bez pierwszych
\([x,p_0)\).
\end{proposition}

\begin{proof}
Pierwsze \(p,r\) są nieparzyste. Ponieważ obie dzielą \(h\), są nie
większe niż \(h\), więc \(x\le z<p_0\). Ponadto
\[
  2z=(N-p)+(2h-r),
\]
a oba składniki prawej strony są podzielne przez \(r\). Odwracalność
dwójki modulo \(r\) daje \(r\mid z\). W nietrywialnym starcie
\(z\ge x>h\ge r\), więc \(z\) jest złożona.
\end{proof}
```
