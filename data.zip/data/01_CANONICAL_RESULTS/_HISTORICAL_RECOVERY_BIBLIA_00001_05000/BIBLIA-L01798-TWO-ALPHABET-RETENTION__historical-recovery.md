---
id: BIBLIA-L01798-TWO-ALPHABET-RETENTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1798
line_end: 1837
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Two-Alphabet Retention

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1798-1837`
- Original label: `thm:two-alphabet-retention`
- Section: Alfabet luki i teoria dwóch alfabetów > Retencja dwóch alfabetów
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Two-Alphabet Retention] Dla (q Q) połóżmy [ _q= (N-q,m_0)= (m_0, 2h-q), E_q= (N-q,M). ] Wtedy

## Exact source transcript

```tex
\begin{theorem}[Two-Alphabet Retention]
\label{thm:two-alphabet-retention}
Dla \(q\in Q\) połóżmy
\[
  \rho_q=\gcd(N-q,m_0)=\gcd(m_0,\abs{2h-q}),
  \qquad
  E_q=\gcd(N-q,M).
\]
Wtedy
\[
  E_q=\rho_qc_q,
  \qquad
  \PF(E_q)=\PF(N-q)\cap S_h.
\]
Dla różnych \(q,r\in Q\)
\[
  \gcd(E_q,E_r)\mid(q-r),
\]
a dla \(Q_0=\{q_1,\ldots,q_s\}\subseteq Q\)
\[
  \prod_{i=1}^{s}E_{q_i}
  \le m_0h\prod_{i<j}\abs{q_i-q_j}.
  \tag{V2A}
\]
\end{theorem}

\begin{proof}
Ponieważ \(\gcd(m_0,h)=1\), NWD z iloczynem rozdziela się:
\[
  \gcd(N-q,m_0h)=\gcd(N-q,m_0)\gcd(N-q,h).
\]
Pierwszy czynnik jest równy \(\rho_q\), drugi \(c_q\). Liczba
\(N-q\) jest nieparzysta, więc usunięcie \(2\) z \(R_h\) nie zmienia
równości supportów. Dzielność parowa wynika z
\[
  \gcd(E_q,E_r)\mid\gcd(N-q,N-r)\mid(q-r).
\]
Nierówność (V2A) otrzymujemy z ogólnej nierówności użytej w dowodzie
\cref{thm:first-front-cancellation} oraz \(\lcm(E_{q_i})\mid M\).
\end{proof}
```
