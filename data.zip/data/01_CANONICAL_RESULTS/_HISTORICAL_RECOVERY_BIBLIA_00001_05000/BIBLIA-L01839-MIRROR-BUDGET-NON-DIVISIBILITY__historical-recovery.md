---
id: BIBLIA-L01839-MIRROR-BUDGET-NON-DIVISIBILITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1839
line_end: 1874
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Mirror Budget Non-Divisibility

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1839-1874`
- Original label: `lem:mirror-budget`
- Section: Alfabet luki i teoria dwóch alfabetów > Retencja dwóch alfabetów
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Mirror Budget Non-Divisibility] Jeżeli (m_0 h^2), to dla każdego (p S_h) [ N-p m_0h. ]

## Exact source transcript

```tex
\begin{lemma}[Mirror Budget Non-Divisibility]
\label{lem:mirror-budget}
Jeżeli \(m_0\ge h^2\), to dla każdego \(p\in S_h\)
\[
  N-p\nmid m_0h.
\]
\end{lemma}

\begin{proof}
Najpierw niech \(p=q\in Q\) i załóżmy, że
\(t=m_0h/(N-q)\) jest całkowite. Ponieważ \(N-q>m_0\), mamy \(t<h\).
Redukcja równania \(t(N-q)=m_0h\) modulo \(q\), wraz z
\(\gcd(q,2h)=1\), daje \(q\mid t\). Zatem \(q<h\), piszemy
\(t=qu\), \(m_0=qk\), a z \(N-q>2m_0\) mamy
\(u<h/(2q)\). Po podzieleniu równania przez \(q\) i redukcji modulo
\(k\) otrzymujemy
\[
  k\mid u(2h-q).
\]
Jeżeli \(g=\gcd(k,2h-q)\), to \(k/g\mid u\), lecz
\[
  \frac{k}{g}>\frac{k}{2h}
  =\frac{m_0}{2qh}\ge\frac{h}{2q}>u,
\]
sprzeczność.

Teraz niech \(p=r\in R_h\). Gdyby
\(t=m_0h/(N-r)\) było całkowite, to \(t<h/2\). Piszemy
\(h=rj\). Redukcja modulo \(m_0\) daje
\[
  \frac{m_0}{g}\mid t,
  \qquad
  g=\gcd(m_0,2j-1)<\frac{2h}{3}.
\]
Stąd \(m_0/g>3h/2>t\), ponownie sprzeczność.
\end{proof}
```
