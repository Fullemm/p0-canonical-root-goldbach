---
id: BIBLIA-L01876-EKSPANSJA-ALBO-LOKALNY-RDZEN-DWOCH-ALFABETOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1876
line_end: 1918
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Ekspansja albo lokalny rdzeń dwóch alfabetów

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1876-1918`
- Original label: `thm:two-alphabet-local-core`
- Section: Alfabet luki i teoria dwóch alfabetów > Retencja dwóch alfabetów
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Ekspansja albo lokalny rdzeń dwóch alfabetów] Załóżmy (m_0 h^2). Zachodzi co najmniej jedna z alternatyw: istnieją (p S_h) i pierwsza (r N-p) taka, że (r S_h); istnieje cykl mapy świadków (C S_h (0,2h)).

## Exact source transcript

```tex
\begin{theorem}[Ekspansja albo lokalny rdzeń dwóch alfabetów]
\label{thm:two-alphabet-local-core}
Załóżmy \(m_0\ge h^2\). Zachodzi co najmniej jedna z alternatyw:
\begin{enumerate}
  \item istnieją \(p\in S_h\) i pierwsza \(r\mid N-p\) taka, że
  \(r\notin S_h\);
  \item istnieje cykl mapy świadków
  \(C\subset S_h\cap(0,2h)\).
\end{enumerate}
W drugim przypadku, jeżeli krawędź świadków ma target \(s\), to
\[
\begin{aligned}
  s\in Q
  &\quad\Longrightarrow\quad
  v_s(\abs{2h-p})=v_s(m_0),\\
  s\in R_h
  &\quad\Longrightarrow\quad
  v_s(\abs{2m_0-p})=v_s(h).
\end{aligned}
\tag{MW}
\]
\end{theorem}

\begin{proof}
Załóżmy, że pierwsza alternatywa nie zachodzi. Dla \(s\in S_h\) niech
\(e_s=v_s(M)\). Dla każdego \(p\in S_h\) wszystkie czynniki pierwsze
\(N-p\) należą do \(S_h\), ale z \cref{lem:mirror-budget}
\(N-p\nmid M\). Istnieje więc \(s\in S_h\) takie, że
\[
  v_s(N-p)>e_s.
\]
Jeżeli \(s\in Q\), porównanie składników
\(N-p=2m_0+(2h-p)\) wymusza pierwszą równość (MW). Jeżeli
\(s\in R_h\), z \(N-p=2h+(2m_0-p)\) otrzymujemy drugą.

Wybierzmy dla każdego \(p\) jeden taki target \(f(p)=s\). Nie ma punktu
stałego, ponieważ \(p\mid N-p\) implikowałoby \(p\mid N\), wbrew
aktywności. Skończona mapa ma więc cykl. Target w \(R_h\) jest nie
większy niż \(h\). Target \(s\in Q\) dzieli z pełną wykładniczą
składową \(\abs{2h-p}\): dla \(p>2h\) mamy \(s<p\), a po wejściu do
\((0,2h)\) każdy kolejny target pozostaje w tym przedziale. Ścisły spadek
wyklucza wierzchołek większy niż \(2h\) na cyklu.
\end{proof}
```
