---
id: BIBLIA-L01930-CROSS-ALPHABET-BARRIER
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1930
line_end: 1945
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Cross-Alphabet Barrier

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1930-1945`
- Original label: `lem:cross-alphabet-barrier`
- Section: Alfabet luki i teoria dwóch alfabetów > Bariera przejść i mieszane cykle
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Cross-Alphabet Barrier] Jeżeli (r R_h), (q Q) i (r q), to [ q (2h-r), q< 2h3. ]

## Exact source transcript

```tex
\begin{lemma}[Cross-Alphabet Barrier]
\label{lem:cross-alphabet-barrier}
Jeżeli \(r\in R_h\), \(q\in Q\) i \(r\to q\), to
\[
  q\mid(2h-r),
  \qquad
  q<\frac{2h}{3}.
\]
\end{lemma}

\begin{proof}
Redukcja \(q\mid N-r=2m_0+2h-r\) modulo \(q\mid m_0\) daje pierwszą
dzielność. Piszemy \(2h-r=aq\). Współczynnik \(a\) jest dodatni i
nieparzysty. Równość \(a=1\) dawałaby \(r\mid q\), ponieważ \(r\mid h\),
a więc \(r=q\), wbrew rozłączności alfabetów. Zatem \(a\ge3\).
\end{proof}
```
