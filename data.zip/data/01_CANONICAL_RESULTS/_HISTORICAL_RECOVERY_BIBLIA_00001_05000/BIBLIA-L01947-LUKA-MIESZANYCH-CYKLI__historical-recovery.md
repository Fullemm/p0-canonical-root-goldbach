---
id: BIBLIA-L01947-LUKA-MIESZANYCH-CYKLI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1947
line_end: 1971
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Luka mieszanych cykli

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1947-1971`
- Original label: `thm:mixed-cycle-gap`
- Section: Alfabet luki i teoria dwóch alfabetów > Bariera przejść i mieszane cykle
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Luka mieszanych cykli] Niech prosty skierowany cykl w grafie indukowanym przez (S_h) używa obu alfabetów. Każdy jego wierzchołek (q Q) należy wtedy do [ (0, 2h3 ) ( 4h3,2h ). ]

## Exact source transcript

```tex
\begin{theorem}[Luka mieszanych cykli]
\label{thm:mixed-cycle-gap}
Niech prosty skierowany cykl w grafie indukowanym przez \(S_h\) używa
obu alfabetów. Każdy jego wierzchołek \(q\in Q\) należy wtedy do
\[
  \left(0,\frac{2h}{3}\right)
  \cup
  \left(\frac{4h}{3},2h\right).
\]
Wierzchołek z górnego przedziału musi na następnej krawędzi cyklu przejść
do \(R_h\).
\end{theorem}

\begin{proof}
Każdy segment \(Q\) mieszanej orbity zaczyna się krawędzią z \(R_h\),
więc jego pierwszy wierzchołek jest mniejszy niż \(2h/3\) na mocy
\cref{lem:cross-alphabet-barrier}. Dla krawędzi \(q\to s\) wewnątrz
\(Q\), gdy \(q<2h/3\), Shadow Identity daje
\(2h-q=as\) z nieparzystym \(a\). Jeśli \(a\ge3\), to
\(s<2h/3\). Jeśli \(a=1\), to \(s=2h-q>4h/3\). W tym drugim
przypadku jedynym dzieckiem \(s\) pozostającym w \(Q\) jest ponownie
\(q\), bo \(2h-s=q\) jest pierwsza. Powrót zamknąłby dwucykl i
uniemożliwił użycie \(R_h\), więc prosty mieszany cykl musi po \(s\)
wyjść do \(R_h\). Iteracja po segmentach kończy dowód.
\end{proof}
```
