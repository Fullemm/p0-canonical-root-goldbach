---
id: BIBLIA-L01973-MONOCHROMATYCZNE-SCC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1973
line_end: 1987
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Monochromatyczne SCC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1973-1987`
- Original label: `cor:monochromatic-two-alphabet`
- Section: Alfabet luki i teoria dwóch alfabetów > Bariera przejść i mieszane cykle
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Monochromatyczne SCC] Jeżeli [ P^-(m_0) 2h3, ] to żadna SCC grafu indukowanego przez (S_h) nie używa obu alfabetów. Każda taka SCC leży całkowicie w (Q) albo całkowicie w (R_h).

## Exact source transcript

```tex
\begin{corollary}[Monochromatyczne SCC]
\label{cor:monochromatic-two-alphabet}
Jeżeli
\[
  P^-(m_0)\ge\frac{2h}{3},
\]
to żadna SCC grafu indukowanego przez \(S_h\) nie używa obu alfabetów.
Każda taka SCC leży całkowicie w \(Q\) albo całkowicie w \(R_h\).
\end{corollary}

\begin{proof}
Mieszana silnie spójna składowa zawiera prosty cykl przechodzący między
oboma alfabetami. Z \cref{thm:mixed-cycle-gap} cykl ten wymaga
\(q\in Q\) mniejszego niż \(2h/3\), wbrew założeniu.
\end{proof}
```
