---
id: BIBLIA-L01991-RDZEN-WSPARTY-NA-CZYNNIKACH-LUKI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 1991
line_end: 2033
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Rdzeń wsparty na czynnikach luki

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:1991-2033`
- Original label: `prop:gap-alphabet-core`
- Section: Alfabet luki i teoria dwóch alfabetów > Kompresja terminalnego rdzenia (R_h)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Rdzeń wsparty na czynnikach luki] Niech (C R_h) będzie terminalną złą SCC i niech (s= C), (c= C). Wtedy: (s 2), a (c) ma dokładnie jednego wewnętrznego poprzednika; jeśli ( _j) oznacza (j)-tą nieparzystą pierwszą, to [

## Exact source transcript

```tex
\begin{proposition}[Rdzeń wsparty na czynnikach luki]
\label{prop:gap-alphabet-core}
Niech \(C\subseteq R_h\) będzie terminalną złą SCC i niech
\(s=\abs C\), \(c=\max C\). Wtedy:
\begin{enumerate}
  \item \(s\ge2\), a \(c\) ma dokładnie jednego wewnętrznego
  poprzednika;
  \item jeśli \(\ell_j\) oznacza \(j\)-tą nieparzystą pierwszą, to
  \[
    c\le\frac{h}{\ell_1\ell_2\cdots\ell_{s-1}};
  \]
  w szczególności \(c\le h/15\) dla \(s=3\) i
  \(c\le h/105\) dla \(s\ge4\);
  \item dla \(s=2\), po zapisaniu \(C=\{a,c\}\), istnieją
  \(u,v\ge2\) takie, że
  \[
    N-a=c^u,
    \qquad N-c=a^v;
  \]
  \item dla \(s=3\), po zapisaniu \(C=\{a<b<c\}\), co najmniej jeden
  z wierszy \(N-a,N-b\) jest czystą potęgą: jeśli jedynym
  poprzednikiem \(c\) jest \(a\), to \(N-b=a^u\); jeśli jest nim
  \(b\), to \(N-a=b^u\).
\end{enumerate}
\end{proposition}

\begin{proof}
Pętla \(r\to r\) implikowałaby \(r\mid N\), więc singleton jest
niemożliwy. Dla wspólnego dziecka \(c\) różnice nieparzystych parentów
są wielokrotnościami \(2c\), natomiast wszystkie parenty leżą poniżej
\(c\). Silna spójność daje zatem dokładnie jednego poprzednika.

Iloczyn wszystkich różnych pierwszych z \(C\) dzieli \(h\). Iloczyn
pozostałych \(s-1\) wierzchołków jest co najmniej iloczynem pierwszych
\(s-1\) nieparzystych pierwszych, co daje oszacowania.

Dla \(s=2\) silna spójność i brak pętli wymuszają obie krawędzie, a
terminalność nie pozostawia w każdym wierszu innej bazy pierwszej. Dla
\(s=3\), jeśli jedynym poprzednikiem \(c\) jest \(a\), wiersz \(N-b\)
nie ma dziecka \(b\) przez aktywność ani dziecka \(c\) przez
jednoznaczność poprzednika. Terminalność zostawia wyłącznie bazę \(a\).
Drugi przypadek jest symetryczny.
\end{proof}
```
