---
id: BIBLIA-L02062-SYGNATURA-UJSC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2062
line_end: 2072
env: definition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Sygnatura ujść

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2062-2072`
- Original label: ``
- Section: Poprawny globalny certyfikat porażki > Kondensacja i sygnatury ujść
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Sygnatura ujść] Dla (v R) niech [ (v)= C S: z (v) istnieje ścieżka do (C). ] Dla ( A S) definiujemy basen zbiorowy [ B( A)=v R: (v) A.

## Exact source transcript

```tex
\begin{definition}[Sygnatura ujść]
Dla \(v\in R\) niech
\[
  \Sigma(v)=
  \{C\in\mathcal S:\text{ z \(v\) istnieje ścieżka do \(C\)}\}.
\]
Dla \(\mathcal A\subseteq\mathcal S\) definiujemy basen zbiorowy
\[
  B(\mathcal A)=\{v\in R:\Sigma(v)\subseteq\mathcal A\}.
\]
\end{definition}
```
