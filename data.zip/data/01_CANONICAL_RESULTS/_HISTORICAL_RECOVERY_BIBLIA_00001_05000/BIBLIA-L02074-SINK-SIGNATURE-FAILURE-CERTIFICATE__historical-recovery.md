---
id: BIBLIA-L02074-SINK-SIGNATURE-FAILURE-CERTIFICATE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2074
line_end: 2096
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Sink-Signature Failure Certificate

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2074-2096`
- Original label: `thm:sink-signature`
- Section: Poprawny globalny certyfikat porażki > Kondensacja i sygnatury ujść
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Sink-Signature Failure Certificate] Rodzina ( S) jest niepusta. Każde (C S) jest terminalną złą SCC i odpowiada EAC po odwróceniu orientacji. Dla każdego (v R) [ (v)= _q (N-v), q N (q). SS

## Exact source transcript

```tex
\begin{theorem}[Sink-Signature Failure Certificate]
\label{thm:sink-signature}
Rodzina \(\mathcal S\) jest niepusta. Każde \(C\in\mathcal S\) jest
terminalną złą SCC i odpowiada EAC po odwróceniu orientacji. Dla każdego
\(v\in R\)
\[
  \Sigma(v)=
  \bigcup_{q\in\PF(N-v),\ q\nmid N}\Sigma(q).
  \tag{SS}
\]
Jeżeli \(m_0\) jest złożone, to \(Q\subseteq R\) i
\[
  \mathcal S=\Sigma(p_0)=\bigcup_{q\in Q}\Sigma(q).
\]
\end{theorem}

\begin{proof}
Niepustość i terminalność wynikają z \cref{lem:reach-closed,cor:terminal-scc}.
Każda ścieżka z \(v\) do ujścia rozpoczyna się od jednego aktywnego
dziecka \(q\), a każda ścieżka rozpoczynająca się od dziecka jest zarazem
ścieżką z \(v\). To daje (SS). Dzieci \(p_0\) są dokładnie elementami
\(Q\), ponieważ \(\gcd(m_0,N)=1\), co kończy dowód.
\end{proof}
```
