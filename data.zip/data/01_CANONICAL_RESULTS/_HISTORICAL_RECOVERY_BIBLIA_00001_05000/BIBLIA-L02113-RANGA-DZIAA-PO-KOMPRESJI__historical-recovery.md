---
id: BIBLIA-L02113-RANGA-DZIAA-PO-KOMPRESJI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2113
line_end: 2129
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Ranga działa po kompresji

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2113-2129`
- Original label: `prop:dag-rank`
- Section: Poprawny globalny certyfikat porażki > Nietrywialne przejściowe SCC
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Ranga działa po kompresji] Na DAG-u kondensacji zdefiniujmy [ (X)= długość ścieżki z (X) do ujścia. ] Dla każdej krawędzi między różnymi SCC, (X Y), zachodzi ( (X)> (Y)). Nie ma analogicznego ścisłego spadku na każdej krawędzi oryginalnego grafu wewnątrz nietrywialnej SCC.

## Exact source transcript

```tex
\begin{proposition}[Ranga działa po kompresji]
\label{prop:dag-rank}
Na DAG-u kondensacji zdefiniujmy
\[
  \rho(X)=\max\{\text{długość ścieżki z \(X\) do ujścia}\}.
\]
Dla każdej krawędzi między różnymi SCC, \(X\to Y\), zachodzi
\(\rho(X)>\rho(Y)\). Nie ma analogicznego ścisłego spadku na każdej
krawędzi oryginalnego grafu wewnątrz nietrywialnej SCC.
\end{proposition}

\begin{proof}
Każdą najdłuższą ścieżkę z \(Y\) można poprzedzić krawędzią \(X\to Y\),
więc \(\rho(X)\ge1+\rho(Y)\). Na cyklu wewnątrz SCC ścisły spadek
wzdłuż każdej krawędzi prowadziłby po powrocie do nierówności
\(\rho(v)>\rho(v)\).
\end{proof}
```
