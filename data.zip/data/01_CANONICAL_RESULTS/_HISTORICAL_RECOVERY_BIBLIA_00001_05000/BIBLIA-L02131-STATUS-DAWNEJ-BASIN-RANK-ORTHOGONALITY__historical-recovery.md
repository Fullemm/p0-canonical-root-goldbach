---
id: BIBLIA-L02131-STATUS-DAWNEJ-BASIN-RANK-ORTHOGONALITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2131
line_end: 2138
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Status dawnej basin-rank orthogonality

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2131-2138`
- Original label: ``
- Section: Poprawny globalny certyfikat porażki > Nietrywialne przejściowe SCC
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Status dawnej basin-rank orthogonality] Argument rozłącznych alfabetów jest poprawny w przypadku, gdy kondensacja ma jedno ujście i wszystkie przejściowe SCC są jednowierzchołkowe bez pętli. Wtedy każde dziecko ma niższą rangę, a wybieranie elementu o minimalnej randze wymusza, że następny alfabet ma wszystkie rangi poniżej poprzedniego minimum. Nie jest to jednak twierdzenie o dowolnej porażce.

## Exact source transcript

```tex
\begin{remark}[Status dawnej basin-rank orthogonality]
\CONDITIONAL\ Argument rozłącznych alfabetów jest poprawny w przypadku,
gdy kondensacja ma jedno ujście i wszystkie przejściowe SCC są
jednowierzchołkowe bez pętli. Wtedy każde dziecko ma niższą rangę,
a wybieranie elementu o minimalnej randze wymusza, że następny alfabet ma
wszystkie rangi poniżej poprzedniego minimum. Nie jest to jednak twierdzenie
o dowolnej porażce.
\end{remark}
```
