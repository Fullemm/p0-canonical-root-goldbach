---
id: BIBLIA-L02166-MINIMAL-QUOTIENT-MAXIMUM-GEOMETRY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2166
line_end: 2195
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Minimal Quotient / Maximum Geometry

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2166-2195`
- Original label: `thm:min-quotient`
- Section: Geometria dowolnej nietrywialnej SCC > Minimalny iloraz i maksimum składowej
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Minimal Quotient / Maximum Geometry] Niech (c= C). Wtedy (c) ma dokładnie jednego wewnętrznego poprzednika (g), a [ := N-gc= Nc ] jest najmniejszą etykietą wszystkich wewnętrznych krawędzi. Jest to nieparzysta liczba ( 3), a

## Exact source transcript

```tex
\begin{theorem}[Minimal Quotient / Maximum Geometry]
\label{thm:min-quotient}
Niech \(c=\max C\). Wtedy \(c\) ma dokładnie jednego wewnętrznego
poprzednika \(g\), a
\[
  \kappa:=\frac{N-g}{c}=\floor{\frac Nc}
\]
jest najmniejszą etykietą wszystkich wewnętrznych krawędzi. Jest to
nieparzysta liczba \(\kappa\ge3\), a
\[
  \frac{N}{\kappa+1}<c<\frac{N}{\kappa}.
\]
\end{theorem}

\begin{proof}
Silna spójność daje co najmniej jednego poprzednika \(g\to c\).
Gdyby \(g_1,g_2\) były dwoma różnymi poprzednikami, to
\(c\mid g_1-g_2\), podczas gdy
\(0<\abs{g_1-g_2}<c\), bo oba należą do \(C\). Jest to niemożliwe.

Z \(N-g=\kappa c\) i \(0<g<c\) wynika
\(\kappa<N/c<\kappa+1\), a więc wzór na część całkowitą i obie
nierówności dla \(c\). Dla dowolnej krawędzi wewnętrznej \(p\to q\)
z etykietą \(k\) mamy \(q\le c\), \(p<c\), zatem
\[
  k=\frac{N-p}{q}>\frac{N-c}{c}>\kappa-1.
\]
Całkowitość daje \(k\ge\kappa\). Iloraz jest nieparzysty; w złym wierszu
nie może być równy \(1\), więc \(\kappa\ge3\).
\end{proof}
```
