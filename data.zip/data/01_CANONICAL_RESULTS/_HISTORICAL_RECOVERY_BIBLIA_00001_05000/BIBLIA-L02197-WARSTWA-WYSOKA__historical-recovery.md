---
id: BIBLIA-L02197-WARSTWA-WYSOKA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2197
line_end: 2217
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Warstwa wysoka

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2197-2217`
- Original label: `cor:high-layer`
- Section: Geometria dowolnej nietrywialnej SCC > Minimalny iloraz i maksimum składowej
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Warstwa wysoka] Niech [ U= q C:q> N +1 , L=C U. ] Każda krawędź wchodząca do (U) ma etykietę ( ), każdy wierzchołek (U) ma jednego wewnętrznego poprzednika, nie istnieje

## Exact source transcript

```tex
\begin{corollary}[Warstwa wysoka]
\label{cor:high-layer}
Niech
\[
  U=\left\{q\in C:q>\frac{N}{\kappa+1}\right\},
  \qquad L=C\setminus U.
\]
Każda krawędź wchodząca do \(U\) ma etykietę \(\kappa\), każdy
wierzchołek \(U\) ma jednego wewnętrznego poprzednika, nie istnieje
krawędź \(U\to U\), a \(\abs U\le\abs L\).
\end{corollary}

\begin{proof}
Etykieta większa od \(\kappa\) jest, z powodu nieparzystości, co najmniej
\(\kappa+2\), a wtedy cel \(q=(N-p)/k<N/(\kappa+2)\), więc nie należy do
\(U\). Dla etykiety \(\kappa\) poprzednik jest jednoznacznie równy
\(N-\kappa q\). Gdyby \(p,q\in U\) i \(p=N-\kappa q\), nierówność
\(p>N/(\kappa+1)\) dawałaby \(q<N/(\kappa+1)\), sprzeczność.
Każdy element \(U\) ma zatem różnego poprzednika w \(L\), co daje
iniekcję \(U\hookrightarrow L\).
\end{proof}
```
