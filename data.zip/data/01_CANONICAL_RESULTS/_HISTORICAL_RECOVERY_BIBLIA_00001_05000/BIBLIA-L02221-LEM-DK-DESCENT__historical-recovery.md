---
id: BIBLIA-L02221-LEM-DK-DESCENT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2221
line_end: 2226
env: definition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# lem:dk-descent

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2221-2226`
- Original label: `lem:dk-descent`
- Section: Geometria dowolnej nietrywialnej SCC > Ścisły descent (D_ )
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Dla nieparzystego (k 3) definiujemy [ D_k(z)=(k+1)z-N. ] [Strict (D_k) Descent]

## Exact source transcript

```tex
\begin{definition}
Dla nieparzystego \(k\ge3\) definiujemy
\[
  D_k(z)=(k+1)z-N.
\]
\end{definition}
```
