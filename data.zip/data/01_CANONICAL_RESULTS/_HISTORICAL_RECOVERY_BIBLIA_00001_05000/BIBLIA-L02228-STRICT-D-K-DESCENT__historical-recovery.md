---
id: BIBLIA-L02228-STRICT-D-K-DESCENT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2228
line_end: 2259
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Strict (D_k) Descent

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2228-2259`
- Original label: `lem:dk-descent`
- Section: Geometria dowolnej nietrywialnej SCC > Ścisły descent (D_ )
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Strict (D_k) Descent] Na krawędzi (p q) o etykiecie (k) [ D_k(q)=- D_k(p)k. ] Wewnątrz SCC nie istnieje cykl o stałej etykiecie (k). Każdy ciąg kolejnych krawędzi o etykiecie (k), liczący ( ) krawędzi, spełnia [

## Exact source transcript

```tex
\begin{lemma}[Strict \(D_k\) Descent]
\label{lem:dk-descent}
Na krawędzi \(p\to q\) o etykiecie \(k\)
\[
  D_k(q)=-\frac{D_k(p)}{k}.
\]
Wewnątrz SCC nie istnieje cykl o stałej etykiecie \(k\). Każdy ciąg
kolejnych krawędzi o etykiecie \(k\), liczący \(\ell\) krawędzi, spełnia
\[
  \ell<1+\log_k N.
\]
Jeżeli jego pierwszy wierzchołek sam jest celem krawędzi o etykiecie
\(k\), to mocniejsze oszacowanie brzmi \(\ell<\log_k N\).
\end{lemma}

\begin{proof}
Z \(p=N-kq\) otrzymujemy
\[
 D_k(p)=(k+1)(N-kq)-N=-k((k+1)q-N)=-kD_k(q).
\]
Każdy cel krawędzi o etykiecie \(k\) jest mniejszy niż \(N/k\). Dla
takiego celu \(z\) mamy \(0<\abs{D_k(z)}<N\), chyba że \(D_k(z)=0\).
Ostatnia możliwość oznacza \(z=N/(k+1)\), a zatem \(z\mid N\), co
przeczy aktywności. Jeżeli ciąg ma \(\ell\) krawędzi, to po odrzuceniu
pierwszej z nich pozostaje \(\ell-1\) kroków wychodzących z celu
pierwszej krawędzi. Niezerowa całkowita wartość bezwzględna zmniejsza
się więc \(k^{\ell-1}\) razy, skąd \(k^{\ell-1}<N\). Gdy pierwszy
wierzchołek jest już celem krawędzi o etykiecie \(k\), można uwzględnić
wszystkie \(\ell\) kroków i otrzymać \(k^\ell<N\). Cykl o jednej
etykiecie dawałby jednocześnie ścisłe zmniejszenie i powrót do wartości
początkowej.
\end{proof}
```
