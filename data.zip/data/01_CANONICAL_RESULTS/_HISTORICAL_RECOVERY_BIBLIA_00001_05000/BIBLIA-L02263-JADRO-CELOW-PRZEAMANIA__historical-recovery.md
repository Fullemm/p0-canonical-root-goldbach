---
id: BIBLIA-L02263-JADRO-CELOW-PRZEAMANIA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2263
line_end: 2269
env: definition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Jądro celów przełamania

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2263-2269`
- Original label: ``
- Section: Geometria dowolnej nietrywialnej SCC > Break-Target Kernel
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Jądro celów przełamania] Dla ( ) z thm:min-quotient definiujemy [ T_ (C)= q C: istnieje (p q) o etykiecie (k> ). ] [Break-Target Kernel Theorem]

## Exact source transcript

```tex
\begin{definition}[Jądro celów przełamania]
Dla \(\kappa\) z \cref{thm:min-quotient} definiujemy
\[
 T_\kappa(C)=
 \{q\in C:\text{ istnieje \(p\to q\) o etykiecie \(k>\kappa\)}\}.
\]
\end{definition}
```
