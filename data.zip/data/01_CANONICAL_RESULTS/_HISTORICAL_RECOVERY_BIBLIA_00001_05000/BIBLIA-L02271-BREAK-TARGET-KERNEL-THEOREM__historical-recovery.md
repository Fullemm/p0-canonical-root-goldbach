---
id: BIBLIA-L02271-BREAK-TARGET-KERNEL-THEOREM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2271
line_end: 2306
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Break-Target Kernel Theorem

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2271-2306`
- Original label: `thm:break-kernel`
- Section: Geometria dowolnej nietrywialnej SCC > Break-Target Kernel
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Break-Target Kernel Theorem] Dla każdej nietrywialnej SCC (C): (T_ (C) (0,N/( +2))); (T_ (C)) przecina każdy skierowany cykl w (C); każdy (q C T_ (C)) ma dokładnie jednego wewnętrznego poprzednika, po krawędzi o etykiecie ( ); graf indukowany przez (C T_ (C)) jest rozłączną

## Exact source transcript

```tex
\begin{theorem}[Break-Target Kernel Theorem]
\label{thm:break-kernel}
Dla każdej nietrywialnej SCC \(C\):
\begin{enumerate}
  \item \(T_\kappa(C)\subset(0,N/(\kappa+2))\);
  \item \(T_\kappa(C)\) przecina każdy skierowany cykl w \(C\);
  \item każdy \(q\in C\setminus T_\kappa(C)\) ma dokładnie jednego
  wewnętrznego poprzednika, po krawędzi o etykiecie \(\kappa\);
  \item graf indukowany przez \(C\setminus T_\kappa(C)\) jest rozłączną
  sumą skierowanych łańcuchów o etykiecie \(\kappa\);
  \item każdy taki łańcuch ma mniej niż \(\log_\kappa N\) krawędzi.
\end{enumerate}
\end{theorem}

\begin{proof}
Jeżeli \(p\to q\) ma etykietę \(k>\kappa\), to
\(k\ge\kappa+2\) i
\[
  q=\frac{N-p}{k}<\frac{N}{\kappa+2},
\]
co daje punkt 1. Każdy cykl bez celu przełamania składałby się wyłącznie
z krawędzi o minimalnej etykiecie \(\kappa\), wbrew
\cref{lem:dk-descent}; to punkt 2.

Silna spójność daje każdemu \(q\) poprzednika. Dla
\(q\notin T_\kappa(C)\) każda krawędź wchodząca ma etykietę \(\kappa\),
a jej parent jest jednoznacznie równy \(N-\kappa q\). Również z danego
parenta wychodzi najwyżej jedna krawędź o etykiecie \(\kappa\).
Składowe grafu indukowanego mają więc stopnie wejściowe i wyjściowe
co najwyżej \(1\). Nie mogą być cyklami na mocy \cref{lem:dk-descent},
więc są łańcuchami. Pierwszy wierzchołek każdego łańcucha ma swojego
jedynego wewnętrznego poprzednika w \(T_\kappa(C)\), po krawędzi o
etykiecie \(\kappa\). Sam jest zatem celem takiej krawędzi i stosuje się
do niego mocniejsze oszacowanie z ostatniego zdania
\cref{lem:dk-descent}.
\end{proof}
```
