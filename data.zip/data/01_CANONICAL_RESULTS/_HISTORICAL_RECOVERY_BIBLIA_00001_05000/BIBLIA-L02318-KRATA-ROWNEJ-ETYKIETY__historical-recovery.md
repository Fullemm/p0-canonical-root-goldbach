---
id: BIBLIA-L02318-KRATA-ROWNEJ-ETYKIETY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2318
line_end: 2330
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Krata równej etykiety

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2318-2330`
- Original label: `lem:equal-label-lattice`
- Section: Geometria dowolnej nietrywialnej SCC > Dodatkowa geometria stopni i prawie-pierwszych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Krata równej etykiety] Jeżeli (p q) i (p' q') mają tę samą etykietę (k), to [ p-p'=-k(q-q'). ] Dla różnych dzieci odległość parentów jest zatem co najmniej (2k).

## Exact source transcript

```tex
\begin{lemma}[Krata równej etykiety]
\label{lem:equal-label-lattice}
Jeżeli \(p\to q\) i \(p'\to q'\) mają tę samą etykietę \(k\), to
\[
  p-p'=-k(q-q').
\]
Dla różnych dzieci odległość parentów jest zatem co najmniej \(2k\).
\end{lemma}

\begin{proof}
Odejmujemy \(p=N-kq\) i \(p'=N-kq'\). Różne nieparzyste pierwsze
\(q,q'\) różnią się o parzystą liczbę co najmniej \(2\).
\end{proof}
```
