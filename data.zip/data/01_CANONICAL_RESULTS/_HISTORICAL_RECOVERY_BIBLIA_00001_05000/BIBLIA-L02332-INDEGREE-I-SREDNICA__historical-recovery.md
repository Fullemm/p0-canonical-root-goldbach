---
id: BIBLIA-L02332-INDEGREE-I-SREDNICA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2332
line_end: 2356
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Indegree i średnica

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2332-2356`
- Original label: `lem:indegree-diameter`
- Section: Geometria dowolnej nietrywialnej SCC > Dodatkowa geometria stopni i prawie-pierwszych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Indegree i średnica] Jeżeli parenty wspólnego dziecka (v) leżą w przedziale średnicy ( ), to ich liczba jest co najwyżej [ 1+ 2v. ] Jeżeli terminalne (C [a,c]) spełnia (c<3a), to każdy wierzchołek ma indegree (1), (C) jest jednym cyklem supportowym, a

## Exact source transcript

```tex
\begin{lemma}[Indegree i średnica]
\label{lem:indegree-diameter}
Jeżeli parenty wspólnego dziecka \(v\) leżą w przedziale średnicy
\(\Delta\), to ich liczba jest co najwyżej
\[
  1+\floor{\frac{\Delta}{2v}}.
\]
Jeżeli terminalne \(C\subset[a,c]\) spełnia \(c<3a\), to każdy
wierzchołek ma indegree \(1\), \(C\) jest jednym cyklem supportowym, a
każdy wiersz \(N-p\) jest czystą potęgą jednej pierwszej.
\end{lemma}

\begin{proof}
Dla dwóch parentów \(x,y\) wspólnego dziecka mamy
\(v\mid(N-x)-(N-y)=y-x\). Wszystkie parenty leżą więc w jednej klasie
modulo \(v\). Ponieważ różnica dwóch nieparzystych pierwszych jest
parzysta, a \(v\) jest nieparzyste, w istocie \(2v\mid y-x\), co daje
podane oszacowanie. Przy \(c<3a\) średnica
\(\Delta=c-a<2a\le2v\), więc indegree jest najwyżej \(1\), a silna
spójność daje dokładnie \(1\). Suma indegree równa liczbie wierzchołków;
każdy outdegree jest co najmniej \(1\), więc także każdy outdegree wynosi
\(1\), a składowa jest jednym cyklem. Terminalność wyklucza drugi
różny czynnik pierwszej w którymkolwiek wierszu, zatem wiersz jest czystą
potęgą jedynego dziecka.
\end{proof}
```
