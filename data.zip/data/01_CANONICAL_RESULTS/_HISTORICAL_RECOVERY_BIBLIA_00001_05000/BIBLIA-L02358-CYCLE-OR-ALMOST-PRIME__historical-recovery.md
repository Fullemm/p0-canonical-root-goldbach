---
id: BIBLIA-L02358-CYCLE-OR-ALMOST-PRIME
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2358
line_end: 2381
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Cycle-or-Almost-Prime

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2358-2381`
- Original label: `thm:cycle-almost-prime`
- Section: Geometria dowolnej nietrywialnej SCC > Dodatkowa geometria stopni i prawie-pierwszych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Cycle-or-Almost-Prime] Załóżmy dodatkowo, że (C) jest terminalna. Dla (m 2) połóżmy [ C_m=p C:p N^1/m. ] Jeżeli graf indukowany przez (C_m) nie zawiera cyklu, to istnieje (p C_m), dla którego [

## Exact source transcript

```tex
\begin{theorem}[Cycle-or-Almost-Prime]
\label{thm:cycle-almost-prime}
Załóżmy dodatkowo, że \(C\) jest terminalna. Dla \(m\ge2\) połóżmy
\[
  C_m=\{p\in C:p\le N^{1/m}\}.
\]
Jeżeli graf indukowany przez \(C_m\) nie zawiera cyklu, to istnieje
\(p\in C_m\), dla którego
\[
  \Omega(N-p)\le m-1,
\]
gdzie \(\Omega\) liczy czynniki pierwsze z krotnościami. Dla \(m=3\)
otrzymujemy: albo niski cykl, albo wiersz semipierwszy.
\end{theorem}

\begin{proof}
Acykliczny skończony graf indukowany ma ujście \(p\). Gdyby
\(\Omega(N-p)\ge m\), a wszystkie czynniki pierwsze \(N-p\) były większe
od \(N^{1/m}\), ich iloczyn przekraczałby \(N\), choć \(N-p<N\).
Istnieje zatem czynnik \(q\le N^{1/m}\). Terminalność \(C\) daje
\(q\in C_m\) i krawędź \(p\to q\), sprzecznie z wyborem ujścia.
Dla \(m=3\) wiersz jest zły, więc \(\Omega(N-p)\ge2\), a zatem równa się
\(2\).
\end{proof}
```
