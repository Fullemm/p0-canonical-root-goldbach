---
id: BIBLIA-L02392-CORE-MASS-DICHOTOMY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2392
line_end: 2441
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Core Mass Dichotomy

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2392-2441`
- Original label: `thm:core-mass`
- Section: Terminalny (Q)-core: masa i nasycenie > Core Mass Dichotomy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Core Mass Dichotomy] Zachodzi co najmniej jedna z alternatyw: (A) &N- < ^s-1, (B) & istnieje permutacja bez punktów stałych :C C & taka, że -q=k_q, (q)^a_ (q),

## Exact source transcript

```tex
\begin{theorem}[Core Mass Dichotomy]
\label{thm:core-mass}
Zachodzi co najmniej jedna z alternatyw:
\begin{align*}
\textnormal{(A)}\quad &N-\delta<\delta^{s-1},\\
\textnormal{(B)}\quad &\text{istnieje permutacja bez punktów stałych }
\sigma:C\to C\\
&\text{taka, że }\quad
\delta-q=k_q\,\sigma(q)^{a_{\sigma(q)}},
\quad k_q\ge1\text{ nieparzyste}.
\end{align*}
W gałęzi (B)
\[
  \frac1s\sum_{q\in C}q\le h.
\]
\end{theorem}

\begin{proof}
Ponieważ \(q\) jest aktywne, baza \(q\) nie dzieli \(N-q\). Każdy wiersz
\(N-q\) jest zatem iloczynem co najwyżej \(s-1\) składowych
prime-power \(r^{b_{q,r}}\), \(r\in C\setminus\{q\}\).

Jeżeli w pewnym wierszu wszystkie te składowe są mniejsze niż \(\delta\),
to \(N-q<\delta^{s-1}\). Ponieważ \(q<\delta\), mamy
\(N-\delta<N-q\), co daje (A).

Załóżmy, że (A) jest fałszywa. Każdy z \(s\) wierszy musi wtedy zawierać
składową \(r^b\ge\delta\). Ta sama baza \(r\) nie może być tak duża w
dwóch różnych wierszach, bo \(r^b\) dzieliłaby różnicę dwóch wierszy,
czyli różnicę dwóch elementów \(C\), o wartości bezwzględnej mniejszej
niż \(\delta\). Otrzymujemy iniekcję z \(s\) wierszy do \(s\) baz, a więc
permutację \(\sigma\). Nie ma ona punktów stałych, bo \(q\nmid N-q\).

Niech \(r=\sigma(q)\), \(a=a_r=v_r(m_0)\) i
\(b=v_r(N-q)\). Mamy \(r^b\ge\delta>\delta-q>0\).
Przypadek \(b\le a\) oznaczałby, że \(r^b\) dzieli zarówno \(N-q\), jak
i \(2m_0\), a zatem także \(\delta-q\), co jest niemożliwe ze względu na
rozmiar. Stąd \(b>a\), a z
\[
  N-q=2m_0+(\delta-q)
\]
wynika \(v_r(\delta-q)=a\). To daje równanie w (B).

Sumując równania i używając \(k_q\ge1\), otrzymujemy
\[
 \sum_{q\in C}q+\sum_{q\in C}q^{a_q}\le s\delta=2hs.
\]
Ponieważ \(q^{a_q}\ge q\), lewa strona jest co najmniej
\(2\sum q\), co kończy dowód średniej.
\end{proof}
```
