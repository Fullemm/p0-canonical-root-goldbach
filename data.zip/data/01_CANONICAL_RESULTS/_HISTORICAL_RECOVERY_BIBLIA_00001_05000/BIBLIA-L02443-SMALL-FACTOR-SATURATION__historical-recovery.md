---
id: BIBLIA-L02443-SMALL-FACTOR-SATURATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2443
line_end: 2461
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Small-Factor Saturation

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2443-2461`
- Original label: `cor:small-factor-saturation`
- Section: Terminalny (Q)-core: masa i nasycenie > Core Mass Dichotomy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Small-Factor Saturation] W gałęzi (A) [ _< (m_0)> 1+ (N- ) , ] gdzie ( _< (m_0)) oznacza liczbę różnych dzielników pierwszych (m_0) mniejszych niż ( ).

## Exact source transcript

```tex
\begin{corollary}[Small-Factor Saturation]
\label{cor:small-factor-saturation}
W gałęzi (A)
\[
  \omega_{<\delta}(m_0)>
  1+\frac{\log(N-\delta)}{\log\delta},
\]
gdzie \(\omega_{<\delta}(m_0)\) oznacza liczbę różnych dzielników
pierwszych \(m_0\) mniejszych niż \(\delta\).
\end{corollary}

\begin{proof}
Z \(N-\delta<\delta^{s-1}\) wynika
\[
 s>1+\frac{\log(N-\delta)}{\log\delta}.
\]
Ponieważ \(C\subset Q\cap(0,\delta)\), mamy
\(s\le\omega_{<\delta}(m_0)\).
\end{proof}
```
