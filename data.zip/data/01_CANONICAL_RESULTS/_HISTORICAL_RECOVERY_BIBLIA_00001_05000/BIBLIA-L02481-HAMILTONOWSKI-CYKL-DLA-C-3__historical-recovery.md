---
id: BIBLIA-L02481-HAMILTONOWSKI-CYKL-DLA-C-3
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2481
line_end: 2502
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Hamiltonowski cykl dla ( C=3)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2481-2502`
- Original label: `thm:hamilton-three`
- Section: Terminalna trójka i Prime Shadow Triangle > Hamiltonowski trójcykl
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Hamiltonowski cykl dla ( C=3)] Każda terminalna zła SCC (C=a,b,c) o trzech wierzchołkach zawiera skierowany cykl Hamiltona. Silnie spójny digraf na trzech wierzchołkach bez skierowanego trójcyklu musiałby, po zmianie nazw, mieć topologię dwukierunkowej ścieżki

## Exact source transcript

```tex
\begin{theorem}[Hamiltonowski cykl dla \(\abs C=3\)]
\label{thm:hamilton-three}
Każda terminalna zła SCC \(C=\{a,b,c\}\) o trzech wierzchołkach zawiera
skierowany cykl Hamiltona.
\end{theorem}

\begin{proof}
Silnie spójny digraf na trzech wierzchołkach bez skierowanego trójcyklu
musiałby, po zmianie nazw, mieć topologię dwukierunkowej ścieżki
\(r\leftrightarrow g\leftrightarrow c\), bez krawędzi między \(r\) i
\(c\). Wtedy z terminalności wiersze \(N-r\) i \(N-c\) mają jedyną bazę
\(g\), więc
\[
  N-r=g^v,\qquad N-c=g^u
\]
z \(v>u\). Stąd
\[
  c-r=g^u(g^{v-u}-1)\ge2g^u=2(N-c).
\]
Każdy wierzchołek złej SCC jest mniejszy niż \(N/3\), więc lewa strona
jest mniejsza niż \(N/3\), a prawa większa niż \(4N/3\), sprzeczność.
\end{proof}
```
