---
id: BIBLIA-L02539-PRIME-SHADOW-TRIANGLE-RIGIDITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2539
line_end: 2590
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Prime Shadow Triangle Rigidity

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2539-2590`
- Original label: `thm:shadow-triangle`
- Section: Terminalna trójka i Prime Shadow Triangle > Dokładna parametryzacja shadow
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Prime Shadow Triangle Rigidity] Jeżeli [ g= (D,A)= (D,B)= (D,C^ ), ] to [ = Dg,

## Exact source transcript

```tex
\begin{theorem}[Prime Shadow Triangle Rigidity]
\label{thm:shadow-triangle}
Jeżeli
\[
 g=\gcd(D,A)=\gcd(D,B)=\gcd(D,C^\ast),
\]
to
\[
  \delta=\frac Dg,\qquad
  a=\frac Ag,\qquad
  b=\frac Bg,\qquad
  c=\frac{C^\ast}{g}.
\]
Ponadto \(\mu\le\nu<\lambda\).
\end{theorem}

\begin{proof}
Rozwiązanie liniowego układu (ST) daje
\[
 Da=\delta A,\qquad Db=\delta B,\qquad Dc=\delta C^\ast.
\]
Tożsamości
\[
  D-\lambda A=B,\qquad
  D-\nu B=C^\ast,\qquad
  D-\mu C^\ast=A
\]
pokazują równość trzech wskazanych największych wspólnych dzielników.
Po skróceniu
\[
  \gcd(D/g,A/g)=1,
\]
więc \(D/g\mid\delta\).
Niech \(t=\delta/(D/g)\). Wtedy jednocześnie
\[
  a=tA/g,\qquad b=tB/g,\qquad c=tC^\ast/g.
\]
Gdyby \(t>1\), wspólny dzielnik \(t\) dzieliłby trzy różne liczby
pierwsze \(a,b,c\), co jest niemożliwe. Zatem \(t=1\).

Bezpośrednio z (ST), \(a<b<c\) daje
\[
 \nu=\frac{\delta-c}{b}
 <\frac{\delta-b}{a}=\lambda.
\]
Gdyby \(\mu>\nu\), to z nieparzystości
\(\mu\ge\nu+2\), a
\[
 C^\ast-B=\lambda(\nu-\mu+1)-\nu<0,
\]
sprzecznie z \(c>b\). Stąd \(\mu\le\nu\).
\end{proof}
```
