---
id: BIBLIA-L02601-REDUKCJA-SUPPORTU-TROJKATA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2601
line_end: 2627
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Redukcja supportu trójkąta

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2601-2627`
- Original label: `thm:shadow-support`
- Section: Terminalna trójka i Prime Shadow Triangle > Shadow Support Reduction
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Redukcja supportu trójkąta] W powyższej orientacji [ (N-a) b,c, b N-a b , ] oraz [

## Exact source transcript

```tex
\begin{theorem}[Redukcja supportu trójkąta]
\label{thm:shadow-support}
W powyższej orientacji
\[
 \PF(N-a)\subseteq\{b,c\},
 \qquad b\mid N-a\Longleftrightarrow b\mid\mu,
\]
oraz
\[
 \PF(N-c)\subseteq\{a,b\},
 \qquad a\mid N-c\Longleftrightarrow a\mid\nu.
\]
Analogiczny test dla trzeciego wiersza otrzymuje się z
\(\delta-b=\lambda a\).
\end{theorem}

\begin{proof}
Terminalność daje \(\PF(N-a)\subseteq C\). Dla \(r\in C\), na mocy
\cref{thm:shadow},
\[
 r\mid N-a\Longleftrightarrow r\mid\delta-a=\mu c.
\]
Pierwsza \(c\) jest zawsze dzieckiem. Pierwsza \(a\) nie może dzielić
\(\delta\), ponieważ \(a\in Q\) i \(\gcd(h,m_0)=1\); zatem nie dzieli
\(\delta-a\). Dodatkowe dziecko \(b\) występuje dokładnie wtedy, gdy
\(b\mid\mu\). Drugi wiersz jest identyczny.
\end{proof}
```
