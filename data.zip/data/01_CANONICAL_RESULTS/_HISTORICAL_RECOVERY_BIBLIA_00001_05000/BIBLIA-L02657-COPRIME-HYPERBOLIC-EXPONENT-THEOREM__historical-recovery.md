---
id: BIBLIA-L02657-COPRIME-HYPERBOLIC-EXPONENT-THEOREM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2657
line_end: 2721
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Coprime Hyperbolic Exponent Theorem

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2657-2721`
- Original label: `thm:coprime-hyperbolic`
- Section: Bezchordowy trójkąt czystych potęg > Układ i sygnatura wykładników
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Coprime Hyperbolic Exponent Theorem] W układzie (PP)--(NF) [ > > 2, ] [ ( , )= ( , )= ( , )=1, ]

## Exact source transcript

```tex
\begin{theorem}[Coprime Hyperbolic Exponent Theorem]
\label{thm:coprime-hyperbolic}
W układzie (PP)--(NF)
\[
  \gamma>\eta>\beta\ge2,
\]
\[
  \gcd(\beta,\eta)=\gcd(\beta,\gamma)=\gcd(\eta,\gamma)=1,
\]
oraz
\[
  \frac1\beta+\frac1\eta+\frac1\gamma<1.
\]
\end{theorem}

\begin{proof}
Z (NF), \(b>a\) i \(\lambda>\nu\) otrzymujemy
\(a^{\gamma-1}>b^{\eta-1}\). Ponieważ \(a<b\), jest to niemożliwe dla
\(\gamma\le\eta\); zatem \(\gamma>\eta\). Analogicznie \(c>b\) i
\(\nu\ge\mu\) dają
\(b^{\eta-1}>c^{\beta-1}\), skąd \(\eta>\beta\).

Każdy wierzchołek terminalnego złego core jest mniejszy niż \(N/3\).
Z (PP) wynika zatem
\[
 a^\gamma,\ b^\eta,\ c^\beta>\frac{2N}{3}.
\]
Po wymnożeniu odpowiednich dolnych oszacowań baz:
\[
 abc>
 \left(\frac{2N}{3}\right)^{
  1/\gamma+1/\eta+1/\beta}.
\]
Jednocześnie \(abc\le m_0<N/2\). Suma odwrotności co najmniej \(1\)
dawałaby \(abc>2N/3\), sprzeczność.

Załóżmy \(d=\gcd(\beta,\gamma)\ge2\). Z różnicy pierwszych dwóch
odpowiednich potęg mamy
\[
 c^\beta-a^\gamma=b-a<c.
\]
Po zapisaniu \(X=c^{\beta/d}\), \(Y=a^{\gamma/d}\) lewa strona to
\(X^d-Y^d\ge X^{d-1}\ge c\), sprzeczność. Tak samo z
\(c^\beta-b^\eta=c-a<c\) dostajemy \(\gcd(\beta,\eta)=1\).

Pozostaje \(d=\gcd(\gamma,\eta)\ge2\). Niech
\(X=a^{\gamma/d}\), \(Y=b^{\eta/d}\). Wtedy \(X>Y\) oraz
\[
 c-b=X^d-Y^d\ge X^{d-1}.
 \tag{1}
\]
Ponadto
\[
 c^\beta=X^d+(b-a)<2X^d.
 \tag{2}
\]
Jeżeli \(\beta(d-1)\ge d+1\), to dla \(X\ge3\)
\[
 2X^d<X^{d+1}\le X^{\beta(d-1)}.
\]
Z (2) wynikałoby \(c<X^{d-1}\), wbrew (1). Jedyną parą
\(\beta,d\ge2\) spełniającą
\(\beta(d-1)<d+1\) jest \((2,2)\). Wtedy \(2=d\mid\gamma\), co przeczy
już dowiedzionemu \(\gcd(\beta,\gamma)=1\). Wszystkie tezy są dowiedzione.
\end{proof}
```
