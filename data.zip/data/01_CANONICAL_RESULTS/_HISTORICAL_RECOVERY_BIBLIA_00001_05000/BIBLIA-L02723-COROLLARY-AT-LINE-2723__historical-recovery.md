---
id: BIBLIA-L02723-COROLLARY-AT-LINE-2723
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2723
line_end: 2731
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# corollary at line 2723

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2723-2731`
- Original label: ``
- Section: Bezchordowy trójkąt czystych potęg > Układ i sygnatura wykładników
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Najmniejszą sygnaturą zgodną jednocześnie z porządkiem, względną pierwszością i nierównością hiperboliczną jest [ ( , , )=(3,4,5). ] Inna wczesna możliwość uporządkowana według wartości wykładników to ((2,3,7)).

## Exact source transcript

```tex
\begin{corollary}
Najmniejszą sygnaturą zgodną jednocześnie z porządkiem, względną
pierwszością i nierównością hiperboliczną jest
\[
  (\beta,\eta,\gamma)=(3,4,5).
\]
Inna wczesna możliwość uporządkowana według wartości wykładników to
\((2,3,7)\).
\end{corollary}
```
