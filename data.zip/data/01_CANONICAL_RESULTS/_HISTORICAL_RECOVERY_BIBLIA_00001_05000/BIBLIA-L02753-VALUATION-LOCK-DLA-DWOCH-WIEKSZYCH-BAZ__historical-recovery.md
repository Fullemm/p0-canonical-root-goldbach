---
id: BIBLIA-L02753-VALUATION-LOCK-DLA-DWOCH-WIEKSZYCH-BAZ
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2753
line_end: 2796
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Valuation Lock dla dwóch większych baz

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2753-2796`
- Original label: `prop:345-valuations`
- Section: Podpis ((3,4,5)) > Sztywność krotności w (m_0)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Valuation Lock dla dwóch większych baz] W układzie (345a), przy zapisie (m_0=abcM), zachodzi [ M<b<c, v_b(m_0)=v_c(m_0)=1. ] Dla współczynników shadow z (ST) wynika ponadto

## Exact source transcript

```tex
\begin{proposition}[Valuation Lock dla dwóch większych baz]
\label{prop:345-valuations}
W układzie (345a), przy zapisie \(m_0=abcM\), zachodzi
\[
 M<b<c,
 \qquad
 v_b(m_0)=v_c(m_0)=1.
\]
Dla współczynników shadow z (ST) wynika ponadto
\[
 b\nmid\nu,
 \qquad
 c\nmid\mu.
\]
\end{proposition}

\begin{proof}
Każdy wierzchołek terminalnego złego core jest mniejszy niż \(N/3\).
Z (345a) dostajemy więc
\[
 a>\left(\frac{2N}{3}\right)^{1/5},\qquad
 b>\left(\frac{2N}{3}\right)^{1/4},\qquad
 c>\left(\frac{2N}{3}\right)^{1/3}.
\]
Ponieważ \(m_0<N/2\),
\[
 \frac Mb
 =\frac{m_0}{ab^2c}
 <\frac12\left(\frac32\right)^{31/30}N^{-1/30}<1.
\]
Stąd \(M<b<c\). Bazy \(b,c\) występują zatem w \(abcM\) dokładnie
raz.

W wierszu \(N-c=b^4\) jedynym świadkiem z
\cref{thm:witness} jest \(b\), a \(\delta-c=\nu b\). Zatem
\[
 v_b(m_0)=v_b(\delta-c)=1+v_b(\nu).
\]
Analogicznie z \(N-a=c^3\) i \(\delta-a=\mu c\) mamy
\[
 v_c(m_0)=1+v_c(\mu).
\]
Obie lewe strony są równe \(1\), co daje ostatnie dwie tezy.
\end{proof}
```
