---
id: BIBLIA-L02800-TRIPLE-NEAREST-POWER-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2800
line_end: 2833
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Triple Nearest-Power Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2800-2833`
- Original label: `thm:nearest-lock`
- Section: Podpis ((3,4,5)) > Triple Nearest-Power Lock
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Triple Nearest-Power Lock] Każde rozwiązanie w różnych pierwszych (a<b<c) układu (345b) spełnia [ b= a^5/4, c= a^5/3= b^4/3. ]

## Exact source transcript

```tex
\begin{theorem}[Triple Nearest-Power Lock]
\label{thm:nearest-lock}
Każde rozwiązanie w różnych pierwszych \(a<b<c\) układu (345b) spełnia
\[
 b=\floor{a^{5/4}},\qquad
 c=\ceil{a^{5/3}}=\ceil{b^{4/3}}.
\]
\end{theorem}

\begin{proof}
Liczba \(a^5\) nie jest sześcianem. Z pierwszego równania
\(c^3>a^5\), więc \(c\ge\ceil{a^{5/3}}\). Gdyby
\(c\ge\ceil{a^{5/3}}+1\), to \((c-1)^3>a^5\), a zatem
\[
 c^3-a^5>c^3-(c-1)^3>c,
\]
sprzecznie z \(c^3-a^5=b-a<c\). Stąd
\(c=\ceil{a^{5/3}}\).

Drugie równanie daje \(b^4<a^5\), więc
\(b\le\floor{a^{5/4}}\). Gdyby
\(b\le\floor{a^{5/4}}-1\), to
\[
 a^5-b^4>(b+1)^4-b^4>b^3.
\]
Z już uzyskanego wzoru dla \(c\), dla pierwszej \(a\ge3\) mamy
\(c<a^2\), a ponieważ \(b>a\), zachodzi \(b^3>a^3>c\).
Otrzymalibyśmy \(a^5-b^4>c\), sprzecznie z
\(a^5-b^4=c-b<c\).

Wreszcie trzecie równanie daje \(c^3>b^4\). Ten sam argument z luką
między kolejnymi sześcianami i nierównością \(c-a<c\) wymusza
\(c=\ceil{b^{4/3}}\).
\end{proof}
```
