---
id: BIBLIA-L02835-DOKADNE-DEFEKTY-JEDNOPARAMETROWE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2835
line_end: 2880
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Dokładne defekty jednoparametrowe

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2835-2880`
- Original label: `cor:345-defects`
- Section: Podpis ((3,4,5)) > Triple Nearest-Power Lock
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Dokładne defekty jednoparametrowe] Połóżmy [ b(a)= a^5/4, c(a)= a^5/3. ] Układ (345b) jest równoważny jednoczesnemu znikaniu

## Exact source transcript

```tex
\begin{corollary}[Dokładne defekty jednoparametrowe]
\label{cor:345-defects}
Połóżmy
\[
 b(a)=\floor{a^{5/4}},
 \qquad
 c(a)=\ceil{a^{5/3}}.
\]
Układ (345b) jest równoważny jednoczesnemu znikaniu
\[
\begin{aligned}
 D_3(a)&=c(a)^3-a^5-\bigl(b(a)-a\bigr),\\
 D_4(a)&=a^5-b(a)^4-\bigl(c(a)-b(a)\bigr),
\end{aligned}
\]
przy dodatkowym warunku, że \(b(a),c(a)\) są pierwsze. Dla
\[
 u=a^{5/4}-b,
 \qquad
 v=c-a^{5/3}
\]
zachodzą dokładne wzory
\[
 u=\frac{c-b}{a^{15/4}+a^{5/2}b+a^{5/4}b^2+b^3},
\]
\[
 v=\frac{b-a}{c^2+ca^{5/3}+a^{10/3}},
\]
a w szczególności
\[
 0<u<\frac{c}{4b^3},
 \qquad
 0<v<\frac{b}{3a^{10/3}}.
\]
Oba błędy są więc rzędu \(O(a^{-25/12})\).
\end{corollary}

\begin{proof}
Pierwsze dwa równania są dokładnie dwiema pierwszymi równościami (345b)
po podstawieniu z \cref{thm:nearest-lock}; trzecia równość (345b) jest
ich sumą. Wzory dla \(u,v\) wynikają z faktoryzacji różnicy odpowiednio
czwartych potęg i sześcianów. W pierwszym mianowniku trzy składniki są
większe niż \(b^3\), a czwarty jest mu równy; w drugim dwa składniki są
większe niż \(a^{10/3}\), a trzeci jest mu równy. Ostatni rząd wielkości wynika z
\(b\asymp a^{5/4}\) i \(c\asymp a^{5/3}\).
\end{proof}
```
