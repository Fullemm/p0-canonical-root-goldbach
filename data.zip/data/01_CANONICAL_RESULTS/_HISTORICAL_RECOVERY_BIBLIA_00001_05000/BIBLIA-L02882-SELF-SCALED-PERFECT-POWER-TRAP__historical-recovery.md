---
id: BIBLIA-L02882-SELF-SCALED-PERFECT-POWER-TRAP
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2882
line_end: 2893
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Self-scaled perfect-power trap

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2882-2893`
- Original label: ``
- Section: Podpis ((3,4,5)) > Triple Nearest-Power Lock
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Self-scaled perfect-power trap] Trzy liczby [ b^4<a^5<c^3 ] leżą w przedziale długości (c-a<c<N^1/3).

## Exact source transcript

```tex
\begin{corollary}[Self-scaled perfect-power trap]
Trzy liczby
\[
  b^4<a^5<c^3
\]
leżą w przedziale długości \(c-a<c<N^{1/3}\).
\end{corollary}

\begin{proof}
Skrajna różnica jest z trzeciego równania (345b) równa \(c-a\).
Ponieważ \(N-a=c^3\), mamy \(c<N^{1/3}\).
\end{proof}
```
