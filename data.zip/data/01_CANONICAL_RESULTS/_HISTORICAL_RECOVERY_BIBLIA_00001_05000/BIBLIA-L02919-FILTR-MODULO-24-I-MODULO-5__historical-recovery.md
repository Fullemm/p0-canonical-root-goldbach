---
id: BIBLIA-L02919-FILTR-MODULO-24-I-MODULO-5
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2919
line_end: 2957
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Filtr modulo (24) i modulo (5)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2919-2957`
- Original label: `thm:local-congruences`
- Section: Podpis ((3,4,5)) > Kongruencje elementarne
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Filtr modulo (24) i modulo (5)] Dla rozwiązania pierwszego (345b) [ a 1 24, b c 24. ] Modulo (5) możliwe są tylko trójki [ (a,b,c)

## Exact source transcript

```tex
\begin{theorem}[Filtr modulo \(24\) i modulo \(5\)]
\label{thm:local-congruences}
Dla rozwiązania pierwszego (345b)
\[
  a\equiv1\pmod{24},\qquad b\equiv c\pmod{24}.
\]
Modulo \(5\) możliwe są tylko trójki
\[
 (a,b,c)\equiv
 (1,1,1),\ (1,4,4),\ (2,2,3)\pmod5.
\]
Po osobnym wykluczeniu \(a=5\) wynika
\[
  a\equiv1\ \text{lub}\ 97\pmod{120}.
\]
\end{theorem}

\begin{proof}
Dla nieparzystego \(z\) mamy modulo \(8\):
\(z^3\equiv z\), \(z^5\equiv z\), \(z^4\equiv1\).
Porównując trzy postacie \(N\) w (345a), dostajemy najpierw
\(b\equiv c\pmod8\), a następnie \(a\equiv1\pmod8\).

Jeżeli \(a=3\), to \(b,c\) są jednostkami modulo \(3\), a z
\(N=a+c^3\) i \(N=c+b^4\) wynikałoby jednocześnie
\(N\equiv c\) i \(N\equiv c+1\pmod3\), sprzeczność.
Dla pozostałych baz te same kongruencje
\(z^3\equiv z\), \(z^5\equiv z\), \(z^4\equiv1\pmod3\) dają
\(a\equiv1\) i \(b\equiv c\pmod3\). Chińskie twierdzenie o resztach
łączy warunki do modułu \(24\).

Przypadek \(a=5\) sprawdza się bezpośrednio: z
\(b^4<5^5<(b+1)^4\) wynika \(b=7\), lecz drugie równanie (345b) nie
zachodzi. Dla jednostek i zera modulo \(5\) podstawienie do trzech
równań (345a) jest skończoną kontrolą \(5^3\) klas; po narzuceniu
różności baz pierwszych pozostają dokładnie trzy trójki podane w tezie.
Połączenie klas \(a\equiv1\pmod{24}\) z \(a\equiv1\) lub \(2\pmod5\)
daje \(a\equiv1\) lub \(97\pmod{120}\).
\end{proof}
```
