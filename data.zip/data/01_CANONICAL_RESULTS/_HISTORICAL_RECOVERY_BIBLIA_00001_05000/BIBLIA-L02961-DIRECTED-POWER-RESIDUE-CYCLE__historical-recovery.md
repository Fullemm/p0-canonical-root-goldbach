---
id: BIBLIA-L02961-DIRECTED-POWER-RESIDUE-CYCLE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2961
line_end: 2976
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Directed Power-Residue Cycle

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2961-2976`
- Original label: `lem:power-residue`
- Section: Podpis ((3,4,5)) > Cykl reszt potęgowych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Directed Power-Residue Cycle] Z (345a) wynikają kongruencje [ b c^3 a, c a^5 b, a b^4 c. ]

## Exact source transcript

```tex
\begin{lemma}[Directed Power-Residue Cycle]
\label{lem:power-residue}
Z (345a) wynikają kongruencje
\[
  b\equiv c^3\pmod a,\qquad
  c\equiv a^5\pmod b,\qquad
  a\equiv b^4\pmod c.
\]
\end{lemma}

\begin{proof}
Każda kongruencja powstaje przez porównanie dwóch równych postaci \(N\):
odpowiednio \(a+c^3=b+a^5\),
\(b+a^5=c+b^4\) i \(c+b^4=a+c^3\), a następnie redukcję modulo
wskazanej bazy.
\end{proof}
```
