---
id: BIBLIA-L02978-FILTRY-WYZSZYCH-POTEG
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 2978
line_end: 3009
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Filtry wyższych potęg

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:2978-3009`
- Original label: `cor:power-residue-filters`
- Section: Podpis ((3,4,5)) > Cykl reszt potęgowych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Filtry wyższych potęg] Każde rozwiązanie (345a) spełnia [ a c^11-c^2+1, b a^14-a^4+1, c b^19-b^3+1.

## Exact source transcript

```tex
\begin{corollary}[Filtry wyższych potęg]
\label{cor:power-residue-filters}
Każde rozwiązanie (345a) spełnia
\[
 a\mid c^{11}-c^2+1,
 \qquad
 b\mid a^{14}-a^4+1,
 \qquad
 c\mid b^{19}-b^3+1.
\]
\end{corollary}

\begin{proof}
Modulo \(a\), z drugiego równania (345b) i
\(b\equiv c^3\pmod a\) dostajemy
\[
 0\equiv b^4-b+c
   \equiv c^{12}-c^3+c
   =c(c^{11}-c^2+1).
\]
Ponieważ \(a\ne c\), można skrócić przez \(c\). Modulo \(b\), po
podstawieniu \(c\equiv a^5\), pierwsze równanie (345b) daje
\[
 0\equiv a^{15}-a^5+a=a(a^{14}-a^4+1).
\]
Modulo \(c\), podstawienie \(a\equiv b^4\) do drugiego równania (345b)
daje
\[
 0\equiv b^{20}-b^4+b=b(b^{19}-b^3+1).
\]
Różność baz pozwala skrócić odpowiednio przez \(a\) i \(b\).
\end{proof}
```
