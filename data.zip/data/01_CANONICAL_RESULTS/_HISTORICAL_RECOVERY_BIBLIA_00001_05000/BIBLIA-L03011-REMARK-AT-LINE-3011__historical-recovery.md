---
id: BIBLIA-L03011-REMARK-AT-LINE-3011
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3011
line_end: 3017
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# remark at line 3011

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3011-3017`
- Original label: ``
- Section: Podpis ((3,4,5)) > Cykl reszt potęgowych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Ponieważ (a 1 3), kongruencja (b c^3 a) jest rzeczywistym warunkiem sześciennej resztowości w niebanalnej podgrupie (( /a )^ ). To uzasadnia priorytet dla wzajemności sześciennej, ale samo w sobie nie daje jeszcze sprzeczności. [Quadratic-Residue Corollary]

## Exact source transcript

```tex
\begin{remark}
Ponieważ \(a\equiv1\pmod3\), kongruencja
\(b\equiv c^3\pmod a\) jest rzeczywistym warunkiem sześciennej
resztowości w niebanalnej podgrupie \((\Z/a\Z)^\times\). To uzasadnia
priorytet dla wzajemności sześciennej, ale samo w sobie nie daje jeszcze
sprzeczności.
\end{remark}
```
