---
id: BIBLIA-L03019-QUADRATIC-RESIDUE-COROLLARY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3019
line_end: 3047
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Quadratic-Residue Corollary

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3019-3047`
- Original label: `thm:quadratic-residue`
- Section: Podpis ((3,4,5)) > Cykl reszt potęgowych
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Quadratic-Residue Corollary] Symbole Legendre'a spełniają [ ( ac )= ( ca )= ( ba )= ( ab )= ( cb )=1.

## Exact source transcript

```tex
\begin{theorem}[Quadratic-Residue Corollary]
\label{thm:quadratic-residue}
Symbole Legendre'a spełniają
\[
 \left(\frac ac\right)=
 \left(\frac ca\right)=
 \left(\frac ba\right)=
 \left(\frac ab\right)=
 \left(\frac cb\right)=1.
\]
Ponadto
\[
 \left(\frac bc\right)=
 \begin{cases}
  1,&b\equiv c\equiv1\pmod4,\\
 -1,&b\equiv c\equiv3\pmod4.
 \end{cases}
\]
\end{theorem}

\begin{proof}
Z \(a\equiv b^4\pmod c\) wynika \((a/c)=1\). Ponieważ
\(a\equiv1\pmod4\), wzajemność kwadratowa daje \((c/a)=1\).
Z \(b\equiv c^3\pmod a\) otrzymujemy
\((b/a)=(c/a)=1\), a ponownie dzięki \(a\equiv1\pmod4\):
\((a/b)=1\). Kongruencja \(c\equiv a^5\pmod b\) daje
\((c/b)=(a/b)=1\). Ostatni wzór jest bezpośrednio prawem wzajemności
dla \(b,c\), przy użyciu \((c/b)=1\).
\end{proof}
```
