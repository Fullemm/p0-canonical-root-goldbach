---
id: BIBLIA-L03106-DOKADNE-KONSEKWENCJE-WEWNATRZ-SCIANY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3106
line_end: 3117
env: proposition
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Dokładne konsekwencje wewnątrz ściany

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3106-3117`
- Original label: `prop:historical-exact`
- Section: Archiwum redukcji lokalnych sprzed shadow triangle > Ściana (bc^2,a^ ,b^8)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Dokładne konsekwencje wewnątrz ściany] Jeżeli układ (H) zachodzi dla pierwszych (a<b<c), to [ c= b^7/2, q:= c/b=c^2-b^7, ] [ q a^2+2a^3b b^2,

## Exact source transcript

```tex
\begin{proposition}[Dokładne konsekwencje wewnątrz ściany]
\label{prop:historical-exact}
Jeżeli układ (H) zachodzi dla pierwszych \(a<b<c\), to
\[
 c=\ceil{b^{7/2}},\qquad
 q:=\floor{c/b}=c^2-b^7,
\]
\[
 q\equiv a^2+2a^3b\pmod{b^2},
\]
a \(\gamma\) jest nieparzyste i \(\gamma\ge9\).
\end{proposition}
```
