---
id: BIBLIA-L03382-KOREKTA-1-5
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3382
line_end: 3388
env: remark
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Korekta 1.5

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3382-3388`
- Original label: ``
- Section: Eksperymenty i dane kontrolne > Sześć znanych EAC i ochrona (p_0)
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Korekta 1.5] Wartości dla (N=1862,1928,6142) zostały poprawione (poprzednio (122,87,160)) i przeliczone po randze kondensacji. Dawne warstwowanie nie obierało wierzchołków leżących w nietrywialnych SCC przejściowych, których istnienie w tych trzech przypadkach wykazano w sec:atak-transient. W każdym z tych sześciu (N) eksperymentalnie występuje dokładnie jedno

## Exact source transcript

```tex
\begin{remark}[Korekta 1.5]
\CORRECTED\ Wartości dla \(N=1862,1928,6142\) zostały poprawione
(poprzednio \(122,87,160\)) i przeliczone po randze kondensacji. Dawne
warstwowanie nie obierało wierzchołków leżących w nietrywialnych SCC
przejściowych, których istnienie w tych trzech przypadkach wykazano
w \cref{sec:atak-transient}.
\end{remark}
```
