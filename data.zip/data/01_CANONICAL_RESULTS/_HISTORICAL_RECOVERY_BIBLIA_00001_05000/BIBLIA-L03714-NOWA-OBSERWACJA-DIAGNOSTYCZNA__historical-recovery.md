---
id: BIBLIA-L03714-NOWA-OBSERWACJA-DIAGNOSTYCZNA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3714
line_end: 3721
env: remark
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Nowa obserwacja diagnostyczna

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3714-3721`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Niezależna reprodukcja eksperymentów
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Nowa obserwacja diagnostyczna] Szerokość rośnie mniej więcej liniowo w ( N), natomiast głębokość nie rośnie wcale: rekord (10) pozostaje osiągany dokładnie raz, przez (N=11,822), a liczności głębokości (9) i (10) są identyczne ((4) i (1)) w zakresach (10^7) i (10^8). Wzmacnia to wniosek z ch:experiments: trudność jest zjawiskiem szerokości frontu, nie długości trajektorii.

## Exact source transcript

```tex
\begin{remark}[Nowa obserwacja diagnostyczna]
Szerokość rośnie mniej więcej liniowo w \(\log N\), natomiast
\emph{głębokość nie rośnie wcale}: rekord \(10\) pozostaje osiągany
dokładnie raz, przez \(N=11\,822\), a liczności głębokości \(9\) i \(10\)
są identyczne (\(4\) i \(1\)) w zakresach \(10^7\) i \(10^8\). Wzmacnia to
wniosek z \cref{ch:experiments}: trudność jest zjawiskiem szerokości
frontu, nie długości trajektorii.
\end{remark}
```
