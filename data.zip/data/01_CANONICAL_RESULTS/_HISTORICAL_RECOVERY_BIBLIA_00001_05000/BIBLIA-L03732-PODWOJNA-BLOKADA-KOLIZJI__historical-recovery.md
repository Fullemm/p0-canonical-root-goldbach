---
id: BIBLIA-L03732-PODWOJNA-BLOKADA-KOLIZJI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3732
line_end: 3771
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Podwójna blokada kolizji

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3732-3771`
- Original label: `thm:atak-collision`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Most Bézout--SCC: podwójna blokada kolizji
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Podwójna blokada kolizji] Niech dwa spacery w grafie faktoryzacyjnym wychodzą z (p_0) i kończą się w tym samym aktywnym wierzchołku (p). Dla spaceru (i 1,2) niech (t_i) będzie długością, (K_i= _j k_j) iloczynem etykiet, ( _i=(-1)^t_i), a [ B_ip-A_ix= _iH_i,

## Exact source transcript

```tex
\begin{theorem}[Podwójna blokada kolizji]
\label{thm:atak-collision}
Niech dwa spacery w grafie faktoryzacyjnym wychodzą z \(p_0\) i kończą się
w tym samym aktywnym wierzchołku \(p\). Dla spaceru \(i\in\{1,2\}\) niech
\(t_i\) będzie długością, \(K_i=\prod_j k_j\) iloczynem etykiet,
\(\varepsilon_i=(-1)^{t_i}\), a
\[
  B_ip-A_ix=\varepsilon_iH_i,
  \qquad
  \gcd(B_i,H_i)=1
\]
stanem zredukowanym z \cref{thm:bezout-path}. Wtedy jednocześnie
\[
  N\mid K_1-\varepsilon_1\varepsilon_2K_2
  \tag{C1}
\]
oraz
\[
  x\mid B_1H_2-\varepsilon_1\varepsilon_2B_2H_1 .
  \tag{C2}
\]
\end{theorem}

\begin{proof}
Z normalnej postaci winding (\cref{thm:winding-normal-form})
\(K_ip=W_iN+\varepsilon_ip_0\), czyli
\(K_ip\equiv\varepsilon_ip_0\pmod N\). Mnożąc przez \(\varepsilon_i=\pm1\)
otrzymujemy \(\varepsilon_iK_ip\equiv p_0\) dla obu spacerów, więc
\((\varepsilon_1K_1-\varepsilon_2K_2)p\equiv0\pmod N\). Wierzchołek \(p\)
jest aktywny, więc \(\gcd(p,N)=1\) i \(N\mid\varepsilon_1K_1-\varepsilon_2K_2\);
mnożenie przez \(\varepsilon_1\) daje (C1).

Redukcja stanu zredukowanego modulo \(x\) daje
\(B_ip\equiv\varepsilon_iH_i\pmod x\). Mnożymy pierwszą kongruencję przez
\(\varepsilon_1H_2\), drugą przez \(\varepsilon_2H_1\); obie prawe strony
stają się równe \(H_1H_2\). Odejmując,
\((\varepsilon_1B_1H_2-\varepsilon_2B_2H_1)p\equiv0\pmod x\). Aktywna
pierwsza \(p\) nie dzieli \(N=2x\), więc \(\gcd(p,x)=1\), co po
przemnożeniu przez \(\varepsilon_1\) daje (C2).
\end{proof}
```
