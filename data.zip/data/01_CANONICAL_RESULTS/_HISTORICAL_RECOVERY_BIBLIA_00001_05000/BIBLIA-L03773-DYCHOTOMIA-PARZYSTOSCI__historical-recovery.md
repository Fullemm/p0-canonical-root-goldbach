---
id: BIBLIA-L03773-DYCHOTOMIA-PARZYSTOSCI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3773
line_end: 3804
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Dychotomia parzystości

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3773-3804`
- Original label: `cor:atak-parity`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Most Bézout--SCC: podwójna blokada kolizji
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Dychotomia parzystości] W oznaczeniach thm:atak-collision: jeżeli (t_1 t_2 2), to [ K_1+K_2 N, B_1H_2+B_2H_1 x;

## Exact source transcript

```tex
\begin{corollary}[Dychotomia parzystości]
\label{cor:atak-parity}
W oznaczeniach \cref{thm:atak-collision}:
\begin{enumerate}
  \item jeżeli \(t_1\not\equiv t_2\pmod2\), to
  \[
    K_1+K_2\ge N,
    \qquad
    B_1H_2+B_2H_1\ge x;
  \]
  \item jeżeli \(t_1\equiv t_2\pmod2\), to albo
  \(\abs{B_1H_2-B_2H_1}\ge x\), albo wyznacznik znika, a wtedy
  \[
    (B_1,H_1)=(B_2,H_2),
    \qquad A_1=A_2,
    \qquad K_1=K_2 .
  \]
\end{enumerate}
\end{corollary}

\begin{proof}
W przypadku 1 mamy \(\varepsilon_1\varepsilon_2=-1\), więc (C1) i (C2)
dotyczą sum liczb dodatnich; niezerowa wielokrotność \(N\) (odp. \(x\))
jest co najmniej \(N\) (odp. \(x\)).

W przypadku 2 znikanie wyznacznika oznacza \(B_1H_2=B_2H_1\), czyli
równość ułamków \(B_1/H_1=B_2/H_2\); obie pary są względnie pierwsze i
dodatnie, więc \(B_1=B_2\) i \(H_1=H_2\). Wtedy
\(A_ix=B_ip-\varepsilon_iH_i\) z tym samym \(\varepsilon\) daje
\(A_1=A_2\). Wreszcie \(H_i=h/d_i\) z \(d_i=\gcd(K_i,h)\) daje
\(d_1=d_2\), a \(K_i=B_id_i\) --- równość \(K_1=K_2\).
\end{proof}
```
