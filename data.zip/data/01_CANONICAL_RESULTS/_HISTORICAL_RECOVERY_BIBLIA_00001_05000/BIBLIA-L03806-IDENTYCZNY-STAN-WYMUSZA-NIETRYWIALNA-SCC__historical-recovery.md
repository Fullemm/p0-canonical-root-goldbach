---
id: BIBLIA-L03806-IDENTYCZNY-STAN-WYMUSZA-NIETRYWIALNA-SCC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3806
line_end: 3831
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Identyczny stan wymusza nietrywialną SCC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3806-3831`
- Original label: `thm:atak-return`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Most Bézout--SCC: podwójna blokada kolizji
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Identyczny stan wymusza nietrywialną SCC] Niech dwa spacery mają wspólny prefiks kończący się w (u), po czym rozchodzą się do różnych dzieci (q_1 q_2) wiersza (n=N-u), i niech kończą się w tym samym wierzchołku z identycznym stanem zredukowanym. Wtedy każde (q_i) leży na skierowanym cyklu, a więc w nietrywialnej SCC.

## Exact source transcript

```tex
\begin{theorem}[Identyczny stan wymusza nietrywialną SCC]
\label{thm:atak-return}
Niech dwa spacery mają wspólny prefiks kończący się w \(u\), po czym
rozchodzą się do różnych dzieci \(q_1\ne q_2\) wiersza \(n=N-u\), i niech
kończą się w tym samym wierzchołku z \emph{identycznym} stanem
zredukowanym. Wtedy każde \(q_i\) leży na skierowanym cyklu, a więc
w nietrywialnej SCC.
\end{theorem}

\begin{proof}
Z \cref{cor:atak-parity} mamy \(K_1=K_2\); po skróceniu wspólnego prefiksu
zostają iloczyny etykiet po rozgałęzieniu,
\[
  L_i=\frac{n}{q_i}\,U_i,
\]
gdzie \(U_i\) jest iloczynem etykiet gałęzi \(i\) \emph{od} \(q_i\) w dół.
Z \(L_1=L_2\) wynika \(q_2U_1=q_1U_2\). Liczby \(q_1,q_2\) są różnymi
pierwszymi, więc \(q_1\mid U_1\) i \(q_2\mid U_2\).

Zatem na gałęzi \(i\) istnieje etykieta \(k_j=(N-p_j)/p_{j+1}\) podzielna
przez \(q_i\), gdzie \(p_j\) leży na tej gałęzi za \(q_i\). Nie może to być
pierwsza etykieta wychodząca z \(q_i\): \(q_i\mid(N-q_i)\) dawałoby
\(q_i\mid N\), wbrew aktywności. Zatem \(j\ge1\) i \(p_j\) jest osiągalne
z \(q_i\). Z \(q_i\mid k_j\mid N-p_j\) istnieje krawędź \(p_j\to q_i\).
Razem ze ścieżką \(q_i\to\cdots\to p_j\) daje to cykl przez \(q_i\).
\end{proof}
```
