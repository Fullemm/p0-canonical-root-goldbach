---
id: BIBLIA-L03833-STREFA-BEZ-KOLIZJI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3833
line_end: 3852
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Strefa bez kolizji

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3833-3852`
- Original label: `cor:atak-nocollision`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Most Bézout--SCC: podwójna blokada kolizji
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Strefa bez kolizji] Załóżmy, że oba spacery kończą się w tym samym (p) i że [ B_1,B_2< x2h. NC ] Ponieważ (H_i h), mamy (B_iH_j<x/2), a zatem:

## Exact source transcript

```tex
\begin{corollary}[Strefa bez kolizji]
\label{cor:atak-nocollision}
Załóżmy, że oba spacery kończą się w tym samym \(p\) i że
\[
  B_1,B_2<\frac{x}{2h}.
  \tag{NC}
\]
Ponieważ \(H_i\le h\), mamy \(B_iH_j<x/2\), a zatem:
\begin{enumerate}
  \item długości \(t_1,t_2\) muszą mieć \emph{tę samą} parzystość
  (przeciwny przypadek przeczy \cref{cor:atak-parity}(1));
  \item stany zredukowane są identyczne, więc na mocy
  \cref{thm:atak-return} oba pierwsze wierzchołki po rozgałęzieniu leżą
  w nietrywialnych SCC.
\end{enumerate}
W szczególności w przypadku III z \cref{ch:global} --- jedno ujście
i wyłącznie trywialne SCC przejściowe --- dwie gałęzie wychodzące z tego
samego wiersza \emph{nie mogą} ponownie się spotkać, dopóki obie mają
\(B<x/(2h)\).
\end{corollary}
```
