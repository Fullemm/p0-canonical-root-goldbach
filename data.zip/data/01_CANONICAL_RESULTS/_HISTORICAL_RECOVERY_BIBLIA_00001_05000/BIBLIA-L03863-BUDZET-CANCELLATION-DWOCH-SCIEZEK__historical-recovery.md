---
id: BIBLIA-L03863-BUDZET-CANCELLATION-DWOCH-SCIEZEK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3863
line_end: 3888
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Budżet cancellation dwóch ścieżek

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3863-3888`
- Original label: `thm:atak-budget`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Most Bézout--SCC: podwójna blokada kolizji
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Budżet cancellation dwóch ścieżek] Niech (d_i= (K_i,h)) i niech (K_1- _1 _2K_2= N) z ( ). Wtedy [ d_1d_2 h . ] W szczególności, jeżeli (0< K_1- _1 _2K_2<2N), to ( = 1) i (d_1d_2 h).

## Exact source transcript

```tex
\begin{theorem}[Budżet cancellation dwóch ścieżek]
\label{thm:atak-budget}
Niech \(d_i=\gcd(K_i,h)\) i niech
\(K_1-\varepsilon_1\varepsilon_2K_2=\ell N\) z \(\ell\in\Z\). Wtedy
\[
  d_1d_2\mid h\ell .
\]
W szczególności, jeżeli \(0<\abs{K_1-\varepsilon_1\varepsilon_2K_2}<2N\),
to \(\ell=\pm1\) i \(d_1d_2\mid h\).
\end{theorem}

\begin{proof}
Każde \(K_i\) jest iloczynem nieparzystych etykiet, więc \(d_i\) jest
nieparzyste. Niech \(r\) będzie nieparzystą pierwszą i
\(\alpha=v_r(K_1)\), \(\beta=v_r(K_2)\), \(c=v_r(h)\). Jeżeli \(r\mid h\),
to \(r\nmid N\): z \(r\mid h\) i \(r\mid N=2x\) wynikałoby \(r\mid x\),
a więc \(r\mid x-h=m_0\), wbrew \cref{lem:gcd-hm}. Stąd
\[
  v_r(\ell)=v_r(\ell N)=v_r\bigl(K_1-\varepsilon_1\varepsilon_2K_2\bigr)
  \ge\min(\alpha,\beta).
\]
Wystarczy więc nierówność
\(\min(\alpha,c)+\min(\beta,c)\le c+\min(\alpha,\beta)\), którą sprawdza
się bezpośrednio w trzech przypadkach uporządkowania \(c\) względem
\(\alpha\le\beta\). Ostatnie zdanie wynika z \(\abs\ell<2\).
\end{proof}
```
