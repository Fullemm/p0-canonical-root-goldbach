---
id: BIBLIA-L03905-WYKLUCZENIE-ROZMIARU-2
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3905
line_end: 3920
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Wykluczenie rozmiaru (2)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3905-3920`
- Original label: `thm:atak-no-two`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Terminalny rdzeń rozmiaru dwa nie istnieje w porażce
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Wykluczenie rozmiaru (2)] Hipotetyczna porażka pełnego BFS nie ma żadnej terminalnej złej SCC o dwóch wierzchołkach --- ani w (Q), ani w (R_h), ani w (S_h), ani poza nimi. Bożek dowodzi bezwarunkowo, że istnieje dokładnie jedna EAC

## Exact source transcript

```tex
\begin{theorem}[Wykluczenie rozmiaru \(2\)]
\label{thm:atak-no-two}
Hipotetyczna porażka pełnego BFS nie ma \emph{żadnej} terminalnej złej SCC
o dwóch wierzchołkach --- ani w \(Q\), ani w \(R_h\), ani w \(S_h\), ani
poza nimi.
\end{theorem}

\begin{proof}
\LITERATURE\ Bożek dowodzi bezwarunkowo, że istnieje dokładnie jedna EAC
indukowana przez dwa wierzchołki \cite{Bozek2019,Scott1993}. Terminalna
zła SCC o dwóch wierzchołkach jest, po odwróceniu orientacji, taką EAC;
jedynym jej wystąpieniem jest \(C=\{3,13\}\) przy \(N=2200\). Dla
\(N=2200\) mamy \(x=1100\), \(p_0=1103\) i \(m_0=1097\), liczbę
\emph{pierwszą}: minimalny start kończy się natychmiastowym sukcesem, więc
\(N=2200\) nie jest porażką.
\end{proof}
```
