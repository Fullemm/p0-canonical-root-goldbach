---
id: BIBLIA-L03922-SFORMUOWANIE-PRZEZ-S-H-JEST-ZBEDNIE-SABE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3922
line_end: 3928
env: remark
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Sformułowanie przez (S_h) jest zbędnie słabe

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3922-3928`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Terminalny rdzeń rozmiaru dwa nie istnieje w porażce
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Sformułowanie przez (S_h) jest zbędnie słabe] Kuszące jest wyprowadzenie tezy z obserwacji, że dla (N=2200) zachodzi (S_h=3,1097), a więc (3,13 S_h). Taki wywód daje jedynie ,,brak rdzenia rozmiaru (2) wewnątrz (S_h)''. Istotny jest inny fakt: (N=2200) w ogóle nie jest porażką, co wyklucza rozmiar (2) globalnie. Należy używać mocniejszej wersji. [title=Niezależna kontrola klasyfikacji rozmiaru 2]experiment

## Exact source transcript

```tex
\begin{remark}[Sformułowanie przez \(S_h\) jest zbędnie słabe]
\CORRECTED\ Kuszące jest wyprowadzenie tezy z obserwacji, że dla
\(N=2200\) zachodzi \(S_h=\{3,1097\}\), a więc \(\{3,13\}\not\subseteq S_h\).
Taki wywód daje jedynie ,,brak rdzenia rozmiaru \(2\) \emph{wewnątrz}
\(S_h\)''. Istotny jest inny fakt: \(N=2200\) w ogóle nie jest porażką,
co wyklucza rozmiar \(2\) globalnie. Należy używać mocniejszej wersji.
\end{remark}
```
