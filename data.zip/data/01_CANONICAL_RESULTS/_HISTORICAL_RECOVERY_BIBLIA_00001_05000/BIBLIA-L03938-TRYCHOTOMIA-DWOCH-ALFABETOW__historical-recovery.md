---
id: BIBLIA-L03938-TRYCHOTOMIA-DWOCH-ALFABETOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3938
line_end: 3964
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Trychotomia dwóch alfabetów

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3938-3964`
- Original label: `thm:atak-trichotomy`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Terminalny rdzeń rozmiaru dwa nie istnieje w porażce
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Trychotomia dwóch alfabetów] Załóżmy (m_0 h^2). Zachodzi co najmniej jedna z możliwości: [label=( )] ekspansja: istnieją (p S_h) i pierwsza (r N-p) z (r S_h); sukces: istnieje (p S_h), dla którego (N-p) jest pierwsza --- wtedy (N=p+(N-p)) jest reprezentacją Goldbacha dla (N), niezależnie od osiągalności (p) z (p_0);

## Exact source transcript

```tex
\begin{theorem}[Trychotomia dwóch alfabetów]
\label{thm:atak-trichotomy}
Załóżmy \(m_0\ge h^2\). Zachodzi co najmniej jedna z możliwości:
\begin{enumerate}[label=(\alph*)]
  \item \textbf{ekspansja:} istnieją \(p\in S_h\) i pierwsza \(r\mid N-p\)
  z \(r\notin S_h\);
  \item \textbf{sukces:} istnieje \(p\in S_h\), dla którego \(N-p\) jest
  pierwsza --- wtedy \(N=p+(N-p)\) jest reprezentacją Goldbacha dla \(N\),
  niezależnie od osiągalności \(p\) z \(p_0\);
  \item \textbf{rdzeń:} istnieje terminalna zła SCC \(C\subseteq S_h\)
  o \(\abs C\ge3\).
\end{enumerate}
\end{theorem}

\begin{proof}
Załóżmy, że (a) nie zachodzi; wtedy \(S_h\) jest domknięty na wszystkie
dzieci, więc podgraf indukowany przez \(S_h\) jest domknięty również
w pełnym grafie. Jeżeli któryś \(p\in S_h\) jest dobry, zachodzi (b).

W przeciwnym razie wszystkie wierzchołki \(S_h\) są złe. Kondensacja
skończonego grafu ma ujście \(C\). Ujście jednowierzchołkowe wymagałoby
albo braku dzieci --- niemożliwe, bo wiersz złego wierzchołka jest złożony
i ma czynnik pierwszy, leżący w \(S_h\) na mocy domknięcia --- albo pętli
\(p\to p\), czyli \(p\mid N\), wbrew aktywności. Zatem \(\abs C\ge2\).
Domknięcie czyni \(C\) terminalną w pełnym grafie, więc \(C\) jest EAC po
odwróceniu orientacji, a \cref{thm:atak-no-two} wyklucza \(\abs C=2\).
\end{proof}
```
