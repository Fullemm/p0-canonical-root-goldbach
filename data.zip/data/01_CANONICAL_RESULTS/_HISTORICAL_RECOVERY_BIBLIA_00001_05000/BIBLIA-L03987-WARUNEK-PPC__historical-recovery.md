---
id: BIBLIA-L03987-WARUNEK-PPC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3987
line_end: 3992
env: definition
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Warunek (PPC)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3987-3992`
- Original label: `def:ppc`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Warunek (PPC)] Terminalna zła SCC (C), ( C=s 2), spełnia warunek cyklu czystych potęg (PPC), jeżeli dla każdego (p C) wiersz (N-p) jest potęgą jednej liczby pierwszej. [Normalizacja]

## Exact source transcript

```tex
\begin{definition}[Warunek (PPC)]
\label{def:ppc}
Terminalna zła SCC \(C\), \(\abs C=s\ge2\), spełnia warunek \emph{cyklu
czystych potęg} (PPC), jeżeli dla każdego \(p\in C\) wiersz \(N-p\) jest
potęgą jednej liczby pierwszej.
\end{definition}
```
