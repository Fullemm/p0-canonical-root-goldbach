---
id: BIBLIA-L03994-NORMALIZACJA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 3994
line_end: 4020
env: lemma
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Normalizacja

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:3994-4020`
- Original label: `lem:ppc-normal`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Normalizacja] Przy (PPC) składowa (C) jest pojedynczym cyklem skierowanym; można zapisać (C=p_1, ,p_s) tak, że [ N-p_i-1=p_i^a_i, a_i 2, i /s , ]

## Exact source transcript

```tex
\begin{lemma}[Normalizacja]
\label{lem:ppc-normal}
Przy (PPC) składowa \(C\) jest pojedynczym cyklem skierowanym; można
zapisać \(C=\{p_1,\ldots,p_s\}\) tak, że
\[
  N-p_{i-1}=p_i^{a_i},
  \qquad a_i\ge2,
  \qquad i\in\Z/s\Z,
\]
i wtedy
\[
  \left(\tfrac{2N}{3}\right)^{1/a_i}<p_i<N^{1/a_i},
  \qquad
  \max_i p_i<\sqrt N .
  \tag{PP1}
\]
\end{lemma}

\begin{proof}
Terminalność daje \(\PF(N-p)\subseteq C\), a (PPC) --- że ten zbiór jest
jednoelementowy, czyli stopień wyjściowy każdego wierzchołka wynosi \(1\).
Skończony digraf silnie spójny o wszystkich stopniach wyjściowych \(1\)
jest jednym cyklem. Wykładnik \(a_i\ge2\), bo wiersz złego wierzchołka jest
złożony. Każde \(p_i\) jest właściwym czynnikiem pierwszym nieparzystej
liczby złożonej \(N-p_{i-1}<N\), więc \(p_i<N/3\); stąd
\(p_i^{a_i}=N-p_{i-1}>2N/3\) i (PP1).
\end{proof}
```
