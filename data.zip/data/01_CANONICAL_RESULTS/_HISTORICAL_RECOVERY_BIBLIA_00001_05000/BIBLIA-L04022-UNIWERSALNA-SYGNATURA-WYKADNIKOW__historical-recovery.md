---
id: BIBLIA-L04022-UNIWERSALNA-SYGNATURA-WYKADNIKOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4022
line_end: 4061
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Uniwersalna sygnatura wykładników

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4022-4061`
- Original label: `thm:atak-universal-signature`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Uniwersalna sygnatura wykładników] Przy (PPC) wykładniki (a_1, ,a_s) są parami różne i parami względnie pierwsze, oraz [ a_i>a_j p_i<p_j . ]

## Exact source transcript

```tex
\begin{theorem}[Uniwersalna sygnatura wykładników]
\label{thm:atak-universal-signature}
Przy (PPC) wykładniki \(a_1,\ldots,a_s\) są parami różne i parami względnie
pierwsze, oraz
\[
  a_i>a_j
  \quad\Longleftrightarrow\quad
  p_i<p_j .
\]
\end{theorem}

\begin{proof}
Dla \(i\ne j\) odjęcie równań normalizacji daje kluczową tożsamość
\[
  p_i^{a_i}-p_j^{a_j}=p_{j-1}-p_{i-1},
  \qquad\text{a więc}\qquad
  0<\abs{p_i^{a_i}-p_j^{a_j}}<\max_k p_k<\sqrt N .
  \tag{PP2}
\]

\emph{Różność.} Gdyby \(a_i=a_j=a\ge2\) i \(p_i>p_j\), to
\[
  p_i^{a}-p_j^{a}\ge(p_i-p_j)\,a\,p_j^{a-1}
  \ge2a\,\frac{p_j^{a}}{p_j}
  >2a\cdot\frac{2N/3}{\sqrt N}\ge\frac83\sqrt N,
\]
wbrew (PP2).

\emph{Względna pierwszość.} Niech \(d=\gcd(a_i,a_j)\ge2\),
\(X=p_i^{a_i/d}\), \(Y=p_j^{a_j/d}\); wtedy \(X^d,Y^d\in(2N/3,N)\) i
\(X\ne Y\), bo są potęgami różnych pierwszych. Dla \(X>Y\)
\[
  X^d-Y^d\ge d\,Y^{d-1}=d\,\frac{Y^d}{Y}
  >d\cdot\frac{2N/3}{N^{1/d}}\ge\frac43\sqrt N,
\]
bo \(Y<N^{1/d}\le\sqrt N\); znowu sprzeczność z (PP2).

\emph{Odwrócenie porządku.} Gdyby \(a_i>a_j\) i \(p_i\ge p_j\), to
\(N>p_i^{a_i}\ge p_j^{a_j+1}>\tfrac{2N}{3}\cdot3=2N\).
\end{proof}
```
