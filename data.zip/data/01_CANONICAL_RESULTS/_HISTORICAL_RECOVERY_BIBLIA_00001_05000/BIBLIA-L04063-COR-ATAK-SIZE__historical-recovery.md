---
id: BIBLIA-L04063-COR-ATAK-SIZE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4063
line_end: 4068
env: remark
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# cor:atak-size

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4063-4068`
- Original label: `cor:atak-size`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

thm:coprime-hyperbolic jest szczególnym przypadkiem (s=3), (C Q), brak chordów. Powyższy dowód nie używa (abc m_0), współczynników ( , , ) ani porządku ( < ); wynika z jednej tożsamości (PP2). [Bezwarunkowy bound na rozmiar rdzenia]

## Exact source transcript

```tex
\begin{remark}
\cref{thm:coprime-hyperbolic} jest szczególnym przypadkiem \(s=3\),
\(C\subseteq Q\), brak chordów. Powyższy dowód nie używa \(abc\mid m_0\),
współczynników \(\lambda,\mu,\nu\) ani porządku \(\mu\le\nu<\lambda\);
wynika z jednej tożsamości (PP2).
\end{remark}
```
