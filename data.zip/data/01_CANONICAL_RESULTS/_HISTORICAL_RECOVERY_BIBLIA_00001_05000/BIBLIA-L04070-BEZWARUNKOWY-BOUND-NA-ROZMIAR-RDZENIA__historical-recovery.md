---
id: BIBLIA-L04070-BEZWARUNKOWY-BOUND-NA-ROZMIAR-RDZENIA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4070
line_end: 4081
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Bezwarunkowy bound na rozmiar rdzenia

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4070-4081`
- Original label: `cor:atak-size`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Bezwarunkowy bound na rozmiar rdzenia] Przy (PPC) (;s ( N/ 3) N/ N). Dla (N 10^18) daje to (s 12). Z (3 p_i) i (p_i^a_i<N) wynika (a_i<A:= N/ 3). Liczby (a_i [2,A]) są parami względnie pierwsze, więc ich niepuste zbiory

## Exact source transcript

```tex
\begin{corollary}[Bezwarunkowy bound na rozmiar rdzenia]
\label{cor:atak-size}
Przy (PPC) \(\;s\le\pi(\log N/\log3)\ll\log N/\log\log N\). Dla
\(N\le10^{18}\) daje to \(s\le12\).
\end{corollary}

\begin{proof}
Z \(3\le p_i\) i \(p_i^{a_i}<N\) wynika \(a_i<A:=\log N/\log3\). Liczby
\(a_i\in[2,A]\) są parami względnie pierwsze, więc ich niepuste zbiory
czynników pierwszych są parami rozłączne, a każdy zawiera pierwszą
\(\le A\).
\end{proof}
```
