---
id: BIBLIA-L04083-HIPERBOLICZNOSC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4083
line_end: 4092
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Hiperboliczność

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4083-4092`
- Original label: `cor:atak-hyperbolic`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Hiperboliczność] Jeżeli dodatkowo (C Q), to ( _i1/a_i< (N/2)/ (2N/3)<1). Różne (p_i) dzielą (m_0), więc ( _ip_i m_0<N/2); z (PP1) ( _ip_i>(2N/3)^ 1/a_i).

## Exact source transcript

```tex
\begin{corollary}[Hiperboliczność]
\label{cor:atak-hyperbolic}
Jeżeli dodatkowo \(C\subseteq Q\), to
\(\sum_i1/a_i<\log(N/2)/\log(2N/3)<1\).
\end{corollary}

\begin{proof}
Różne \(p_i\) dzielą \(m_0\), więc \(\prod_ip_i\le m_0<N/2\); z (PP1)
\(\prod_ip_i>(2N/3)^{\sum1/a_i}\).
\end{proof}
```
