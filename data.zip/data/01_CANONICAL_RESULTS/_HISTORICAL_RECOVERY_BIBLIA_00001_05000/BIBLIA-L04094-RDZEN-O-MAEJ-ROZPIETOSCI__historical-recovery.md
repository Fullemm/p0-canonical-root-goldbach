---
id: BIBLIA-L04094-RDZEN-O-MAEJ-ROZPIETOSCI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4094
line_end: 4102
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Rdzeń o małej rozpiętości

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4094-4102`
- Original label: `cor:atak-narrow`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Rdzeń o małej rozpiętości] Każda terminalna zła SCC z ( C<3 C) spełnia (PPC) na mocy lem:indegree-diameter, a więc podlega thm:atak-universal-signature i cor:atak-size. Analogicznie terminalny rdzeń (C R_h) rozmiaru (2) z prop:gap-alphabet-core(3) ma wykładniki różne i względnie pierwsze --- czego ta propozycja nie stwierdza.

## Exact source transcript

```tex
\begin{corollary}[Rdzeń o małej rozpiętości]
\label{cor:atak-narrow}
Każda terminalna zła SCC z \(\max C<3\min C\) spełnia (PPC) na mocy
\cref{lem:indegree-diameter}, a więc podlega
\cref{thm:atak-universal-signature} i \cref{cor:atak-size}. Analogicznie
terminalny rdzeń \(C\subseteq R_h\) rozmiaru \(2\) z
\cref{prop:gap-alphabet-core}(3) ma wykładniki różne i względnie pierwsze
--- czego ta propozycja nie stwierdza.
\end{corollary}
```
