---
id: BIBLIA-L04104-UNIWERSALNY-FILTR-MODULO-8-I-3
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4104
line_end: 4124
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Uniwersalny filtr modulo (8) i (3)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4104-4124`
- Original label: `thm:atak-local`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Uniwersalny filtr modulo (8) i (3)] Przy (PPC) co najwyżej jeden wykładnik jest parzysty; jeżeli istnieje, oznaczmy jego indeks przez (J). Wtedy [ N& p_i-1+p_i 8 && dla i J, N& p_J-1+1 8 && jeżeli J istnieje,

## Exact source transcript

```tex
\begin{theorem}[Uniwersalny filtr modulo \(8\) i \(3\)]
\label{thm:atak-local}
Przy (PPC) co najwyżej jeden wykładnik jest parzysty; jeżeli istnieje,
oznaczmy jego indeks przez \(J\). Wtedy
\[
\begin{aligned}
  N&\equiv p_{i-1}+p_i \pmod 8 &&\text{dla } i\ne J,\\
  N&\equiv p_{J-1}+1 \pmod 8 &&\text{jeżeli } J \text{ istnieje,}
\end{aligned}
\]
i te same kongruencje modulo \(3\), o ile \(3\notin C\). Jeżeli wszystkie
wykładniki są nieparzyste, to \(p_{i+1}\equiv p_{i-1}\pmod8\) dla każdego
\(i\); przy nieparzystym \(s\) daje to jedną klasę reszt dla całego \(C\).
\end{theorem}

\begin{proof}
Dla nieparzystego \(z\) mamy \(z^2\equiv1\pmod8\), więc \(z^a\equiv z\) dla
\(a\) nieparzystego i \(z^a\equiv1\) dla \(a\) parzystego. Podstawienie do
\(N-p_{i-1}=p_i^{a_i}\) daje obie kongruencje; modulo \(3\) korzystamy
z \(z^2\equiv1\) dla \(z\not\equiv0\).
\end{proof}
```
