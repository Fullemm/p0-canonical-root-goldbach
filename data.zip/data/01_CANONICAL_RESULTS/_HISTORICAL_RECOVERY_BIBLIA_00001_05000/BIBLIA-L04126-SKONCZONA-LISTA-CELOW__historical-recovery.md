---
id: BIBLIA-L04126-SKONCZONA-LISTA-CELOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4126
line_end: 4139
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Skończona lista celów

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4126-4139`
- Original label: `cor:atak-signature-list`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Cykle czystych potęg w pełnej ogólności
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Skończona lista celów] Sygnatury dopuszczalne przez thm:atak-universal-signature i cor:atak-hyperbolic, uporządkowane według maksymalnego wykładnika: [ s=2:& (2,3),(3,4),(2,5),(3,5),(4,5),(5,6),(2,7),(3,7), s=3:& (3,4,5),(2,3,7),(2,5,7),(3,4,7),(3,5,7),(4,5,7), s=4:& (3,4,5,7),(3,5,7,8),(2,5,7,9),(4,5,7,9),

## Exact source transcript

```tex
\begin{corollary}[Skończona lista celów]
\label{cor:atak-signature-list}
Sygnatury dopuszczalne przez \cref{thm:atak-universal-signature} i
\cref{cor:atak-hyperbolic}, uporządkowane według maksymalnego wykładnika:
\[
\begin{aligned}
 s=2:&\ (2,3),(3,4),(2,5),(3,5),(4,5),(5,6),(2,7),(3,7),\ldots\\
 s=3:&\ (3,4,5),(2,3,7),(2,5,7),(3,4,7),(3,5,7),(4,5,7),\ldots\\
 s=4:&\ (3,4,5,7),(3,5,7,8),(2,5,7,9),(4,5,7,9),\ldots\\
 s=5:&\ (3,5,7,8,11),(4,5,7,9,11),(5,7,8,9,11),\ldots
\end{aligned}
\]
Dla \(s\ge4\) celem minimalnym jest \((3,4,5,7)\).
\end{corollary}
```
