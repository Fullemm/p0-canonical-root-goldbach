---
id: BIBLIA-L04152-NORMALNA-POSTAC-KWADRATOWEGO-WIERSZA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4152
line_end: 4170
env: lemma
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Normalna postać kwadratowego wiersza

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `lemma`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4152-4170`
- Original label: `lem:atak-square-normal`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Square-Shadow Gap: wykluczenie sygnatur z wykładnikiem (2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Normalna postać kwadratowego wiersza] Zapiszmy (m_0=abcM). Niech ( ) będzie współczynnikiem shadow wiersza będącego kwadratem, to znaczy ( -a= c) w orientacji (b a c b), a ( -b= c) w orientacji (a b c a). W obu przypadkach [ c=2abM+ , a więc

## Exact source transcript

```tex
\begin{lemma}[Normalna postać kwadratowego wiersza]
\label{lem:atak-square-normal}
Zapiszmy \(m_0=abcM\). Niech \(\mu\) będzie współczynnikiem shadow wiersza
będącego kwadratem, to znaczy \(\delta-a=\mu c\) w orientacji
\(b\to a\to c\to b\), a \(\delta-b=\mu c\) w orientacji
\(a\to b\to c\to a\). W obu przypadkach
\[
  c=2abM+\mu,
  \qquad\text{a więc}\qquad
  c\equiv\mu \pmod{ab}.
\]
\end{lemma}

\begin{proof}
Niech \(w\) oznacza wierzchołek, którego wiersz jest kwadratem
(\(w=a\), odpowiednio \(w=b\)). Z \(N=2m_0+\delta\) mamy
\(N-w=2abcM+(\delta-w)=2abcM+\mu c=c(2abM+\mu)\). Jednocześnie
\(N-w=c^2\); podzielenie przez \(c\) kończy dowód.
\end{proof}
```
