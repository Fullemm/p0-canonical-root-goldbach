---
id: BIBLIA-L04172-SQUARE-SHADOW-GAP
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4172
line_end: 4214
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Square-Shadow Gap

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4172-4214`
- Original label: `thm:atak-sg`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Square-Shadow Gap: wykluczenie sygnatur z wykładnikiem (2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Square-Shadow Gap] W obu orientacjach [ ^2 a+b, a zatem h> c2 a+b> c2 b . SG ]

## Exact source transcript

```tex
\begin{theorem}[Square-Shadow Gap]
\label{thm:atak-sg}
W obu orientacjach
\[
  \mu^2\ge a+b,
  \qquad\text{a zatem}\qquad
  h>\frac c2\sqrt{a+b}>\frac c2\sqrt b .
  \tag{SG}
\]
\end{theorem}

\begin{proof}
\emph{Orientacja \(b\to a\to c\to b\)}, czyli
\(N-a=c^2\), \(N-b=a^\gamma\), \(N-c=b^\eta\).
Z \(N-c=b^\eta\) mamy \(N\equiv c\pmod b\), więc
\(c^2=N-a\equiv c-a\pmod b\), czyli \(b\mid c^2-c+a\), a po podstawieniu
\(c\equiv\mu\pmod b\) z \cref{lem:atak-square-normal}
\[
  b\mid\mu^2-\mu+a .
\]
Liczba \(\mu^2-\mu+a\) jest dodatnia dla każdego \(\mu\ge1\), więc
\(\mu^2-\mu+a\ge b\) i stąd \(\mu^2>b-a\).

Z \(N-b=a^\gamma\) mamy \(N\equiv b\pmod a\), więc
\(c^2=N-a\equiv b\pmod a\) i \(c\equiv\mu\pmod a\) dają
\[
  a\mid\mu^2-b .
\]
Równość \(\mu^2=b\) jest niemożliwa, bo \(b\) jest pierwsza. Gdyby
\(\mu^2<b\), to \(0<b-\mu^2<b\) i \(a\mid b-\mu^2\) wymuszałoby
\(b-\mu^2\ge a\), czyli \(\mu^2\le b-a\) --- sprzeczność z poprzednim
akapitem. Zatem \(\mu^2>b\), a \(a\mid\mu^2-b>0\) daje \(\mu^2\ge a+b\).

\emph{Orientacja \(a\to b\to c\to a\)}, czyli
\(N-a=b^\eta\), \(N-b=c^2\), \(N-c=a^\gamma\).
Z \(N-a=b^\eta\) mamy \(N\equiv a\pmod b\), więc
\(c^2=N-b\equiv a\pmod b\) i \(b\mid\mu^2-a\). Równość \(\mu^2=a\) jest
niemożliwa (\(a\) pierwsza), a \(\mu^2<a\) dawałoby \(0<a-\mu^2<b\), co
przeczy podzielności. Zatem \(\mu^2-a\ge b\).

W obu przypadkach \(2h=\delta\ge\mu c\) (bo \(\delta=w+\mu c>\mu c\)), więc
\(h>\mu c/2\ge\tfrac c2\sqrt{a+b}\).
\end{proof}
```
