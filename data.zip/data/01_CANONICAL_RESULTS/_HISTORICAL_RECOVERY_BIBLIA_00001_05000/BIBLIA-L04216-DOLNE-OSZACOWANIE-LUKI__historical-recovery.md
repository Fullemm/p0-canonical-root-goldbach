---
id: BIBLIA-L04216-DOLNE-OSZACOWANIE-LUKI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4216
line_end: 4231
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Dolne oszacowanie luki

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4216-4231`
- Original label: `cor:atak-lb`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Square-Shadow Gap: wykluczenie sygnatur z wykładnikiem (2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Dolne oszacowanie luki] Przy założeniach tego rozdziału [ h> 12 ( 23 )^ 12+ 12 N^ 12+ 12 . LB ]

## Exact source transcript

```tex
\begin{corollary}[Dolne oszacowanie luki]
\label{cor:atak-lb}
Przy założeniach tego rozdziału
\[
  h>\frac12\left(\frac23\right)^{\frac12+\frac1{2\eta}}
      N^{\frac12+\frac1{2\eta}} .
  \tag{LB}
\]
\end{corollary}

\begin{proof}
Każdy wierzchołek terminalnej złej SCC jest mniejszy od \(N/3\), więc
\(c^2=N-a>2N/3\) i \(b^\eta=N-c>2N/3\), czyli \(c>(2N/3)^{1/2}\) i
\(b>(2N/3)^{1/\eta}\). Wstawienie do (SG) w postaci \(h>\tfrac c2\sqrt b\)
daje tezę.
\end{proof}
```
