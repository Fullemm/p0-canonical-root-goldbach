---
id: BIBLIA-L04233-WYKLUCZENIE-RODZINY-2
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4233
line_end: 4243
env: theorem
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Wykluczenie rodziny ((2, , ))

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4233-4243`
- Original label: `thm:atak-exclusion`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Square-Shadow Gap: wykluczenie sygnatur z wykładnikiem (2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Wykluczenie rodziny ((2, , ))] Z Baker--Harman--Pintza (h N^0.525) dla dostatecznie dużych (N) . Ponieważ ( 12+ 12 >0.525 <20), dla każdego nieparzystego ( 19) warunek (LB) jest sprzeczny z BHP przy dostatecznie dużym (N). Zatem dla dostatecznie dużych (N) nie istnieje bezchordowy terminalny trójkąt (C Q) o sygnaturze ((2, , )) z ( 19). Pierwszą sygnaturą nieusuniętą tą metodą jest

## Exact source transcript

```tex
\begin{theorem}[Wykluczenie rodziny \((2,\eta,\gamma)\)]
\label{thm:atak-exclusion}
\LITERATURE\ Z Baker--Harman--Pintza \(h\ll N^{0.525}\) dla dostatecznie
dużych \(N\) \cite{BHP2001}. Ponieważ
\(\tfrac12+\tfrac1{2\eta}>0.525\iff\eta<20\), dla każdego nieparzystego
\(\eta\le19\) warunek (LB) jest sprzeczny z BHP przy dostatecznie dużym
\(N\). Zatem dla dostatecznie dużych \(N\) nie istnieje bezchordowy
terminalny trójkąt \(C\subseteq Q\) o sygnaturze \((2,\eta,\gamma)\)
z \(\eta\le19\). Pierwszą sygnaturą nieusuniętą tą metodą jest
\((2,21,\gamma)\).
\end{theorem}
```
