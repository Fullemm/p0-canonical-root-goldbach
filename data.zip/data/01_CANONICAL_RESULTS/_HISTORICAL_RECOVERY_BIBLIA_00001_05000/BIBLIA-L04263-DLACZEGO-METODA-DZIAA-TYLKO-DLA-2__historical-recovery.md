---
id: BIBLIA-L04263-DLACZEGO-METODA-DZIAA-TYLKO-DLA-2
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4263
line_end: 4272
env: remark
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Dlaczego metoda działa tylko dla ( =2)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4263-4272`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Square-Shadow Gap: wykluczenie sygnatur z wykładnikiem (2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Dlaczego metoda działa tylko dla ( =2)] Ten sam rachunek dla ogólnego ( ) daje (c^ -1 ab) i, po podniesieniu relacji (b c( -1)+a) do potęgi ( -1), oszacowanie rzędu ( b^1/ ), a więc (h N^1/ +1/( )). Dla ( 3) wykładnik nie przekracza (1/3+1/9<0.45) i nie może przeciąć bariery (0.525). Mechanizm jest więc ściśle związany z barierą pierwiastkową: działa dokładnie wtedy, gdy najmniejszy wykładnik wynosi (2), bo tylko wt

## Exact source transcript

```tex
\begin{remark}[Dlaczego metoda działa tylko dla \(\beta=2\)]
\WORKING\ Ten sam rachunek dla ogólnego \(\beta\) daje
\(c^{\beta-1}\equiv\mu\pmod{ab}\) i, po podniesieniu relacji
\(b\mid c(\mu-1)+a\) do potęgi \(\beta-1\), oszacowanie rzędu
\(\mu\gg b^{1/\beta}\), a więc \(h\gg N^{1/\beta+1/(\beta\eta)}\). Dla
\(\beta\ge3\) wykładnik nie przekracza \(1/3+1/9<0.45\) i nie może
przeciąć bariery \(0.525\). Mechanizm jest więc ściśle związany
z barierą pierwiastkową: działa dokładnie wtedy, gdy najmniejszy wykładnik
wynosi \(2\), bo tylko wtedy \(c\asymp\sqrt N\).
\end{remark}
```
