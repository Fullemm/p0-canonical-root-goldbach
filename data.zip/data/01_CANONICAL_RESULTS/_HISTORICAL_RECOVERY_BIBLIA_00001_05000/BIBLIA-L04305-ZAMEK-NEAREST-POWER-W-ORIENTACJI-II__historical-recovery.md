---
id: BIBLIA-L04305-ZAMEK-NEAREST-POWER-W-ORIENTACJI-II
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4305
line_end: 4328
env: proposition
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Zamek nearest-power w orientacji II

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4305-4328`
- Original label: `prop:atak-lock-II`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Luka orientacji uporządkowanego trójkąta
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Zamek nearest-power w orientacji II] W orientacji II zachodzi (a^ <c^ <b^ ) oraz [ b= a^ / , c= a^ / , ] dla wszystkich dostatecznie dużych (a). Dla sygnatury ((3,4,5)) daje to

## Exact source transcript

```tex
\begin{proposition}[Zamek nearest-power w orientacji II]
\label{prop:atak-lock-II}
W orientacji II zachodzi \(a^\gamma<c^\beta<b^\eta\) oraz
\[
  b=\ceil{a^{\gamma/\eta}},
  \qquad
  c=\ceil{a^{\gamma/\beta}},
\]
dla wszystkich dostatecznie dużych \(a\). Dla sygnatury \((3,4,5)\) daje to
\(b=\ceil{a^{5/4}}\) i \(c=\ceil{a^{5/3}}\) --- wobec
\(b=\floor{a^{5/4}}\), \(c=\ceil{a^{5/3}}\) z \cref{thm:nearest-lock}.
\end{proposition}

\begin{proof}
Z trzech postaci \(N\): \(b^\eta-a^\gamma=c-a>0\),
\(c^\beta-a^\gamma=c-b>0\) i \(b^\eta-c^\beta=b-a>0\), co daje
uporządkowanie. Ponieważ \(\gcd(\eta,\gamma)=1\), liczba \(a^\gamma\) nie
jest \(\eta\)-tą potęgą, więc \(b\ge\ceil{a^{\gamma/\eta}}=:m\). Gdyby
\(b\ge m+1\), to \(b^\eta-a^\gamma>\eta m^{\eta-1}\asymp a^{\gamma(\eta-1)/\eta}\),
podczas gdy \(c-a<c\asymp a^{\gamma/\beta}\); nierówność
\(\beta(\eta-1)>\eta\) zachodzi dla \(\beta\ge2,\eta\ge3\), więc dla dużych
\(a\) jest to niemożliwe. Analogicznie dla \(c\), z
\(c^\beta-a^\gamma=c-b<c\) i \(\beta m'^{\beta-1}\ge2m'>c\).
\end{proof}
```
