---
id: BIBLIA-L04330-FILTRY-LOKALNE-OBU-ORIENTACJI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4330
line_end: 4350
env: corollary
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Filtry lokalne obu orientacji

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4330-4350`
- Original label: `cor:atak-orientation-filters`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Luka orientacji uporządkowanego trójkąta
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Filtry lokalne obu orientacji] Dla sygnatury ((3,4,5)) thm:atak-local daje [ orientacja I: & a 1, b c 24, orientacja II: & c 1, a b 24. ]

## Exact source transcript

```tex
\begin{corollary}[Filtry lokalne obu orientacji]
\label{cor:atak-orientation-filters}
Dla sygnatury \((3,4,5)\) \cref{thm:atak-local} daje
\[
\begin{aligned}
 \text{orientacja I: }&\quad a\equiv1,\quad b\equiv c\pmod{24},\\
 \text{orientacja II: }&\quad c\equiv1,\quad a\equiv b\pmod{24}.
\end{aligned}
\]
W orientacji I odzyskujemy \cref{thm:local-congruences}. W orientacji II
warunek jednostkowy dotyczy \emph{największej} bazy, więc nie redukuje
przestrzeni przeszukiwania po parametrze \(a\) --- praktyczna różnica przy
projektowaniu skanu.
\end{corollary}

\begin{proof}
Jedynym parzystym wykładnikiem jest \(4\), przy bazie \(b\). W orientacji I
poprzednikiem \(b\) w cyklu jest \(c\), w orientacji II --- \(a\).
Podstawienie do \cref{thm:atak-local} i połączenie z analogicznymi
kongruencjami modulo \(3\) daje tezę.
\end{proof}
```
