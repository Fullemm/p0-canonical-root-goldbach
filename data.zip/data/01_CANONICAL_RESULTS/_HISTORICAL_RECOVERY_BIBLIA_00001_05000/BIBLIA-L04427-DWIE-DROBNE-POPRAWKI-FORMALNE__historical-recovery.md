---
id: BIBLIA-L04427-DWIE-DROBNE-POPRAWKI-FORMALNE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4427
line_end: 4439
env: remark
visibility_class: RECOVERY_PRIORITY_MEDIUM
recovery_priority: MEDIUM
---

# Dwie drobne poprawki formalne

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4427-4439`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Nietrywialne SCC przejściowe naprawdę występują
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_MEDIUM**
- Recovery priority: **MEDIUM**

## Extracted historical synopsis

[Dwie drobne poprawki formalne] Po pierwsze: dla aktywnej (p) każdy czynnik pierwszy (N-p) jest automatycznie aktywny (gdyby (q N) i (q N-p), to (q p), więc (q=p) i (p N)). Filtr N % q != 0 w algorytmie referencyjnym nigdy się nie uruchamia; częścią poprawności jest wyłącznie rozdzielenie seen/ queued. Po drugie: wierzchołek (p=N-1) (gdy pierwszy) ma wiersz (N-p=1), a więc zero aktywnych dzieci, i formalnie tworzy je

## Exact source transcript

```tex
\begin{remark}[Dwie drobne poprawki formalne]
\CORRECTED\ Po pierwsze: dla \emph{aktywnej} \(p\) każdy czynnik pierwszy
\(N-p\) jest automatycznie aktywny (gdyby \(q\mid N\) i \(q\mid N-p\), to
\(q\mid p\), więc \(q=p\) i \(p\mid N\)). Filtr \texttt{N \% q != 0}
w algorytmie referencyjnym nigdy się nie uruchamia; częścią poprawności
jest wyłącznie rozdzielenie \texttt{seen}/\texttt{queued}. Po drugie:
wierzchołek \(p=N-1\) (gdy pierwszy) ma wiersz \(N-p=1\), a więc zero
aktywnych dzieci, i formalnie tworzy jednowierzchołkowe ujście terminalne;
argument ,,singleton niemożliwy, bo pętla \(r\to r\) implikuje \(r\mid N\)''
wyklucza tylko singleton z pętlą. Wierzchołek ten jest nieosiągalny, ale
bez konwencji \(N-p\ge2\) skrypty raportują fałszywe drugie ujście dla
\(N=128\) i \(N=1862\).
\end{remark}
```
