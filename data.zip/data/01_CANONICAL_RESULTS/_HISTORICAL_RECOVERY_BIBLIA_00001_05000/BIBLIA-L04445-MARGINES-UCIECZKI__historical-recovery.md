---
id: BIBLIA-L04445-MARGINES-UCIECZKI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4445
line_end: 4449
env: definition
visibility_class: HISTORICAL_VISIBLE_UNCLASSIFIED
recovery_priority: NORMAL
---

# Margines ucieczki

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `definition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4445-4449`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Ile naprawdę wart jest minimalny start
- Visibility classification from Audit 1/10: **HISTORICAL_VISIBLE_UNCLASSIFIED**
- Recovery priority: **NORMAL**

## Extracted historical synopsis

[Margines ucieczki] Dla startu (p) niech ( _ esc(p)) będzie minimalną liczbą krawędzi, których usunięcie z ( (p)) odcina (p) od wszystkich dobrych wierzchołków. [title=Ochrona jest realna, ale minimalna]experiment Dla czterech znanych (N) z EAC, w których (m_0) jest złożone:

## Exact source transcript

```tex
\begin{definition}[Margines ucieczki]
Dla startu \(p\) niech \(\mu_{\mathrm{esc}}(p)\) będzie minimalną liczbą
krawędzi, których usunięcie z \(\Reach(p)\) odcina \(p\) od wszystkich
dobrych wierzchołków.
\end{definition}
```
