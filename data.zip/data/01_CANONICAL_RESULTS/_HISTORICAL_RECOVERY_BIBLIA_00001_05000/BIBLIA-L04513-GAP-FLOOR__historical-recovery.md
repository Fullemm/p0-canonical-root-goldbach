---
id: BIBLIA-L04513-GAP-FLOOR
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4513
line_end: 4533
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Gap Floor

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4513-4533`
- Original label: `thm:atak-gapfloor`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Podłoga luki
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Gap Floor] Niech (C Q) będzie terminalną złą SCC, ( C=s 3), bezchordową, a ( ) najmniejszym wykładnikiem, przy największej bazie (c= C). Wtedy [ h> 32,c> 32 ( 2N3 )^1/ . ] W szczególności

## Exact source transcript

```tex
\begin{theorem}[Gap Floor]
\label{thm:atak-gapfloor}
Niech \(C\subseteq Q\) będzie terminalną złą SCC, \(\abs C=s\ge3\),
bezchordową, a \(\beta\) najmniejszym wykładnikiem, przy największej bazie
\(c=\max C\). Wtedy
\[
  h>\frac32\,c>\frac32\left(\frac{2N}{3}\right)^{1/\beta}.
\]
W szczególności
\[
  \beta=2
  \quad\Longrightarrow\quad
  h>\frac32\sqrt{\frac{2N}{3}}>1{,}2247\sqrt N .
\]
\end{theorem}

\begin{proof}
Z \cref{cor:qcore-compression} zachodzi \(C\subset(0,2h/3)\), czyli
\(c<2h/3\). Bezchordowość daje \(c^\beta=N-p\) dla poprzednika \(p\) bazy
\(c\), a \(p<N/3\), więc \(c^\beta>2N/3\).
\end{proof}
```
