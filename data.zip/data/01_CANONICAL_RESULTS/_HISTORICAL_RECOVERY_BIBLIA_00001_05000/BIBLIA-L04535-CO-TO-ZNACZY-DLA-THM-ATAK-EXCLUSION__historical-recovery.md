---
id: BIBLIA-L04535-CO-TO-ZNACZY-DLA-THM-ATAK-EXCLUSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4535
line_end: 4549
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Co to znaczy dla thm:atak-exclusion

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4535-4549`
- Original label: `rem:atak-optimality`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Podłoga luki
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Co to znaczy dla thm:atak-exclusion] thm:atak-gapfloor daje (h N^1/2) za darmo, bez żadnego rachunku kongruencyjnego. Square-Shadow Gap ( thm:atak-sg) poprawia to do (h N^1/2+1/(2 )), a więc jego jedyną rolą jest wspinaczka powyżej bariery pierwiastkowej. Ponieważ ( ) może być dowolnie duże, domknięcie całej gałęzi ( =2) wymagałoby bezwarunkowego wykładnika luk pierwszych mniejszego niż ( 12+ 12 ) dla każdego ( ), c

## Exact source transcript

```tex
\begin{remark}[Co to znaczy dla \cref{thm:atak-exclusion}]
\label{rem:atak-optimality}
\cref{thm:atak-gapfloor} daje \(h\gg N^{1/2}\) \emph{za darmo}, bez żadnego
rachunku kongruencyjnego. Square-Shadow Gap
(\cref{thm:atak-sg}) poprawia to do \(h\gg N^{1/2+1/(2\eta)}\), a więc jego
jedyną rolą jest \emph{wspinaczka powyżej bariery pierwiastkowej}. Ponieważ
\(\eta\) może być dowolnie duże, domknięcie całej gałęzi \(\beta=2\)
wymagałoby bezwarunkowego wykładnika luk pierwszych mniejszego niż
\(\tfrac12+\tfrac1{2\eta}\) dla każdego \(\eta\), czyli w praktyce
\(\tfrac12+o(1)\). Jest to poza Baker--Harman--Pintzem
(\(0{,}525\)), poza preprintem Li (\(0{,}52\)) i --- o czynnik logarytmiczny
--- poza hipotezą Riemanna, która daje \(h\ll\sqrt x\log x\). Wniosek
praktyczny: \(\eta\le19\) jest \emph{prawie optymalne} dla tej metody
i nie warto szukać drobnych ulepszeń rachunku kongruencyjnego.
\end{remark}
```
