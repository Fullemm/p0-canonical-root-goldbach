---
id: BIBLIA-L04551-WERSJA-WARUNKOWA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4551
line_end: 4557
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Wersja warunkowa

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4551-4557`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Podłoga luki
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Wersja warunkowa] Przy hipotezie Riemanna (h x x), a wtedy cor:atak-lb daje (b ^2N), a więc także (a<b ^2N) i ( N/ N). Gałąź ( =2) redukuje się wówczas do konfiguracji z dwiema bardzo małymi bazami i jedną bazą (c= N-a). Eksplozja minimalnej etykiety

## Exact source transcript

```tex
\begin{remark}[Wersja warunkowa]
\CONDITIONAL\ Przy hipotezie Riemanna \(h\ll\sqrt x\log x\), a wtedy
\cref{cor:atak-lb} daje \(b\ll\log^2N\), a więc także \(a<b\ll\log^2N\)
i \(\eta\gg\log N/\log\log N\). Gałąź \(\beta=2\) redukuje się wówczas do
konfiguracji z dwiema \emph{bardzo małymi} bazami i jedną bazą
\(c=\sqrt{N-a}\).
\end{remark}
```
