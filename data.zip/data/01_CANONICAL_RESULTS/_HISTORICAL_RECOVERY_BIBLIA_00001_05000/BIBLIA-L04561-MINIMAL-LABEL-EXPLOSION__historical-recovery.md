---
id: BIBLIA-L04561-MINIMAL-LABEL-EXPLOSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4561
line_end: 4588
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Minimal-label explosion

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4561-4588`
- Original label: `thm:atak-kappa`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Eksplozja minimalnej etykiety
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Minimal-label explosion] Niech (C Q) będzie terminalną złą SCC z ( C 3) (bezchordowość zbędna). Wtedy minimalna etykieta wewnętrzna z thm:min-quotient spełnia [ = Nc> 3N2h-1 . ] Jeżeli (h N^1- ), to każdy łańcuch ( ) z

## Exact source transcript

```tex
\begin{theorem}[Minimal-label explosion]
\label{thm:atak-kappa}
Niech \(C\subseteq Q\) będzie terminalną złą SCC z \(\abs C\ge3\)
(bezchordowość zbędna). Wtedy minimalna etykieta wewnętrzna z
\cref{thm:min-quotient} spełnia
\[
  \kappa=\floor{\frac Nc}>\frac{3N}{2h}-1 .
\]
Jeżeli \(h\le N^{1-\eps}\), to każdy łańcuch \(\kappa\) z
\cref{thm:break-kernel} ma mniej niż \(\log N/\log\kappa\) krawędzi; przy
\(h\ll N^{0.525}\) daje to co najwyżej \(2\) krawędzie, a więc
\[
  \abs{T_\kappa(C)}\ \ge\ \frac{\abs C}{4}.
\]
\end{theorem}

\begin{proof}
Z \cref{cor:qcore-compression} \(c<2h/3\), więc \(N/c>3N/(2h)\) i teza dla
\(\kappa\). Punkt 5 \cref{thm:break-kernel} ogranicza długość łańcucha przez
\(\log_\kappa N\); przy \(\kappa\gg N^{0.475}\) jest to mniej niż
\(2{,}11\), czyli co najwyżej \(2\) krawędzie i co najwyżej \(3\)
wierzchołki na łańcuch. Pierwszy wierzchołek każdego łańcucha ma swojego
jedynego wewnętrznego poprzednika w \(T_\kappa(C)\), a z jednego
wierzchołka wychodzi co najwyżej jedna krawędź o etykiecie \(\kappa\), więc
przyporządkowanie łańcuchom ich poprzedników jest różnowartościowe. Stąd
liczba łańcuchów nie przekracza \(\abs{T_\kappa}\), a
\(\abs{C\setminus T_\kappa}\le3\abs{T_\kappa}\).
\end{proof}
```
