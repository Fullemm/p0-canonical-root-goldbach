---
id: BIBLIA-L04590-REMARK-AT-LINE-4590
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4590
line_end: 4598
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# remark at line 4590

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4590-4598`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Eksplozja minimalnej etykiety
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Jest to pierwsze połączenie ch:qcore z ch:scc: kompresja (Q)-rdzenia mówi, że rdzeń jest mały, a to natychmiast mówi, że etykiety wewnętrzne są ogromne, a więc szkielet Break-Target Kernel degeneruje się do jąder przełamania połączonych łańcuchami długości co najwyżej dwóch krawędzi. Znane EAC mają ( T_ / C) równe (6/8,,23/28,,17/21,,12/14,,1/2,,9/10) --- wszystkie powyżej (1/4), choć leżą poza zakresem twierdzenia (

## Exact source transcript

```tex
\begin{remark}
Jest to pierwsze połączenie \cref{ch:qcore} z \cref{ch:scc}: kompresja
\(Q\)-rdzenia mówi, że rdzeń jest \emph{mały}, a to natychmiast mówi, że
etykiety wewnętrzne są \emph{ogromne}, a więc szkielet Break-Target Kernel
degeneruje się do jąder przełamania połączonych łańcuchami długości co
najwyżej dwóch krawędzi. Znane EAC mają \(\abs{T_\kappa}/\abs C\) równe
\(6/8,\,23/28,\,17/21,\,12/14,\,1/2,\,9/10\) --- wszystkie powyżej
\(1/4\), choć leżą poza zakresem twierdzenia (nie są zawarte w \(Q\)).
\end{remark}
```
