---
id: BIBLIA-L04602-ENDPOINT-DETERMINED-STATE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4602
line_end: 4624
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Endpoint-determined state

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4602-4624`
- Original label: `thm:atak-endpoint`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Stan zredukowany jest wyznaczony przez punkt końcowy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Endpoint-determined state] Dla dowolnego spaceru z (p_0) kończącego się w aktywnym (p) [ B H p^-1 x . ] Zatem dla ustalonego (p), każdej pary (( ,H)) z (H h) odpowiada dokładnie jedna reszta (B_0( ,H) [1,x]), a zbiór dopuszczalnych iloczynów etykiet jest sumą co najwyżej (2 (h))

## Exact source transcript

```tex
\begin{theorem}[Endpoint-determined state]
\label{thm:atak-endpoint}
Dla dowolnego spaceru z \(p_0\) kończącego się w aktywnym \(p\)
\[
  B\equiv\varepsilon H p^{-1}\pmod x .
\]
Zatem dla ustalonego \(p\), każdej pary \((\varepsilon,H)\) z \(H\mid h\)
odpowiada dokładnie jedna reszta \(B_0(\varepsilon,H)\in[1,x]\), a zbiór
dopuszczalnych iloczynów etykiet jest sumą co najwyżej \(2\tau(h)\)
postępów arytmetycznych
\[
  K\in\frac hH\Bigl(B_0(\varepsilon,H)+x\,\Z_{\ge0}\Bigr),
  \qquad
  K\ \ge\ \frac{m_0}{p}.
\]
\end{theorem}

\begin{proof}
Redukcja \(Bp-Ax=\varepsilon H\) modulo \(x\) i \(\gcd(p,x)=1\) dają
kongruencję. Dalej \(K=Bh/H\). Ostatnia nierówność wynika z
\cref{thm:winding-normal-form}: \(K p=WN+\varepsilon p_0\) z \(W\ge1\),
więc \(Kp\ge N-p_0=m_0\).
\end{proof}
```
