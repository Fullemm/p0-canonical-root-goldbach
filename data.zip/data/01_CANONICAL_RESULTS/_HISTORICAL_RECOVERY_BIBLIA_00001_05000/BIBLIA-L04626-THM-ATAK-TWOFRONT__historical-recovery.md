---
id: BIBLIA-L04626-THM-ATAK-TWOFRONT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4626
line_end: 4631
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# thm:atak-twofront

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4626-4631`
- Original label: `thm:atak-twofront`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Stan zredukowany jest wyznaczony przez punkt końcowy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

cor:path-state-count podawała jedynie liczbę stanów; thm:atak-endpoint podaje je jawnie. Zamienia to pytanie ,,czy (p) jest osiągalne z (p_0) iloczynem etykiet (K)'' na test kongruencyjny, wykonalny bez budowania grafu. [Two-Front Lock]

## Exact source transcript

```tex
\begin{remark}
\cref{cor:path-state-count} podawała jedynie \emph{liczbę} stanów;
\cref{thm:atak-endpoint} podaje je \emph{jawnie}. Zamienia to pytanie
,,czy \(p\) jest osiągalne z \(p_0\) iloczynem etykiet \(K\)'' na test
kongruencyjny, wykonalny bez budowania grafu.
\end{remark}
```
