---
id: BIBLIA-L04633-TWO-FRONT-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4633
line_end: 4663
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Two-Front Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4633-4663`
- Original label: `thm:atak-twofront`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Stan zredukowany jest wyznaczony przez punkt końcowy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Two-Front Lock] Niech dwa spacery wychodzą z (p_0) przez różne (q_1 q_2 Q), mają długości (t_1,t_2) i kończą się w tym samym wierzchołku, a (L_1,L_2) będą iloczynami etykiet po pierwszym froncie. Wtedy [ N | q_2L_1-(-1)^t_1+t_2q_1L_2 . ] W konsekwencji albo (q_1 L_1) i (q_2 L_2) --- a wtedy oba

## Exact source transcript

```tex
\begin{theorem}[Two-Front Lock]
\label{thm:atak-twofront}
Niech dwa spacery wychodzą z \(p_0\) przez różne \(q_1\ne q_2\in Q\),
mają długości \(t_1,t_2\) i kończą się w tym samym wierzchołku, a
\(L_1,L_2\) będą iloczynami etykiet \emph{po} pierwszym froncie. Wtedy
\[
  N\ \bigm|\ q_2L_1-(-1)^{t_1+t_2}q_1L_2 .
\]
W konsekwencji albo \(q_1\mid L_1\) i \(q_2\mid L_2\) --- a wtedy oba
\(q_i\) leżą na cyklach --- albo
\[
  \abs{q_2L_1-q_1L_2}\ge N
  \quad\text{(równe parzystości)},
  \qquad
  q_2L_1+q_1L_2\ge N
  \quad\text{(różne)} .
\]
\end{theorem}

\begin{proof}
Mamy \(K_i=(m_0/q_i)L_i\). Z (C1) \cref{thm:atak-collision}
\[
  N\ \bigm|\ \frac{m_0}{q_1}L_1-(-1)^{t_1+t_2}\frac{m_0}{q_2}L_2 .
\]
Mnożenie przez \(q_1q_2\), wzajemnie pierwsze z \(N\), daje
\(N\mid m_0\bigl(q_2L_1-(-1)^{t_1+t_2}q_1L_2\bigr)\); ponieważ
\(\gcd(m_0,N)=1\) na mocy \cref{lem:q-small-active}, można \(m_0\) skreślić.
Przypadek zerowej różnicy to \(q_2L_1=q_1L_2\), a \(\gcd(q_1,q_2)=1\) daje
\(q_1\mid L_1\), \(q_2\mid L_2\); reszta to
\cref{thm:atak-return}.
\end{proof}
```
