---
id: BIBLIA-L04665-ZASIEG-STREFY-BEZ-KOLIZJI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4665
line_end: 4690
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Zasięg strefy bez kolizji

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `proposition`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4665-4690`
- Original label: `prop:atak-zone-reach`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Stan zredukowany jest wyznaczony przez punkt końcowy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Zasięg strefy bez kolizji] Każdy osiągalny stan spełnia (Bp m_0). W szczególności [ B<T:= x2h p>q_0:= 2h,m_0x> 85h , ] gdzie ostatnia nierówność korzysta z twierdzenia Nagury. Ponieważ

## Exact source transcript

```tex
\begin{proposition}[Zasięg strefy bez kolizji]
\label{prop:atak-zone-reach}
\CORRECTED\ Każdy osiągalny stan spełnia \(Bp\ge m_0\). W szczególności
\[
  B<T:=\frac{x}{2h}
  \quad\Longrightarrow\quad
  p>q_0:=\frac{2h\,m_0}{x}>\frac85h ,
\]
gdzie ostatnia nierówność korzysta z twierdzenia Nagury. Ponieważ
terminalna zła SCC \(C\subseteq Q\) o \(\abs C\ge3\) leży w \((0,2h/3)\),
\emph{żaden} spacer kończący się w takim rdzeniu nie należy do strefy
z \cref{cor:atak-nocollision}.
\end{proposition}

\begin{proof}
W stanie \(Bp-Ax=\varepsilon H\) współczynnik \(A=C_t/d_t\) jest dodatnią
liczbą całkowitą (\(C_t\ge1\) na mocy \cref{thm:winding-normal-form},
a \(d_t\mid C_t\) na mocy \cref{thm:bezout-path}), więc
\[
  Bp=Ax+\varepsilon H\ge x-H\ge x-h=m_0 .
\]
Podstawienie \(B<T\) daje \(p>m_0/T=q_0\). Twierdzenie Nagury o pierwszej
w przedziale \((n,6n/5)\) dla \(n\ge25\) daje \(h<x/5\), a więc
\(m_0/x>4/5\) i \(q_0>8h/5>2h/3\); przypadki \(x<25\) sprawdza się
bezpośrednio \cite{Nagura1952}.
\end{proof}
```
