---
id: BIBLIA-L04704-KOREKTA-W-DOWODZIE-THM-THREE-EDGE-COMPRESSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4704
line_end: 4712
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Korekta w dowodzie thm:three-edge-compression

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4704-4712`
- Original label: `rem:atak-three-edge`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Stan zredukowany jest wyznaczony przez punkt końcowy
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Korekta w dowodzie thm:three-edge-compression] W dowodzie trzykrawędziowej kompresji krok ,,(k_1k_2 u_N)'' jest o włos za mocny; z (p_2p_3<N) wynika jedynie (k_1k_2>u_N^2/N). Potrzebna konkluzja (k_1k_2>h) pozostaje prawdziwa przy (h N^0.525), bo (u_N^2/N=N-2 N+O(1)). Samo twierdzenie i jego wniosek są poprawne; poprawić należy jedną nierówność w tekście dowodu.

## Exact source transcript

```tex
\begin{remark}[Korekta w dowodzie \cref{thm:three-edge-compression}]
\label{rem:atak-three-edge}
\CORRECTED\ W dowodzie trzykrawędziowej kompresji krok ,,\(k_1k_2\ge u_N\)''
jest o włos za mocny; z \(p_2p_3<N\) wynika jedynie
\(k_1k_2>u_N^2/N\). Potrzebna konkluzja \(k_1k_2>h\) pozostaje prawdziwa
przy \(h\ll N^{0.525}\), bo \(u_N^2/N=N-2\sqrt N+O(1)\). Samo twierdzenie
i jego wniosek są poprawne; poprawić należy jedną nierówność w tekście
dowodu.
\end{remark}
```
