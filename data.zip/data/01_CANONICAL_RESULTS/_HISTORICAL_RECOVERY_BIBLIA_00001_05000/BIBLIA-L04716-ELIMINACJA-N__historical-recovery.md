---
id: BIBLIA-L04716-ELIMINACJA-N
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4716
line_end: 4750
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Eliminacja (N)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4716-4750`
- Original label: `thm:atak-normalform`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Normalna postać gałęzi ( =2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Eliminacja (N)] Dla bezchordowego terminalnego trójkąta (C=a<b<c Q) z ( =2) parametr (N) można wyeliminować: [ orientacja I: & b^ =c^2-c+a, && czyli (2c-1)^2=4b^ +1-4a, orientacja II: & b^ =c^2+(b-a),

## Exact source transcript

```tex
\begin{theorem}[Eliminacja \(N\)]
\label{thm:atak-normalform}
Dla bezchordowego terminalnego trójkąta \(C=\{a<b<c\}\subseteq Q\)
z \(\beta=2\) parametr \(N\) można wyeliminować:
\[
\begin{aligned}
 \text{orientacja I: }&\quad b^\eta=c^2-c+a,
 &&\text{czyli }(2c-1)^2=4b^\eta+1-4a,\\
 \text{orientacja II: }&\quad b^\eta=c^2+(b-a),
 &&\text{czyli }c^2=b^\eta-(b-a),\ \ 0<b-a<b.
\end{aligned}
\]
Obie są równaniami typu Lebesgue'a--Nagella \(y^2+D=z^n\). Pozostałe
równanie układu to
\[
\begin{aligned}
 \text{orientacja I: }&\quad a^\gamma=N-b, && N=a+c^2,\\
 \text{orientacja II: }&\quad a^\gamma=N-c=b^\eta+a-c, && N=b^\eta+a .
\end{aligned}
\]

\begin{warning}[Korekta wobec wersji 1.6]
\CORRECTED\ W wersji 1.6 pozostałe równanie było zapisane jako
\(a^\gamma=N-b\) dla \emph{obu} orientacji. Dla orientacji II jest to
błąd: tam \(N-b=c^2\), a potęgą bazy \(a\) jest \(N-c\). Skrypt
\texttt{atak\_beta2\_normalna\_postac.py} od początku liczył
\(N-c\), więc wyniki skanu pozostają ważne; błąd dotyczył wyłącznie
zapisu.
\end{warning}
\end{theorem}

\begin{proof}
Odjęcie odpowiednich par spośród \(N-a\), \(N-b\), \(N-c\) usuwa \(N\);
domnożenie przez \(4\) i uzupełnienie do kwadratu daje wersję z \((2c-1)^2\).
\end{proof}
```
