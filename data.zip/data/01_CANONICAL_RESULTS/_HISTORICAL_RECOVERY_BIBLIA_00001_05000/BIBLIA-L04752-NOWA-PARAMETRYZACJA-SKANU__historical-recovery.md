---
id: BIBLIA-L04752-NOWA-PARAMETRYZACJA-SKANU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4752
line_end: 4761
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Nowa parametryzacja skanu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4752-4761`
- Original label: `cor:atak-newscan`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Normalna postać gałęzi ( =2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Nowa parametryzacja skanu] W thm:atak-normalform parametrem jest najmniejsza baza (b), a nie (a). Dla ustalonej pary ((b, )) obie orientacje mają co najwyżej jednego kandydata: w orientacji II jest to (c= b^ ) i (a=b-(b^ -c^2)), w orientacji I --- największe nieparzyste (w) z (w^2 4b^ -11), (c=(w+1)/2), (a=(4b^ +1-w^2)/4). Skan po ((b, )) pokrywa więc wszystkie ( ) naraz, czego skan po (a) z ch:345 nie robi.

## Exact source transcript

```tex
\begin{corollary}[Nowa parametryzacja skanu]
\label{cor:atak-newscan}
W \cref{thm:atak-normalform} parametrem jest \emph{najmniejsza} baza \(b\),
a nie \(a\). Dla ustalonej pary \((b,\eta)\) obie orientacje mają co
najwyżej jednego kandydata: w orientacji II jest to \(c=\floor{\sqrt{b^\eta}}\)
i \(a=b-(b^\eta-c^2)\), w orientacji I --- największe nieparzyste \(w\)
z \(w^2\le4b^\eta-11\), \(c=(w+1)/2\), \(a=(4b^\eta+1-w^2)/4\).
Skan po \((b,\eta)\) pokrywa więc \emph{wszystkie} \(\gamma\) naraz,
czego skan po \(a\) z \cref{ch:345} nie robi.
\end{corollary}
```
