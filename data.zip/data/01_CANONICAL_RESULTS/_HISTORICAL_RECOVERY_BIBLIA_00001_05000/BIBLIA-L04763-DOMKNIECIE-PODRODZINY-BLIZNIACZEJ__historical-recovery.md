---
id: BIBLIA-L04763-DOMKNIECIE-PODRODZINY-BLIZNIACZEJ
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4763
line_end: 4772
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Domknięcie podrodziny bliźniaczej

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4763-4772`
- Original label: `cor:atak-twin`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 3: bariera pierwiastkowa jest strukturalna > Normalna postać gałęzi ( =2)
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Domknięcie podrodziny bliźniaczej] W orientacji II z ( =3) i (b-a=2) równanie przyjmuje postać (c^2=b^3-2). Klasyczny wynik Fermata--Eulera o (y^2+2=x^3) daje jedyne rozwiązanie całkowite ((x,y)=(3, 5)), skąd (b=3), (a=1) --- liczba niepierwsza. Podrodzina z (b-a=2) i ( =3) jest więc całkowicie wykluczona. Ogólniej dla ustalonego (D=b-a) i ( =3) orientacja II jest krzywą Mordella (y^2=x^3-D), której punkty całkowite

## Exact source transcript

```tex
\begin{corollary}[Domknięcie podrodziny bliźniaczej]
\label{cor:atak-twin}
\LITERATURE\ W orientacji II z \(\eta=3\) i \(b-a=2\) równanie przyjmuje
postać \(c^2=b^3-2\). Klasyczny wynik Fermata--Eulera o
\(y^2+2=x^3\) daje jedyne rozwiązanie całkowite \((x,y)=(3,\pm5)\), skąd
\(b=3\), \(a=1\) --- liczba niepierwsza. Podrodzina z \(b-a=2\) i
\(\eta=3\) jest więc \emph{całkowicie} wykluczona.
Ogólniej dla ustalonego \(D=b-a\) i \(\eta=3\) orientacja II jest krzywą
Mordella \(y^2=x^3-D\), której punkty całkowite są efektywnie obliczalne.
\end{corollary}
```
