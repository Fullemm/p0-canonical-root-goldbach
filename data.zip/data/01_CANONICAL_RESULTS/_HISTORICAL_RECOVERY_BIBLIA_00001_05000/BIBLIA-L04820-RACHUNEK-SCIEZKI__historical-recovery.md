---
id: BIBLIA-L04820-RACHUNEK-SCIEZKI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4820
line_end: 4848
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Rachunek ścieżki

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4820-4848`
- Original label: `thm:atak4-derivative`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Pochodna i całka po ścieżce
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Rachunek ścieżki] Dla krawędzi (e=(p q;k)) połóżmy (F_e(z)=(N-z)/k) oraz ( (e)= k). Wtedy (F_e(p)=q), (F_e'=-1/k), a dla ścieżki (P) o iloczynie etykiet (K) [ (F_e_t-1 F_e_0 )'= (-1)^tK, _P = K,

## Exact source transcript

```tex
\begin{theorem}[Rachunek ścieżki]
\label{thm:atak4-derivative}
Dla krawędzi \(e=(p\to q;k)\) połóżmy \(F_e(z)=(N-z)/k\) oraz
\(\omega(e)=\log k\). Wtedy \(F_e(p)=q\), \(F_e'=-1/k\), a dla ścieżki
\(P\) o iloczynie etykiet \(K\)
\[
  \bigl(F_{e_{t-1}}\circ\cdots\circ F_{e_0}\bigr)'=\frac{(-1)^t}{K},
  \qquad
  \int_P\omega=\log K,
  \qquad
  \abs{F_P'}=\frac{H}{hB},
  \tag{GD}
\]
gdzie ostatnia równość wynika z \(K=hB/H\)
(\cref{cor:cancellation-free-potential}). Ponadto z
\(\phi(p)=\log p\) i \(G(p)=\log\frac{N-p}{p}\)
\[
  \omega(p\to q)=G(p)+\phi(p)-\phi(q),
  \qquad
  \oint_C\omega=\sum_{p\in C}\log\frac{N-p}{p}=\log K_C .
\]
\end{theorem}

\begin{proof}
Pochodne map afinicznych mnożą się; całka 1-formy po ścieżce jest sumą jej
wartości na krawędziach. Ostatnia tożsamość to
\(\log k=\log\frac{N-p}{q}=\log\frac{N-p}{p}+\log p-\log q\), a na cyklu
człon potencjału teleskopuje.
\end{proof}
```
