---
id: BIBLIA-L04860-DERIVATIVE-ZONE-ARBORESCENCE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4860
line_end: 4897
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Derivative-Zone Arborescence

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4860-4897`
- Original label: `thm:atak4-arborescence`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Strefa pochodnej jest drzewem
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Derivative-Zone Arborescence] Niech ( D) będzie zbiorem stanów osiągalnych z (p_0) po złych wierszach, dla których (K<x). W ( D) każdy wierzchołek jest osiągany dokładnie jedną ścieżką: nie ma powrotu do wcześniejszego wierzchołka, zlania dwóch gałęzi ani cyklu. Każda ścieżka w ( D) ma mniej niż ( _3x) krawędzi.

## Exact source transcript

```tex
\begin{theorem}[Derivative-Zone Arborescence]
\label{thm:atak4-arborescence}
Niech \(\mathcal D\) będzie zbiorem stanów osiągalnych z \(p_0\) po złych
wierszach, dla których \(K<x\). W \(\mathcal D\) każdy wierzchołek jest
osiągany \emph{dokładnie jedną} ścieżką: nie ma powrotu do wcześniejszego
wierzchołka, zlania dwóch gałęzi ani cyklu. Każda ścieżka w \(\mathcal D\)
ma mniej niż \(\log_3x\) krawędzi.
\end{theorem}

\begin{proof}
Niech dwie ścieżki kończą się w tym samym aktywnym \(p\), o iloczynach
\(K_1,K_2<x\). Z (C1) \cref{thm:atak-collision}
\(N\mid K_1-\varepsilon_1\varepsilon_2K_2\). Przy różnych parzystościach
mielibyśmy \(0<K_1+K_2<2x=N\), co jest niemożliwe. Przy równych
\(\abs{K_1-K_2}<x<N\), więc \(K_1=K_2\).

Niech \(u\) będzie ostatnim wspólnym wierzchołkiem, a \(q_1\ne q_2\)
dziećmi, do których ścieżki się rozchodzą; połóżmy \(n=N-u\) i niech
\(L_1,L_2\) będą iloczynami etykiet \emph{po} pierwszej rozbieżnej
krawędzi. Wtedy \(\frac n{q_1}L_1=\frac n{q_2}L_2\), czyli
\(q_2L_1=q_1L_2\), a pierwszość i różność \(q_1,q_2\) dają
\(L_i=q_iL\) ze wspólnym całkowitym \(L\ge1\). Iloczyn całej ścieżki od
\(u\) wynosi więc \(nL\).

Jeżeli \(u\ne p_0\), to \(u<N/3\), a zatem \(n>2N/3=4x/3>x\) i
\(K\ge nL>x\) --- sprzeczność.

Jeżeli \(u=p_0\), to \(n=m_0>4x/5\) na mocy twierdzenia Nagury
\cite{Nagura1952}, więc \(m_0L<x\) wymusza \(L=1\), czyli \(L_i=q_i\).
Ponieważ każda etykieta jest nieparzysta i co najmniej \(3\), iloczyn
równy liczbie pierwszej \(q_i\) składa się z dokładnie jednej etykiety
\(k=q_i\). Krawędź o etykiecie \(q_i\) wychodząca z \(q_i\) dawałaby
\(q_i\mid N-q_i\), a więc \(q_i\mid N\), wbrew aktywności.

Przypadek, w którym jedna ścieżka jest właściwym prefiksem drugiej, przy
\(K_1=K_2\) dawałby niepusty iloczyn etykiet równy \(1\). Ostatnie
oszacowanie wynika z \(K\ge3^t\).
\end{proof}
```
