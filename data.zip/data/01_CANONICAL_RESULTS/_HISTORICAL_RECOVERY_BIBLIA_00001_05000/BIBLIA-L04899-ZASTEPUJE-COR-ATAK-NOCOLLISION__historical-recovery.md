---
id: BIBLIA-L04899-ZASTEPUJE-COR-ATAK-NOCOLLISION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4899
line_end: 4908
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Zastępuje cor:atak-nocollision

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `remark`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4899-4908`
- Original label: `rem:atak4-supersede`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Strefa pochodnej jest drzewem
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Zastępuje cor:atak-nocollision] Strefa (B<T) jest zawarta w ( D): z (K=hB/H) i (H 1) wynika (K<x/2). thm:atak4-arborescence jest więc mocniejsza pod każdym względem --- nie zakłada przypadku III z ch:global, nie zależy od (h), obejmuje wszystkie redukcje i wyklucza zlanie bezpośrednio, a nie przez odwołanie do thm:atak-return. Równość (K=x) jest niemożliwa, bo ( (K,x)=1); pierwsze wyjście ze strefy spełnia więc (K>x

## Exact source transcript

```tex
\begin{remark}[Zastępuje \cref{cor:atak-nocollision}]
\label{rem:atak4-supersede}
Strefa \(B<T\) jest zawarta w \(\mathcal D\): z \(K=hB/H\) i \(H\ge1\)
wynika \(K<x/2\). \cref{thm:atak4-arborescence} jest więc mocniejsza pod
każdym względem --- nie zakłada przypadku III z \cref{ch:global}, nie
zależy od \(h\), obejmuje wszystkie redukcje i wyklucza zlanie
\emph{bezpośrednio}, a nie przez odwołanie do \cref{thm:atak-return}.
Równość \(K=x\) jest niemożliwa, bo \(\gcd(K,x)=1\); pierwsze wyjście ze
strefy spełnia więc \(K>x\).
\end{remark}
```
