---
id: BIBLIA-L04910-RAW-FLUX-CUT-I-JEDEN-KREGOSUP
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4910
line_end: 4940
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Raw Flux Cut i jeden kręgosłup

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4910-4940`
- Original label: `thm:atak4-flux`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Strefa pochodnej jest drzewem
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Raw Flux Cut i jeden kręgosłup] Niech stan po pierwszym kroku ma wierzchołek (p), iloczyn (K<x) i zły wiersz (n=N-p). Dla dziecka (q n) [ K_q=K nq, K_q,q=K,n, RF

## Exact source transcript

```tex
\begin{theorem}[Raw Flux Cut i jeden kręgosłup]
\label{thm:atak4-flux}
Niech stan po pierwszym kroku ma wierzchołek \(p\), iloczyn \(K<x\) i zły
wiersz \(n=N-p\). Dla dziecka \(q\mid n\)
\[
  K_q=K\frac nq,
  \qquad
  K_q\,q=K\,n,
  \tag{RF}
\]
a dziecko pozostaje w \(\mathcal D\) dokładnie wtedy, gdy \(q>Kn/x\).
Połóżmy \(U_0=\sqrt{3x/4}\). Wtedy:
\begin{enumerate}
  \item jeżeli \(K\ge U_0\), to co najwyżej jedno dziecko pozostaje
  w \(\mathcal D\);
  \item dla dowolnego \(K\) co najwyżej jedno dziecko spełnia \(K_q<U_0\),
  a jeżeli istnieje, to \(q=P^+(n)\), \(q>\sqrt n\) i \(v_q(n)=1\);
  \item każde inne dziecko w \(\mathcal D\) spełnia \(K_q>\tfrac43U_0\).
\end{enumerate}
\end{theorem}

\begin{proof}
(RF) jest definicją etykiety. Gdyby dwa dzieci pozostawały w
\(\mathcal D\), ich etykiety \(k_i=n/q_i\) spełniałyby \(k_i<x/K\), a
Strong Branching LCM (\cref{lem:strong-branching} przy \(H=1\)) daje
\(\lcm(k_1,k_2)=n>4x/3\); przy \(K\ge U_0\) otrzymalibyśmy
\(n\le k_1k_2<(x/K)^2\le4x/3\), sprzeczność. Jeżeli \(K_q<U_0\), to
\(q>Kn/U_0\ge n/U_0>\sqrt n\), bo \(n>4x/3>U_0^2\); w \(n\) istnieje
najwyżej jeden taki czynnik i ma wykładnik \(1\). Wreszcie dla
\(q\le\sqrt n\) mamy \(K_q=Kn/q\ge\sqrt n>\sqrt{4x/3}=\tfrac43U_0\).
\end{proof}
```
