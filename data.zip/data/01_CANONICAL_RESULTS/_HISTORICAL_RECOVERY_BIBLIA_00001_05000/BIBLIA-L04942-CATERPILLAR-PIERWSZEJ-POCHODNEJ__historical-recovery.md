---
id: BIBLIA-L04942-CATERPILLAR-PIERWSZEJ-POCHODNEJ
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4942
line_end: 4961
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Caterpillar pierwszej pochodnej

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4942-4961`
- Original label: `cor:atak4-caterpillar`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Strefa pochodnej jest drzewem
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Caterpillar pierwszej pochodnej] W całej strefie (K<x) wszystkie gałęzie pierwszego frontu poza co najwyżej jedną są prostymi łańcuchami. Jedyna możliwa gałąź wyjątkowa zaczyna się w [ q=P^+(m_0), v_q(m_0)=1, m_0q<U_0, ] a wewnątrz niej w każdym punkcie co najwyżej jedno dziecko pozostaje

## Exact source transcript

```tex
\begin{corollary}[Caterpillar pierwszej pochodnej]
\label{cor:atak4-caterpillar}
W całej strefie \(K<x\) wszystkie gałęzie pierwszego frontu poza co
najwyżej jedną są prostymi łańcuchami. Jedyna możliwa gałąź wyjątkowa
zaczyna się w
\[
  q=P^+(m_0),\qquad v_q(m_0)=1,\qquad \frac{m_0}{q}<U_0,
\]
a wewnątrz niej w każdym punkcie co najwyżej jedno dziecko pozostaje
poniżej \(U_0\). Kręgosłup ma mniej niż
\(\lceil\log_3(U_0q/m_0)\rceil\) krawędzi.
\end{corollary}

\begin{proof}
Stan pierwszego frontu ma \(K_1=m_0/q\); z \(m_0>4x/5>U_0^2\) próg
\(m_0/U_0\) przekracza \(\sqrt{m_0}\), więc najwyżej jeden czynnik
pierwszy \(m_0\) leży powyżej niego i nie może mieć wykładnika \(\ge2\).
Reszta wynika z \cref{thm:atak4-flux}; każda krawędź mnoży \(K\) co
najmniej przez \(3\).
\end{proof}
```
