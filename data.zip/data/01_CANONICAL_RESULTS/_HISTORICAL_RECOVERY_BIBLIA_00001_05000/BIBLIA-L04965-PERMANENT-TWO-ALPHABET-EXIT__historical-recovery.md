---
id: BIBLIA-L04965-PERMANENT-TWO-ALPHABET-EXIT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4965
line_end: 4986
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Permanent Two-Alphabet Exit

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `theorem`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4965-4986`
- Original label: `thm:atak4-exit`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Trwałe wyjście z dwóch alfabetów
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Permanent Two-Alphabet Exit] Niech ścieżka z (p_0) o długości (t 2) ma stan końcowy z (B<T). Wtedy jej punkt końcowy nie należy do (S_h=Q R_h). Innymi słowy, po pierwszym froncie ścieżka podprogowa nigdy nie wraca do żadnego z dwóch naturalnych alfabetów.

## Exact source transcript

```tex
\begin{theorem}[Permanent Two-Alphabet Exit]
\label{thm:atak4-exit}
Niech ścieżka z \(p_0\) o długości \(t\ge2\) ma stan końcowy z \(B<T\).
Wtedy jej punkt końcowy nie należy do \(S_h=Q\cup R_h\). Innymi słowy, po
pierwszym froncie ścieżka podprogowa nigdy nie wraca do żadnego z dwóch
naturalnych alfabetów.
\end{theorem}

\begin{proof}
Z \cref{prop:atak-zone-reach} punkt końcowy spełnia \(p>q_0>\tfrac85h\);
elementy \(R_h\) dzielą \(h\), więc są \(\le h\) i odpadają.

Załóżmy \(p=q\in Q\). Nierówność \(q>q_0=m_0/T\) jest równoważna
\(m_0/q<T\), a więc bezpośrednia krawędź \(p_0\to q\) ma iloczyn
\(K_0=m_0/q<T\le x/2\). Rozważana ścieżka ma \(K=hB/H<x/2\). Porównujemy
dwie ścieżki do tego samego \(q\): przy różnych parzystościach
\(0<K+K_0<x<N\) nie może być wielokrotnością \(N\); przy równych (C1)
wymusza \(K=K_0\). Jeżeli ścieżka wychodzi z \(p_0\) przez \(r\in Q\),
a \(L\) jest iloczynem etykiet po pierwszym froncie, to
\(\frac{m_0}{r}L=\frac{m_0}{q}\), czyli \(qL=r\); pierwszość \(r\) daje
\(q=r\) i \(L=1\), a więc \(t=1\), wbrew założeniu.
\end{proof}
```
