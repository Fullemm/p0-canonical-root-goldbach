---
id: BIBLIA-L04988-PODATEK-RETENCJI-PIERWSZEGO-FRONTU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 4988
line_end: 5000
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Podatek retencji pierwszego frontu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The mathematical claim retains the historical source status and must be independently audited before being used as a new premise.

- Historical environment: `corollary`
- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:4988-5000`
- Original label: `cor:atak4-retention-tax`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Trwałe wyjście z dwóch alfabetów
- Visibility classification from Audit 1/10: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Podatek retencji pierwszego frontu] Dla (q Q) i dziecka (s N-q) połóżmy ( _s= (N-q)/s ((N-q)/s,,h)). Wtedy [ s S_h _s xq2h,m_0= qq_0, ]

## Exact source transcript

```tex
\begin{corollary}[Podatek retencji pierwszego frontu]
\label{cor:atak4-retention-tax}
Dla \(q\in Q\) i dziecka \(s\mid N-q\) połóżmy
\(\mu_s=\frac{(N-q)/s}{\gcd((N-q)/s,\,h)}\). Wtedy
\[
  s\in S_h
  \quad\Longrightarrow\quad
  \mu_s\ \ge\ \frac{xq}{2h\,m_0}=\frac{q}{q_0},
\]
a równoważnie: \(\mu_s<q/q_0\) dowodzi \(s\notin S_h\). Jeżeli cały
support wiersza \(N-q\) pozostaje w \(S_h\), to
\(P^+(N-q)\le\frac{2h\,m_0(N-q)}{xq}\).
\end{corollary}
```
