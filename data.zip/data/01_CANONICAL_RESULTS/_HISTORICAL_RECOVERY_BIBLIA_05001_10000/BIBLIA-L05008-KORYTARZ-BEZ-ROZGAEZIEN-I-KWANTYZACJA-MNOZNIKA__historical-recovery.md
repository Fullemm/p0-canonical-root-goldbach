---
id: BIBLIA-L05008-KORYTARZ-BEZ-ROZGAEZIEN-I-KWANTYZACJA-MNOZNIKA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5008
line_end: 5030
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Korytarz bez rozgałęzień i kwantyzacja mnożnika

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5008-5030`
- Historical environment: `theorem`
- Original label: `thm:atak4-corridor`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Trwałe wyjście z dwóch alfabetów
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Korytarz bez rozgałęzień i kwantyzacja mnożnika] Połóżmy (U= 3x/(16h)). Jeżeli zły osiągalny stan po pierwszym kroku ma (U B<T), to co najwyżej jedno jego dziecko ma (B'<T); cała dalsza część podprogowa jest jedną ścieżką o co najwyżej ( (H)+ _3(T/B) ) krawędziach. Ponadto dla (q Q) w pasie (q_0<q 3q_0) każda krawędź pozostająca poniżej (T) jest SLOW (( =1)), a iloczyn cofaktorów po pierwszym froncie dzieli (h).

## Exact source transcript

```tex
\begin{theorem}[Korytarz bez rozgałęzień i kwantyzacja mnożnika]
\label{thm:atak4-corridor}
Połóżmy \(U=\sqrt{3x/(16h)}\). Jeżeli zły osiągalny stan po pierwszym
kroku ma \(U\le B<T\), to co najwyżej jedno jego dziecko ma \(B'<T\);
cała dalsza część podprogowa jest jedną ścieżką o co najwyżej
\(\Omega(H)+\lceil\log_3(T/B)\rceil\) krawędziach. Ponadto dla
\(q\in Q\) w pasie \(q_0<q\le3q_0\) każda krawędź pozostająca poniżej
\(T\) jest SLOW (\(\mu=1\)), a iloczyn cofaktorów po pierwszym froncie
dzieli \(h\).
\end{theorem}

\begin{proof}
Gdyby dwa dzieci \(r,s\) miały \(B'<T\), to \(\mu_r,\mu_s<T/B\), a
Strong Branching LCM dawałby
\(\frac{n}{\gcd(n,H)}=\lcm(\mu_r,\mu_s)\le\mu_r\mu_s<(T/B)^2\). Lewa
strona przekracza \(\frac{2N}{3h}=\frac{4x}{3h}\), więc
\(B^2<T^2\cdot\frac{3h}{4x}=\frac{3x}{16h}=U^2\). Liczba \(B\) nie maleje,
więc jednoznaczność utrzymuje się na wszystkich dalszych krokach. Kroki
SLOW zużywają cofaktory dzielące \(H\), więc jest ich najwyżej
\(\Omega(H)\); każdy krok FAST mnoży \(B\) co najmniej przez \(3\).
Dla \(q\le3q_0\) mamy \(B_1=m_0/q\ge T/3\), więc każdy krok FAST
opuściłby strefę, a \(\mu<q/q_0\le3\) i nieparzystość dają \(\mu=1\).
\end{proof}
```
