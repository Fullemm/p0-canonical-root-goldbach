---
id: BIBLIA-L05034-CONTINUED-FRACTION-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5034
line_end: 5053
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Continued-Fraction Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5034-5053`
- Historical environment: `theorem`
- Original label: `thm:atak4-legendre`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Blokada Legendre'a--Euklidesa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Continued-Fraction Lock] Dla każdego stanu ((p,A,B,H)) z (B<T) ułamek (A/B) jest zbieżnikiem rozwinięcia liczby wymiernej (p/x) w ułamek łańcuchowy, a (H= Bp-Ax) jest jedną z dodatnich reszt algorytmu Euklidesa dla pary ((x,p)). Liczba stanów podprogowych w ustalonym wierzchołku jest zatem nie większa niż ( (h),,1+ _ x), gdzie ( ) jest złotą proporcją.

## Exact source transcript

```tex
\begin{theorem}[Continued-Fraction Lock]
\label{thm:atak4-legendre}
Dla każdego stanu \((p,A,B,H)\) z \(B<T\) ułamek \(A/B\) jest
\emph{zbieżnikiem} rozwinięcia liczby wymiernej \(p/x\) w ułamek
łańcuchowy, a \(H=\abs{Bp-Ax}\) jest jedną z dodatnich reszt algorytmu
Euklidesa dla pary \((x,p)\). Liczba stanów podprogowych w ustalonym
wierzchołku jest zatem nie większa niż
\(\min\{\tau(h),\,1+\log_\varphi x\}\), gdzie \(\varphi\) jest złotą
proporcją.
\end{theorem}

\begin{proof}
Z \(Bp-Ax=\pm H\) mamy \(\bigl|\frac px-\frac AB\bigr|=\frac{H}{Bx}\).
Z \(B<x/(2h)\) i \(H\le h\) wynika \(\frac{H}{Bx}<\frac1{2B^2}\), a
kryterium Legendre'a mówi, że ułamek nieskracalny spełniający tę
nierówność jest zbieżnikiem \cite{HanclNguyen2024}. Dla zbieżników
\(p/x\) wielkości \(\abs{Bp-Ax}\) są kolejnymi resztami algorytmu
Euklidesa; ściśle maleją, a każda musi dzielić \(h\). Liczba kroków
algorytmu jest maksymalna dla kolejnych liczb Fibonacciego.
\end{proof}
```
