---
id: BIBLIA-L05067-FILTR-LOKALNY-I-PROG-A-73
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5067
line_end: 5087
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Filtr lokalny i próg (a 73)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5067-5087`
- Historical environment: `proposition`
- Original label: `prop:atak4-mod24`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Gałąź ( =2), orientacja II: defekt jest duży i niegładki
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Filtr lokalny i próg (a 73)] W orientacji II zachodzi (a 1 24) i (b c 24); w orientacji I odpowiednio (b 1) i (a c 24). Przypadek (a=3) jest sprzeczny modulo (3), więc (a 73). Ponadto [ D 24 0,4,6,10,12,16,18,22. ]

## Exact source transcript

```tex
\begin{proposition}[Filtr lokalny i próg \(a\ge73\)]
\label{prop:atak4-mod24}
W orientacji II zachodzi \(a\equiv1\pmod{24}\) i \(b\equiv c\pmod{24}\);
w orientacji I odpowiednio \(b\equiv1\) i \(a\equiv c\pmod{24}\).
Przypadek \(a=3\) jest sprzeczny modulo \(3\), więc \(a\ge73\). Ponadto
\[
  D\bmod 24\in\{0,4,6,10,12,16,18,22\}.
\]
\end{proposition}

\begin{proof}
Jedynym parzystym wykładnikiem jest \(\beta=2\), przy bazie \(c\); jego
poprzednikiem w cyklu jest \(b\) w orientacji II, a \(a\) w orientacji I.
Podstawienie do \cref{thm:atak-local} daje obie pary kongruencji, a
powtórzenie modulo \(3\) (dla \(3\notin C\)) domyka moduł \(24\). Dla
\(a=3\) rozważamy wiersze modulo \(3\): \(N\equiv c\) z \(N-c=3^\gamma\),
\(N\equiv b\) z \(N-a=b^\eta\) i \(N\equiv b+1\) z \(N-b=c^2\), co daje
\(b\equiv b+1\). Najmniejszą liczbą pierwszą \(\equiv1\pmod{24}\)
większą od \(3\) jest \(73\). Wreszcie \(D=b-a\equiv b-1\), a \(b\) jest
pierwsza, więc \(b\bmod24\in\{1,5,7,11,13,17,19,23\}\).
\end{proof}
```
