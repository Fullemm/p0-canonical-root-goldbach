---
id: BIBLIA-L05089-DUZY-I-NIEGADKI-DEFEKT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5089
line_end: 5111
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Duży i niegładki defekt

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5089-5111`
- Historical environment: `theorem`
- Original label: `thm:atak4-defect`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Gałąź ( =2), orientacja II: defekt jest duży i niegładki
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Duży i niegładki defekt] W orientacji II zachodzi (D 102) oraz (P^+(D) 13). Równanie thm:atak-normalform ma postać (c^2+D=b^ ), czyli równania Lebesgue'a--Nagella. Bugeaud, Mignotte i Siksek wyznaczyli wszystkie rozwiązania (x^2+D=y^n) dla (1 D 100)

## Exact source transcript

```tex
\begin{theorem}[Duży i niegładki defekt]
\label{thm:atak4-defect}
\LITERATURE\ W orientacji II zachodzi \(D\ge102\) oraz \(P^+(D)\ge13\).
\end{theorem}

\begin{proof}
Równanie \cref{thm:atak-normalform} ma postać \(c^2+D=b^\eta\), czyli
równania Lebesgue'a--Nagella. Bugeaud, Mignotte i Siksek wyznaczyli
\emph{wszystkie} rozwiązania \(x^2+D=y^n\) dla \(1\le D\le100\)
\cite{BMS2006}. Po nałożeniu warunków \(\eta\) nieparzyste, \(b\) i \(c\)
pierwsze, \(c>b\), pozostaje pięć wierszy
\[
  (D,c,b,\eta)=(2,5,3,3),\ (4,11,5,3),\ (13,70,17,3),\
  (28,225,37,3),\ (76,1015,101,3),
\]
w których \(a=b-D\) wynosi odpowiednio \(1,1,4,9,25\) --- żadna nie jest
pierwsza (w trzech ostatnich \(c\) jest ponadto złożone). Zatem
\(D>100\), a parzystość \(D=b-a\) daje \(D\ge102\). Analogicznie
Bennett i Siksek wyznaczyli wszystkie rozwiązania, w których \(D\) ma
czynniki pierwsze wyłącznie w \(\{2,3,5,7,11\}\) \cite{BennettSiksek2021b};
filtracja ich tablic tymi samymi warunkami nie zostawia żadnego wiersza,
skąd \(P^+(D)\ge13\).
\end{proof}
```
