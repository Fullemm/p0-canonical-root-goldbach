---
id: BIBLIA-L05120-SQUARE-SHADOW-GAP-ZE-WSPOCZYNNIKIEM-8
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5120
line_end: 5147
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Square-Shadow Gap ze współczynnikiem (8)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5120-5147`
- Historical environment: `theorem`
- Original label: `thm:atak4-sg8`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Gałąź ( =2), orientacja II: defekt jest duży i niegładki
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Square-Shadow Gap ze współczynnikiem (8)] Przy ( =2) parametr ( ) jest nieparzysty, a z prop:atak4-mod24 zachodzi (b 1 8) w orientacji I, odpowiednio (a 1 8) w orientacji II. Dlatego [ I: ^2=b+8ka, II: ^2=a+8kb,

## Exact source transcript

```tex
\begin{theorem}[Square-Shadow Gap ze współczynnikiem \(8\)]
\label{thm:atak4-sg8}
Przy \(\beta=2\) parametr \(\mu\) jest nieparzysty, a z
\cref{prop:atak4-mod24} zachodzi \(b\equiv1\pmod8\) w orientacji I,
odpowiednio \(a\equiv1\pmod8\) w orientacji II. Dlatego
\[
  \text{I: }\ \mu^2=b+8ka,
  \qquad
  \text{II: }\ \mu^2=a+8kb,
  \qquad k\ge1,
\]
a więc
\[
  \text{I: }\ h>\frac c2\sqrt{b+8a},
  \qquad
  \text{II: }\ h>\frac c2\sqrt{a+8b}.
\]
\end{theorem}

\begin{proof}
Z \cref{thm:atak-sg} mamy \(\mu^2>b\) (orientacja I), odpowiednio
\(\mu^2>a\) (orientacja II), oraz podzielność \(a\mid\mu^2-b\),
odpowiednio \(b\mid\mu^2-a\). Ponieważ \(\mu\) jest nieparzyste,
\(\mu^2\equiv1\pmod 8\); wraz z \(b\equiv1\), odpowiednio \(a\equiv1\),
daje to \(8\mid\mu^2-b\), odpowiednio \(8\mid\mu^2-a\). Drugi czynnik
(\(a\), odpowiednio \(b\)) jest nieparzysty, więc iloraz jest podzielny
przez \(8\). Podstawienie do \(2h=\delta\ge\mu c\) kończy dowód.
\end{proof}
```
