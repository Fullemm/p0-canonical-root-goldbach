---
id: BIBLIA-L05149-SHADOW-EXPONENT-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5149
line_end: 5170
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Shadow--Exponent Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5149-5170`
- Historical environment: `proposition`
- Original label: `prop:atak4-selock`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 4: rachunek grafowy i drzewo do progu (K=x) > Gałąź ( =2), orientacja II: defekt jest duży i niegładki
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Shadow--Exponent Lock] Przy ( =2) [ I: & b a^2 -a^ +a, &&a b (1-b^ -1 )^2-1, II: & a b^2 -b^ +b, &&b a (1-a^ -1 )^2-1 .

## Exact source transcript

```tex
\begin{proposition}[Shadow--Exponent Lock]
\label{prop:atak4-selock}
Przy \(\beta=2\)
\[
\begin{aligned}
 \text{I: }&\quad b\mid a^{2\gamma}-a^\gamma+a,
 &&a\mid b\bigl(1-b^{\eta-1}\bigr)^2-1,\\
 \text{II: }&\quad a\mid b^{2\eta}-b^\eta+b,
 &&b\mid a\bigl(1-a^{\gamma-1}\bigr)^2-1 .
\end{aligned}
\]
\end{proposition}

\begin{proof}
Orientacja I: z \(N-c=b^\eta\) mamy \(N\equiv c\pmod b\), więc
\(a^\gamma=N-b\equiv c\) i \(c^2=N-a\equiv c-a\pmod b\); podstawienie
\(c\equiv a^\gamma\) daje pierwszą dzielność. Z \(N-b=a^\gamma\) mamy
\(N\equiv b\pmod a\), więc \(b^\eta=N-c\equiv b-c\), czyli
\(c\equiv b-b^\eta\), a z \(c^2\equiv b\pmod a\) po podzieleniu przez
\(b\) otrzymujemy drugą. Orientacja II jest symetryczna: rolę \(b\)
przejmuje \(a\).
\end{proof}
```
