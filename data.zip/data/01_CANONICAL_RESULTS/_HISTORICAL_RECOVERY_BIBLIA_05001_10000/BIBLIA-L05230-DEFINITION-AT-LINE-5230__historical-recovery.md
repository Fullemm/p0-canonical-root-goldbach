---
id: BIBLIA-L05230-DEFINITION-AT-LINE-5230
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5230
line_end: 5239
env: definition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# definition at line 5230

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5230-5239`
- Historical environment: `definition`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Kontrakcja pierwiastkowa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Dla nieparzystej liczby złożonej (n) i (s>0) połóżmy [ R_s(n)= _ q n q pierwsza ( qn )^s = _e F'_e^s, ] gdzie sumowanie po prawej biegnie po krawędziach wychodzących z wiersza (n), a (F_e) są mapami z thm:atak4-derivative.

## Exact source transcript

```tex
\begin{definition}
Dla nieparzystej liczby złożonej \(n\) i \(s>0\) połóżmy
\[
  R_s(n)=\sum_{\substack{q\mid n\\ q\ \text{pierwsza}}}
         \left(\frac qn\right)^{s}
        =\sum_{e}\abs{F'_e}^{s},
\]
gdzie sumowanie po prawej biegnie po krawędziach wychodzących z wiersza
\(n\), a \(F_e\) są mapami z \cref{thm:atak4-derivative}.
\end{definition}
```
