---
id: BIBLIA-L05241-KONTRAKCJA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5241
line_end: 5275
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Kontrakcja

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5241-5275`
- Historical environment: `theorem`
- Original label: `thm:atak5-contraction`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Kontrakcja pierwiastkowa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Kontrakcja] Niech (s_*) będzie jedynym dodatnim pierwiastkiem (3^-s+5^-s=1), [ s_*=0,518370274122346 ] Wtedy dla każdej nieparzystej liczby złożonej (n): [ R_s(n) 1 (s s_*),

## Exact source transcript

```tex
\begin{theorem}[Kontrakcja]
\label{thm:atak5-contraction}
Niech \(s_*\) będzie jedynym dodatnim pierwiastkiem \(3^{-s}+5^{-s}=1\),
\[
  s_*=0{,}518370274122346\ldots
\]
Wtedy dla każdej nieparzystej liczby złożonej \(n\):
\[
  R_s(n)\le1\quad(s\ge s_*),
\]
z równością wyłącznie dla \(s=s_*\), \(n=15\). Ponadto
\[
  R_{1/2}(n)\le\frac1{\sqrt3}+\frac1{\sqrt7}=0{,}955314742198853\ldots
  \qquad(n\ne15),
\]
z równością wyłącznie dla \(n=21\), oraz
\[
  R_1(n)\le\frac8{15},
\]
z równością wyłącznie dla \(n=15\).
\end{theorem}

\begin{proof}
Funkcja \(q\mapsto(q/n)^s\) rośnie z \(q\) i maleje z \(n\), więc przy
ustalonej liczbie \(\omega(n)=w\) różnych baz maksimum \(R_s\) osiąga
\(n=\rad(n)\) równe iloczynowi \(w\) najmniejszych nieparzystych
pierwszych; każda dodatkowa potęga powiększa \(n\), nie zmieniając
licznika. Dla \(w=1\) mamy \(R_s(n)=(1/q^{a-1})^s\le3^{-s}\). Dla
\(w=2\) maksimum daje \(n=15\) i \(R_s=3^{-s}+5^{-s}\); po usunięciu
\(n=15\) kolejnym maksimum jest \(n=21\) z \(3^{-s}+7^{-s}\). Dla
\(w\ge3\) maksimum daje \(n=105\) z
\(R_{1/2}=0{,}64545\ldots<0{,}9553\), a dalsze bazy tylko zmniejszają
sumę, bo \((q/n)^s\) maleje szybciej niż rośnie liczba składników.
Podstawienie \(s=1/2\) i \(s=1\) daje pozostałe tezy.
\end{proof}
```
