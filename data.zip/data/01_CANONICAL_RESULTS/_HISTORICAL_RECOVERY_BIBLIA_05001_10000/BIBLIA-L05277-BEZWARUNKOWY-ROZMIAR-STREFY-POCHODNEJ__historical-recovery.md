---
id: BIBLIA-L05277-BEZWARUNKOWY-ROZMIAR-STREFY-POCHODNEJ
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5277
line_end: 5308
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Bezwarunkowy rozmiar strefy pochodnej

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5277-5308`
- Historical environment: `corollary`
- Original label: `cor:atak5-zonesize`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Kontrakcja pierwiastkowa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Bezwarunkowy rozmiar strefy pochodnej] Niech ( D) będzie strefą z thm:atak4-arborescence. Ponieważ każdy zły wierzchołek po starcie spełnia (N-p>2N/3), wiersz (15) nie może wystąpić poza pierwszym krokiem dla (N 24). Zatem [ _p D 1 K(p) ( 1 3+ 1 5 ) _t 0 ( 1 3+ 1 7 )^t

## Exact source transcript

```tex
\begin{corollary}[Bezwarunkowy rozmiar strefy pochodnej]
\label{cor:atak5-zonesize}
Niech \(\mathcal D\) będzie strefą z \cref{thm:atak4-arborescence}.
Ponieważ każdy zły wierzchołek po starcie spełnia \(N-p>2N/3\), wiersz
\(15\) nie może wystąpić poza pierwszym krokiem dla \(N\ge24\). Zatem
\[
  \sum_{p\in\mathcal D}\frac1{\sqrt{K(p)}}
  \le\Bigl(\tfrac1{\sqrt3}+\tfrac1{\sqrt5}\Bigr)
     \sum_{t\ge0}\Bigl(\tfrac1{\sqrt3}+\tfrac1{\sqrt7}\Bigr)^{t}
  <22{,}928455,
\]
a stąd, ponieważ \(K<x\) na całej strefie,
\[
  \abs{\mathcal D}<22{,}928455\sqrt x .
\]
Analogicznie z \(R_1\le8/15\)
\[
  \sum_{p\in\mathcal D}\frac1{K(p)}\le\frac{15}{7},
\]
a liczba krawędzi pierwszego przekroczenia spełnia
\(\abs{\partial\mathcal D}=O(\sqrt N\log N)\).
\end{corollary}

\begin{proof}
Suma po ścieżkach długości \(t\) jest ograniczona przez iloczyn kolejnych
\(R_{1/2}\); pierwszy czynnik dopuszcza \(n=15\), pozostałe nie. Jeżeli
\(\abs{\mathcal D}\) stanów ma każde \(K<x\), to
\(\abs{\mathcal D}x^{-1/2}<\sum K^{-1/2}\). Dla \(\sum1/K\) argument jest
identyczny z \(R_1\le8/15\) i sumą geometryczną \(1/(1-8/15)\). Liczba
krawędzi wychodzących ze strefy jest ograniczona przez sumę
\(\omega(N-p)\ll\log N\) po stanach.
\end{proof}
```
