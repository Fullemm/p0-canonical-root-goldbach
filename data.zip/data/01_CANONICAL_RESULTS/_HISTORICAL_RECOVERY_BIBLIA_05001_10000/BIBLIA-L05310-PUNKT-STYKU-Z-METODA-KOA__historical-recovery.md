---
id: BIBLIA-L05310-PUNKT-STYKU-Z-METODA-KOA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5310
line_end: 5326
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Punkt styku z metodą koła

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5310-5326`
- Historical environment: `remark`
- Original label: `rem:atak5-fourier`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Kontrakcja pierwiastkowa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Punkt styku z metodą koła] Przy wagach (w_p=K(p)^-1/2) energia wielomianu (G_N( )= _p Dw_pe( p)) jest niezależna od (N): ( _0^1 G_N^2 15/7). Pozostały cel można wtedy zapisać jako dodatniość [ _0^1G_N( )S_N( )e(-N ),d >0, ]

## Exact source transcript

```tex
\begin{remark}[Punkt styku z metodą koła]
\label{rem:atak5-fourier}
Przy wagach \(w_p=K(p)^{-1/2}\) energia wielomianu
\(G_N(\alpha)=\sum_{p\in\mathcal D}w_pe(\alpha p)\) jest \emph{niezależna
od \(N\)}: \(\int_0^1\abs{G_N}^2\le15/7\). Pozostały cel można wtedy
zapisać jako dodatniość
\[
  \int_0^1G_N(\alpha)S_N(\alpha)e(-N\alpha)\,d\alpha>0,
\]
gdzie \(S_N\) jest sumą wykładniczą po liczbach pierwszych; dodatniość
oznacza osiągalny wierzchołek \(p\) z \(N-p\) pierwszą. \OPEN\ Jest to
jedynie \emph{przeformułowanie}: klasyczna metoda kołowa nie domyka
problemu binarnego z powodu łuków pobocznych \cite{HelfgottMinor}.
Bliskość \(s_*=0{,}5184\) do wykładnika \(0{,}52\) w twierdzeniach
o pierwszych w krótkich przedziałach \cite{Li2023} jest \emph{zbiegiem
okoliczności} --- nie istnieje żaden dowód związku.
\end{remark}
```
