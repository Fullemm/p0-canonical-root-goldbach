---
id: BIBLIA-L05330-DWA-ARKUSZE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5330
line_end: 5383
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Dwa arkusze

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5330-5383`
- Historical environment: `theorem`
- Original label: `thm:atak5-twosheets`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Twierdzenie dwóch arkuszy i most Fareya
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Dwa arkusze] Niech dwie złe ścieżki z (p_0) kończą się w tym samym aktywnym (p) i mają (K_1,K_2<N). Wtedy: jeżeli (t_1 t_2 2), to ścieżki są identyczne; jeżeli (t_1 t_2 2), to [ K_1+K_2=N, W_1+W_2=p,

## Exact source transcript

```tex
\begin{theorem}[Dwa arkusze]
\label{thm:atak5-twosheets}
Niech dwie złe ścieżki z \(p_0\) kończą się w tym samym aktywnym \(p\)
i mają \(K_1,K_2<N\). Wtedy:
\begin{enumerate}
  \item jeżeli \(t_1\equiv t_2\pmod2\), to ścieżki są \emph{identyczne};
  \item jeżeli \(t_1\not\equiv t_2\pmod2\), to
  \[
    K_1+K_2=N,\qquad W_1+W_2=p,
  \]
  ścieżki rozchodzą się już w \(p_0\), przez różne \(q_1,q_2\in Q\),
  a pierwszy wiersz jest \emph{półpierwszy}:
  \[
    m_0=q_1q_2 .
  \]
  Jeżeli \(U_i\) i \(V_i\) są produktem etykiet i windingiem części po
  pierwszym froncie, to
  \[
    q_2U_1+q_1U_2=N,
    \qquad
    q_2V_1+q_1V_2=p,
    \qquad
    U_1V_2-U_2V_1=\pm1 .
  \]
\end{enumerate}
\end{theorem}

\begin{proof}
Z (C1) \cref{thm:atak-collision} \(N\mid K_1-(-1)^{t_1+t_2}K_2\).

Przy tej samej parzystości \(\abs{K_1-K_2}<N\) daje \(K_1=K_2\). Niech
\(u\) będzie ostatnim wspólnym wierzchołkiem, \(n=N-u\), a \(L_i\)
produktami po pierwszej rozbieżnej krawędzi; jak w
\cref{thm:atak4-arborescence} otrzymujemy \(L_i=q_iL\) i całkowity
produkt \(K_{\mathrm{pre}}nL\). Dla \(u\ne p_0\) mamy \(n>2N/3\), więc
\(L<3/2\); dla \(u=p_0\) twierdzenie Nagury daje \(m_0>2N/5\), więc
\(L<5/2\). W obu przypadkach \(L=1\), a wtedy jedyna etykieta po
rozejściu równa się \(q_i\), co dawałoby \(q_i\mid N\). Sprzeczność;
ścieżki nie mogą się rozejść, więc są identyczne.

Przy różnych parzystościach \(0<K_1+K_2<2N\) i podzielność przez \(N\)
dają \(K_1+K_2=N\); dodanie równań
\(K_ip=W_iN+\varepsilon_ip_0\) o przeciwnych \(\varepsilon_i\) daje
\(W_1+W_2=p\). Produkt wspólnego prefiksu dzieli \(K_1\) i \(K_2\), więc
dzieli \(N\); jednocześnie każda etykieta dzieli \(N-p'\) dla aktywnego
\(p'\), a \(\gcd(N-p',N)=1\), więc prefiks jest względnie pierwszy z
\(N\) i musi być równy \(1\). Rozejście następuje zatem w \(p_0\).
Podstawiając \(K_i=(m_0/q_i)U_i\) do \(K_1+K_2=N\) otrzymujemy
\(m_0(q_2U_1+q_1U_2)=Nq_1q_2\); z \(\gcd(m_0,N)=1\) wynika
\(m_0\mid q_1q_2\), a \(q_1q_2\mid m_0\) daje \(m_0=q_1q_2\) oraz
\(q_2U_1+q_1U_2=N\). Analogiczne podstawienie w równaniu windingu daje
\(q_2V_1+q_1V_2=p\). Wyeliminowanie \(N\) i \(p\) z obu równań
prowadzi do \(U_1V_2-U_2V_1=\pm1\).
\end{proof}
```
