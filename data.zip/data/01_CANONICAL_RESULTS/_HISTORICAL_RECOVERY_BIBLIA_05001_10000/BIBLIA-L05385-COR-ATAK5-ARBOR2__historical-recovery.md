---
id: BIBLIA-L05385-COR-ATAK5-ARBOR2
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5385
line_end: 5391
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# cor:atak5-arbor2

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5385-5391`
- Historical environment: `corollary`
- Original label: `cor:atak5-arbor2`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Twierdzenie dwóch arkuszy i most Fareya
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Jeżeli (m_0) nie jest iloczynem dwóch różnych liczb pierwszych, to cały zły świat z (K<N) jest arborescencją. Ponadto most Fareya nie propaguje się: po dołożeniu wspólnej krawędzi o etykiecie (k 3) suma produktów wynosi (kN 3N), więc oba nie mogą pozostać poniżej (N).

## Exact source transcript

```tex
\begin{corollary}
\label{cor:atak5-arbor2}
Jeżeli \(m_0\) nie jest iloczynem dwóch różnych liczb pierwszych, to cały
zły świat z \(K<N\) jest arborescencją. Ponadto most Fareya nie
propaguje się: po dołożeniu wspólnej krawędzi o etykiecie \(k\ge3\) suma
produktów wynosi \(kN\ge3N\), więc oba nie mogą pozostać poniżej \(N\).
\end{corollary}
```
