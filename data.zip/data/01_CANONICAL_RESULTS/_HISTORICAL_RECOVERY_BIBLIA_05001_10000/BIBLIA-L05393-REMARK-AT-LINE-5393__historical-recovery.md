---
id: BIBLIA-L05393-REMARK-AT-LINE-5393
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5393
line_end: 5397
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# remark at line 5393

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5393-5397`
- Historical environment: `remark`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Twierdzenie dwóch arkuszy i most Fareya
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Ułamki (V_1/U_1) i (V_2/U_2) są zatem sąsiadami w ciągu Fareya. Kolizja poniżej (N) nie jest więc dowolna: jest dokładnie jednym elementem ( SL_2( )). Rekonstrukcja cyklu ze słowa etykiet [Rekonstrukcja]

## Exact source transcript

```tex
\begin{remark}
Ułamki \(V_1/U_1\) i \(V_2/U_2\) są zatem sąsiadami w ciągu Fareya.
Kolizja poniżej \(N\) nie jest więc dowolna: jest dokładnie jednym
elementem \(\mathrm{SL}_2(\Z)\).
\end{remark}
```
