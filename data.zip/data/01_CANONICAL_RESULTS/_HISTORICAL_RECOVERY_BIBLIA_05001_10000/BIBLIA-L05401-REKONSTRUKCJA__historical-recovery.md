---
id: BIBLIA-L05401-REKONSTRUKCJA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5401
line_end: 5428
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Rekonstrukcja

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5401-5428`
- Historical environment: `theorem`
- Original label: `thm:atak5-reconstruction`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Rekonstrukcja cyklu ze słowa etykiet
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Rekonstrukcja] Niech (k_0, ,k_r-1 3) będą nieparzyste, (K= _ik_i), ( =(-1)^r), (D=K- ), a [ A_i=(-1)^r-1 _j=0^r-1(-1)^j _ =0^j-1k_i+ , g= (A_0, ,A_r-1). ]

## Exact source transcript

```tex
\begin{theorem}[Rekonstrukcja]
\label{thm:atak5-reconstruction}
Niech \(k_0,\ldots,k_{r-1}\ge3\) będą nieparzyste,
\(K=\prod_ik_i\), \(\varepsilon=(-1)^r\), \(D=K-\varepsilon\), a
\[
  A_i=(-1)^{r-1}\sum_{j=0}^{r-1}(-1)^j\prod_{\ell=0}^{j-1}k_{i+\ell},
  \qquad
  g=\gcd(A_0,\ldots,A_{r-1}).
\]
Wtedy zachodzi tożsamość
\[
  A_i+k_iA_{i+1}=D
  \qquad(i\in\Z/r\Z),
\]
a słowo \((k_i)\) generuje prosty aktywny zły cykl wtedy i tylko wtedy,
gdy \(g\mid D\), liczba \(N=D/g\) jest parzysta, a \(p_i=A_i/g\) są
różnymi liczbami pierwszymi niedzielącymi \(N\). Cykl i \(N\) są wtedy
wyznaczone \emph{jednoznacznie}.
\end{theorem}

\begin{proof}
Tożsamość sprawdza się bezpośrednio z definicji \(A_i\) przez rozbicie
sumy na pierwszy wyraz i resztę. Iterowanie \(p_i+k_ip_{i+1}=N\) wokół
cyklu daje \(Dp_i=NA_i\). Aktywność wierzchołków daje \(\gcd(p_i,N)=1\),
więc \(N\mid D\); pisząc \(D=mN\) otrzymujemy \(A_i=mp_i\), a ponieważ
różne liczby pierwsze \(p_i\) mają NWD równy \(1\), musi być \(m=g\).
Dostateczność wynika z podzielenia tożsamości przez \(g\).
\end{proof}
```
