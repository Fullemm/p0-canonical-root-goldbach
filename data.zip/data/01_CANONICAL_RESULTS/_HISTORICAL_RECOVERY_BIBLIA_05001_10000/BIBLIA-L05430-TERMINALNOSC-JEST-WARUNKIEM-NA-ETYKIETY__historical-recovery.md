---
id: BIBLIA-L05430-TERMINALNOSC-JEST-WARUNKIEM-NA-ETYKIETY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5430
line_end: 5434
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Terminalność jest warunkiem na etykiety

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5430-5434`
- Historical environment: `corollary`
- Original label: `cor:atak5-terminal-labels`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Rekonstrukcja cyklu ze słowa etykiet
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Terminalność jest warunkiem na etykiety] Cykl Hamiltona (C=p_0, ,p_r-1) jest terminalny wtedy i tylko wtedy, gdy ( (k_i) C) dla wszystkich (i). [Dzielnik rekonstrukcyjny terminalnego cyklu] Dla terminalnego cyklu Hamiltona nieparzystej długości (r)

## Exact source transcript

```tex
\begin{corollary}[Terminalność jest warunkiem na etykiety]
\label{cor:atak5-terminal-labels}
Cykl Hamiltona \(C=\{p_0,\ldots,p_{r-1}\}\) jest terminalny wtedy i tylko
wtedy, gdy \(\PF(k_i)\subseteq C\) dla wszystkich \(i\).
\end{corollary}
```
