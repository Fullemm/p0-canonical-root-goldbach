---
id: BIBLIA-L05436-DZIELNIK-REKONSTRUKCYJNY-TERMINALNEGO-CYKLU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5436
line_end: 5455
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Dzielnik rekonstrukcyjny terminalnego cyklu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5436-5455`
- Historical environment: `theorem`
- Original label: `thm:atak5-g3`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Rekonstrukcja cyklu ze słowa etykiet
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Dzielnik rekonstrukcyjny terminalnego cyklu] Dla terminalnego cyklu Hamiltona nieparzystej długości (r) [ g 3, K=gN-1 3N-1 . ]

## Exact source transcript

```tex
\begin{theorem}[Dzielnik rekonstrukcyjny terminalnego cyklu]
\label{thm:atak5-g3}
Dla terminalnego cyklu Hamiltona nieparzystej długości \(r\)
\[
  g\ge3,
  \qquad
  K=gN-1\ge3N-1 .
\]
\end{theorem}

\begin{proof}
Z definicji \(A_i\equiv1\pmod{k_i}\). Gdyby \(g=1\), to \(p_i=A_i\), więc
\(k_i\mid p_i-1\) i \(k_i<p_i\); terminalność daje
\(\PF(k_i)\subseteq C\), więc z \(p_i\) można wybrać wierzchołek
\(p_j<p_i\). Iterowanie tego wyboru dałoby ściśle malejący nieskończony
ciąg w zbiorze skończonym. Zatem \(g\ge2\). Dla nieparzystego \(r\)
wszystkie \(A_i\) są sumami \(r\) nieparzystych składników o zmiennych
znakach, więc są nieparzyste; \(g\) jest zatem nieparzyste, czyli
\(g\ge3\). Wreszcie \(\varepsilon=-1\) daje \(D=K+1=gN\).
\end{proof}
```
