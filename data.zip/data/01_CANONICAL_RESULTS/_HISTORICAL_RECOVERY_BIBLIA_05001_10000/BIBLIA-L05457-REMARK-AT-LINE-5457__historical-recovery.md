---
id: BIBLIA-L05457-REMARK-AT-LINE-5457
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5457
line_end: 5463
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# remark at line 5457

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5457-5463`
- Historical environment: `remark`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Rekonstrukcja cyklu ze słowa etykiet
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

Poprawia to thm:global-cycle-lock z (K N-1) do (K 3N-1) dla terminalnych cykli nieparzystej długości, w szczególności dla każdej terminalnej trójki. Dla parzystego (r) otrzymujemy filtr (2)-adyczny (v_2(A_0)= =v_2(A_r-1)=v_2(g)<v_2(D)). [Redukcja liczby niewiadomych]

## Exact source transcript

```tex
\begin{remark}
Poprawia to \cref{thm:global-cycle-lock} z \(K\ge N-1\) do
\(K\ge3N-1\) dla terminalnych cykli nieparzystej długości, w
szczególności dla każdej terminalnej trójki. Dla parzystego \(r\)
otrzymujemy filtr \(2\)-adyczny
\(v_2(A_0)=\cdots=v_2(A_{r-1})=v_2(g)<v_2(D)\).
\end{remark}
```
