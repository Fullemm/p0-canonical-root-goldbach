---
id: BIBLIA-L05465-REDUKCJA-LICZBY-NIEWIADOMYCH
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5465
line_end: 5477
env: remark
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Redukcja liczby niewiadomych

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5465-5477`
- Historical environment: `remark`
- Original label: ``
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 5: transformata Laplace'a, dwa arkusze i rekonstrukcja cykli > Rekonstrukcja cyklu ze słowa etykiet
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Redukcja liczby niewiadomych] thm:atak5-reconstruction zamienia parę ((N,C)) na jedno słowo ((k_i)). Dla terminalnej trójki warunek terminalności przyjmuje postać samoodnoszącego się układu supportów [ (k_0k_1k_2) k_0k_1-k_0+1g, k_1k_2-k_1+1g, k_2k_0-k_2+1g ,

## Exact source transcript

```tex
\begin{remark}[Redukcja liczby niewiadomych]
\cref{thm:atak5-reconstruction} zamienia parę \((N,C)\) na jedno słowo
\((k_i)\). Dla terminalnej trójki warunek terminalności przyjmuje postać
samoodnoszącego się układu supportów
\[
  \PF(k_0k_1k_2)\subseteq
  \left\{\frac{k_0k_1-k_0+1}{g},\
         \frac{k_1k_2-k_1+1}{g},\
         \frac{k_2k_0-k_2+1}{g}\right\},
\]
czyli konkretnego problemu \(S\)-jednostkowego. Uogólnia to Prime Shadow
Triangle z \cref{ch:triangle} na cykle dowolnej długości.
\end{remark}
```
