---
id: BIBLIA-L05530-ROZKAD-KREGOSUP-ANCUCHY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5530
line_end: 5581
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Rozkład kręgosłup--łańcuchy

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5530-5581`
- Historical environment: `theorem`
- Original label: `thm:atak6-decomposition`
- Section: Atak zewnętrzny: most Bézout--SCC, sygnatury, korekty > Iteracja 6: strefa pochodnej jest polilogarytmiczna
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Rozkład kręgosłup--łańcuchy] Niech (U_0= 3x/4) i ( S=v D:K(v)<U_0). Wtedy: ( S) jest pojedynczą ścieżką skierowaną z (p_0), o mniej niż ( _3U_0) krawędziach; każdy stan ( D S) ma co najwyżej jedno dziecko w ( D), więc ( D S) jest

## Exact source transcript

```tex
\begin{theorem}[Rozkład kręgosłup--łańcuchy]
\label{thm:atak6-decomposition}
Niech \(U_0=\sqrt{3x/4}\) i \(\mathcal S=\{v\in\mathcal D:K(v)<U_0\}\).
Wtedy:
\begin{enumerate}
  \item \(\mathcal S\) jest \emph{pojedynczą} ścieżką skierowaną z \(p_0\),
  o mniej niż \(\log_3U_0\) krawędziach;
  \item każdy stan \(\mathcal D\setminus\mathcal S\) ma co najwyżej jedno
  dziecko w \(\mathcal D\), więc \(\mathcal D\setminus\mathcal S\) jest
  rozłączną sumą ścieżek skierowanych, każda o mniej niż
  \(\log_3(x/U_0)\) krawędziach;
  \item pierwszy wierzchołek każdej takiej ścieżki jest dzieckiem
  wierzchołka z \(\mathcal S\).
\end{enumerate}
W konsekwencji
\[
  \abs{\mathcal D}\ \le\
  \bigl(1+\log_3U_0\bigr)
  \Bigl(1+\Omega\,\log_3\tfrac{x}{U_0}\Bigr),
  \qquad
  \Omega=\max_{v\in\mathcal S}\omega(N-v),
\]
a ponieważ \(\log_3U_0\) i \(\log_3(x/U_0)\) są oba
\(\tfrac12\log_3x+O(1)\), zaś \(\omega(n)\ll\log n/\log\log n\),
\[
  \abs{\mathcal D}=O\!\left(\frac{\log^3N}{\log\log N}\right),
  \qquad
  \abs{\partial\mathcal D}=O\!\left(\frac{\log^4N}{(\log\log N)^2}\right).
\]
\end{theorem}

\begin{proof}
Punkt 2 \cref{thm:atak4-flux} mówi, że każdy stan ma co najwyżej jedno
dziecko z \(K_q<U_0\). Ponadto dziecko stanu o \(K\ge U_0\) spełnia
\(K_q=Kn/q\ge3K>U_0\), więc żadne dziecko takiego stanu nie wpada do
\(\mathcal S\). Zbiór \(\mathcal S\) jest zatem drzewem ukorzenionym
o stopniu wyjściowym co najwyżej \(1\), czyli ścieżką; wzdłuż niej \(K\)
mnoży się przez \(n/q\ge3\), co daje oszacowanie długości. To jest punkt 1.

Punkt 2 wynika wprost z punktu 1 \cref{thm:atak4-flux}: stan o
\(K\ge U_0\) ma co najwyżej jedno dziecko pozostające w \(\mathcal D\).
Wzdłuż takiej ścieżki \(K\) rośnie co najmniej trzykrotnie na krok,
startując z \(\ge U_0\) i pozostając poniżej \(x\).

Punkt 3: gdyby rodzic pierwszego wierzchołka maksymalnej ścieżki leżał
w \(\mathcal D\setminus\mathcal S\), to miałby co najwyżej jedno dziecko
w \(\mathcal D\), więc należałby do tej samej ścieżki, wbrew
maksymalności. Liczba maksymalnych ścieżek nie przekracza więc
\(\sum_{v\in\mathcal S}\omega(N-v)\le\abs{\mathcal S}\,\Omega\).
Zsumowanie długości daje tezę; oszacowanie \(\abs{\partial\mathcal D}\)
otrzymujemy przez \(\sum_{v\in\mathcal D}\omega(N-v)\).
\end{proof}
```
