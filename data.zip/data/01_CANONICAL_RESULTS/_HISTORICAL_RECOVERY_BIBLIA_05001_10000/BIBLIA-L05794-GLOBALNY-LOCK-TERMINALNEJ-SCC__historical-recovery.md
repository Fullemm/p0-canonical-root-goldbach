---
id: BIBLIA-L05794-GLOBALNY-LOCK-TERMINALNEJ-SCC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5794
line_end: 5842
env: theorem
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Globalny lock terminalnej SCC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5794-5842`
- Historical environment: `theorem`
- Original label: `thm:global-scc-product-lock`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Globalny iloczynowy lock
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Globalny lock terminalnej SCC] Niech [ E_j= _i=1^r a_ij. ] Wtedy T_C:= _i(N-p_i) _i p_i

## Exact source transcript

```tex
\begin{theorem}[Globalny lock terminalnej SCC]
\label{thm:global-scc-product-lock}
Niech
\[
 E_j=\sum_{i=1}^r a_{ij}.
\]
Wtedy
\begin{equation}
 T_C:=\frac{\prod_i(N-p_i)}{\prod_i p_i}
     =\prod_jp_j^{E_j-1}
     \in\N
 \label{eq:scc-global-T}
\end{equation}
oraz
\begin{equation}
 \boxed{T_C\equiv(-1)^r\pmod N.}
 \label{eq:scc-global-congruence}
\end{equation}
W szczególności
\begin{equation}
 T_C\ge
 \begin{cases}
 N+1,&r\text{ parzyste},\\
 N-1,&r\text{ nieparzyste}.
 \end{cases}
 \label{eq:scc-global-lower}
\end{equation}
\end{theorem}

\begin{proof}
Mnożenie \eqref{eq:scc-row-factorization} po wszystkich $i$ daje
\[
 \prod_i(N-p_i)=\prod_jp_j^{E_j}.
\]
Silna spójność supportu daje $E_j\ge1$, więc iloraz
\eqref{eq:scc-global-T} jest całkowity. Modulo $N$ mamy
\[
 T_C\prod_ip_i\equiv(-1)^r\prod_ip_i.
\]
Aktywność wszystkich $p_i$ pozwala skrócić ich iloczyn, co dowodzi
\eqref{eq:scc-global-congruence}.

Ponadto
\[
 \sum_j(E_j-1)=\sum_i\Omega(N-p_i)-r\ge r,
\]
więc $T_C>1$. Kongruencja daje
\eqref{eq:scc-global-lower}.
\end{proof}
```
