---
id: BIBLIA-L05852-SMALL-VERTEX-NECESSITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5852
line_end: 5869
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Small-Vertex Necessity

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5852-5869`
- Historical environment: `corollary`
- Original label: `cor:scc-small-vertex`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Mały wierzchołek albo duży rdzeń
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Small-Vertex Necessity] Dla m= C zachodzi m N1+(N-1)^1/r. Dla parzystego r wolno zastąpić N-1 przez N+1.

## Exact source transcript

```tex
\begin{corollary}[Small-Vertex Necessity]
\label{cor:scc-small-vertex}
Dla $m=\min C$ zachodzi
\begin{equation}
 \boxed{m\le\frac{N}{1+(N-1)^{1/r}}.}
 \label{eq:scc-small-vertex}
\end{equation}
Dla parzystego $r$ wolno zastąpić $N-1$ przez $N+1$.
\end{corollary}

\begin{proof}
Funkcja $p\mapsto(N-p)/p$ jest ściśle malejąca, zatem
\[
 T_C=\prod_{p\in C}\frac{N-p}{p}
 \le\left(\frac{N-m}{m}\right)^r.
\]
Łączymy to z \eqref{eq:scc-global-lower} i rozwiązujemy względem $m$.
\end{proof}
```
