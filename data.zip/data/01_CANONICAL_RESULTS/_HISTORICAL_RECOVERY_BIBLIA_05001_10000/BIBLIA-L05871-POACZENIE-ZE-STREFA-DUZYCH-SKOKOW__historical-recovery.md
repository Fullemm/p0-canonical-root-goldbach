---
id: BIBLIA-L05871-POACZENIE-ZE-STREFA-DUZYCH-SKOKOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5871
line_end: 5892
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Połączenie ze strefą dużych skoków

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5871-5892`
- Historical environment: `corollary`
- Original label: `cor:scc-large-jump-zone`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Mały wierzchołek albo duży rdzeń
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Połączenie ze strefą dużych skoków] Każda terminalna zła SCC spełnia C< 5N108 albo |C| (N-1) (103/5) =0.3305 N+O(1).

## Exact source transcript

```tex
\begin{corollary}[Połączenie ze strefą dużych skoków]
\label{cor:scc-large-jump-zone}
Każda terminalna zła SCC spełnia
\begin{equation}
 \boxed{
 \min C<\frac{5N}{108}
 \quad\text{albo}\quad
 |C|\ge\frac{\log(N-1)}{\log(103/5)}
 =0.3305\ldots\log N+O(1).
 }
 \label{eq:scc-zone-dichotomy}
\end{equation}
\end{corollary}

\begin{proof}
Jeżeli wszystkie $p\in C$ są co najmniej równe $5N/108$, to
\[
 \frac{N-p}{p}\le\frac{103}{5}.
\]
Stąd $T_C\le(103/5)^r$. Użycie
\eqref{eq:scc-global-lower} kończy dowód.
\end{proof}
```
