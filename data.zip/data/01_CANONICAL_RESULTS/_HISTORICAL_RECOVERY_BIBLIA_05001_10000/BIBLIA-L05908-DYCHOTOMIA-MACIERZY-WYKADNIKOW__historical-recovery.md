---
id: BIBLIA-L05908-DYCHOTOMIA-MACIERZY-WYKADNIKOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5908
line_end: 5946
env: theorem
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Dychotomia macierzy wykładników

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5908-5946`
- Historical environment: `theorem`
- Original label: `thm:scc-matrix-dichotomy`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Dychotomia macierzy wykładników] Zachodzi dokładnie jeden z przypadków: 0 i dla każdego p_j C p_j^ 1 N, _N(p_j) 2 ;

## Exact source transcript

```tex
\begin{theorem}[Dychotomia macierzy wykładników]
\label{thm:scc-matrix-dichotomy}
Zachodzi dokładnie jeden z przypadków:
\begin{enumerate}
 \item $\Delta\ne0$ i dla każdego $p_j\in C$
 \begin{equation}
  p_j^\Delta\equiv\pm1\pmod N,
  \qquad \ord_N(p_j)\mid2\abs\Delta;
  \label{eq:scc-order-lock}
 \end{equation}
 \item $\Delta=0$ i dla każdego
 $y\in\ker(B^T)\cap\Z^r$
 \begin{align}
  \prod_i\left(\frac{N-p_i}{p_i}\right)^{y_i}&=1,
  \label{eq:scc-resonance}\\
  \sum_i y_i&\equiv0\pmod2.
  \label{eq:scc-kernel-parity}
 \end{align}
 Każdy niezerowy $y$ ma współrzędne obu znaków.
\end{enumerate}
\end{theorem}

\begin{proof}
Jeżeli $\Delta\ne0$, mnożymy relacje
\eqref{eq:scc-row-unit-relation} do całkowitych potęg danych przez
odpowiedni wiersz $\operatorname{adj}(B)$. Tożsamość
$\operatorname{adj}(B)B=\Delta I$ izoluje $p_j^\Delta$; prawa strona
jest potęgą $-1$. Po podniesieniu do kwadratu otrzymujemy ograniczenie
rzędu.

Jeżeli $B^Ty=0$, to $A^Ty=y$. Mnożenie dokładnych faktoryzacji
\eqref{eq:scc-row-factorization} do potęg $y_i$ daje
\eqref{eq:scc-resonance}. Mnożenie kongruencji
\eqref{eq:scc-row-unit-relation} daje
$1\equiv(-1)^{\sum_i y_i}\pmod N$, a $N>2$ daje
\eqref{eq:scc-kernel-parity}. Wszystkie ilorazy w
\eqref{eq:scc-resonance} są większe od $1$, więc niezerowy wektor nie
może mieć tylko jednego znaku.
\end{proof}
```
