---
id: BIBLIA-L05948-OSCYLACJA-REZONANSU-ZBILANSOWANEGO
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5948
line_end: 5964
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Oscylacja rezonansu zbilansowanego

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5948-5964`
- Historical environment: `corollary`
- Original label: `cor:scc-resonance-oscillation`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Oscylacja rezonansu zbilansowanego] Uporządkujmy p_1< <p_r. Jeżeli niezerowy wektor rezonansowy y spełnia dodatkowo _i y_i=0, to sumy częściowe S_k= _i ky_i przyjmują wartości dodatnie i ujemne. Dla ściśle malejącej funkcji

## Exact source transcript

```tex
\begin{corollary}[Oscylacja rezonansu zbilansowanego]
\label{cor:scc-resonance-oscillation}
Uporządkujmy $p_1<\cdots<p_r$. Jeżeli niezerowy wektor rezonansowy $y$
spełnia dodatkowo $\sum_i y_i=0$, to sumy częściowe
$S_k=\sum_{i\le k}y_i$ przyjmują wartości dodatnie i ujemne.
\end{corollary}

\begin{proof}
Dla ściśle malejącej funkcji
$f(p)=\log((N-p)/p)$ logarytm
\eqref{eq:scc-resonance} i sumowanie przez części dają
\[
 0=\sum_{k=1}^{r-1}S_k\bigl(f(p_k)-f(p_{k+1})\bigr).
\]
Wszystkie różnice są dodatnie. Sumy częściowe jednego znaku nie mogą
więc dać zera, chyba że $y=0$.
\end{proof}
```
