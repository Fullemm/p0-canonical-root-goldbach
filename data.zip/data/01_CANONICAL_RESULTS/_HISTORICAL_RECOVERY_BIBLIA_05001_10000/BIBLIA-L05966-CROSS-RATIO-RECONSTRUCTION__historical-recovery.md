---
id: BIBLIA-L05966-CROSS-RATIO-RECONSTRUCTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5966
line_end: 5990
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Cross-Ratio Reconstruction

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5966-5990`
- Historical environment: `corollary`
- Original label: `cor:scc-cross-ratio`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Cross-Ratio Reconstruction] Jeżeli lewy kernel zawiera wektor y=e_a+e_d-e_b-e_c wsparty na czterech różnych wierzchołkach a,b,c,d C, to N= bc(a+d)-ad(b+c)bc-ad.

## Exact source transcript

```tex
\begin{corollary}[Cross-Ratio Reconstruction]
\label{cor:scc-cross-ratio}
Jeżeli lewy kernel zawiera wektor
$y=e_a+e_d-e_b-e_c$ wsparty na czterech różnych wierzchołkach
$a,b,c,d\in C$, to
\begin{equation}
 \boxed{
 N=\frac{bc(a+d)-ad(b+c)}{bc-ad}.
 }
 \label{eq:scc-cross-ratio}
\end{equation}
W szczególności te cztery wierzchołki wyznaczają $N$ jednoznacznie.
\end{corollary}

\begin{proof}
Równanie \eqref{eq:scc-resonance} ma w tym przypadku postać
\[
 \frac{N-a}{a}\frac{N-d}{d}
 =\frac{N-b}{b}\frac{N-c}{c}.
\]
Po wymnożeniu mianowników wyrazy stałe $abcd$ kasują się. Dzieląc przez
$N>0$, otrzymujemy \eqref{eq:scc-cross-ratio}. Mianownik nie znika,
bo $bc=ad$ dla czterech różnych liczb pierwszych przeczyłoby
jednoznaczności rozkładu.
\end{proof}
```
