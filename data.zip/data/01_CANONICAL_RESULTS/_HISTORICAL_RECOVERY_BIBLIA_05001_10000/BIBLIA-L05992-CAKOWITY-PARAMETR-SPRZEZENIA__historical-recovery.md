---
id: BIBLIA-L05992-CAKOWITY-PARAMETR-SPRZEZENIA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 5992
line_end: 6036
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Całkowity parametr sprzężenia

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:5992-6036`
- Historical environment: `corollary`
- Original label: `cor:scc-integral-coupling`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Całkowity parametr sprzężenia] Przy założeniach Corollary~ istnieje parzysta liczba całkowita k 2 taka, że N=a+d+kad=b+c+kbc. Ponadto

## Exact source transcript

```tex
\begin{corollary}[Całkowity parametr sprzężenia]
\label{cor:scc-integral-coupling}
Przy założeniach Corollary~\ref{cor:scc-cross-ratio} istnieje parzysta
liczba całkowita $k\ge2$ taka, że
\begin{equation}
 \boxed{N=a+d+kad=b+c+kbc.}
 \label{eq:scc-coupling-normal-form}
\end{equation}
Ponadto
\begin{equation}
 \boxed{kN+1=(ka+1)(kd+1)=(kb+1)(kc+1),}
 \label{eq:scc-kN-factorizations}
\end{equation}
a każda z par $\{a,d\}$ i $\{b,c\}$ tworzy skierowany 2-cykl w
supporcie $A$. W szczególności
\begin{equation}
 \min(a,d)<\sqrt{N/2},
 \qquad
 \min(b,c)<\sqrt{N/2}.
 \label{eq:scc-two-small-vertices}
\end{equation}
\end{corollary}

\begin{proof}
Niech $D=bc-ad$ i $S=a+d-b-c$. Z
\eqref{eq:scc-cross-ratio} wynika
\[
 N-(b+c)=\frac{bcS}{D},
 \qquad
 N-(a+d)=\frac{adS}{D}.
\]
Cztery liczby pierwsze są różne, więc
$\gcd(D,bc)=\gcd(D,ad)=1$. Całkowitość $N$ daje $D\mid S$.
Położenie $k=S/D$ daje \eqref{eq:scc-coupling-normal-form}.

Liczba $k$ jest parzysta, ponieważ $N$ oraz sumy dwóch nieparzystych
liczb pierwszych są parzyste, a ich iloczyny są nieparzyste. Dla
$k\le-1$ mielibyśmy $N\le b+c-bc<0$. Przypadek $k=0$ dawałby
$N-b=c$, czyli wiersz pierwszy w złej SCC. Zatem $k\ge2$.

Rozwinięcie obu stron daje \eqref{eq:scc-kN-factorizations}. Z kolei
$N-a=d(ka+1)$ i $N-d=a(kd+1)$, a analogiczne równości zachodzą dla
$b,c$; stąd oba 2-cykle. Wreszcie $kad<N$ i $kbc<N$, co przy $k\ge2$
daje \eqref{eq:scc-two-small-vertices}.
\end{proof}
```
