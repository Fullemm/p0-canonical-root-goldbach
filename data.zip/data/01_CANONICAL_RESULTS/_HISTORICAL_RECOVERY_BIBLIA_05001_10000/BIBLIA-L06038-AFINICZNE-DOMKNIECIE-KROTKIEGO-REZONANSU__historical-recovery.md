---
id: BIBLIA-L06038-AFINICZNE-DOMKNIECIE-KROTKIEGO-REZONANSU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6038
line_end: 6061
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Afiniczne domknięcie krótkiego rezonansu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6038-6061`
- Historical environment: `corollary`
- Original label: `cor:scc-affine-closure`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Afiniczne domknięcie krótkiego rezonansu] Zachodzą (ka+1), (kd+1), (kb+1), (kc+1) C oraz

## Exact source transcript

```tex
\begin{corollary}[Afiniczne domknięcie krótkiego rezonansu]
\label{cor:scc-affine-closure}
Zachodzą
\begin{equation}
 \PF(ka+1),\PF(kd+1),\PF(kb+1),\PF(kc+1)\subseteq C
 \label{eq:scc-affine-closure}
\end{equation}
oraz
\begin{equation}
 \boxed{\PF(kN+1)\subseteq C.}
 \label{eq:scc-kN-closure}
\end{equation}
Dla $N\ge234$ co najmniej dwa spośród $a,b,c,d$ są mniejsze niż
$5N/108$.
\end{corollary}

\begin{proof}
Pierwsze włączenia wynikają z terminalności i równości
$N-a=d(ka+1)$ oraz trzech analogicznych. Równanie
\eqref{eq:scc-kN-factorizations} daje drugie włączenie. Wreszcie każda
z rozłącznych par $\{a,d\}$, $\{b,c\}$ zawiera wierzchołek mniejszy od
$\sqrt{N/2}$, a dla $N\ge234$ mamy
$\sqrt{N/2}<5N/108$.
\end{proof}
```
