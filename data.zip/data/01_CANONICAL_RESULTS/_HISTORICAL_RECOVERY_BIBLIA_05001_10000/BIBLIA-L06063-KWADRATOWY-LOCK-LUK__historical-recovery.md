---
id: BIBLIA-L06063-KWADRATOWY-LOCK-LUK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6063
line_end: 6111
env: corollary
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Kwadratowy lock luk

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6063-6111`
- Historical environment: `corollary`
- Original label: `cor:scc-square-gap-lock`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Determinant albo rezonans
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Kwadratowy lock luk] Przy tych samych założeniach zachodzą podzielności ka+1& (a-b)(a-c),&kd+1& (d-b)(d-c), kb+1& (b-a)(b-d),&kc+1& (c-a)(c-d), oraz istnieje L 4 takie, że

## Exact source transcript

```tex
\begin{corollary}[Kwadratowy lock luk]
\label{cor:scc-square-gap-lock}
Przy tych samych założeniach zachodzą podzielności
\begin{align}
 ka+1&\mid(a-b)(a-c),&kd+1&\mid(d-b)(d-c),\nonumber\\
 kb+1&\mid(b-a)(b-d),&kc+1&\mid(c-a)(c-d),
 \label{eq:scc-gap-divisibilities}
\end{align}
oraz istnieje $L\in4\Z$ takie, że
\begin{equation}
 \boxed{
 (a-b)(a-c)(d-b)(d-c)=(kN+1)L^2.
 }
 \label{eq:scc-square-gap-lock}
\end{equation}
Po uporządkowaniu $a<d$ i $b<c$ jedna para ściśle zawiera drugą:
\begin{equation}
 \boxed{a<b<c<d\quad\text{albo}\quad b<a<d<c.}
 \label{eq:scc-pair-nesting}
\end{equation}
\end{corollary}

\begin{proof}
Piszemy $X_p=kp+1$. Jeżeli $x\mid yz$, to
$x\mid\gcd(x,y)\gcd(x,z)$. Ponadto
$\gcd(X_p,X_q)\mid p-q$, gdyż ten największy wspólny dzielnik jest
względnie pierwszy z $k$ i dzieli $k(p-q)$. Z równości
$X_aX_d=X_bX_c$ otrzymujemy \eqref{eq:scc-gap-divisibilities}.

Liczby
\[
 L_b=\frac{(a-b)(d-b)}{X_b},
 \qquad
 L_c=\frac{(a-c)(d-c)}{X_c}
\]
są całkowite. Po zapisaniu różnic jako
$a-b=(X_a-X_b)/k$ okazuje się, że
$k^2L_b=k^2L_c=X_b+X_c-X_a-X_d$. Zatem $L_b=L_c=L$ i
\[
 (a-b)(d-b)(a-c)(d-c)=X_bX_cL^2=(kN+1)L^2.
\]
Obie różnice w liczniku $L_b$ są parzyste, a $X_b$ jest nieparzyste,
więc $4\mid L$.

Układ naprzemienny par dawałby ujemną lewą stronę
\eqref{eq:scc-square-gap-lock}. Układ dwóch rozłącznych przedziałów
przeczyłby ścisłej monotoniczności $(N-p)/p$ w
\eqref{eq:scc-resonance}. Pozostają dokładnie dwa układy zagnieżdżone.
\end{proof}
```
