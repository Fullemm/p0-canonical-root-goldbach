---
id: BIBLIA-L06115-MAE-RDZENIE-SA-NIEREZONANSOWE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6115
line_end: 6143
env: proposition
visibility_class: PRESENT_PARTIAL_CURRENT
recovery_priority: HIGH
---

# Małe rdzenie są nierezonansowe

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6115-6143`
- Historical environment: `proposition`
- Original label: `prop:scc-small-nonresonant`
- Section: Iteracja 9: globalny lock SCC i rezonans wykładników > Rdzenie rozmiaru dwa i trzy
- Visibility classification: **PRESENT_PARTIAL_CURRENT**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Małe rdzenie są nierezonansowe] Jeżeli terminalna zła SCC ma dwa albo trzy wierzchołki, to (A-I) 0. Dla dwóch wierzchołków [

## Exact source transcript

```tex
\begin{proposition}[Małe rdzenie są nierezonansowe]
\label{prop:scc-small-nonresonant}
Jeżeli terminalna zła SCC ma dwa albo trzy wierzchołki, to
$\det(A-I)\ne0$.
\end{proposition}

\begin{proof}
Dla dwóch wierzchołków
\[
 A=\begin{pmatrix}0&a\\b&0\end{pmatrix},
 \qquad a,b\ge2,
\]
więc $\det(A-I)=1-ab\ne0$.

Dla trzech wierzchołków piszemy
\[
 A=\begin{pmatrix}0&a&b\\c&0&d\\e&f&0\end{pmatrix}.
\]
Wtedy
\[
 \det(A-I)=-1+ac+be+df+ade+bcf.
\]
Suma po $-1$ zbiera wagi skierowanych cykli prostych supportu. Gdyby
była równa $1$, istniałby dokładnie jeden taki cykl, o wszystkich wagach
równych $1$. W silnie spójnym grafie każda dodatkowa krawędź leży na
cyklu, więc support musiałby być dokładnie trójcyklem jednostkowym.
Każda suma wiersza byłaby wtedy równa $1$, sprzecznie ze złożonością
wierszy.
\end{proof}
```
