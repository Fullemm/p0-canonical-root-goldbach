---
id: BIBLIA-L06239-SQUARE-ROOT-ATTRACTOR
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6239
line_end: 6259
env: theorem
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Square-Root Attractor

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6239-6259`
- Historical environment: `theorem`
- Original label: `thm:sqrt-attractor`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Uniwersalny atraktor poniżej pierwiastka
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Square-Root Attractor] Funkcja [ f(p)=P^-(N-p) ] odwzorowuje całe C do L. Jej ograniczenie f:L L zawiera skierowany cykl długości co najmniej 2. W szczególności każda terminalna zła SCC zawiera co najmniej dwa wierzchołki poniżej

## Exact source transcript

```tex
\begin{theorem}[Square-Root Attractor]
\label{thm:sqrt-attractor}
Funkcja
\[
 f(p)=P^-(N-p)
\]
odwzorowuje całe $C$ do $L$. Jej ograniczenie $f:L\to L$ zawiera
skierowany cykl długości co najmniej $2$. W szczególności każda
terminalna zła SCC zawiera co najmniej dwa wierzchołki poniżej
$\sqrt N$.
\end{theorem}

\begin{proof}
Liczba $N-p$ jest złożona, więc
\[
 f(p)^2\le N-p<N.
\]
Terminalność daje $f(p)\in C$, stąd $f(p)\in L$. Funkcja na skończonym
zbiorze $L$ ma cykl. Pętla wymagałaby $p\mid N-p$, a więc $p\mid N$,
sprzecznie z aktywnością.
\end{proof}
```
