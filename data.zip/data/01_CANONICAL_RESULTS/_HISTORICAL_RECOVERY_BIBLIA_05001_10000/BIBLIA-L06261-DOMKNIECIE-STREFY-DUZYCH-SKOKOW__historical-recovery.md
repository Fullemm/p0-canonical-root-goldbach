---
id: BIBLIA-L06261-DOMKNIECIE-STREFY-DUZYCH-SKOKOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6261
line_end: 6273
env: corollary
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Domknięcie strefy dużych skoków

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6261-6273`
- Historical environment: `corollary`
- Original label: `cor:sqrt-large-jump-zone`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Uniwersalny atraktor poniżej pierwiastka
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Domknięcie strefy dużych skoków] Dla N 468 każda terminalna zła SCC zawiera cały cykl w przedziale 0<p< N< 5N108.

## Exact source transcript

```tex
\begin{corollary}[Domknięcie strefy dużych skoków]
\label{cor:sqrt-large-jump-zone}
Dla $N\ge468$ każda terminalna zła SCC zawiera cały cykl w przedziale
\begin{equation}
 0<p<\sqrt N<\frac{5N}{108}.
 \label{eq:sqrt-inside-large-jump}
\end{equation}
\end{corollary}

\begin{proof}
Pozostaje podnieść nierówność $\sqrt N<5N/108$ do kwadratu; jest ona
równoważna $N>(108/5)^2=466{,}56$.
\end{proof}
```
