---
id: BIBLIA-L06277-HIGH-LAYER-FUNCTIONAL-STRUCTURE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6277
line_end: 6287
env: lemma
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# High-Layer Functional Structure

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6277-6287`
- Historical environment: `lemma`
- Original label: `lem:sqrt-high-functional`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Struktura wysokiej warstwy
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[High-Layer Functional Structure] W każdym wierszu A występuje co najwyżej jeden czynnik z H, zawsze z wykładnikiem 1. Blok A_HH jest więc macierzą 0,1 o sumach wierszy nie większych niż 1. Iloczyn dwóch czynników większych od N, podobnie jak kwadrat

## Exact source transcript

```tex
\begin{lemma}[High-Layer Functional Structure]
\label{lem:sqrt-high-functional}
W każdym wierszu $A$ występuje co najwyżej jeden czynnik z $H$, zawsze z
wykładnikiem $1$. Blok $A_{HH}$ jest więc macierzą $0,1$ o sumach
wierszy nie większych niż $1$.
\end{lemma}

\begin{proof}
Iloczyn dwóch czynników większych od $\sqrt N$, podobnie jak kwadrat
jednego z nich, byłby większy od $N$, choć dzieliłby $N-p<N$.
\end{proof}
```
