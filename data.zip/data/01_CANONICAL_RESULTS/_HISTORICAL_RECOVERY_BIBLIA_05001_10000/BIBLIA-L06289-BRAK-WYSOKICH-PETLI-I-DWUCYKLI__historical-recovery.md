---
id: BIBLIA-L06289-BRAK-WYSOKICH-PETLI-I-DWUCYKLI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6289
line_end: 6306
env: lemma
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Brak wysokich pętli i dwucykli

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6289-6306`
- Historical environment: `lemma`
- Original label: `lem:sqrt-no-high-two-cycle`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Struktura wysokiej warstwy
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Brak wysokich pętli i dwucykli] Graf indukowany przez H nie ma cyklu długości 1 ani 2. Pętlę wyklucza aktywność. Gdyby różne p,q> N tworzyły dwucykl, to dla pewnych a,b>1 [

## Exact source transcript

```tex
\begin{lemma}[Brak wysokich pętli i dwucykli]
\label{lem:sqrt-no-high-two-cycle}
Graf indukowany przez $H$ nie ma cyklu długości $1$ ani $2$.
\end{lemma}

\begin{proof}
Pętlę wyklucza aktywność. Gdyby różne $p,q>\sqrt N$ tworzyły dwucykl,
to dla pewnych $a,b>1$
\[
 N-p=aq,\qquad N-q=bp.
\]
Mamy $a,b<\sqrt N<p,q$. Odjęcie równań daje
\[
 q(a-1)=p(b-1).
\]
Pierwszość i różność $p,q$ wymuszają $p\mid a-1$, choć
$0<a-1<p$; sprzeczność.
\end{proof}
```
