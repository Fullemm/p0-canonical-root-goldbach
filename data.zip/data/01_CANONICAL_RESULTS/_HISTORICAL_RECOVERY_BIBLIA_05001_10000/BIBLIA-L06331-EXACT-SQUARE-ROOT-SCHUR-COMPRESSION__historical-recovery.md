---
id: BIBLIA-L06331-EXACT-SQUARE-ROOT-SCHUR-COMPRESSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6331
line_end: 6364
env: theorem
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Exact Square-Root Schur Compression

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6331-6364`
- Historical environment: `theorem`
- Original label: `thm:sqrt-schur-compression`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Dokładne całkowanie wysokich ścieżek
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Exact Square-Root Schur Compression] Zachodzą (A-I_r)&=(-1)^|R| (A_*-I_|K|), (A^T-I_r)&= (A_*^T-I_|K|).

## Exact source transcript

```tex
\begin{theorem}[Exact Square-Root Schur Compression]
\label{thm:sqrt-schur-compression}
Zachodzą
\begin{align}
 \det(A-I_r)&=(-1)^{|R|}\det(A_*-I_{|K|}),
 \label{eq:sqrt-det-compression}\\
 \dim\ker(A^T-I_r)&=\dim\ker(A_*^T-I_{|K|}).
 \label{eq:sqrt-nullity-compression}
\end{align}
Jeżeli $z\in\ker(A_*^T-I)\cap\Z^K$, to jego jedynym podniesieniem do
pełnego lewego jądra jest
\begin{equation}
 y_K=z,
 \qquad
 y_R=(I-A_{RR}^T)^{-1}A_{KR}^Tz,
 \label{eq:sqrt-kernel-lift}
\end{equation}
i podniesienie jest całkowite.
\end{theorem}

\begin{proof}
Dla $B=A-I$ blok
$B_{RR}=-(I-A_{RR})$ jest odwracalny i ma wyznacznik $(-1)^{|R|}$.
Jego dopełnienie Schura wynosi
\[
 B_{KK}-B_{KR}B_{RR}^{-1}B_{RK}
 =A_*-I.
\]
Standardowa eliminacja blokowa daje
\eqref{eq:sqrt-det-compression}--\eqref{eq:sqrt-nullity-compression}.
Dolne równanie układu $B^Ty=0$ daje
\eqref{eq:sqrt-kernel-lift}. Całkowitość wynika z rozwinięcia
\eqref{eq:sqrt-green}.
\end{proof}
```
