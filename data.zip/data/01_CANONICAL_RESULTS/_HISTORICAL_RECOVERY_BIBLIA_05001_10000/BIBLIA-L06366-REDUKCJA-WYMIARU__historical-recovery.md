---
id: BIBLIA-L06366-REDUKCJA-WYMIARU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6366
line_end: 6381
env: corollary
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Redukcja wymiaru

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6366-6381`
- Historical environment: `corollary`
- Original label: `cor:sqrt-dimension-bound`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Dokładne całkowanie wysokich ścieżek
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Redukcja wymiaru] Jeśli c_H jest liczbą cykli wysokiej warstwy, to |K|=|L|+c_H |C|+2|L|3. Gdy H jest acykliczne, K=L: cały determinant i rezonans żyją na

## Exact source transcript

```tex
\begin{corollary}[Redukcja wymiaru]
\label{cor:sqrt-dimension-bound}
Jeśli $c_H$ jest liczbą cykli wysokiej warstwy, to
\begin{equation}
 |K|=|L|+c_H
 \le\frac{|C|+2|L|}{3}.
 \label{eq:sqrt-compressed-size}
\end{equation}
Gdy $H$ jest acykliczne, $K=L$: cały determinant i rezonans żyją na
wierzchołkach poniżej $\sqrt N$.
\end{corollary}

\begin{proof}
Na mocy \cref{lem:sqrt-no-high-two-cycle} wysokie cykle są rozłączne i
mają długość co najmniej $3$, więc $3c_H\le|H|$.
\end{proof}
```
