---
id: BIBLIA-L06385-PERRON-EXPONENT-SLOPE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6385
line_end: 6412
env: theorem
visibility_class: KNOWN_OLDER_ORIGIN
recovery_priority: CRITICAL
---

# Perron Exponent-Slope

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6385-6412`
- Historical environment: `theorem`
- Original label: `thm:sqrt-perron-slope`
- Section: Iteracja 10: pierwiastkowy atraktor SCC > Spektralna pochodna wykładnikowa
- Visibility classification: **KNOWN_OLDER_ORIGIN**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Perron Exponent-Slope] Niech = (A). Istnieje p_i C takie, że N-p_i p_i^ , p_i<N^1/ N.

## Exact source transcript

```tex
\begin{theorem}[Perron Exponent-Slope]
\label{thm:sqrt-perron-slope}
Niech $\rho=\rho(A)$. Istnieje $p_i\in C$ takie, że
\begin{equation}
 N-p_i\ge p_i^\rho,
 \qquad p_i<N^{1/\rho}\le\sqrt N.
 \label{eq:sqrt-perron-small-vertex}
\end{equation}
\end{theorem}

\begin{proof}
Twierdzenie Perrona--Frobeniusa daje dodatni wektor $w$ taki, że
$w^TA=\rho w^T$. Dla $\ell_i=\log p_i$ równanie
\eqref{eq:sqrt-row-factorization} daje
\[
 A\ell=(\log(N-p_i))_i.
\]
Zatem
\[
 \rho=
 \frac{\sum_iw_i\log p_i\,
       \dfrac{\log(N-p_i)}{\log p_i}}
      {\sum_iw_i\log p_i}.
\]
Jeden z ilorazów jest co najmniej równy $\rho$. Każda suma wiersza $A$
jest co najmniej $2$, więc nierówność Collatza--Wielandta daje
$\rho\ge2$.
\end{proof}
```
