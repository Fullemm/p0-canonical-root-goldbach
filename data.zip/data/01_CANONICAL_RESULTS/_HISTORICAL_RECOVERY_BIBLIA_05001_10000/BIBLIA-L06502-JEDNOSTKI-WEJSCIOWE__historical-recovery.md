---
id: BIBLIA-L06502-JEDNOSTKI-WEJSCIOWE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6502
line_end: 6517
env: lemma
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Jednostki wejściowe

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6502-6517`
- Historical environment: `lemma`
- Original label: `lem:phase-units`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Ustawienie i jednostki
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Jednostki wejściowe] Liczby (p_0,p_i,P_i) są jednostkami modulo (N), natomiast (h,p_i,P_i) są jednostkami modulo (x). Ponieważ (h>0), pierwsza (p_0>x), więc nie dzieli (x), a jako liczba nieparzysta jest względnie pierwsza z (N=2x). Aktywność daje

## Exact source transcript

```tex
\begin{lemma}[Jednostki wejściowe]
\label{lem:phase-units}
Liczby \(p_0,p_i,P_i\) są jednostkami modulo \(N\), natomiast
\(h,p_i,P_i\) są jednostkami modulo \(x\).
\end{lemma}

\begin{proof}
Ponieważ \(h>0\), pierwsza \(p_0>x\), więc nie dzieli \(x\), a jako
liczba nieparzysta jest względnie pierwsza z \(N=2x\). Aktywność daje
\(\gcd(p_i,N)=1\). Jeżeli pierwsza \(q\) dzieli jednocześnie etykietę
krawędzi \(k=(N-p)/p'\) i \(N\), to \(q\mid N-p\) oraz \(q\mid N\),
zatem \(q\mid p\), wbrew aktywności parenta. Każda etykieta, a więc
również \(P_i\), jest jednostką modulo \(N\) i modulo \(x\).
Wreszcie wspólny dzielnik \(h\) i \(x\) dzieliłby pierwszą
\(p_0=x+h\); ponieważ \(0<h<p_0\), otrzymujemy \(\gcd(h,x)=1\).
\end{proof}
```
