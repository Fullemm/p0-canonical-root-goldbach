---
id: BIBLIA-L06521-PATH-INDEPENDENT-ENTRY-PHASE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6521
line_end: 6545
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Path-Independent Entry Phase

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6521-6545`
- Historical environment: `theorem`
- Original label: `thm:path-independent-entry-phase`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Normalizacja wejścia jest odwrotnością endpointu
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Path-Independent Entry Phase] Dla każdego (p_i C) zachodzą dokładne kongruencje _iP_ip_0^-1 p_i^-1 N, _iP_ih^-1 p_i^-1 x.

## Exact source transcript

```tex
\begin{theorem}[Path-Independent Entry Phase]
\label{thm:path-independent-entry-phase}
Dla każdego \(p_i\in C\) zachodzą dokładne kongruencje
\begin{align}
 \boxed{\epsilon_iP_ip_0^{-1}\equiv p_i^{-1}\pmod N,}
 \label{eq:phase-normal-N}\\
 \boxed{\epsilon_iP_ih^{-1}\equiv p_i^{-1}\pmod x.}
 \label{eq:phase-normal-x}
\end{align}
W szczególności obie znormalizowane fazy są niezależne od wyboru
ścieżki do \(p_i\).
\end{theorem}

\begin{proof}
Normalna postać winding dla wybranej ścieżki ma postać
\begin{equation}
 P_ip_i=W_iN+\epsilon_ip_0
 \label{eq:phase-winding}
\end{equation}
z całkowitym \(W_i\). Redukcja modulo \(N\) i użycie
\cref{lem:phase-units} daje \eqref{eq:phase-normal-N}. Ponieważ
\(N=2x\) oraz \(p_0=x+h\), redukcja \eqref{eq:phase-winding} modulo
\(x\) daje \(P_ip_i\equiv\epsilon_ih\pmod x\), czyli
\eqref{eq:phase-normal-x}. Prawe strony zależą tylko od endpointu.
\end{proof}
```
