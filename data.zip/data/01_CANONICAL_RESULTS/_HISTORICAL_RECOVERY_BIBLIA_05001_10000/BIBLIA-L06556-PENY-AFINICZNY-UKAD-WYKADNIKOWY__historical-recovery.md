---
id: BIBLIA-L06556-PENY-AFINICZNY-UKAD-WYKADNIKOWY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6556
line_end: 6575
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Pełny afiniczny układ wykładnikowy

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6556-6575`
- Historical environment: `theorem`
- Original label: `thm:full-affine-phase-system`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Normalizacja wejścia jest odwrotnością endpointu
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Pełny afiniczny układ wykładnikowy] Dla (M N,x), każdego wiersza (i) i ( B=A-I) zachodzi _j=1^r (r_j^(M) )^ B_ij -1 M.

## Exact source transcript

```tex
\begin{theorem}[Pełny afiniczny układ wykładnikowy]
\label{thm:full-affine-phase-system}
Dla \(M\in\{N,x\}\), każdego wiersza \(i\) i
\(\mathsf B=A-I\) zachodzi
\begin{equation}
 \boxed{
 \prod_{j=1}^r\bigl(r_j^{(M)}\bigr)^{\mathsf B_{ij}}
 \equiv-1\pmod M.}
 \label{eq:full-affine-phase-system}
\end{equation}
\end{theorem}

\begin{proof}
Z \eqref{eq:phase-row-factorization} modulo \(M\mid N\) mamy
\[
 \prod_jp_j^{a_{ij}}\equiv-p_i\pmod M.
\]
Wszystkie czynniki są jednostkami. Po podzieleniu przez \(p_i\) i
odwróceniu otrzymujemy dokładnie \eqref{eq:full-affine-phase-system}.
\end{proof}
```
