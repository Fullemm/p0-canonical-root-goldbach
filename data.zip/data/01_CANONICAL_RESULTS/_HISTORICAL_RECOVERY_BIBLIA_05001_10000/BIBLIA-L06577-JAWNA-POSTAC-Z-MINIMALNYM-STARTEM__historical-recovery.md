---
id: BIBLIA-L06577-JAWNA-POSTAC-Z-MINIMALNYM-STARTEM
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6577
line_end: 6589
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Jawna postać z minimalnym startem

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6577-6589`
- Historical environment: `corollary`
- Original label: `cor:full-p0-matrix-bridge`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Normalizacja wejścia jest odwrotnością endpointu
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Jawna postać z minimalnym startem] Dla każdego wiersza (i), przy (b_i= _j B_ij), zachodzi _j( _jP_j)^ B_ij & -p_0^b_i N, _j( _jP_j)^ B_ij

## Exact source transcript

```tex
\begin{corollary}[Jawna postać z minimalnym startem]
\label{cor:full-p0-matrix-bridge}
Dla każdego wiersza \(i\), przy
\(b_i=\sum_j\mathsf B_{ij}\), zachodzi
\begin{align}
 \prod_j(\epsilon_jP_j)^{\mathsf B_{ij}}
 &\equiv-p_0^{b_i}\pmod N,
 \label{eq:full-p0-matrix-bridge-N}\\
 \prod_j(\epsilon_jP_j)^{\mathsf B_{ij}}
 &\equiv-h^{b_i}\pmod x.
 \label{eq:full-p0-matrix-bridge-x}
\end{align}
\end{corollary}
```
