---
id: BIBLIA-L06608-EXACT-AFFINE-PHASE-COMPRESSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6608
line_end: 6651
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Exact Affine Phase Compression

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6608-6651`
- Historical environment: `theorem`
- Original label: `thm:exact-affine-phase-compression`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Afiniczna kompresja do portów A_*A*
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Exact Affine Phase Compression] Dla (M=N) oraz (M=x) pełny układ jest równoważny układowi portowemu _k K (r_k^(M) )^S_ik (-1)^ _i M (i K).

## Exact source transcript

```tex
\begin{theorem}[Exact Affine Phase Compression]
\label{thm:exact-affine-phase-compression}
Dla \(M=N\) oraz \(M=x\) pełny układ
\eqref{eq:full-affine-phase-system} jest równoważny układowi portowemu
\begin{equation}
 \boxed{
 \prod_{k\in K}\bigl(r_k^{(M)}\bigr)^{S_{ik}}
 \equiv(-1)^{\beta_i}\pmod M
 \qquad(i\in K).}
 \label{eq:compressed-affine-phase-system}
\end{equation}
Fazy usuniętego bloku podnoszą się jednoznacznie według wzoru
\begin{equation}
 \boxed{
 r_\rho^{(M)}\equiv
 (-1)^{(G\mathbf1_R)_\rho}
 \prod_{k\in K}
 \bigl(r_k^{(M)}\bigr)^{(GA_{RK})_{\rho k}}
 \pmod M.}
 \label{eq:phase-lifting}
\end{equation}
Jest to bijekcja pomiędzy rozwiązaniami pełnego i skompresowanego
układu w grupie jednostek modulo \(M\).
\end{theorem}

\begin{proof}
Zapiszmy grupę jednostek addytywnie, a element \(-1\) oznaczmy przez
\(\iota\). Dolny blok równania \(\mathsf Br=\iota\mathbf1\) ma postać
\[
 A_{RK}r_K+(A_{RR}-I)r_R=\iota\mathbf1_R.
\]
Ponieważ \((I-A_{RR})^{-1}=G\), otrzymujemy
\[
 r_R=GA_{RK}r_K-G\mathbf1_R\iota.
\]
Podstawienie do górnego bloku daje
\[
 Sr_K=(\mathbf1_K+A_{KR}G\mathbf1_R)\iota=\beta\iota.
\]
Po powrocie do notacji multiplikatywnej minus przy wykładniku znaku nie
ma znaczenia, bo \((-1)^{-a}=(-1)^a\). Otrzymujemy
\eqref{eq:compressed-affine-phase-system} i \eqref{eq:phase-lifting}.
Odwracalność bloku \(A_{RR}-I\) daje jednoznaczność w obie strony.
\end{proof}
```
