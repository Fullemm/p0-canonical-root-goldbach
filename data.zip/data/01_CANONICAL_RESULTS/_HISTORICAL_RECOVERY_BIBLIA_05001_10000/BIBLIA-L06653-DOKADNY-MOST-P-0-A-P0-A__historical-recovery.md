---
id: BIBLIA-L06653-DOKADNY-MOST-P-0-A-P0-A
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6653
line_end: 6666
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Dokładny most p_0 A_*p0-A*

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6653-6666`
- Historical environment: `corollary`
- Original label: `cor:exact-p0-Astar-bridge`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Afiniczna kompresja do portów A_*A*
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Dokładny most p_0 A_*p0-A*] Dla ( _i= _k KS_ik) zachodzi _k K( _kP_k)^S_ik (-1)^ _ip_0^ _i N,

## Exact source transcript

```tex
\begin{corollary}[Dokładny most \texorpdfstring{$p_0\to A_*$}{p0-A*}]
\label{cor:exact-p0-Astar-bridge}
Dla \(\rho_i=\sum_{k\in K}S_{ik}\) zachodzi
\begin{align}
 \boxed{
 \prod_{k\in K}(\epsilon_kP_k)^{S_{ik}}
 \equiv(-1)^{\beta_i}p_0^{\rho_i}\pmod N,}
 \label{eq:exact-p0-Astar-bridge-N}\\
 \boxed{
 \prod_{k\in K}(\epsilon_kP_k)^{S_{ik}}
 \equiv(-1)^{\beta_i}h^{\rho_i}\pmod x.}
 \label{eq:exact-p0-Astar-bridge-x}
\end{align}
\end{corollary}
```
