---
id: BIBLIA-L06674-PORT-ROOT-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6674
line_end: 6711
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Port Root Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6674-6711`
- Historical environment: `theorem`
- Original label: `thm:port-root-lock`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Gałąź wyznacznikowa i klasyfikacja Smitha
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Port Root Lock] Załóżmy [ = S 0, = adj(S) . ] Wtedy dla każdego (k K) i (M N,x)

## Exact source transcript

```tex
\begin{theorem}[Port Root Lock]
\label{thm:port-root-lock}
Załóżmy
\[
 \Delta=\det S\ne0,
 \qquad
 \gamma=\operatorname{adj}(S)\beta.
\]
Wtedy dla każdego \(k\in K\) i \(M\in\{N,x\}\)
\begin{equation}
 \boxed{\bigl(r_k^{(M)}\bigr)^\Delta
 \equiv(-1)^{\gamma_k}\pmod M.}
 \label{eq:port-root-lock}
\end{equation}
W szczególności
\begin{align}
 (\epsilon_kP_kp_0^{-1})^\Delta
 &\equiv(-1)^{\gamma_k}\pmod N,
 \label{eq:p0-port-root-lock}\\
 (\epsilon_kP_kh^{-1})^\Delta
 &\equiv(-1)^{\gamma_k}\pmod x.
 \label{eq:h-port-root-lock}
\end{align}
Jeżeli \(D=|\Delta|\), to bez względu na znaki
\begin{equation}
 \boxed{(P_kp_0^{-1})^{2D}\equiv1\pmod N.}
 \label{eq:p0-port-torsion}
\end{equation}
\end{theorem}

\begin{proof}
Mnożymy \eqref{eq:compressed-affine-phase-system} przez
\(\operatorname{adj}(S)\). Tożsamość
\(\operatorname{adj}(S)S=\Delta I\) daje
\eqref{eq:port-root-lock}. Następne dwa wzory wynikają z
\cref{thm:path-independent-entry-phase}; podniesienie do potęgi
\(2D\) usuwa oba znaki.
\end{proof}
```
