---
id: BIBLIA-L06713-AFINICZNA-KLASYFIKACJA-SMITHA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6713
line_end: 6741
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Afiniczna klasyfikacja Smitha

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6713-6741`
- Historical environment: `theorem`
- Original label: `thm:affine-smith-classification`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Gałąź wyznacznikowa i klasyfikacja Smitha
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Afiniczna klasyfikacja Smitha] Niech [ USV= diag(d_1, ,d_s,0, ,0) ] będzie postacią Smitha, gdzie (U,V) są unimodularne. Po zmianie współrzędnych (r_K=Vw) układ portowy jest równoważny

## Exact source transcript

```tex
\begin{theorem}[Afiniczna klasyfikacja Smitha]
\label{thm:affine-smith-classification}
Niech
\[
 USV=\operatorname{diag}(d_1,\ldots,d_s,0,\ldots,0)
\]
będzie postacią Smitha, gdzie \(U,V\) są unimodularne. Po zmianie
współrzędnych \(r_K=Vw\) układ portowy jest równoważny
\begin{equation}
 d_iw_i=(U\beta)_i\,[-1]\quad(i\le s),
 \label{eq:affine-smith-torsion}
\end{equation}
a każdy zerowy wiersz wymusza warunek parzystości
\begin{equation}
 \boxed{(U\beta)_i\equiv0\pmod2\quad(i>s).}
 \label{eq:affine-smith-parity}
\end{equation}
Pozostałe \(\nu=|K|-s=\dim\ker S\) współrzędnych są swobodnymi fazami
portowymi, z zastrzeżeniem przynależności do grupy jednostek modulo
\(M\).
\end{theorem}

\begin{proof}
W addytywnej notacji grupy jednostek układ brzmi
\(Sr=\beta[-1]\). Mnożenie przez \(U\) i podstawienie \(r=Vw\) daje
\eqref{eq:affine-smith-torsion}. Element \([-1]\) ma rząd dwa, więc
zerowy lewy bok jest zgodny dokładnie wtedy, gdy odpowiedni współczynnik
\(U\beta\) jest parzysty.
\end{proof}
```
