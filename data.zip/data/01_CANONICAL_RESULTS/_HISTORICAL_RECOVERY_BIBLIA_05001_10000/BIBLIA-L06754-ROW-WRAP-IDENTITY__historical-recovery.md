---
id: BIBLIA-L06754-ROW-WRAP-IDENTITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6754
line_end: 6771
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Row-Wrap Identity

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6754-6771`
- Historical environment: `theorem`
- Original label: `thm:row-wrap-identity`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Całkowity indeks zawinięcia
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Row-Wrap Identity] Dla każdego wiersza istnieje jednoznaczna liczba całkowita ( _i) taka, że E_ih^s_i-1P_i+ _iQ_i= _i x.

## Exact source transcript

```tex
\begin{theorem}[Row-Wrap Identity]
\label{thm:row-wrap-identity}
Dla każdego wiersza istnieje jednoznaczna liczba całkowita \(\tau_i\)
taka, że
\begin{equation}
 \boxed{
 E_ih^{s_i-1}P_i+\epsilon_iQ_i=\tau_i x.}
 \label{eq:row-wrap-identity}
\end{equation}
\end{theorem}

\begin{proof}
Z winding modulo \(x\) mamy
\(p_j\equiv\epsilon_jhP_j^{-1}\pmod x\). Podstawiamy to do
\(\prod_jp_j^{a_{ij}}\equiv-p_i\pmod x\), usuwamy jednostki i
otrzymujemy podzielność lewej strony \eqref{eq:row-wrap-identity} przez
\(x\). Iloraz definiuje \(\tau_i\).
\end{proof}
```
