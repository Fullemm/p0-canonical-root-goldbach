---
id: BIBLIA-L06773-FORCED-WRAP-ALBO-PRAWY-REZONANS
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6773
line_end: 6822
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Forced Wrap albo prawy rezonans

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6773-6822`
- Historical environment: `theorem`
- Original label: `thm:forced-wrap-or-right-resonance`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Całkowity indeks zawinięcia
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Forced Wrap albo prawy rezonans] Załóżmy, że (|C| 3). Jeżeli wszystkie ( _i=0), to dla [ z_i= (P_i/h) ] zachodzi

## Exact source transcript

```tex
\begin{theorem}[Forced Wrap albo prawy rezonans]
\label{thm:forced-wrap-or-right-resonance}
Załóżmy, że \(|C|\ge3\).
\begin{enumerate}
 \item Jeżeli wszystkie \(\tau_i=0\), to dla
 \[
  z_i=\log(P_i/h)
 \]
 zachodzi
 \begin{equation}
  (A-I)z=0,
  \qquad
  z_R=GA_{RK}z_K,
  \qquad
  Sz_K=0.
  \label{eq:zero-wrap-real-resonance}
 \end{equation}
 \item Jeżeli \(\det S\ne0\), to przynajmniej jeden wiersz ma
 \(\tau_i\ne0\), a więc
 \begin{equation}
  \boxed{
  \left|E_ih^{s_i-1}P_i+\epsilon_iQ_i\right|\ge x}
  \label{eq:forced-wrap-size}
 \end{equation}
 dla pewnego \(i\).
\end{enumerate}
\end{theorem}

\begin{proof}
Jeśli \(\tau_i=0\), dodatnie moduły obu składników w
\eqref{eq:row-wrap-identity} są równe:
\[
 Q_i=h^{s_i-1}P_i.
\]
Po zalogarytmowaniu dostajemy \(Az=z\). Eliminacja bloku \(R\) jest
identyczna jak w \cref{thm:exact-affine-phase-compression}, lecz teraz
w przestrzeni rzeczywistej i z prawą stroną zero; daje
\eqref{eq:zero-wrap-real-resonance}.

Jeżeli \(\det S\ne0\), to \(z=0\), czyli \(P_i=h\) dla wszystkich
\(i\). Każdy \(P_i\) jest jednostką modulo \(N\), więc także \(h\) jest
jednostką. Z winding modulo \(N\)
\[
 hp_i\equiv\epsilon_ip_0\pmod N.
\]
Dla każdego z dwóch znaków istnieje najwyżej jeden endpoint
\(0<p_i<N\). Otrzymalibyśmy \(|C|\le2\), sprzecznie z założeniem.
Zatem pewne \(\tau_i\ne0\); wtedy \eqref{eq:forced-wrap-size} wynika
z \eqref{eq:row-wrap-identity}.
\end{proof}
```
