---
id: BIBLIA-L06824-MULTIPLIKATYWNY-WYMIAR-PROFILU-BEZ-ZAWINIECIA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6824
line_end: 6850
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Multiplikatywny wymiar profilu bez zawinięcia

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6824-6850`
- Historical environment: `corollary`
- Original label: `cor:zero-wrap-multiplicative-rank`
- Section: Iteracja 11: fazowy most p_0 A A_*p0-A-A* > Całkowity indeks zawinięcia
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Multiplikatywny wymiar profilu bez zawinięcia] Jeżeli wszystkie ( _i=0) i ( = S), to grupa multiplikatywna generowana przez portowe ilorazy (P_k/h) ma rangę co najwyżej ( ). Dokładniej, dla każdej pierwszej ( ) wektor [ (v_ (P_k/h) )_k K ] leży w całkowitej kracie ( S).

## Exact source transcript

```tex
\begin{corollary}[Multiplikatywny wymiar profilu bez zawinięcia]
\label{cor:zero-wrap-multiplicative-rank}
Jeżeli wszystkie \(\tau_i=0\) i \(\nu=\dim\ker S\), to grupa
multiplikatywna generowana przez portowe ilorazy \(P_k/h\) ma rangę co
najwyżej \(\nu\). Dokładniej, dla każdej pierwszej \(\ell\) wektor
\[
 \bigl(v_\ell(P_k/h)\bigr)_{k\in K}
\]
leży w całkowitej kracie \(\ker S\).

Jeśli \(\nu=1\), a \(v=(v_k)\) jest pierwotnym całkowitym generatorem
prawego jądra, istnieje \(T\in\mathbb Q_{>0}\) takie, że
\begin{equation}
 \boxed{\frac{P_k}{h}=T^{v_k}\qquad(k\in K).}
 \label{eq:rank-one-path-profile}
\end{equation}
\end{corollary}

\begin{proof}
Równości \(Q_i=h^{s_i-1}P_i\) są równościami liczb wymiernych, więc
zastosowanie każdej valuacji pierwszej daje całkowity wektor w jądrze
\(S\). To ogranicza rangę multiplikatywną. Gdy jądro ma rangę jeden,
każdy taki wektor jest całkowitą wielokrotnością pierwotnego \(v\):
całkowitość współczynnika wynika z tożsamości Bézouta dla współrzędnych
\(v\). Złożenie odpowiednich potęg pierwszych daje wymierne \(T\) w
\eqref{eq:rank-one-path-profile}.
\end{proof}
```
