---
id: BIBLIA-L06935-GSFC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6935
line_end: 6951
env: definition
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# GSFC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6935-6951`
- Historical environment: `definition`
- Original label: `def:gsfc`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Definicja i osadzenie w problemie Goldbacha
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[GSFC] Parę ((N,C)) nazywamy semipierwszym rdzeniem faktoryzacyjnym Goldbacha (GSFC), jeżeli: (N>2) jest parzysta, a (C) jest skończonym zbiorem aktywnych nieparzystych liczb pierwszych; dla każdego (p C), z uwzględnieniem krotności,

## Exact source transcript

```tex
\begin{definition}[GSFC]
\label{def:gsfc}
Parę \((N,C)\) nazywamy \emph{semipierwszym rdzeniem faktoryzacyjnym
Goldbacha} (GSFC), jeżeli:
\begin{enumerate}
 \item \(N>2\) jest parzysta, a \(C\) jest skończonym zbiorem aktywnych
 nieparzystych liczb pierwszych;
 \item dla każdego \(p\in C\), z uwzględnieniem krotności,
 \begin{equation}
  N-p=q_pr_p,\qquad q_p,r_p\in C;
  \label{eq:gsfc-row}
 \end{equation}
 \item digraf supportu z krawędziami \(p\to q_p,p\to r_p\) jest silnie
 spójny.
\end{enumerate}
Jeśli \(m=\min C>N^{1/3}\), mówimy o \emph{large-min GSFC}.
\end{definition}
```
