---
id: BIBLIA-L06957-CUBE-ROOT-SEMIPRIME-RIGIDITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6957
line_end: 6974
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Cube-Root Semiprime Rigidity

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6957-6974`
- Historical environment: `theorem`
- Original label: `thm:gsfc-cuberoot-rigidity`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Definicja i osadzenie w problemie Goldbacha
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Cube-Root Semiprime Rigidity] Niech (C) będzie terminalną złą SCC i (m= C>N^1/3). Wtedy (N-p)=2 (p C), a więc ((N,C)) jest large-min GSFC.

## Exact source transcript

```tex
\begin{theorem}[Cube-Root Semiprime Rigidity]
\label{thm:gsfc-cuberoot-rigidity}
Niech \(C\) będzie terminalną złą SCC i
\(m=\min C>N^{1/3}\). Wtedy
\begin{equation}
 \boxed{\Omega(N-p)=2\qquad(p\in C),}
 \label{eq:gsfc-semiprime-rigidity}
\end{equation}
a więc \((N,C)\) jest large-min GSFC.
\end{theorem}

\begin{proof}
Terminalność oznacza, że każdy czynnik pierwszy \(N-p\) należy do
\(C\), a więc jest co najmniej \(m\). Trzy czynniki z krotnościami
dawałyby \(N-p\ge m^3>N\), niemożliwe. Wiersz jest zły, więc
\(N-p\) nie jest pierwsza; ma zatem dokładnie dwa czynniki z
krotnościami. Silna spójność jest częścią definicji SCC.
\end{proof}
```
