---
id: BIBLIA-L06991-EXACT-EXTREME-GEOMETRY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 6991
line_end: 7025
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Exact Extreme Geometry

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:6991-7025`
- Historical environment: `theorem`
- Original label: `thm:gsfc-extreme-geometry`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Geometria ekstremów i jądro przełamania
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Exact Extreme Geometry] Minimalna etykieta wewnętrzna wynosi ( =m). Maksimum (M) ma jednego wewnętrznego parenta (t), przy czym N=mM+t, m<t<M. Dla (T=T_m(C)) zachodzi

## Exact source transcript

```tex
\begin{theorem}[Exact Extreme Geometry]
\label{thm:gsfc-extreme-geometry}
Minimalna etykieta wewnętrzna wynosi \(\kappa=m\). Maksimum \(M\) ma
jednego wewnętrznego parenta \(t\), przy czym
\begin{equation}
 \boxed{N=mM+t,\qquad m<t<M.}
 \label{eq:gsfc-extreme-normal-form}
\end{equation}
Dla \(T=T_m(C)\) zachodzi
\begin{equation}
 \boxed{m,t\in T,\qquad M\notin T.}
 \label{eq:gsfc-extreme-kernel-membership}
\end{equation}
\end{theorem}

\begin{proof}
Każda etykieta jest drugim czynnikiem semipierwszego wiersza, więc jest
co najmniej \(m\). Ponieważ \(m\) ma wewnętrznego parenta i jego wiersz
ma postać \(N-p=mq\), istnieje też wewnętrzna krawędź o etykiecie \(m\).
Stąd \(\kappa=m\). Twierdzenie \ref{thm:min-quotient} daje unikalnego
parenta \(t\) maksimum oraz \(N-t=mM\). Mamy \(t\ge m\); równość
\(t=m\) dawałaby \(m\mid N\), wbrew aktywności. Unikalny parent nie
jest maksimum, więc \(t<M\).

Z wiersza \(N-t=mM\) wychodzi krawędź \(t\to m\) o etykiecie
\(M>m\), więc \(m\in T\), oraz krawędź \(t\to M\) o etykiecie \(m\).
Gdyby \(t\notin T\), Break-Target Kernel dawałby mu jedynego
wewnętrznego parenta po etykiecie \(m\), równego \(a=N-mt\). Jednak
\[
 a-M=N-mt-M=(m-1)(M-t)>0,
\]
co przeczy maksymalności \(M\). Zatem \(t\in T\). Ponieważ
\(M>N/(m+1)\), a \(T\subset(0,N/(m+2))\), mamy \(M\notin T\);
krawędź \(t\to M\) rozpoczyna więc niepusty łańcuch z \(t\).
\end{proof}
```
