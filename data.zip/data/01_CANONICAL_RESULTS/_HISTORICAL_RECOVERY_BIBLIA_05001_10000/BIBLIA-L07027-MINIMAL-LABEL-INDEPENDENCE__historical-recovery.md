---
id: BIBLIA-L07027-MINIMAL-LABEL-INDEPENDENCE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7027
line_end: 7046
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Minimal-Label Independence

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7027-7046`
- Historical environment: `theorem`
- Original label: `thm:gsfc-minimal-label-independence`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Geometria ekstremów i jądro przełamania
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Minimal-Label Independence] Dla dowolnej nietrywialnej SCC, nie tylko GSFC, p,q T_ (C) nie istnieje p q.

## Exact source transcript

```tex
\begin{theorem}[Minimal-Label Independence]
\label{thm:gsfc-minimal-label-independence}
Dla dowolnej nietrywialnej SCC, nie tylko GSFC,
\begin{equation}
 \boxed{
 p,q\in T_\kappa(C) \Longrightarrow\
 \text{nie istnieje }p\overset{\kappa}{\longrightarrow}q.}
 \label{eq:gsfc-minimal-label-independence}
\end{equation}
\end{theorem}

\begin{proof}
Gdyby \(N-p=\kappa q\), to z
\(p,q<N/(\kappa+2)\) wynikałoby
\[
 N=p+\kappa q
 <\frac{\kappa+1}{\kappa+2}N<N,
\]
sprzeczność.
\end{proof}
```
