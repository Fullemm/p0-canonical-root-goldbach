---
id: BIBLIA-L07056-EXACT-START-RESIDUE-CHARACTERIZATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7056
line_end: 7074
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Exact Start Residue Characterization

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7056-7074`
- Historical environment: `theorem`
- Original label: `thm:gsfc-start-residue`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Starty łańcuchów i afiniczne porty
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Exact Start Residue Characterization] Zachodzi dokładna równość X=v T:v N m. W szczególności (t X), więc (X ).

## Exact source transcript

```tex
\begin{theorem}[Exact Start Residue Characterization]
\label{thm:gsfc-start-residue}
Zachodzi dokładna równość
\begin{equation}
 \boxed{X=\{v\in T:v\equiv N\pmod m\}.}
 \label{eq:gsfc-start-residue}
\end{equation}
W szczególności \(t\in X\), więc \(X\ne\varnothing\).
\end{theorem}

\begin{proof}
Jeżeli \(v\in X\), pierwszy krok ma postać \(N-v=mq\), więc
\(v\equiv N\pmod m\). Odwrotnie, ta kongruencja i semipierwszość
wiersza dają \(N-v=mq\) z \(q\in C\). Gdyby \(q\in T\), mielibyśmy
krawędź minimalnej etykiety wewnątrz \(T\), wbrew
\cref{thm:gsfc-minimal-label-independence}. Zatem \(q\notin T\) i
\(v\) rozpoczyna zewnętrzny łańcuch. Przynależność \(t\) wynika także
bezpośrednio z \(t\to M\).
\end{proof}
```
