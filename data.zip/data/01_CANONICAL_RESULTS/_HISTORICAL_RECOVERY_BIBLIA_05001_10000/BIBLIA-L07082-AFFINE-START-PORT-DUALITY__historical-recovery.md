---
id: BIBLIA-L07082-AFFINE-START-PORT-DUALITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7082
line_end: 7111
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Affine Start--Port Duality

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7082-7111`
- Historical environment: `theorem`
- Original label: `thm:gsfc-affine-start-port`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Starty łańcuchów i afiniczne porty
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Affine Start--Port Duality] Dla każdego (v X) istnieje całkowite (j 0) takie, że v=t+2mj, H(v)=M-2j. Ponadto

## Exact source transcript

```tex
\begin{theorem}[Affine Start--Port Duality]
\label{thm:gsfc-affine-start-port}
Dla każdego \(v\in X\) istnieje całkowite \(j\ge0\) takie, że
\begin{equation}
 \boxed{v=t+2mj,\qquad H(v)=M-2j.}
 \label{eq:gsfc-affine-start-port}
\end{equation}
Ponadto
\begin{equation}
 0\le2j\le m-3,
 \qquad
 \operatorname{diam}H(X)\le m-3<m.
 \label{eq:gsfc-port-diameter}
\end{equation}
\end{theorem}

\begin{proof}
Odejmujemy \(N-t=mM\) od \(N-v=mH(v)\):
\[
 v-t=m(M-H(v)).
\]
Ponieważ \(H(v)\le M\), mamy \(v\ge t\). Różnica dwóch nieparzystych
pierwszych jest parzysta, a \(m\) jest nieparzysta, więc
\(v-t=2mj\) i otrzymujemy oba wzory. Dalej
\(v<N/(m+2)<m^3/(m+2)\) oraz \(t>m\), zatem
\[
 2j<\frac{m^2}{m+2}-1<m-2.
\]
Ponieważ \(2j\) jest parzyste, dostajemy \(2j\le m-3\).
\end{proof}
```
