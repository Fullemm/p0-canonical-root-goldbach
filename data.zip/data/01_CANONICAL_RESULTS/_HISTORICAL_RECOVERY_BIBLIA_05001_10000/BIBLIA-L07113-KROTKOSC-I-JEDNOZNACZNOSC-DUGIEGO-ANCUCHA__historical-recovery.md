---
id: BIBLIA-L07113-KROTKOSC-I-JEDNOZNACZNOSC-DUGIEGO-ANCUCHA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7113
line_end: 7138
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Krótkość i jednoznaczność długiego łańcucha

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7113-7138`
- Historical environment: `theorem`
- Original label: `thm:gsfc-short-chains`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Starty łańcuchów i afiniczne porty
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Krótkość i jednoznaczność długiego łańcucha] Każdy łańcuch wychodzący z (T) zawiera jeden albo dwa zewnętrzne wierzchołki. Co najwyżej jeden start (v X) może mieć dwa zewnętrzne wierzchołki. Niech łańcuch z (v T) zawiera ( ) kolejnych krawędzi

## Exact source transcript

```tex
\begin{theorem}[Krótkość i jednoznaczność długiego łańcucha]
\label{thm:gsfc-short-chains}
Każdy łańcuch wychodzący z \(T\) zawiera jeden albo dwa zewnętrzne
wierzchołki. Co najwyżej jeden start \(v\in X\) może mieć dwa
zewnętrzne wierzchołki.
\end{theorem}

\begin{proof}
Niech łańcuch z \(v\in T\) zawiera \(\lambda\) kolejnych krawędzi
etykiety \(m\). Ponieważ \(v<N/(m+2)\), liczba
\(D_m(v)=(m+1)v-N\) jest niezerowa i ma moduł mniejszy niż \(N\).
Z \cref{lem:dk-descent}
\[
 D_m(v)=(-m)^\lambda D_m(q_\lambda).
\]
Prawa końcowa wartość jest niezerową liczbą całkowitą, więc
\(m^\lambda<N<m^3\), a zatem \(\lambda\le2\).

Gdyby dwa różne starty miały długość dwa, ich first porty
\(H_1,H_2\) spełniałyby z jednej strony
\(0<|H_1-H_2|<m\) na mocy
\eqref{eq:gsfc-port-diameter}. Z drugiego kroku
\(N-H_i=mQ_i\) wynikałoby jednak
\(H_1-H_2=-m(Q_1-Q_2)\). Różne nieparzyste pierwsze \(Q_i\) różnią
się o co najmniej dwa, więc \(|H_1-H_2|\ge2m\), sprzeczność.
\end{proof}
```
