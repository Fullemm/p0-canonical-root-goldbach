---
id: BIBLIA-L07145-TERMINAL-ENDPOINT-RICHNESS
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7145
line_end: 7175
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Terminal Endpoint Richness

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7145-7175`
- Historical environment: `theorem`
- Original label: `thm:gsfc-terminal-richness`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Terminalne reprezentanty i packing
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Terminal Endpoint Richness] Dla każdego (v X) N-E(v)=ab, a,b T m.

## Exact source transcript

```tex
\begin{theorem}[Terminal Endpoint Richness]
\label{thm:gsfc-terminal-richness}
Dla każdego \(v\in X\)
\begin{equation}
 \boxed{N-E(v)=ab,\qquad a,b\in T\setminus\{m\}.}
 \label{eq:gsfc-terminal-richness}
\end{equation}
\end{theorem}

\begin{proof}
Z końcowości zewnętrznego łańcucha oba czynniki ostatniego wiersza
należą do \(T\). Trzeba wykluczyć czynnik \(m\).

Jeśli łańcuch ma długość jeden, \(E=H=(N-v)/m<N/m\). Gdyby
\(N-H=ma\) z \(a\in T\), to
\[
 a>\frac{N(m-1)}{m^2}>\frac{N}{m+2},
\]
bo \((m-1)(m+2)>m^2\) dla \(m>2\). Przeczy to
\(a\in T\subset(0,N/(m+2))\).

Jeśli łańcuch ma długość dwa,
\(v\to H\to E\), to
\[
 H-E=\frac{H-v}{m},\qquad 0<H-E<m;
\]
ostatnia nierówność korzysta z \(H\le M<N/m<m^2\). Gdyby
\(N-E=ma\), porównanie z \(N-H=mE\) dałoby
\(H-E=m(a-E)\), czyli niezerową wielokrotność \(m\) o module
mniejszym niż \(m\). To niemożliwe.
\end{proof}
```
