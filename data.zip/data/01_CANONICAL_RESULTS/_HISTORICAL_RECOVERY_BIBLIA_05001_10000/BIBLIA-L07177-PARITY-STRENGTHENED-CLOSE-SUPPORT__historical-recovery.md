---
id: BIBLIA-L07177-PARITY-STRENGTHENED-CLOSE-SUPPORT
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7177
line_end: 7191
env: lemma
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Parity-Strengthened Close Support

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7177-7191`
- Historical environment: `lemma`
- Original label: `lem:gsfc-close-support`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Terminalne reprezentanty i packing
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Parity-Strengthened Close Support] Jeżeli różne nieparzyste pierwsze (p,q C) spełniają (0<|p-q|<2m), to (N-p) (N-q)= .

## Exact source transcript

```tex
\begin{lemma}[Parity-Strengthened Close Support]
\label{lem:gsfc-close-support}
Jeżeli różne nieparzyste pierwsze \(p,q\in C\) spełniają
\(0<|p-q|<2m\), to
\begin{equation}
 \PF(N-p)\cap\PF(N-q)=\varnothing.
 \label{eq:gsfc-close-support}
\end{equation}
\end{lemma}

\begin{proof}
Wspólny czynnik \(a\ge m\) dzieliłby \(p-q\). Różnica jest parzysta,
a \(a\) nieparzysta, więc niezerowy iloraz \((p-q)/a\) byłby parzysty.
Stąd \(|p-q|\ge2a\ge2m\), sprzeczność.
\end{proof}
```
