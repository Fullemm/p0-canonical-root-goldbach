---
id: BIBLIA-L07193-UNIFORM-HALF-START-BOUND
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7193
line_end: 7228
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Uniform Half-Start Bound

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7193-7228`
- Historical environment: `theorem`
- Original label: `thm:gsfc-half-start`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Terminalne reprezentanty i packing
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Uniform Half-Start Bound] Jeżeli ( =|T|) i (x_*=|X|), to x_* 2 . Jeżeli ( 0,1) rejestruje istnienie jedynego możliwego łańcucha długości dwa, to

## Exact source transcript

```tex
\begin{theorem}[Uniform Half-Start Bound]
\label{thm:gsfc-half-start}
Jeżeli \(\tau=|T|\) i \(x_*=|X|\), to
\begin{equation}
 \boxed{x_*\le\left\lfloor\frac{\tau}{2}\right\rfloor.}
 \label{eq:gsfc-half-start}
\end{equation}
Jeżeli \(\varepsilon\in\{0,1\}\) rejestruje istnienie jedynego
możliwego łańcucha długości dwa, to
\begin{equation}
 \boxed{|C|=\tau+x_*+\varepsilon
 \le\tau+\left\lfloor\frac\tau2\right\rfloor+1.}
 \label{eq:gsfc-core-size}
\end{equation}
\end{theorem}

\begin{proof}
First porty mają średnicę mniejszą niż \(m\). Tylko jeden łańcuch może
być długi, a jego endpoint jest od first portu oddalony o mniej niż
\(m\). Dlatego wszystkie różne \(E(v)\) leżą parami w odległości
mniejszej niż \(2m\). Na mocy
\cref{lem:gsfc-close-support,thm:gsfc-terminal-richness} ich
dwuelementowe supporty w \(U=T\setminus\{m\}\) są parami rozłączne.

Co najwyżej jeden z tych wierszy jest kwadratem: dwa różne kwadraty
\(a^2,b^2\) dawałyby
\(|a^2-b^2|=|a-b|(a+b)>4m\), sprzecznie z bliskością endpointów.
Potrzeba zatem co najmniej \(2x_*-1\) różnych elementów zbioru
\(U\), który ma \(\tau-1\) elementów. Stąd
\(2x_*-1\le\tau-1\), co daje \eqref{eq:gsfc-half-start}.

Twierdzenie \ref{thm:break-kernel} rozkłada \(C\setminus T\) na
łańcuchy zaczynające się dokładnie w \(X\). Każdy ma jeden zewnętrzny
wierzchołek, poza co najwyżej jednym, który ma dwa. Zatem
\(|C\setminus T|=x_*+\varepsilon\), a reszta wynika z pierwszej części.
\end{proof}
```
