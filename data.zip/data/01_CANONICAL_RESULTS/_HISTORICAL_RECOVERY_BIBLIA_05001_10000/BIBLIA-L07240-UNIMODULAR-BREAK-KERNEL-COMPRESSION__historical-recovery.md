---
id: BIBLIA-L07240-UNIMODULAR-BREAK-KERNEL-COMPRESSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7240
line_end: 7267
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Unimodular Break-Kernel Compression

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7240-7267`
- Historical environment: `theorem`
- Original label: `thm:gsfc-unimodular-compression`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Unimodularna kompresja jądra przełamania
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Unimodular Break-Kernel Compression] Blok (B_OO) jest trójkątny z przekątną równą (-1), a więc jest unimodularny. Dla S=B_TT-B_TOB_OO^-1B_OT macierz (S) jest całkowita i zachodzi całkowita równoważność

## Exact source transcript

```tex
\begin{theorem}[Unimodular Break-Kernel Compression]
\label{thm:gsfc-unimodular-compression}
Blok \(B_{OO}\) jest trójkątny z przekątną równą \(-1\), a więc jest
unimodularny. Dla
\begin{equation}
 \boxed{S=B_{TT}-B_{TO}B_{OO}^{-1}B_{OT}}
 \label{eq:gsfc-schur}
\end{equation}
macierz \(S\) jest całkowita i zachodzi całkowita równoważność
\begin{equation}
 \boxed{B\sim_{\mathbb Z}\operatorname{diag}(S,I_{|O|}).}
 \label{eq:gsfc-smith-equivalence}
\end{equation}
W szczególności zachowane są postać Smitha, cokernel, wszystkie
niebanalne invariant factors, wyznacznik, ranga modulo każdej pierwszej
i całkowite lewe oraz prawe rezonanse.
\end{theorem}

\begin{proof}
Każdy \(q\in O\) ma dokładnie jednego parenta \(p(q)\) po etykiecie
\(m\), a semipierwszy wiersz ma postać \(N-p(q)=mq\). Kolumna \(q\)
macierzy \(B\) jest więc \(e_{p(q)}-e_q\). Po uporządkowaniu łańcuchów
blok \(B_{OO}\) jest trójkątny z \(-1\) na przekątnej.

Całkowite operacje blokowe eliminują bloki pozadiagonalne i dają
\(\operatorname{diag}(S,B_{OO})\). Ponieważ \(B_{OO}\) jest
unimodularny, sam jest całkowicie równoważny macierzy jednostkowej.
\end{proof}
```
