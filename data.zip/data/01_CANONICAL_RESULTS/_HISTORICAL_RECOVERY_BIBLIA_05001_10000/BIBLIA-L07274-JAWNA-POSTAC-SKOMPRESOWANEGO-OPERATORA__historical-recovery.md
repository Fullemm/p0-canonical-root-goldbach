---
id: BIBLIA-L07274-JAWNA-POSTAC-SKOMPRESOWANEGO-OPERATORA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7274
line_end: 7303
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Jawna postać skompresowanego operatora

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7274-7303`
- Historical environment: `theorem`
- Original label: `thm:gsfc-explicit-S`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Unimodularna kompresja jądra przełamania
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Jawna postać skompresowanego operatora] Każdy wiersz (S) ma postać S_v,*= (v)e_m+e_r_v+e_s_v-e_v. Dla (w_v=1+ (v)) zachodzi

## Exact source transcript

```tex
\begin{theorem}[Jawna postać skompresowanego operatora]
\label{thm:gsfc-explicit-S}
Każdy wiersz \(S\) ma postać
\begin{equation}
 \boxed{
 S_{v,*}=\lambda(v)e_m+e_{r_v}+e_{s_v}-e_v.}
 \label{eq:gsfc-explicit-S}
\end{equation}
Dla \(w_v=1+\lambda(v)\) zachodzi
\begin{equation}
 \boxed{S\mathbf1=w.}
 \label{eq:gsfc-weighted-row-sum}
\end{equation}
\end{theorem}

\begin{proof}
Dla łańcucha
\(v=q_0\to q_1\to\cdots\to q_\lambda\) sumujemy jego kolejne
wiersze
\[
 e_m+e_{q_{i+1}}-e_{q_i}
\]
oraz końcowy wiersz
\(e_{r_v}+e_{s_v}-e_{q_\lambda}\). Współrzędne z \(O\) teleskopują,
pozostawiając \eqref{eq:gsfc-explicit-S}. Dla \(\lambda=0\) jest to
po prostu bogaty wiersz kernelowy; jego czynniki leżą w
\(T\setminus\{m\}\) przez
\cref{thm:gsfc-minimal-label-independence,thm:gsfc-start-residue}.
Suma wiersza wynosi \(\lambda+1\).
\end{proof}
```
