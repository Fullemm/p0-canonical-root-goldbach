---
id: BIBLIA-L07317-GSFC-START-KERNEL-LAW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7317
line_end: 7358
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# GSFC Start--Kernel Law

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7317-7358`
- Historical environment: `theorem`
- Original label: `thm:gsfc-start-kernel-law`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Dokładne prawo wejścia z p_0p0
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[GSFC Start--Kernel Law] Skompresowane fazy spełniają _u Tr_u^S_vu (-1)^w_v N.

## Exact source transcript

```tex
\begin{theorem}[GSFC Start--Kernel Law]
\label{thm:gsfc-start-kernel-law}
Skompresowane fazy spełniają
\begin{equation}
 \boxed{
 \prod_{u\in T}r_u^{S_{vu}}
 \equiv(-1)^{w_v}\pmod N.}
 \label{eq:gsfc-start-kernel-law}
\end{equation}
Jeżeli \(\Delta=\det S\ne0\), to dla każdego \(u\in T\)
\begin{align}
 \boxed{r_u^\Delta\equiv(-1)^\Delta\pmod N,}
 \label{eq:gsfc-uniform-root-lock}\\
 \boxed{(\epsilon_uP_u)^\Delta
 \equiv(-p_0)^\Delta\pmod N.}
 \label{eq:gsfc-direct-p0-lock}
\end{align}
Jeżeli \(\det S=0\), każdy lewy rezonans \(S^Ty=0\) spełnia
automatycznie dokładny bilans znaku
\begin{equation}
 \boxed{y^Tw=0.}
 \label{eq:gsfc-left-resonance-balance}
\end{equation}
\end{theorem}

\begin{proof}
Każdy skompresowany wiersz jest sumą \(w_v=\lambda(v)+1\) pełnych
wierszy. Każdy pełny wiersz ma prawą stronę \(-1\) w
\cref{thm:full-affine-phase-system}, co daje
\eqref{eq:gsfc-start-kernel-law}. Ponieważ
\(S\mathbf1=w\), mamy
\[
 \operatorname{adj}(S)w
 =\operatorname{adj}(S)S\mathbf1
 =\Delta\mathbf1.
\]
Kombinacja układu przez adjugatę daje
\eqref{eq:gsfc-uniform-root-lock}; podstawienie
\eqref{eq:gsfc-entry-phase} daje \eqref{eq:gsfc-direct-p0-lock}.
W gałęzi osobliwej
\(y^Tw=y^TS\mathbf1=0\).
\end{proof}
```
