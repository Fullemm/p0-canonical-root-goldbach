---
id: BIBLIA-L07374-SPECTRAL-CORE-WINDOW
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7374
line_end: 7397
env: corollary
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Spectral Core Window

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7374-7397`
- Historical environment: `corollary`
- Original label: `cor:gsfc-spectral-window`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Spektrum, eliminacja minimum i bogaty szkielet
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Spectral Core Window] Macierz [ A^ =S+I ] jest nieujemna i nieredukowalna, a jej sumy wierszy należą do (2,3,4). Zachodzi

## Exact source transcript

```tex
\begin{corollary}[Spectral Core Window]
\label{cor:gsfc-spectral-window}
Macierz
\[
 A^\sharp=S+I
\]
jest nieujemna i nieredukowalna, a jej sumy wierszy należą do
\(\{2,3,4\}\). Zachodzi
\begin{equation}
 \boxed{2<\rho(A^\sharp)<4.}
 \label{eq:gsfc-spectral-window}
\end{equation}
Jeśli nie ma łańcucha długości dwa, to \(2<\rho(A^\sharp)<3\).
\end{corollary}

\begin{proof}
Z \eqref{eq:gsfc-explicit-S} wiersz \(A^\sharp\) ma postać
\(\lambda(v)e_m+e_{r_v}+e_{s_v}\), więc jego suma wynosi
\(\lambda(v)+2\). Kontrakcja łańcuchów zachowuje silną spójność
supportu. Dla minimum \(\lambda(m)=0\), natomiast
\(\lambda(t)\ge1\). Ścisła wersja oszacowania
Collatza--Wielandta dla macierzy nieredukowalnej umieszcza promień
spektralny ściśle między minimalną i maksymalną sumą wiersza.
\end{proof}
```
