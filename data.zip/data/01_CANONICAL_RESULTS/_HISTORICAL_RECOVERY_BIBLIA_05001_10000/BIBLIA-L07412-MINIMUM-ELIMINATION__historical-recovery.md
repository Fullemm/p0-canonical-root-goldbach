---
id: BIBLIA-L07412-MINIMUM-ELIMINATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7412
line_end: 7441
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Minimum Elimination

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7412-7441`
- Historical environment: `theorem`
- Original label: `thm:gsfc-minimum-elimination`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Spektrum, eliminacja minimum i bogaty szkielet
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Minimum Elimination] Dla H=R-I+ zachodzi

## Exact source transcript

```tex
\begin{theorem}[Minimum Elimination]
\label{thm:gsfc-minimum-elimination}
Dla
\begin{equation}
 \boxed{H=R-I+\lambda\rho}
 \label{eq:gsfc-minimum-eliminated-H}
\end{equation}
zachodzi
\begin{equation}
 \boxed{S\sim_{\mathbb Z}(-1)\oplus H.}
 \label{eq:gsfc-minimum-elimination}
\end{equation}
Po eliminacji fazy minimum wszystkie wiersze mają jednolitą prawą
stronę
\begin{equation}
 \boxed{
 \prod_{q\in U}r_q^{H_{vq}}\equiv-1\pmod N.}
 \label{eq:gsfc-minimum-uniform-sign}
\end{equation}
\end{theorem}

\begin{proof}
Blok \(-1\) jest jednostką w \(\mathbb Z\), a jego dopełnienie Schura
jest \(R-I+\lambda\rho\), co daje równoważność całkowitą.
Wiersz minimum w \eqref{eq:gsfc-start-kernel-law} daje
\(r_U^\rho=-r_m\). Po podstawieniu do wiersza
\(r_m^{\lambda_v}r_U^{(R-I)_v}=(-1)^{1+\lambda_v}\) znaki
\((-1)^{\lambda_v}\) skracają się i pozostaje
\eqref{eq:gsfc-minimum-uniform-sign}.
\end{proof}
```
