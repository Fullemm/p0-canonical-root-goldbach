---
id: BIBLIA-L07443-BOGATY-WIERSZ-I-BOGATY-SZKIELET
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7443
line_end: 7449
env: definition
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Bogaty wiersz i bogaty szkielet

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7443-7449`
- Historical environment: `definition`
- Original label: ``
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Spektrum, eliminacja minimum i bogaty szkielet
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Bogaty wiersz i bogaty szkielet] Wiersz (p) jest M-wierszem, jeśli (N-p=mq), oraz bogaty, jeśli (N-p=qr) z (q,r>m). Bogaty szkielet ( R(C)) jest multigrafem na (U=T m), w którym każdemu bogatemu wierszowi (N-p=qr) odpowiada krawędź (q,r); kwadrat daje pętlę. [Exact Rich Census and Skeleton]

## Exact source transcript

```tex
\begin{definition}[Bogaty wiersz i bogaty szkielet]
Wiersz \(p\) jest \emph{M-wierszem}, jeśli \(N-p=mq\), oraz
\emph{bogaty}, jeśli \(N-p=qr\) z \(q,r>m\). Bogaty szkielet
\(\mathcal R(C)\) jest multigrafem na \(U=T\setminus\{m\}\), w którym
każdemu bogatemu wierszowi \(N-p=qr\) odpowiada krawędź \(\{q,r\}\);
kwadrat daje pętlę.
\end{definition}
```
