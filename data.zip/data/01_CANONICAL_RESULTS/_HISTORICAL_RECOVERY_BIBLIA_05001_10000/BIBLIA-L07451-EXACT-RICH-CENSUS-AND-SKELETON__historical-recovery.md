---
id: BIBLIA-L07451-EXACT-RICH-CENSUS-AND-SKELETON
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7451
line_end: 7486
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Exact Rich Census and Skeleton

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7451-7486`
- Historical environment: `theorem`
- Original label: `thm:gsfc-rich-skeleton`
- Section: GSFC: semipierwsze rdzenie faktoryzacyjne Goldbacha > Spektrum, eliminacja minimum i bogaty szkielet
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Exact Rich Census and Skeleton] Zachodzą # M-wiersze&=|C|-|T|, # bogate wiersze&=|T|.

## Exact source transcript

```tex
\begin{theorem}[Exact Rich Census and Skeleton]
\label{thm:gsfc-rich-skeleton}
Zachodzą
\begin{align}
 \#\{\text{M-wiersze}\}&=|C|-|T|,
 \label{eq:gsfc-M-row-census}\\
 \#\{\text{bogate wiersze}\}&=|T|.
 \label{eq:gsfc-rich-row-census}
\end{align}
Każdy wierzchołek \(U\) należy do supportu bogatego wiersza. Dlatego
\(\mathcal R(C)\) nie ma izolowanych wierzchołków i
\begin{equation}
 \boxed{|E(\mathcal R)|=|V(\mathcal R)|+1.}
 \label{eq:gsfc-rich-excess}
\end{equation}
Jeśli \(\mathcal R\) ma \(c\) składowych, to jego liczba cyklomatyczna
wynosi \(c+1\).
\end{theorem}

\begin{proof}
Każdy \(q\in O=C\setminus T\) ma dokładnie jednego parenta w
M-wierszu \(N-p(q)=mq\). Odwrotnie, każdy M-wiersz jest wewnętrznym
krokiem jednego zewnętrznego łańcucha: minimal-label independence
wyklucza krok między wierzchołkami \(T\), a
\cref{thm:gsfc-terminal-richness} wyklucza M-wiersz na końcu łańcucha.
Jest to bijekcja, która daje \eqref{eq:gsfc-M-row-census}; druga równość
wynika przez odjęcie od \(|C|\).

Jeżeli \(q\in T\setminus\{m\}\), definicja \(T\) daje krawędź
\(p\to q\) o etykiecie większej niż \(m\). W semipierwszym wierszu
drugi czynnik także jest większy niż \(m\), więc jest to bogaty wiersz.
Odwrotna implikacja jest natychmiastowa. Stąd brak izolowanych
wierzchołków. Liczba krawędzi wynosi \(|T|\), liczba wierzchołków
\(|T|-1\), co daje \eqref{eq:gsfc-rich-excess}; wzór
\(\beta_1=E-V+c\) daje ostatnie zdanie.
\end{proof}
```
