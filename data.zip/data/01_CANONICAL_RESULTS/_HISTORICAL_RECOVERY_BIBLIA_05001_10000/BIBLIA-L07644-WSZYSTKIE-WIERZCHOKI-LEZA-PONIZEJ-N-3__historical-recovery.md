---
id: BIBLIA-L07644-WSZYSTKIE-WIERZCHOKI-LEZA-PONIZEJ-N-3
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7644
line_end: 7660
env: lemma
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Wszystkie wierzchołki leżą poniżej (N/3)

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7644-7660`
- Historical environment: `lemma`
- Original label: `lem:terminal-below-third`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Terminalna małość i przeszkoda Perrona
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Wszystkie wierzchołki leżą poniżej (N/3)] Jeżeli (C) jest terminalną złą SCC, to dla każdego (q C) q<N/3. Ponadto każda suma wiersza macierzy (A) jest co najmniej równa dwa.

## Exact source transcript

```tex
\begin{lemma}[Wszystkie wierzchołki leżą poniżej \(N/3\)]
\label{lem:terminal-below-third}
Jeżeli \(C\) jest terminalną złą SCC, to dla każdego \(q\in C\)
\begin{equation}
 \boxed{q<N/3.}
 \label{eq:terminal-below-third}
\end{equation}
Ponadto każda suma wiersza macierzy \(A\) jest co najmniej równa dwa.
\end{lemma}

\begin{proof}
Silna spójność daje krawędź wchodzącą \(p\to q\). Zatem
\(q\mid N-p\). Wiersz jest zły, więc nie może zachodzić \(N-p=q\);
nieparzysty kofaktor ma zatem wartość co najmniej trzy. Stąd
\(3q\le N-p<N\). Druga teza wynika z tego, że każda liczba \(N-p\)
jest nieparzysta i złożona, więc \(\Omega(N-p)\ge2\).
\end{proof}
```
