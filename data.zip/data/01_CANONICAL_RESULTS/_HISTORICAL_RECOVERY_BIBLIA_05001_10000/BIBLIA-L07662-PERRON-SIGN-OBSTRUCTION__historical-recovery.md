---
id: BIBLIA-L07662-PERRON-SIGN-OBSTRUCTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7662
line_end: 7681
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Perron Sign Obstruction

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7662-7681`
- Historical environment: `theorem`
- Original label: `thm:perron-sign-obstruction`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Terminalna małość i przeszkoda Perrona
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Perron Sign Obstruction] Macierz (A) terminalnej złej SCC jest nieujemna i nieredukowalna, a jej promień spektralny spełnia (A) 2. Każdy niezerowy rzeczywisty lewy lub prawy wektor własny dla wartości

## Exact source transcript

```tex
\begin{theorem}[Perron Sign Obstruction]
\label{thm:perron-sign-obstruction}
Macierz \(A\) terminalnej złej SCC jest nieujemna i nieredukowalna,
a jej promień spektralny spełnia
\begin{equation}
 \boxed{\rho(A)\ge2.}
 \label{eq:perron-rho-at-least-two}
\end{equation}
Każdy niezerowy rzeczywisty lewy lub prawy wektor własny dla wartości
własnej \(1\) ma współrzędne obu znaków.
\end{theorem}

\begin{proof}
Support \(A\) jest silnie spójny. Z
\cref{lem:terminal-below-third} mamy \(A\mathbf1\ge2\mathbf1\), więc
nierówność Collatza--Wielandta daje \(\rho(A)\ge2\). Dla macierzy
nieredukowalnej niezerowy nieujemny lewy lub prawy wektor własny może
odpowiadać tylko promieniowi Perrona. Ponieważ \(1<\rho(A)\), wektor
własny dla \(1\) nie może mieć jednego znaku.
\end{proof}
```
