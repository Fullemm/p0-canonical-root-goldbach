---
id: BIBLIA-L07683-WAZONY-BILANS-STOPNI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7683
line_end: 7696
env: corollary
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Ważony bilans stopni

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7683-7696`
- Historical environment: `corollary`
- Original label: `cor:left-kernel-degree-balance`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Terminalna małość i przeszkoda Perrona
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Ważony bilans stopni] Jeżeli (u^T(A-I)=0) i (s_i= _ja_ij), to _i u_i(s_i-1)=0. W szczególności, jeżeli wszystkie wiersze są semipierwsze ((s_i=2)), to ( _i u_i=0).

## Exact source transcript

```tex
\begin{corollary}[Ważony bilans stopni]
\label{cor:left-kernel-degree-balance}
Jeżeli \(u^T(A-I)=0\) i \(s_i=\sum_ja_{ij}\), to
\begin{equation}
 \boxed{\sum_i u_i(s_i-1)=0.}
 \label{eq:left-kernel-degree-balance}
\end{equation}
W szczególności, jeżeli wszystkie wiersze są semipierwsze
\((s_i=2)\), to \(\sum_i u_i=0\).
\end{corollary}

\begin{proof}
Mnożymy równość \(u^T(A-I)=0\) przez \(\mathbf1\) z prawej.
\end{proof}
```
