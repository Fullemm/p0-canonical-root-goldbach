---
id: BIBLIA-L07722-POLYNOMIAL-LEFT-LATTICE-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7722
line_end: 7763
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Polynomial Left-Lattice Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7722-7763`
- Historical environment: `theorem`
- Original label: `thm:polynomial-left-lattice-lock`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Wielomian całej lewej kraty i dokładny lift wejściowy
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Polynomial Left-Lattice Lock] Dla każdego niezerowego (u (A^T-I) Z^r) zachodzą bezwarunkowo _i u_i 0 2,

## Exact source transcript

```tex
\begin{theorem}[Polynomial Left-Lattice Lock]
\label{thm:polynomial-left-lattice-lock}
Dla każdego niezerowego \(u\in\ker(A^T-I)\cap\mathbb Z^r\)
zachodzą bezwarunkowo
\begin{equation}
 \boxed{\sum_i u_i\equiv0\pmod2,}
 \label{eq:left-resonance-parity}
\end{equation}
\begin{equation}
 \boxed{\Phi_u(N)=0.}
 \label{eq:phi-u-N-zero}
\end{equation}
oraz
\begin{equation}
 \boxed{X(X-N)\mid\Phi_u(X)\quad\text{w }\mathbb Z[X].}
 \label{eq:phi-u-two-roots}
\end{equation}
W szczególności czynnik \(X\) nie wymaga bilansu
\(\sum_i u_i=0\); wystarcza wymuszona arytmetycznie parzystość.
\end{theorem}

\begin{proof}
Równość \eqref{eq:iteration12-old-left-lock} po usunięciu mianowników
jest dokładnie \(\Phi_u(N)=0\). Oznaczmy
\(d^\pm=\sum_i u_i^\pm\) i
\(M_u=\prod_i p_i^{u_i^++u_i^-}\). Redukcja tej równości modulo
\(N\) daje
\[
 (-1)^{d^+}M_u\equiv(-1)^{d^-}M_u\pmod N.
\]
Wszystkie \(p_i\) są aktywne, więc \(M_u\) jest jednostką modulo
\(N\). Ponieważ \(N>2\), dwa znaki są równe, a zatem
\(d^+\equiv d^-\pmod2\). Jest to
\eqref{eq:left-resonance-parity}. Po podstawieniu \(X=0\) dostajemy
już jako równość całkowitą
\[
 \Phi_u(0)=\bigl((-1)^{d^+}-(-1)^{d^-}\bigr)M_u=0.
\]
Wielomian ma więc dwa różne całkowite pierwiastki \(0,N\); oba
czynniki są moniczne, co daje \eqref{eq:phi-u-two-roots} w
\(\mathbb Z[X]\).
\end{proof}
```
