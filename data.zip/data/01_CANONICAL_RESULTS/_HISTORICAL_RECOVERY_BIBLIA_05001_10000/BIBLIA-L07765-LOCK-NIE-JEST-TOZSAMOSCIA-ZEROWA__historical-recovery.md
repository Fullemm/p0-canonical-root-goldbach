---
id: BIBLIA-L07765-LOCK-NIE-JEST-TOZSAMOSCIA-ZEROWA
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7765
line_end: 7772
env: remark
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Lock nie jest tożsamością zerową

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7765-7772`
- Historical environment: `remark`
- Original label: `rem:phi-not-identically-zero`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Wielomian całej lewej kraty i dokładny lift wejściowy
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Lock nie jest tożsamością zerową] Dla (u 0) wielomian ( _u) nie znika tożsamościowo. W przeciwnym razie jednoznaczność rozkładu w ( Z[X]) wymuszałaby równość multizbiorów pierwiastków obu iloczynów, czyli (u^+=u^-), a stąd (u=0). Podzielność ma zatem rzeczywistą treść.

## Exact source transcript

```tex
\begin{remark}[Lock nie jest tożsamością zerową]
\label{rem:phi-not-identically-zero}
Dla \(u\ne0\) wielomian \(\Phi_u\) nie znika tożsamościowo.
W przeciwnym razie jednoznaczność rozkładu w \(\mathbb Z[X]\)
wymuszałaby równość multizbiorów pierwiastków obu iloczynów, czyli
\(u^+=u^-\), a stąd \(u=0\). Podzielność
\eqref{eq:phi-u-two-roots} ma zatem rzeczywistą treść.
\end{remark}
```
