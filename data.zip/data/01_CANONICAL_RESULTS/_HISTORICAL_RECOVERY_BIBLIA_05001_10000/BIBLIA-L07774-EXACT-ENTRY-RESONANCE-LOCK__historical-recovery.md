---
id: BIBLIA-L07774-EXACT-ENTRY-RESONANCE-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7774
line_end: 7806
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Exact Entry--Resonance Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7774-7806`
- Historical environment: `theorem`
- Original label: `thm:exact-entry-resonance-lock`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Wielomian całej lewej kraty i dokładny lift wejściowy
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Exact Entry--Resonance Lock] Załóżmy, że (C) jest osiągalna z (p_0), i dla każdego endpointu wybierzmy dowolną ścieżkę o stanie winding P_ip_i=W_iN+ _ip_0. Wtedy dla każdego lewego rezonansu (u) zachodzi dokładna równość

## Exact source transcript

```tex
\begin{theorem}[Exact Entry--Resonance Lock]
\label{thm:exact-entry-resonance-lock}
Załóżmy, że \(C\) jest osiągalna z \(p_0\), i dla każdego endpointu
wybierzmy dowolną ścieżkę o stanie winding
\begin{equation}
 P_ip_i=W_iN+\epsilon_ip_0.
 \label{eq:iteration12-winding-state}
\end{equation}
Wtedy dla każdego lewego rezonansu \(u\) zachodzi dokładna równość
w \(\mathbb Q_{>0}\):
\begin{equation}
 \boxed{
 \prod_i
 \left(
  \frac{(P_i-W_i)N-\epsilon_ip_0}
       {W_iN+\epsilon_ip_0}
 \right)^{u_i}=1.}
 \label{eq:exact-entry-resonance-lock}
\end{equation}
Nie wymaga ona \(\tau_i=0\), \(\det S=0\) ani minimalności wybranych
ścieżek.
\end{theorem}

\begin{proof}
Z \eqref{eq:iteration12-winding-state} mamy
\[
 p_i=\frac{W_iN+\epsilon_ip_0}{P_i},
 \qquad
 N-p_i=\frac{(P_i-W_i)N-\epsilon_ip_0}{P_i}.
\]
Ich iloraz podstawiamy do
\eqref{eq:iteration12-old-left-lock}.
\end{proof}
```
