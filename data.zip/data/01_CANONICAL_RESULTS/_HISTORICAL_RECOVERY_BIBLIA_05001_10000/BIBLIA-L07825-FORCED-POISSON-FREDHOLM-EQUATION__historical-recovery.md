---
id: BIBLIA-L07825-FORCED-POISSON-FREDHOLM-EQUATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7825
line_end: 7877
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Forced Poisson--Fredholm Equation

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7825-7877`
- Historical environment: `theorem`
- Original label: `thm:forced-poisson-fredholm`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Niejednorodne równanie Fredholma
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Forced Poisson--Fredholm Equation] Dla dowolnego wyboru ścieżek do endpointów zachodzi (A-I)z= , z_i= (P_i/h). Po podziale (C=K R) i dokładnej eliminacji Schura z Iteracji

## Exact source transcript

```tex
\begin{theorem}[Forced Poisson--Fredholm Equation]
\label{thm:forced-poisson-fredholm}
Dla dowolnego wyboru ścieżek do endpointów zachodzi
\begin{equation}
 \boxed{(A-I)z=\delta,
 \qquad z_i=\log(P_i/h).}
 \label{eq:full-forced-poisson}
\end{equation}
Po podziale \(C=K\sqcup R\) i dokładnej eliminacji Schura z Iteracji
10 równanie przyjmuje postać
\begin{equation}
 \boxed{
 Sz_K=\delta_*:=\delta_K+A_{KR}G\delta_R.}
 \label{eq:compressed-forced-poisson}
\end{equation}
W konsekwencji
\begin{align}
 y^T(A-I)=0&\Longrightarrow y^T\delta=0,
 \label{eq:full-fredholm-compatibility}\\
 u^TS=0&\Longrightarrow u^T\delta_*=0.
 \label{eq:compressed-fredholm-compatibility}
\end{align}
Pierwsza zgodność ma dokładną postać multiplikatywną
\begin{equation}
 \boxed{
 \prod_i
 \left[
  \epsilon_i\left(
   \frac{\tau_ix}{h^{s_i-1}P_i}-E_i
  \right)
 \right]^{y_i}=1.}
 \label{eq:multiplicative-fredholm-compatibility}
\end{equation}
\end{theorem}

\begin{proof}
Z definicji \(Q_i\) mamy
\[
 \log Q_i=\sum_ja_{ij}\log P_j.
\]
Po odjęciu \((s_i-1)\log h+\log P_i\) otrzymujemy
\(\log R_i=(Az-z)_i\), czyli
\eqref{eq:full-forced-poisson}. Dolny blok ma postać
\[
 A_{RK}z_K-(I-A_{RR})z_R=\delta_R,
\]
więc \(z_R=GA_{RK}z_K-G\delta_R\). Podstawienie do górnego bloku daje
\eqref{eq:compressed-forced-poisson}. Mnożenie przez wektory lewego
jądra daje \eqref{eq:full-fredholm-compatibility} i
\eqref{eq:compressed-fredholm-compatibility}; eksponentacja pierwszej
równości wraz z \eqref{eq:fredholm-positive-forcing} daje
\eqref{eq:multiplicative-fredholm-compatibility}.
\end{proof}
```
