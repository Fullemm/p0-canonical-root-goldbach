---
id: BIBLIA-L07889-ZEROWY-PROFIL-WYMUSZA-ODWRACALNOSC-LUKI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7889
line_end: 7902
env: lemma
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Zerowy profil wymusza odwracalność luki

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7889-7902`
- Historical environment: `lemma`
- Original label: `lem:zero-profile-gap-unit`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Zero-wrap wymusza wczesny portal do SCC
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Zerowy profil wymusza odwracalność luki] Jeżeli dla choć jednego endpointu zachodzi (P_i=h), to (h,N)=1.

## Exact source transcript

```tex
\begin{lemma}[Zerowy profil wymusza odwracalność luki]
\label{lem:zero-profile-gap-unit}
Jeżeli dla choć jednego endpointu zachodzi \(P_i=h\), to
\begin{equation}
 \boxed{\gcd(h,N)=1.}
 \label{eq:zero-profile-gap-unit}
\end{equation}
\end{lemma}

\begin{proof}
Normalna postać winding daje dokładnie
\(hp_i-W_iN=\epsilon_ip_0\). Zatem \(d=\gcd(h,N)\) dzieli pierwszą
\(p_0\). Ponieważ \(1\le d\le h<p_0\), otrzymujemy \(d=1\).
\end{proof}
```
