---
id: BIBLIA-L07904-ZERO-WRAP-STRADDLING
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7904
line_end: 7927
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Zero-Wrap Straddling

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7904-7927`
- Historical environment: `theorem`
- Original label: `thm:zero-wrap-straddling`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Zero-wrap wymusza wczesny portal do SCC
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Zero-Wrap Straddling] Niech (|C| 3). Jeżeli dla wybranego systemu ścieżek ( _i=0) dla wszystkich (i), to _iP_i<h< _iP_i. W szczególności, jeśli wszystkie wybrane ścieżki spełniają

## Exact source transcript

```tex
\begin{theorem}[Zero-Wrap Straddling]
\label{thm:zero-wrap-straddling}
Niech \(|C|\ge3\). Jeżeli dla wybranego systemu ścieżek
\(\tau_i=0\) dla wszystkich \(i\), to
\begin{equation}
 \boxed{\min_iP_i<h<\max_iP_i.}
 \label{eq:zero-wrap-straddles-h}
\end{equation}
W szczególności, jeśli wszystkie wybrane ścieżki spełniają
\(P_i\ge h\), to pewien wiersz ma \(\tau_i\ne0\), niezależnie od
wartości \(\det S\).
\end{theorem}

\begin{proof}
Z \eqref{eq:correct-zero-wrap-chain} mamy \(Az=z\). Wektor \(z\) nie
jest zerowy: gdyby \(P_i=h\) dla wszystkich \(i\), winding modulo
\(N\) dawałby \(hp_i\equiv\epsilon_ip_0\pmod N\). Na mocy
\cref{lem:zero-profile-gap-unit} liczba \(h\) jest wtedy odwracalna
modulo \(N\), więc dla każdego z dwóch znaków istnieje najwyżej jeden
endpoint w \((0,N)\), co dawałoby \(|C|\le2\). Zatem
\cref{thm:perron-sign-obstruction} wymusza dodatnią i ujemną
współrzędną \(z_i=\log(P_i/h)\), co jest równoważne
\eqref{eq:zero-wrap-straddles-h}.
\end{proof}
```
