---
id: BIBLIA-L07929-SUB-GAP-ENTRY-PORTAL
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7929
line_end: 7946
env: corollary
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Sub-gap Entry Portal

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7929-7946`
- Historical environment: `corollary`
- Original label: `cor:subgap-entry-portal`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Zero-wrap wymusza wczesny portal do SCC
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Sub-gap Entry Portal] W hipotetycznej porażce Goldbacha każda etykieta krawędzi BFS jest nieparzystą liczbą co najmniej trzy. Jeżeli wszystkie wrapy znikają, to (h>1) i istnieje ścieżka wejściowa do (C) o długości (d) spełniającej d< _3h.

## Exact source transcript

```tex
\begin{corollary}[Sub-gap Entry Portal]
\label{cor:subgap-entry-portal}
W hipotetycznej porażce Goldbacha każda etykieta krawędzi BFS jest
nieparzystą liczbą co najmniej trzy. Jeżeli wszystkie wrapy znikają,
to \(h>1\) i istnieje ścieżka wejściowa do \(C\) o długości \(d\)
spełniającej
\begin{equation}
 \boxed{d<\log_3h.}
 \label{eq:subgap-entry-depth}
\end{equation}
\end{corollary}

\begin{proof}
W porażce każdy odwiedzony wiersz \(N-p\) jest złożony i nieparzysty.
Dla krawędzi do czynnika pierwszego jej kofaktor jest więc co najmniej
trzy. Z \cref{thm:zero-wrap-straddling} pewna ścieżka ma
\(3^d\le P_i<h\).
\end{proof}
```
