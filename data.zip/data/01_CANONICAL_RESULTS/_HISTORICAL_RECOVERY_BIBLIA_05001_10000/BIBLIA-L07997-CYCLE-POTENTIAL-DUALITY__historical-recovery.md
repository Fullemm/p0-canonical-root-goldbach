---
id: BIBLIA-L07997-CYCLE-POTENTIAL-DUALITY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 7997
line_end: 8020
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Cycle--Potential Duality

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:7997-8020`
- Historical environment: `theorem`
- Original label: `thm:cycle-potential-duality`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Co naprawdę daje ,,rachunek różniczkowy na grafie''
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Cycle--Potential Duality] Niech (D=(V,E)) będzie skończonym digrafem, a (w:E R). Istnieje potencjał (V_0:V R) spełniający V_0(v)-V_0(u) -w(u,v) ((u,v) E)

## Exact source transcript

```tex
\begin{theorem}[Cycle--Potential Duality]
\label{thm:cycle-potential-duality}
Niech \(D=(V,E)\) będzie skończonym digrafem, a \(w:E\to\mathbb R\).
Istnieje potencjał \(V_0:V\to\mathbb R\) spełniający
\begin{equation}
 V_0(v)-V_0(u)\le-w(u,v)
 \qquad((u,v)\in E)
 \label{eq:strict-graph-potential}
\end{equation}
wtedy i tylko wtedy, gdy każdy skierowany cykl \(Z\) spełnia
\begin{equation}
 \sum_{e\in Z}w(e)\le0.
 \label{eq:no-positive-cycle}
\end{equation}
\end{theorem}

\begin{proof}
Sumowanie \eqref{eq:strict-graph-potential} po cyklu daje konieczność.
Dla dostateczności traktujemy \(-w(e)\) jako długości krawędzi i
dodajemy superźródło. Warunek \eqref{eq:no-positive-cycle} mówi, że nie
ma cyklu o ujemnej długości, więc odległości najkrótszych ścieżek
spełniają wszystkie nierówności różnicowe. Jest to klasyczna dualność
Bellmana dla najkrótszych dróg \cite{Bellman1958,Karp1978}.
\end{proof}
```
