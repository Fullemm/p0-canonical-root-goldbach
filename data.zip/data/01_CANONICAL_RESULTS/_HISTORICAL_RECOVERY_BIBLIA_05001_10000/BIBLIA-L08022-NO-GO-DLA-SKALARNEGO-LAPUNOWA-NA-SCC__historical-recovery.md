---
id: BIBLIA-L08022-NO-GO-DLA-SKALARNEGO-LAPUNOWA-NA-SCC
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8022
line_end: 8032
env: corollary
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# No-go dla skalarnego Lapunowa na SCC

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8022-8032`
- Historical environment: `corollary`
- Original label: `cor:no-scalar-lyapunov-scc`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Co naprawdę daje ,,rachunek różniczkowy na grafie''
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[No-go dla skalarnego Lapunowa na SCC] Dla naturalnej akcji krawędziowej (w(e)= k_e>0) nie istnieje potencjał malejący o co najmniej ( k_e) na każdej krawędzi nietrywialnej SCC. Każdy skierowany cykl ma ściśle dodatnią sumę ( _e k_e), co

## Exact source transcript

```tex
\begin{corollary}[No-go dla skalarnego Lapunowa na SCC]
\label{cor:no-scalar-lyapunov-scc}
Dla naturalnej akcji krawędziowej \(w(e)=\log k_e>0\) nie istnieje
potencjał malejący o co najmniej \(\log k_e\) na każdej krawędzi
nietrywialnej SCC.
\end{corollary}

\begin{proof}
Każdy skierowany cykl ma ściśle dodatnią sumę \(\sum_e\log k_e\), co
przeczy \eqref{eq:no-positive-cycle}.
\end{proof}
```
