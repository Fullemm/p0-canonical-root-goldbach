---
id: BIBLIA-L08044-CHARACTER-SMITH-COMPLETENESS
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8044
line_end: 8063
env: theorem
visibility_class: RECOVERY_PRIORITY_CRITICAL
recovery_priority: CRITICAL
---

# Character--Smith Completeness

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8044-8063`
- Historical environment: `theorem`
- Original label: `thm:character-smith-completeness`
- Section: Iteracja 12: rezonans całej SCC, Fredholm i problem selekcji > Fourier, transformata Z i postać Smitha
- Visibility classification: **RECOVERY_PRIORITY_CRITICAL**
- Recovery priority: **CRITICAL**

## Extracted historical synopsis

[Character--Smith Completeness] Niech (H) będzie skończoną grupą abelową, a całkowita macierz (S) definiuje homomorfizm (S:H^m H^n). Dla (b H^n) równanie (Sr=b) ma rozwiązanie wtedy i tylko wtedy, gdy (b)=1

## Exact source transcript

```tex
\begin{theorem}[Character--Smith Completeness]
\label{thm:character-smith-completeness}
Niech \(H\) będzie skończoną grupą abelową, a całkowita macierz \(S\)
definiuje homomorfizm \(S:H^m\to H^n\). Dla \(b\in H^n\) równanie
\(Sr=b\) ma rozwiązanie wtedy i tylko wtedy, gdy
\begin{equation}
 \boxed{\chi(b)=1}
 \label{eq:character-solvability}
\end{equation}
dla każdego charakteru \(\chi\in\widehat{H^n}\), który jest trywialny
na \(\operatorname{im}S\).
\end{theorem}

\begin{proof}
Konieczność jest natychmiastowa. Jeżeli
\(b\notin\operatorname{im}S\), jego niezerowa klasa w skończonym
cokernelu \(H^n/\operatorname{im}S\) jest rozdzielana przez pewien
charakter tej grupy. Złożenie z projekcją daje charakter łamiący
\eqref{eq:character-solvability}.
\end{proof}
```
