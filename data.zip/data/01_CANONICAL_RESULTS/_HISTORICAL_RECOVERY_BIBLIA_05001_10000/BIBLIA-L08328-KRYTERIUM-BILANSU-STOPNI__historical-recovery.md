---
id: BIBLIA-L08328-KRYTERIUM-BILANSU-STOPNI
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8328
line_end: 8347
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Kryterium bilansu stopni

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8328-8347`
- Historical environment: `theorem`
- Original label: `thm:iteration13-balance-criterion`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Bilans stopni nie jest potrzebny do dwóch pierwiastków
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Kryterium bilansu stopni] Następujące warunki są równoważne: każdy (u (A^T-I)) spełnia ( _i u_i=0); układ (A-I)w= 1

## Exact source transcript

```tex
\begin{theorem}[Kryterium bilansu stopni]
\label{thm:iteration13-balance-criterion}
Następujące warunki są równoważne:
\begin{enumerate}
 \item każdy \(u\in\ker(A^T-I)\) spełnia \(\sum_i u_i=0\);
 \item układ
 \begin{equation}
  \boxed{(A-I)w=\mathbf1}
  \label{eq:iteration13-balance-system}
 \end{equation}
 ma rozwiązanie nad \(\mathbb Q\).
\end{enumerate}
\end{theorem}

\begin{proof}
Nad \(\mathbb Q\) zachodzi
\(\operatorname{im}(A-I)=\ker(A^T-I)^\perp\). Pierwszy warunek mówi
dokładnie, że \(\mathbf1\) anihiluje lewe jądro, czyli należy do
obrazu \(A-I\).
\end{proof}
```
