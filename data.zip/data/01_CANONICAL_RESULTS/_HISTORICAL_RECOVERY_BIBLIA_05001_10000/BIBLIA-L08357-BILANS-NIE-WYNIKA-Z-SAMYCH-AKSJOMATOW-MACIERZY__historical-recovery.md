---
id: BIBLIA-L08357-BILANS-NIE-WYNIKA-Z-SAMYCH-AKSJOMATOW-MACIERZY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8357
line_end: 8377
env: proposition
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Bilans nie wynika z samych aksjomatów macierzy

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8357-8377`
- Historical environment: `proposition`
- Original label: `prop:iteration13-unbalanced-countermodel`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Bilans stopni nie jest potrzebny do dwóch pierwiastków
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Bilans nie wynika z samych aksjomatów macierzy] Istnieje nieujemna, nieredukowalna macierz całkowita o zerowej przekątnej i sumach wierszy co najmniej dwa, dla której wartość własna lewa (1) ma niezbilansowany wektor całkowity. Wystarczy wziąć

## Exact source transcript

```tex
\begin{proposition}[Bilans nie wynika z samych aksjomatów macierzy]
\label{prop:iteration13-unbalanced-countermodel}
Istnieje nieujemna, nieredukowalna macierz całkowita o zerowej
przekątnej i sumach wierszy co najmniej dwa, dla której wartość własna
lewa \(1\) ma niezbilansowany wektor całkowity.
\end{proposition}

\begin{proof}
Wystarczy wziąć
\[
 A=\begin{pmatrix}
 0&2&0&0\\
 1&0&0&1\\
 0&0&0&3\\
 0&2&1&0
 \end{pmatrix},
 \qquad u=(2,2,-1,-1)^T.
\]
Support jest silnie spójny, sumy wierszy to \(2,2,3,3\), a bezpośrednie
mnożenie daje \(u^TA=u^T\), mimo że \(\sum_i u_i=2\).
\end{proof}
```
