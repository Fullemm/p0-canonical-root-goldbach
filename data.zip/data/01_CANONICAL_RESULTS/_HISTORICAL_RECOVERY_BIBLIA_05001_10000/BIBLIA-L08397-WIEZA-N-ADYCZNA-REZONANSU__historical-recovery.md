---
id: BIBLIA-L08397-WIEZA-N-ADYCZNA-REZONANSU
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8397
line_end: 8428
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Wieża (N)-adyczna rezonansu

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8397-8428`
- Historical environment: `theorem`
- Original label: `thm:iteration13-nadic-tower`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Pełna wieża kongruencji i jej granica metodologiczna
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Wieża (N)-adyczna rezonansu] Dla każdego (k 2) i każdego całkowitego lewego rezonansu zachodzi _m=1^k-1(-1)^mN^m-1E_m(u;p^-1) 0 N^k-1.

## Exact source transcript

```tex
\begin{theorem}[Wieża \(N\)-adyczna rezonansu]
\label{thm:iteration13-nadic-tower}
Dla każdego \(k\ge2\) i każdego całkowitego lewego rezonansu zachodzi
\begin{equation}
 \boxed{
 \sum_{m=1}^{k-1}(-1)^mN^{m-1}E_m(u;p^{-1})
 \equiv0\pmod{N^{k-1}}.}
 \label{eq:iteration13-nadic-tower}
\end{equation}
Pierwsze dwa poziomy mają postać
\begin{align}
 \sum_i u_ip_i^{-1}&\equiv0\pmod N,
 \label{eq:iteration13-second-order}\\
 -E_1+NE_2&\equiv0\pmod{N^2}.
 \label{eq:iteration13-third-order}
\end{align}
\end{theorem}

\begin{proof}
Z rezonansu oraz parzystości \eqref{eq:left-resonance-parity} mamy
w pierścieniu jednostek modulo każdej potęgi \(N\)
\[
 \prod_i(1-Np_i^{-1})^{u_i}=1.
\]
Rozwijamy każdy czynnik uogólnionym dwumianem i obcinamy modulo
\(N^k\):
\[
 1+\sum_{m=1}^{k-1}(-N)^mE_m\equiv1\pmod{N^k}.
\]
Po skróceniu jednego czynnika \(N\) dostajemy
\eqref{eq:iteration13-nadic-tower}.
\end{proof}
```
