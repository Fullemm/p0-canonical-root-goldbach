---
id: BIBLIA-L08469-SIGN-SUPPORT-BICYCLE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8469
line_end: 8491
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Sign-Support Bicycle

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8469-8491`
- Historical environment: `theorem`
- Original label: `thm:iteration13-sign-bicycle`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Dwa cykle znakowe w każdym rezonansie
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Sign-Support Bicycle] Niech (A) będzie macierzą wykładników terminalnej złej SCC i niech (0 u (A^T-I) Z^r). Podgraf indukowany przez (C_+=p_i:u_i>0) zawiera skierowany cykl i podgraf indukowany przez (C_-=p_i:u_i<0) także zawiera skierowany cykl. Cykle te są wierzchołkowo rozłączne.

## Exact source transcript

```tex
\begin{theorem}[Sign-Support Bicycle]
\label{thm:iteration13-sign-bicycle}
Niech \(A\) będzie macierzą wykładników terminalnej złej SCC i niech
\(0\ne u\in\ker(A^T-I)\cap\mathbb Z^r\). Podgraf
indukowany przez
\(C_+=\{p_i:u_i>0\}\) zawiera skierowany cykl i podgraf indukowany
przez \(C_-=\{p_i:u_i<0\}\) także zawiera skierowany cykl. Cykle te są
wierzchołkowo rozłączne.
\end{theorem}

\begin{proof}
Macierz ma zerową przekątną: relacja \(p_i\mid N-p_i\) dawałaby
\(p_i\mid N\), wbrew aktywności. Oba supporty są niepuste na mocy
\cref{thm:perron-sign-obstruction}. Dla \(u_j>0\) równanie
\[
 u_j=\sum_i a_{ij}u_i
\]
nie może mieć po prawej stronie wyłącznie składników o indeksach
\(u_i\le0\). Każdy wierzchołek dodatniego supportu ma więc parenta w
tym samym supporcie. W skończonym digrafie minimalny nieskończony ciąg
parentów zawiera cykl. Ten sam argument po zmianie znaku działa dla
\(C_-\). Rozłączność wynika z definicji supportów.
\end{proof}
```
