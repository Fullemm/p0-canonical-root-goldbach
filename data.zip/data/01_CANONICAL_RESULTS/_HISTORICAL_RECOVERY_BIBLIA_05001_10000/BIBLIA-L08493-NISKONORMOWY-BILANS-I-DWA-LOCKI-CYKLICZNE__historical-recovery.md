---
id: BIBLIA-L08493-NISKONORMOWY-BILANS-I-DWA-LOCKI-CYKLICZNE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8493
line_end: 8510
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Niskonormowy bilans i dwa locki cykliczne

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8493-8510`
- Historical environment: `corollary`
- Original label: `cor:iteration13-low-norm-balance`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Dwa cykle znakowe w każdym rezonansie
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Niskonormowy bilans i dwa locki cykliczne] Jeżeli (A-I) jest osobliwa, support zawiera dwa wierzchołkowo rozłączne cykle, a więc ma co najmniej cztery wierzchołki. Każdy rezonans całkowity spełnia (|u|_1 4). Jeśli (|u|_1 5), to ( _i u_i=0). W przypadku (|u|_1=4) oba supporty składają się z dwóch współczynników ( 1), a ich cykle są dwucyklami; wraca dokładnie sytuacja cor:scc-cross-ratio,cor:scc-integral-coupling.

## Exact source transcript

```tex
\begin{corollary}[Niskonormowy bilans i dwa locki cykliczne]
\label{cor:iteration13-low-norm-balance}
Jeżeli \(A-I\) jest osobliwa, support zawiera dwa wierzchołkowo
rozłączne cykle, a więc ma co najmniej cztery wierzchołki. Każdy
rezonans całkowity spełnia \(\|u\|_1\ge4\). Jeśli
\(\|u\|_1\le5\), to \(\sum_i u_i=0\). W przypadku
\(\|u\|_1=4\) oba supporty składają się z dwóch współczynników
\(\pm1\), a ich cykle są dwucyklami; wraca dokładnie sytuacja
\cref{cor:scc-cross-ratio,cor:scc-integral-coupling}.
\end{corollary}

\begin{proof}
Brak pętli wymusza co najmniej dwa wierzchołki każdego znaku, więc
\(d^+=\sum u_i^+\ge2\) i \(d^-=\sum u_i^-\ge2\). Parzystość
\eqref{eq:left-resonance-parity} mówi, że \(d^+\) i \(d^-\) mają tę
samą parzystość. Przy sumie \(d^++d^-\le5\) jedyną możliwością jest
\((d^+,d^-)=(2,2)\). Pozostałe tezy są wtedy natychmiastowe.
\end{proof}
```
