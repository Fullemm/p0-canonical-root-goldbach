---
id: BIBLIA-L08538-SQUAREFULL-COLLISION-DECOMPOSITION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8538
line_end: 8576
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Squarefull--Collision Decomposition

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8538-8576`
- Historical environment: `theorem`
- Original label: `thm:iteration13-squarefull-collision`
- Section: Iteracja 13: rezonans i koncentracja domknięcia > Pełnowierszowy rozkład squarefull--collision
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Squarefull--Collision Decomposition] Zachodzą dokładna równość i podzielność _i=1^s(N-p_i) = ( _q (S)q )T_S, T_S U_SG_S.

## Exact source transcript

```tex
\begin{theorem}[Squarefull--Collision Decomposition]
\label{thm:iteration13-squarefull-collision}
Zachodzą dokładna równość i podzielność
\begin{align}
 \boxed{\prod_{i=1}^s(N-p_i)
  =\left(\prod_{q\in\Gamma(S)}q\right)T_S,}
 \label{eq:iteration13-row-radical-factorization}\\
 \boxed{T_S\mid U_SG_S.}
 \label{eq:iteration13-excess-divisibility}
\end{align}
Jeżeli ponadto wszystkie parenty i wszystkie dzieci są mniejsze niż
\(N/3\), a \(g=|\Gamma(S)|\), to
\begin{equation}
 \boxed{U_SG_S>
  2^s\left(\frac N3\right)^{s-g}.}
 \label{eq:iteration13-closure-expansion}
\end{equation}
\end{theorem}

\begin{proof}
Pierwsza równość grupuje pełny iloczyn wierszy według różnych liczb
pierwszych \(q\). Dla ustalonego \(q\) niech dodatnie wykładniki w
wierszach będą \(e_1,\dots,e_k\). Wykładnik \(q\) w \(T_S\) wynosi
\(\sum e_i-1\). W \(U_S\) wynosi \(\sum(e_i-1)=\sum e_i-k\), a w
\(G_S\) co najmniej
\(\sum_{i<j}\min(e_i,e_j)\ge k-1\). Suma obu ostatnich wykładników
jest więc nie mniejsza niż \(\sum e_i-1\), co dowodzi
\eqref{eq:iteration13-excess-divisibility} pierwsza po pierwszej.

Przy ograniczeniach rozmiaru mamy
\[
 \left(\frac{2N}{3}\right)^s
 <\prod_i(N-p_i)
 =\left(\prod_{q\in\Gamma(S)}q\right)T_S
 \le\left(\frac N3\right)^gU_SG_S.
\]
Po podzieleniu dostajemy
\eqref{eq:iteration13-closure-expansion}.
\end{proof}
```
