---
id: BIBLIA-L08721-EXACT-MINIMAL-COLLISION-FACTORIZATION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8721
line_end: 8754
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Exact Minimal-Collision Factorization

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8721-8754`
- Historical environment: `theorem`
- Original label: `thm:iteration14-exact-minimal-collision`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Minimalny czynnik kolizji
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Exact Minimal-Collision Factorization] Dla dowolnego skończonego zbioru aktywnych złych parentów zachodzi dokładna równość T_S=U_SJ_S. Jeżeli (E_S= _qk_q) jest liczbą krawędzi prostego supportu, to

## Exact source transcript

```tex
\begin{theorem}[Exact Minimal-Collision Factorization]
\label{thm:iteration14-exact-minimal-collision}
Dla dowolnego skończonego zbioru aktywnych złych parentów zachodzi
dokładna równość
\begin{equation}
 \boxed{T_S=U_SJ_S.}
 \label{eq:iteration14-TUJ}
\end{equation}
Jeżeli \(E_S=\sum_qk_q\) jest liczbą krawędzi prostego supportu, to
\begin{equation}
 \boxed{\Omega(J_S)=E_S-|\Gamma(S)|.}
 \label{eq:iteration14-J-topology-general}
\end{equation}
Jeśli \(S=C\) jest terminalną SCC o \(r=|C|\), jej support jest słabo
spójny i dla liczby cyklomatycznej
\(\beta_1=E_C-r+1\) mamy
\begin{equation}
 \boxed{\Omega(J_C)=\beta_1-1.}
 \label{eq:iteration14-J-topology-terminal}
\end{equation}
\end{theorem}

\begin{proof}
Ustalmy \(q\) i oznaczmy przez
\(d_q=\sum_i v_q(N-p_i)\) jego pełną krotność. Wykładnik \(q\) w
\(T_S\) wynosi \(d_q-1\). W \(U_S\) wynosi
\[
 \sum_{i\in I_q}\bigl(v_q(N-p_i)-1\bigr)=d_q-k_q,
\]
a w \(J_S\) jest równy \(k_q-1\). Suma dwóch ostatnich wykładników
jest dokładnie \(d_q-1\), co dowodzi \eqref{eq:iteration14-TUJ}.
Pozostałe równości wynikają przez zsumowanie \(k_q-1\); terminalność
daje \(\Gamma(C)=C\), a silna spójność daje słabą spójność supportu.
\end{proof}
```
