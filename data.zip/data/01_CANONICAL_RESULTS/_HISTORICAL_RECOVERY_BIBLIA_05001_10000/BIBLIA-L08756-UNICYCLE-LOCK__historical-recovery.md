---
id: BIBLIA-L08756-UNICYCLE-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8756
line_end: 8775
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Unicycle Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8756-8775`
- Historical environment: `corollary`
- Original label: `cor:iteration14-spanning-unicycle`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Minimalny czynnik kolizji
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Unicycle Lock] W supporcie terminalnej SCC można wybrać skierowane drzewo rozpinające od dowolnego korzenia i jedną krawędź wracającą do korzenia. Otrzymany backbone ma po jednej krawędzi wchodzącej do każdego wierzchołka. Iloczyn wartości dzieci wszystkich pozostałych krawędzi supportu jest równy (J_C). W konsekwencji U_CJ_C=T_C (-1)^r N, U_CJ_C N-1.

## Exact source transcript

```tex
\begin{corollary}[Unicycle Lock]
\label{cor:iteration14-spanning-unicycle}
W supporcie terminalnej SCC można wybrać skierowane drzewo rozpinające
od dowolnego korzenia i jedną krawędź wracającą do korzenia. Otrzymany
backbone ma po jednej krawędzi wchodzącej do każdego wierzchołka.
Iloczyn wartości dzieci wszystkich pozostałych krawędzi supportu jest
równy \(J_C\). W konsekwencji
\begin{equation}
 \boxed{U_CJ_C=T_C\equiv(-1)^r\pmod N,\qquad U_CJ_C\ge N-1.}
 \label{eq:iteration14-unicycle-lock}
\end{equation}
\end{corollary}

\begin{proof}
Silna spójność daje skierowane drzewo osiągalności od korzenia oraz
krawędź wchodzącą do korzenia. Usuwamy w ten sposób dokładnie jedną
krawędź wchodzącą do każdego \(q\). Wśród pozostałych krawędzi \(q\)
występuje \(k_q-1\) razy. Ostatnia kongruencja jest globalnym lockiem
SCC z \cref{thm:global-scc-product-lock}.
\end{proof}
```
