---
id: BIBLIA-L08796-TERMINAL-MODULO-3-PHASE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8796
line_end: 8836
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Terminal Modulo-3 Phase

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8796-8836`
- Historical environment: `theorem`
- Original label: `thm:iteration14-mod3-phase`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Pełnowierszowa faza modulo 33
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Terminal Modulo-3 Phase] Niech (C) będzie terminalną złą SCC i załóżmy (3 C). Wtedy: jeśli (N 1 3), to p -1 3 (p C), (N-p) 1 2;

## Exact source transcript

```tex
\begin{theorem}[Terminal Modulo-3 Phase]
\label{thm:iteration14-mod3-phase}
Niech \(C\) będzie terminalną złą SCC i załóżmy \(3\notin C\).
Wtedy:
\begin{enumerate}
 \item jeśli \(N\equiv1\pmod3\), to
 \begin{equation}
  \boxed{p\equiv-1\pmod3\quad(p\in C),\qquad
  \Omega(N-p)\equiv1\pmod2;}
  \label{eq:iteration14-mod3-one}
 \end{equation}
 \item jeśli \(N\equiv-1\pmod3\), to
 \begin{equation}
  \boxed{p\equiv1\pmod3\quad(p\in C);}
  \label{eq:iteration14-mod3-minus-one}
 \end{equation}
 \item jeśli \(3\mid N\), a
 \(x_p=0,1\) odpowiednio dla \(p\equiv1,-1\pmod3\), to nad
 \(\mathbb F_2\)
 \begin{equation}
  \boxed{(A-I)x=\mathbf1.}
  \label{eq:iteration14-mod3-zero}
 \end{equation}
\end{enumerate}
\end{theorem}

\begin{proof}
Niech \(R_p=\prod_{q\in C}q^{A_{pq}}=N-p\). Wszystkie czynniki są
jednostkami modulo \(3\). Dla \(N\equiv1\pmod3\), reszta \(R_p=1\)
dawałaby \(p\equiv0\), więc koniecznie \(R_p=-1\) i \(p=-1\).
Ponieważ dotyczy to każdego wierzchołka, każdy czynnik w każdym wierszu
ma resztę \(-1\); stąd \(R_p=(-1)^{\Omega(N-p)}=-1\), czyli krotność
jest nieparzysta.

Dla \(N=-1\pmod3\) reszta \(R_p=-1\) dawałaby \(p=0\), zatem
\(R_p=1\) i każdy parent ma resztę \(1\); terminalność przenosi to na
wszystkie czynniki. Jeśli \(3\mid N\), równanie \(p=-R_p\) daje w
zapisie wykładnikowym
\(x_p=1+\sum_qA_{pq}x_q\pmod2\), czyli
\eqref{eq:iteration14-mod3-zero}.
\end{proof}
```
