---
id: BIBLIA-L08838-CUBE-ROOT-LOCALIZATION-W-KLASIE-4-64-MOD-6
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8838
line_end: 8855
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Cube-Root Localization w klasie 4 64 mod 6

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8838-8855`
- Historical environment: `corollary`
- Original label: `cor:iteration14-cuberoot-mod6`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Pełnowierszowa faza modulo 33
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Cube-Root Localization w klasie 4 64 mod 6] Dla każdego (N>27), (N 4 6), i każdej terminalnej złej SCC (C), C<N^1/3. W szczególności dla tej klasy reszt nie istnieje large-min GSFC.

## Exact source transcript

```tex
\begin{corollary}[Cube-Root Localization w klasie \texorpdfstring{$4\pmod6$}{4 mod 6}]
\label{cor:iteration14-cuberoot-mod6}
Dla każdego \(N>27\), \(N\equiv4\pmod6\), i każdej terminalnej złej
SCC \(C\),
\begin{equation}
 \boxed{\min C<N^{1/3}.}
 \label{eq:iteration14-cuberoot-localization}
\end{equation}
W szczególności dla tej klasy reszt nie istnieje large-min GSFC.
\end{corollary}

\begin{proof}
Jeśli \(3\in C\), teza wynika z \(3<N^{1/3}\). Jeśli \(3\notin C\),
\cref{thm:iteration14-mod3-phase} mówi, że każdy zły wiersz ma
nieparzystą liczbę czynników z krotnościami. Nie jest pierwszy, więc
ma ich co najmniej trzy. Dla \(m=\min C\) otrzymujemy
\(N-p\ge m^3\), a ponieważ \(N-p<N\), mamy \(m<N^{1/3}\).
\end{proof}
```
