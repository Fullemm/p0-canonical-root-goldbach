---
id: BIBLIA-L08857-ODD-OMEGA-HIERARCHY
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8857
line_end: 8873
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Odd-Omega Hierarchy

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8857-8873`
- Historical environment: `corollary`
- Original label: `cor:iteration14-odd-omega-hierarchy`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Pełnowierszowa faza modulo 33
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Odd-Omega Hierarchy] W gałęzi (N 1 3), (3 C), jeśli dla (j 2) (m>N^1/(2j+1)), to każdy wiersz spełnia (N-p) 3,5, ,2j-1. W szczególności (m>N^1/5) wymusza dokładnie

## Exact source transcript

```tex
\begin{corollary}[Odd-Omega Hierarchy]
\label{cor:iteration14-odd-omega-hierarchy}
W gałęzi \(N\equiv1\pmod3\), \(3\notin C\), jeśli dla \(j\ge2\)
\(m>N^{1/(2j+1)}\), to każdy wiersz spełnia
\begin{equation}
 \boxed{\Omega(N-p)\in\{3,5,\ldots,2j-1\}.}
 \label{eq:iteration14-odd-omega-levels}
\end{equation}
W szczególności \(m>N^{1/5}\) wymusza dokładnie
\(\Omega(N-p)=3\) dla wszystkich \(p\in C\).
\end{corollary}

\begin{proof}
Parzystość pochodzi z \cref{thm:iteration14-mod3-phase}. Gdyby
\(\Omega(N-p)\ge2j+1\), to
\(N-p\ge m^{2j+1}>N\), sprzeczność.
\end{proof}
```
