---
id: BIBLIA-L08880-WZMOCNIONY-ILOCZYNOWY-LOCK-MODULO-33
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8880
line_end: 8902
env: corollary
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Wzmocniony iloczynowy lock modulo 33

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8880-8902`
- Historical environment: `corollary`
- Original label: `cor:iteration14-strengthened-product-mod3`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Pełnowierszowa faza modulo 33
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Wzmocniony iloczynowy lock modulo 33] Przy (N 1 3) i (3 C) mamy (T_C 1 3). Jeżeli (r=|C|), to T_C 3N+1,&r parzyste,

## Exact source transcript

```tex
\begin{corollary}[Wzmocniony iloczynowy lock modulo \texorpdfstring{$3$}{3}]
\label{cor:iteration14-strengthened-product-mod3}
Przy \(N\equiv1\pmod3\) i \(3\notin C\) mamy \(T_C\equiv1\pmod3\).
Jeżeli \(r=|C|\), to
\begin{equation}
 \boxed{
 T_C\ge
 \begin{cases}
  3N+1,&r\text{ parzyste},\\
  2N-1,&r\text{ nieparzyste}.
 \end{cases}}
 \label{eq:iteration14-strengthened-T}
\end{equation}
\end{corollary}

\begin{proof}
Każdy czynnik \(T_C\) ma resztę \(-1\), a liczba czynników z
krotnościami wynosi
\(\sum_p(\Omega(N-p)-1)\), liczbę parzystą. Zatem \(T_C=1\pmod3\).
Dla parzystego \(r\) piszemy \(T_C=aN+1\), skąd \(a=0\pmod3\) i
\(a\ge3\). Dla nieparzystego \(r\), \(T_C=aN-1\), więc
\(a=2\pmod3\) i \(a\ge2\).
\end{proof}
```
