---
id: BIBLIA-L08906-FULL-SCC-MODULO-4-LOCK
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 8906
line_end: 8928
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Full-SCC Modulo-4 Lock

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:8906-8928`
- Historical environment: `theorem`
- Original label: `thm:iteration14-mod4-lock`
- Section: Iteracja 14: dokładna kolizja i bariera modulo 33 > Macierzowa faza modulo 44
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Full-SCC Modulo-4 Lock] Dla dowolnej terminalnej złej SCC zdefiniujmy (z_p=0,1) odpowiednio dla (p 1,3 4). Wtedy nad ( F_2) (A-I)z=

## Exact source transcript

```tex
\begin{theorem}[Full-SCC Modulo-4 Lock]
\label{thm:iteration14-mod4-lock}
Dla dowolnej terminalnej złej SCC zdefiniujmy
\(z_p=0,1\) odpowiednio dla \(p\equiv1,3\pmod4\). Wtedy nad
\(\mathbb F_2\)
\begin{equation}
 \boxed{
 (A-I)z=
 \begin{cases}
  \mathbf1,&N\equiv0\pmod4,\\
  \mathbf0,&N\equiv2\pmod4.
 \end{cases}}
 \label{eq:iteration14-mod4-system}
\end{equation}
\end{theorem}

\begin{proof}
Mamy \(N-p=\prod_qq^{A_{pq}}\). Po zakodowaniu jednostek modulo \(4\)
przez \(1\mapsto0\), \(3\mapsto1\), prawa strona ma bit
\((Az)_p\). Dla \(N=0\pmod4\) liczba \(N-p\) ma resztę \(-p\), więc
\((Az)_p=z_p+1\). Dla \(N=2\pmod4\) liczba \(2-p\) ma tę samą resztę
co \(p\), więc \((Az)_p=z_p\).
\end{proof}
```
