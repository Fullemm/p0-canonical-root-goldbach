---
id: BIBLIA-L09051-CUBIC-MARKOV-CALCULUS
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 9051
line_end: 9123
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Cubic Markov Calculus

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:9051-9123`
- Historical environment: `theorem`
- Original label: `thm:iteration15-markov-calculus`
- Section: Iteracja 15: rachunek sześcienny i synchronizacja 33-adyczna > Dokładna pochodna Markowa
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Cubic Markov Calculus] Połóżmy (P=A/3). Istnieje jedyna dodatnia miara stacjonarna ( ^TP= ^T), ( _p _p=1). Dla (x_p= (p/ )) zachodzą (Px-x)_p &=D(x_p)= 13 N-pp^3,

## Exact source transcript

```tex
\begin{theorem}[Cubic Markov Calculus]
\label{thm:iteration15-markov-calculus}
Połóżmy \(P=A/3\). Istnieje jedyna dodatnia miara stacjonarna
\(\pi^TP=\pi^T\), \(\sum_p\pi_p=1\). Dla
\(x_p=\log(p/\alpha)\) zachodzą
\begin{align}
 (Px-x)_p
 &=D(x_p)=\frac13\log\frac{N-p}{p^3},
 \label{eq:iteration15-markov-derivative}\\
 \sum_p\pi_pD(x_p)&=0,
 \label{eq:iteration15-zero-integral}\\
 \prod_{p\in C}p^{\pi_p}&<\alpha.
 \label{eq:iteration15-geometric-below-alpha}
\end{align}
W szczególności \(C\) ma wierzchołki po obu stronach \(\alpha\).

Jeśli \(\mu_{pq}=\pi_pA_{pq}/3\), to
\begin{equation}
 \boxed{
 2\sum_p\pi_px_p^2
 <\sum_{p,q}\mu_{pq}(x_q-x_p)^2
 \le4\sum_p\pi_px_p^2,}
 \label{eq:iteration15-energy-window}
\end{equation}
oraz
\begin{equation}
 \boxed{\sum_{p,q}\mu_{pq}x_px_q<0.}
 \label{eq:iteration15-negative-one-step-correlation}
\end{equation}
Zatem support \(A\) zawiera krawędź \(p\to q\) taką, że
\((p-\alpha)(q-\alpha)<0\).
\end{theorem}

\begin{proof}
Równe sumy wierszy dają \(A\mathbf1=3\mathbf1\). Nieredukowalność i
twierdzenie Perrona--Frobeniusa dają dodatnie \(\pi\). Z
\eqref{eq:iteration15-cubic-rows}
\[
 (Px)_p=\frac13\log(N-p)-\log\alpha,
\]
co dowodzi \eqref{eq:iteration15-markov-derivative}; stacjonarność
daje \eqref{eq:iteration15-zero-integral}.

Jako funkcja zmiennej \(x\), gdzie \(p=\alpha e^x\), mamy
\[
 D(0)=0,\qquad
 D'(x)=-1-\frac{\alpha e^x}{3(N-\alpha e^x)}<-1,\qquad
 D''(x)=-\frac{N\alpha e^x}{3(N-\alpha e^x)^2}<0.
\]
Ścisła wklęsłość i nierówność Jensena dają
\[
 0=\sum_p\pi_pD(x_p)<D\left(\sum_p\pi_px_p\right).
\]
Funkcja \(D\) jest malejąca i zeruje się w \(0\), więc
\(\sum_p\pi_px_p<0\), co jest równoważne
\eqref{eq:iteration15-geometric-below-alpha}. Znak \(D(x)\) jest
przeciwny do znaku \(x\); zerowa średnia wymusza oba znaki.

Oba marginesy \(\mu\) są równe \(\pi\). Stąd
\[
 \sum_{p,q}\mu_{pq}(x_q-x_p)^2
 =-2\sum_p\pi_px_pD(x_p).
\]
Nierówność \(D'(x)<-1\) daje \(xD(x)<-x^2\) dla \(x\ne0\), skąd
wynika dolna granica w \eqref{eq:iteration15-energy-window}. Górna
wynika z \((x_q-x_p)^2\le2x_q^2+2x_p^2\). Ponadto
\[
 \sum_{p,q}\mu_{pq}x_px_q
 =\sum_p\pi_px_p(x_p+D(x_p))<0.
\]
Gdyby każda krawędź pozostawała po jednej stronie \(\alpha\), ostatnia
suma byłaby nieujemna.
\end{proof}
```
