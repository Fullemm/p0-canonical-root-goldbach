---
id: BIBLIA-L09132-3-ADIC-SYNCHRONIZATION-OBSTRUCTION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 9132
line_end: 9169
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# 3-Adic Synchronization Obstruction

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:9132-9169`
- Historical environment: `theorem`
- Original label: `thm:iteration15-hensel-obstruction`
- Section: Iteracja 15: rachunek sześcienny i synchronizacja 33-adyczna > Synchronizacja 33-adyczna
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[3-Adic Synchronization Obstruction] Macierz wykładników każdego trójczynnikowego terminalnego rdzenia spełnia (A+I) 0 3.

## Exact source transcript

```tex
\begin{theorem}[3-Adic Synchronization Obstruction]
\label{thm:iteration15-hensel-obstruction}
Macierz wykładników każdego trójczynnikowego terminalnego rdzenia
spełnia
\begin{equation}
 \boxed{\det(A+I)\equiv0\pmod3.}
 \label{eq:iteration15-hensel-determinant}
\end{equation}
\end{theorem}

\begin{proof}
Z \cref{thm:iteration14-mod3-phase} wszystkie \(p_i\) mają resztę
\(-1\pmod3\). Niech \(F(t)=t^3+t-N\). Ponieważ
\(F'(t)=3t^2+1\equiv1\pmod3\), pierwiastek \(-1\pmod3\) ma jedyny
zgodny lift \(a_k\pmod{3^k}\).

Załóżmy, że \(A+I\) jest odwracalna modulo \(3\). Indukcyjnie
wykażemy \(p_i\equiv a_k\pmod{3^k}\) dla wszystkich \(i\). Przy
przejściu \(k\to k+1\) piszemy
\[
 p_i=a_{k+1}+3^ky_i\pmod{3^{k+1}}.
\]
Ponieważ każdy wiersz ma stopień \(3\),
\[
 \prod_jp_j^{A_{ij}}
 \equiv a_{k+1}^3+
 3^ka_{k+1}^2\sum_jA_{ij}y_j
 \pmod{3^{k+1}}.
\]
Porównanie z
\(N-p_i\equiv a_{k+1}^3-3^ky_i\) i użycie
\(a_{k+1}^2\equiv1\pmod3\) daje
\[
 (A+I)y=0\pmod3.
\]
Odwracalność wymusza \(y=0\), więc indukcja działa. Dla \(3^k>N\)
wszystkie różne liczby \(0<p_i<N\) byłyby równe, sprzeczność.
\end{proof}
```
