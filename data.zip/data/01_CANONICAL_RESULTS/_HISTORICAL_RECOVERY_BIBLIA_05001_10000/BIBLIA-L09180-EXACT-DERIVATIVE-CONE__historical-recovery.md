---
id: BIBLIA-L09180-EXACT-DERIVATIVE-CONE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 9180
line_end: 9201
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Exact Derivative Cone

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:9180-9201`
- Historical environment: `theorem`
- Original label: `thm:iteration15-derivative-cone`
- Section: Iteracja 15: rachunek sześcienny i synchronizacja 33-adyczna > Stożki pochodnej i kolizji
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Exact Derivative Cone] Dla każdego (i<r) 0<u_i< 12d_i. Po podstawieniu (x_1=0), (x_j=d_1+ +d_j-1) jest to otwarty jednorodny układ

## Exact source transcript

```tex
\begin{theorem}[Exact Derivative Cone]
\label{thm:iteration15-derivative-cone}
Dla każdego \(i<r\)
\begin{equation}
 \boxed{0<u_i<\frac12d_i.}
 \label{eq:iteration15-half-cone}
\end{equation}
Po podstawieniu \(x_1=0\),
\(x_j=d_1+\cdots+d_{j-1}\) jest to otwarty jednorodny układ
liniowych nierówności o całkowitych współczynnikach.
\end{theorem}

\begin{proof}
Z \cref{lem:terminal-below-third} wszystkie \(p<N/3\). Dla
\(\psi(x)=\log(N-e^x)\) twierdzenie o wartości średniej daje
\[
 \frac{u_i}{d_i}
 =-\psi'(\xi_i)
 =\frac{e^{\xi_i}}{N-e^{\xi_i}}<\frac12
\]
dla pewnego \(e^{\xi_i}\in(p_i,p_{i+1})\).
\end{proof}
```
