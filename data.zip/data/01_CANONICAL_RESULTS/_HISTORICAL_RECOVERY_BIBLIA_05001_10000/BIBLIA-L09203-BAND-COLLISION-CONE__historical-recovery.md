---
id: BIBLIA-L09203-BAND-COLLISION-CONE
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 9203
line_end: 9234
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Band Collision Cone

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:9203-9234`
- Historical environment: `theorem`
- Original label: `thm:iteration15-band-collision-cone`
- Section: Iteracja 15: rachunek sześcienny i synchronizacja 33-adyczna > Stożki pochodnej i kolizji
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Band Collision Cone] Dla (i<j) połóżmy [ g_ij,k= (A_ik,A_jk), s_ij= _kg_ij,k, ] i niech (X_k= (p_k/m)), więc (X_1=0). Jeśli (s_ij>0), to

## Exact source transcript

```tex
\begin{theorem}[Band Collision Cone]
\label{thm:iteration15-band-collision-cone}
Dla \(i<j\) połóżmy
\[
 g_{ij,k}=\min(A_{ik},A_{jk}),\qquad
 s_{ij}=\sum_kg_{ij,k},
\]
i niech \(X_k=\log(p_k/m)\), więc \(X_1=0\). Jeśli \(s_{ij}>0\), to
\begin{equation}
 \boxed{
 2\sum_kg_{ij,k}X_k+(s_{ij}-1)X_r<2X_j.}
 \label{eq:iteration15-band-collision-cone}
\end{equation}
\end{theorem}

\begin{proof}
Liczba
\[
 G_{ij}=\prod_kp_k^{g_{ij,k}}
 =\gcd(N-p_i,N-p_j)
\]
dzieli \(p_j-p_i\), zatem \(G_{ij}<p_j\). Każdy \(p_k\) jest
czynnikiem pewnego trójczynnikowego wiersza, więc
\(p_k<N/m^2<m^3\), gdzie ostatnia nierówność wynika z
\(m>N^{1/5}\). Stąd \(X_r<2\log m\). Po zapisaniu
\(\log p_k=\log m+X_k\) nierówność
\(\log G_{ij}<\log p_j\) daje
\[
 \sum_kg_{ij,k}X_k+(s_{ij}-1)\log m<X_j.
\]
Podstawienie \(\log m>X_r/2\) kończy dowód.
\end{proof}
```
