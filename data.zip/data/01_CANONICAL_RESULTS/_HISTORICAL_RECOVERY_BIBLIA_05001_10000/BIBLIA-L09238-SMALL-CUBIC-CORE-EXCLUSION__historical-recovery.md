---
id: BIBLIA-L09238-SMALL-CUBIC-CORE-EXCLUSION
kind: historical-recovery-card
layer: 1-retrieval-only
status: HISTORICAL CLAIM
verification: REQUIRES HUMAN REVIEW
canonical_truth_promoted: false
source: root/goldbach_biblia(1).tex
line: 9238
line_end: 9280
env: theorem
visibility_class: RECOVERY_PRIORITY_HIGH
recovery_priority: HIGH
---

# Small Cubic-Core Exclusion

> **HISTORICAL RECOVERY CARD — NOT A TRUTH PROMOTION.** This card exists so agents do not mistake absence from the selected canonical theorem registry for absence from the project. The claim must be independently audited before being used as a new premise.

- Source: `07_HISTORICAL_CORPUS/raw/root/goldbach_biblia(1).tex:9238-9280`
- Historical environment: `theorem`
- Original label: `thm:iteration15-small-core-exclusion`
- Section: Iteracja 15: rachunek sześcienny i synchronizacja 33-adyczna > Dokładna klasyfikacja małych topologii
- Visibility classification: **RECOVERY_PRIORITY_HIGH**
- Recovery priority: **HIGH**

## Extracted historical synopsis

[Small Cubic-Core Exclusion] Trójczynnikowa terminalna zła SCC w rozważanym pasie spełnia |C| 5.

## Exact source transcript

```tex
\begin{theorem}[Small Cubic-Core Exclusion]
\label{thm:iteration15-small-core-exclusion}
Trójczynnikowa terminalna zła SCC w rozważanym pasie spełnia
\begin{equation}
 \boxed{|C|\ge5.}
 \label{eq:iteration15-r-at-least-five}
\end{equation}
\end{theorem}

\begin{proof}
Dla ustalonego \(r\le4\) przeglądamy wszystkie macierze z wpisami
nieujemnymi, zerową przekątną i sumami wierszy \(3\). Następnie
wymagamy silnej spójności, locku
\eqref{eq:iteration15-hensel-determinant} i wykonalności stożków
\eqref{eq:iteration15-half-cone} oraz
\eqref{eq:iteration15-band-collision-cone}.

Test stożka jest dokładny. Po przeskalowaniu ma postać
\(Md\ge\mathbf1\); wśród nierówności są \(d_i\ge1\), więc minimum
\(\sum d_i\) osiąga się w wierzchołku. Skrypt przegląda wszystkie
bazy i rozwiązuje je nad \(\mathbb Q\):
\begin{center}
\begin{tabular}{c|r|r|r|r}
\toprule
\(r\)&wszystkie&silnie spójne&po locku \(3\)-adycznym&po stożkach\\
\midrule
2&1&1&0&0\\
3&64&52&18&0\\
4&10000&7323&2769&1\\
\bottomrule
\end{tabular}
\end{center}
Rozmiar \(1\) wyklucza \eqref{eq:iteration15-zero-diagonal}. Dla
\(r=4\), \(C=\{a<b<c<d\}\), jedyny ocalały wzorzec ma
\[
 (N-a,N-b,N-c,N-d)=(c^3,a^2d,b^3,abc).
\]
Odejmując pierwszy i trzeci wiersz, otrzymujemy
\[
 c^3-b^3=c-a<c,
\]
choć \(c^3-b^3>c\). Nie pozostaje żadna macierz dla \(r\le4\).
\end{proof}
```
